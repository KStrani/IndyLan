<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-08-21 06:39:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:39:07 --> No URI present. Default controller set.
DEBUG - 2020-08-21 06:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 06:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 06:39:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 06:39:07 --> Total execution time: 0.1535
DEBUG - 2020-08-21 06:41:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 06:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 06:41:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 06:41:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 06:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 06:41:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 06:41:51 --> Total execution time: 0.1627
DEBUG - 2020-08-21 06:41:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:41:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-21 06:41:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-21 06:42:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:42:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-21 06:42:01 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-08-21 06:42:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:42:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-21 06:42:06 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-08-21 06:43:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 06:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 06:43:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 06:43:21 --> Total execution time: 0.1405
DEBUG - 2020-08-21 06:43:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 06:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 06:43:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 06:44:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 06:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 06:44:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 06:44:30 --> Total execution time: 0.1576
DEBUG - 2020-08-21 06:48:19 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 06:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 06:48:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 06:48:19 --> Total execution time: 0.1659
DEBUG - 2020-08-21 06:50:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 06:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 06:50:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 06:50:23 --> user_login->{"email":"test6@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
ERROR - 2020-08-21 06:50:23 --> {"status":0,"message":"Username or Password Wrong!!","message_en":"","result":[],"status_message":"OK"}
DEBUG - 2020-08-21 06:50:23 --> Total execution time: 0.1445
DEBUG - 2020-08-21 06:51:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 06:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 06:51:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 06:51:46 --> user_register->{"first_name":"Test","last_name":null,"email":"test@gmail.com","password":"123456","confirm_password":"123456","social_id":"","social_type":"0","user_image":"uploads\/user_profile\/1597992706.png"}
DEBUG - 2020-08-21 06:51:46 --> Total execution time: 0.1567
DEBUG - 2020-08-21 06:51:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 06:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 06:51:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 06:51:49 --> Total execution time: 0.1346
DEBUG - 2020-08-21 06:52:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 06:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 06:52:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 06:52:47 --> Total execution time: 0.0996
DEBUG - 2020-08-21 06:55:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:55:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 06:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 06:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 06:55:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 06:55:43 --> Total execution time: 0.1139
DEBUG - 2020-08-21 06:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 06:55:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 06:55:43 --> Total execution time: 0.1689
DEBUG - 2020-08-21 06:56:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 06:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 06:56:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 06:56:25 --> Total execution time: 0.1623
DEBUG - 2020-08-21 06:56:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 06:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 06:56:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 06:56:38 --> Total execution time: 0.1148
DEBUG - 2020-08-21 06:56:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 06:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 06:56:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 06:56:42 --> Total execution time: 0.1158
DEBUG - 2020-08-21 06:57:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 06:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 06:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 06:57:39 --> Total execution time: 0.1141
DEBUG - 2020-08-21 06:57:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 06:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 06:57:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 06:57:44 --> Total execution time: 0.1452
DEBUG - 2020-08-21 06:57:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 06:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 06:57:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 06:57:49 --> Total execution time: 0.1231
DEBUG - 2020-08-21 06:57:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 06:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 06:57:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 06:57:58 --> Total execution time: 0.1218
DEBUG - 2020-08-21 06:59:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 06:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 06:59:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 06:59:07 --> Total execution time: 0.1309
DEBUG - 2020-08-21 06:59:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 06:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 06:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 06:59:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 06:59:09 --> Total execution time: 0.1111
DEBUG - 2020-08-21 07:17:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 07:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 07:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 07:17:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 07:17:25 --> Total execution time: 0.1824
DEBUG - 2020-08-21 07:19:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 07:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 07:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 07:19:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 07:19:52 --> Total execution time: 0.1581
DEBUG - 2020-08-21 07:20:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 07:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 07:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 07:20:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 07:20:58 --> Total execution time: 0.1220
DEBUG - 2020-08-21 07:46:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 07:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 07:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 07:46:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 07:46:51 --> Total execution time: 0.1128
DEBUG - 2020-08-21 07:47:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 07:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 07:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 07:47:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 07:47:41 --> Total execution time: 0.1252
DEBUG - 2020-08-21 07:50:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 07:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 07:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 07:50:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 07:50:22 --> Total execution time: 0.1157
DEBUG - 2020-08-21 07:50:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 07:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 07:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 07:50:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 07:50:41 --> user_login->{"email":"test1@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
ERROR - 2020-08-21 07:50:41 --> {"status":0,"message":"Username or Password Wrong!!","message_en":"","result":[],"status_message":"OK"}
DEBUG - 2020-08-21 07:50:41 --> Total execution time: 0.1158
DEBUG - 2020-08-21 07:51:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 07:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 07:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 07:51:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 07:51:28 --> user_register->{"first_name":"test","last_name":null,"email":"test1@gmail.com","password":"123456","confirm_password":"123456","social_id":"","social_type":"0","user_image":"uploads\/user_profile\/1597996288.png"}
DEBUG - 2020-08-21 07:51:29 --> Total execution time: 0.1548
DEBUG - 2020-08-21 07:51:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 07:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 07:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 07:51:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 07:51:31 --> Total execution time: 0.1215
DEBUG - 2020-08-21 07:54:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 07:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 07:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 07:54:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 07:54:28 --> Total execution time: 0.1196
DEBUG - 2020-08-21 07:54:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 07:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 07:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 07:54:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 07:54:30 --> Total execution time: 0.1578
DEBUG - 2020-08-21 07:55:59 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 07:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 07:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 07:55:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 07:55:59 --> Total execution time: 0.1106
DEBUG - 2020-08-21 07:57:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 07:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 07:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 07:57:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 07:57:27 --> Total execution time: 0.1287
DEBUG - 2020-08-21 07:58:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 07:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 07:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 07:58:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 07:58:07 --> Total execution time: 0.1127
DEBUG - 2020-08-21 07:58:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 07:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 07:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 07:58:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 07:58:31 --> Total execution time: 0.1573
DEBUG - 2020-08-21 07:59:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 07:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 07:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 07:59:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 07:59:09 --> Total execution time: 0.1081
DEBUG - 2020-08-21 07:59:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 07:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 07:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 07:59:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 07:59:27 --> Total execution time: 0.1202
DEBUG - 2020-08-21 07:59:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 07:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 07:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 07:59:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 07:59:33 --> Total execution time: 0.1050
DEBUG - 2020-08-21 07:59:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 07:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 07:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 07:59:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 07:59:55 --> Total execution time: 0.1306
DEBUG - 2020-08-21 08:00:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:00:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:00:22 --> user_login->{"email":"test1@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2020-08-21 08:00:22 --> Total execution time: 0.1546
DEBUG - 2020-08-21 08:00:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:00:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:00:25 --> Total execution time: 0.1460
DEBUG - 2020-08-21 08:05:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:05:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:05:27 --> user_register->{"first_name":"test","last_name":null,"email":"test2@gmail.com","password":"123456","confirm_password":"123456","social_id":"","social_type":"0","user_image":"uploads\/user_profile\/1597997127.png"}
DEBUG - 2020-08-21 08:05:27 --> Total execution time: 0.1277
DEBUG - 2020-08-21 08:05:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:05:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:05:30 --> Total execution time: 0.1230
DEBUG - 2020-08-21 08:05:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:05:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:05:49 --> Total execution time: 0.1135
DEBUG - 2020-08-21 08:05:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:05:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:05:52 --> Total execution time: 0.1179
DEBUG - 2020-08-21 08:06:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:06:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:06:23 --> Total execution time: 0.1713
DEBUG - 2020-08-21 08:06:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:06:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:06:28 --> Total execution time: 0.1139
DEBUG - 2020-08-21 08:06:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:06:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:06:41 --> user_edit_profile->{"first_name":"test","last_name":null,"email":"test2@gmail.com","user_id":"766","is_remove_pic":"0","current_password":null,"new_password":null,"con_new_password":null,"social_type":null,"user_image":"uploads\/user_profile\/1597997201"}
DEBUG - 2020-08-21 08:06:41 --> Total execution time: 0.1462
DEBUG - 2020-08-21 08:08:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:08:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:08:29 --> Total execution time: 0.1344
DEBUG - 2020-08-21 08:08:56 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:08:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:08:56 --> Total execution time: 0.1379
DEBUG - 2020-08-21 08:09:13 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:09:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:09:13 --> user_edit_profile->{"first_name":"test","last_name":null,"email":"test2@gmail.com","user_id":"766","is_remove_pic":"0","current_password":null,"new_password":null,"con_new_password":null,"social_type":null,"user_image":"uploads\/user_profile\/1597997353"}
DEBUG - 2020-08-21 08:09:13 --> Total execution time: 0.1174
DEBUG - 2020-08-21 08:11:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:11:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:11:18 --> user_login->{"email":"test3@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
ERROR - 2020-08-21 08:11:18 --> {"status":0,"message":"Username or Password Wrong!!","message_en":"","result":[],"status_message":"OK"}
DEBUG - 2020-08-21 08:11:18 --> Total execution time: 0.1173
DEBUG - 2020-08-21 08:11:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:11:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:11:27 --> user_login->{"email":"test2@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2020-08-21 08:11:27 --> Total execution time: 0.1453
DEBUG - 2020-08-21 08:11:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:11:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:11:30 --> Total execution time: 0.1257
DEBUG - 2020-08-21 08:11:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:11:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:11:39 --> Total execution time: 0.1140
DEBUG - 2020-08-21 08:11:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:11:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:11:53 --> user_login->{"email":"test1@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2020-08-21 08:11:53 --> Total execution time: 0.1249
DEBUG - 2020-08-21 08:11:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:11:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:11:55 --> Total execution time: 0.1600
DEBUG - 2020-08-21 08:11:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:11:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:11:58 --> Total execution time: 0.1112
DEBUG - 2020-08-21 08:12:19 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:12:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:12:20 --> user_edit_profile->{"first_name":"test","last_name":null,"email":"test1@gmail.com","user_id":"765","is_remove_pic":"0","current_password":null,"new_password":null,"con_new_password":null,"social_type":null,"user_image":"uploads\/user_profile\/1597997540"}
DEBUG - 2020-08-21 08:12:20 --> Total execution time: 0.1516
DEBUG - 2020-08-21 08:12:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:12:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:12:34 --> user_login->{"email":"test1@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2020-08-21 08:12:34 --> Total execution time: 0.0985
DEBUG - 2020-08-21 08:12:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:12:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:12:37 --> Total execution time: 0.1426
DEBUG - 2020-08-21 08:16:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:16:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:16:15 --> Total execution time: 0.1692
DEBUG - 2020-08-21 08:16:50 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:16:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:16:50 --> Total execution time: 0.1521
DEBUG - 2020-08-21 08:16:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:16:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:16:55 --> Total execution time: 0.1315
DEBUG - 2020-08-21 08:17:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:17:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:17:01 --> user_edit_profile->{"first_name":"test","last_name":null,"email":"test1@gmail.com","user_id":"765","is_remove_pic":"1","current_password":null,"new_password":null,"con_new_password":null,"social_type":null,"user_image":""}
DEBUG - 2020-08-21 08:17:01 --> Total execution time: 0.1014
DEBUG - 2020-08-21 08:18:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:18:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:18:11 --> Total execution time: 0.1296
DEBUG - 2020-08-21 08:18:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:18:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:18:28 --> Total execution time: 0.1395
DEBUG - 2020-08-21 08:18:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:18:31 --> No URI present. Default controller set.
DEBUG - 2020-08-21 08:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:18:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:18:31 --> Total execution time: 0.1487
DEBUG - 2020-08-21 08:18:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:18:52 --> user_edit_profile->{"first_name":"test","last_name":null,"email":"test1@gmail.com","user_id":"765","is_remove_pic":"0","current_password":null,"new_password":null,"con_new_password":null,"social_type":null,"user_image":"uploads\/user_profile\/1597997932"}
DEBUG - 2020-08-21 08:18:52 --> Total execution time: 0.1224
DEBUG - 2020-08-21 08:19:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:19:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:19:09 --> No URI present. Default controller set.
DEBUG - 2020-08-21 08:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:19:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:19:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:19:09 --> Total execution time: 0.1499
DEBUG - 2020-08-21 08:19:09 --> Total execution time: 0.1363
DEBUG - 2020-08-21 08:19:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:19:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:19:44 --> Total execution time: 0.1481
DEBUG - 2020-08-21 08:19:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:19:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:19:53 --> Total execution time: 0.1351
DEBUG - 2020-08-21 08:23:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:23:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:23:29 --> Total execution time: 0.1083
DEBUG - 2020-08-21 08:49:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:49:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:49:58 --> Total execution time: 0.1299
DEBUG - 2020-08-21 08:50:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:50:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:50:08 --> Total execution time: 0.1309
DEBUG - 2020-08-21 08:50:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:50:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:50:25 --> user_edit_profile->{"first_name":"test","last_name":null,"email":"test1@gmail.com","user_id":"765","is_remove_pic":"0","current_password":null,"new_password":null,"con_new_password":null,"social_type":null,"user_image":"uploads\/user_profile\/1597999825"}
DEBUG - 2020-08-21 08:50:25 --> Total execution time: 0.1230
DEBUG - 2020-08-21 08:51:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:51:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:51:06 --> Total execution time: 0.1077
DEBUG - 2020-08-21 08:51:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:51:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:51:18 --> user_edit_profile->{"first_name":"test","last_name":null,"email":"test1@gmail.com","user_id":"765","is_remove_pic":"0","current_password":null,"new_password":null,"con_new_password":null,"social_type":null,"user_image":"uploads\/user_profile\/1597999878"}
DEBUG - 2020-08-21 08:51:18 --> Total execution time: 0.1180
DEBUG - 2020-08-21 08:52:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:52:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:52:41 --> Total execution time: 0.1168
DEBUG - 2020-08-21 08:52:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:52:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:52:45 --> Total execution time: 0.1432
DEBUG - 2020-08-21 08:53:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:53:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:53:06 --> user_edit_profile->{"first_name":"test","last_name":null,"email":"test1@gmail.com","user_id":"765","is_remove_pic":"0","current_password":null,"new_password":null,"con_new_password":null,"social_type":null,"user_image":"uploads\/user_profile\/1597999986"}
DEBUG - 2020-08-21 08:53:06 --> Total execution time: 0.1581
DEBUG - 2020-08-21 08:56:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:56:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:56:09 --> Total execution time: 0.1534
DEBUG - 2020-08-21 08:56:14 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:56:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:56:14 --> Total execution time: 0.1111
DEBUG - 2020-08-21 08:56:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:56:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:56:37 --> user_edit_profile->{"first_name":"test","last_name":null,"email":"test1@gmail.com","user_id":"765","is_remove_pic":"0","current_password":null,"new_password":null,"con_new_password":null,"social_type":null,"user_image":"uploads\/user_profile\/1598000197"}
DEBUG - 2020-08-21 08:56:37 --> Total execution time: 0.1114
DEBUG - 2020-08-21 08:56:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 08:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 08:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 08:56:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 08:56:47 --> Total execution time: 0.1412
DEBUG - 2020-08-21 09:00:50 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:00:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:00:50 --> Total execution time: 0.1153
DEBUG - 2020-08-21 09:00:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:00:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:00:54 --> Total execution time: 0.1083
DEBUG - 2020-08-21 09:01:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:01:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:01:15 --> user_edit_profile->{"first_name":"test","last_name":null,"email":"test1@gmail.com","user_id":"765","is_remove_pic":"0","current_password":null,"new_password":null,"con_new_password":null,"social_type":null,"user_image":"uploads\/user_profile\/1598000475"}
DEBUG - 2020-08-21 09:01:15 --> Total execution time: 0.1404
DEBUG - 2020-08-21 09:01:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:01:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:01:37 --> Total execution time: 0.1078
DEBUG - 2020-08-21 09:07:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:07:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:07:47 --> Total execution time: 0.1190
DEBUG - 2020-08-21 09:07:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:07:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:07:49 --> Total execution time: 0.1352
DEBUG - 2020-08-21 09:08:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:08:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:08:32 --> Total execution time: 0.1186
DEBUG - 2020-08-21 09:11:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:11:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:11:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:11:44 --> Total execution time: 0.1392
DEBUG - 2020-08-21 09:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:11:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:11:44 --> Total execution time: 0.0969
DEBUG - 2020-08-21 09:11:56 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:11:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:11:56 --> Total execution time: 0.1424
DEBUG - 2020-08-21 09:11:56 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:11:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:11:56 --> Total execution time: 0.1079
DEBUG - 2020-08-21 09:12:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:12:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:12:07 --> Total execution time: 0.1354
DEBUG - 2020-08-21 09:12:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:12:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:12:16 --> get_category_list->{"lang":"12","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-08-21 09:12:16 --> Total execution time: 0.1332
DEBUG - 2020-08-21 09:12:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:12:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:12:21 --> get_subcategory_list->{"lang":"12","category_id":"50","user_id":"746","support_lang_id":"3"}
DEBUG - 2020-08-21 09:12:21 --> Total execution time: 0.1456
DEBUG - 2020-08-21 09:12:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:12:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:12:27 --> get_exercise_type_list->{"lang":"12","subcategory_id":"58","support_lang_id":"3"}
DEBUG - 2020-08-21 09:12:27 --> Total execution time: 0.1124
DEBUG - 2020-08-21 09:12:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:12:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-21 09:12:29 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-08-21 09:12:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:12:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-21 09:12:33 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-08-21 09:12:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:12:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:12:35 --> get_sorce_lan_word_type_8->{"slang":"12","tlang":"3","exercise_mode_id":"1","category_id":"50","subcategory_id":"58","support_lang_id":"3"}
DEBUG - 2020-08-21 09:12:35 --> Total execution time: 0.1526
DEBUG - 2020-08-21 09:12:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:12:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:12:49 --> Total execution time: 0.1418
DEBUG - 2020-08-21 09:12:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:12:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:12:54 --> get_exercise_type_list->{"lang":"12","subcategory_id":"58","support_lang_id":"3"}
DEBUG - 2020-08-21 09:12:54 --> Total execution time: 0.1473
DEBUG - 2020-08-21 09:12:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:12:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:12:58 --> Total execution time: 0.1127
DEBUG - 2020-08-21 09:14:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:14:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:14:34 --> get_exercise_type_list->{"lang":"12","subcategory_id":"58","support_lang_id":"3"}
DEBUG - 2020-08-21 09:14:34 --> Total execution time: 0.1645
DEBUG - 2020-08-21 09:14:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:14:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:14:34 --> get_subcategory_list->{"lang":"12","category_id":"50","user_id":"746","support_lang_id":"3"}
DEBUG - 2020-08-21 09:14:34 --> Total execution time: 0.1679
DEBUG - 2020-08-21 09:14:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:14:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:14:36 --> get_category_list->{"lang":"12","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-08-21 09:14:36 --> Total execution time: 0.1341
DEBUG - 2020-08-21 09:14:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:14:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:14:37 --> Total execution time: 0.1425
DEBUG - 2020-08-21 09:14:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:14:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:14:39 --> Total execution time: 0.1362
DEBUG - 2020-08-21 09:14:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 09:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 09:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 09:14:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 09:14:42 --> Total execution time: 0.1276
DEBUG - 2020-08-21 10:05:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:05:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:05:49 --> Total execution time: 0.1136
DEBUG - 2020-08-21 10:05:56 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:05:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:05:57 --> Total execution time: 0.1700
DEBUG - 2020-08-21 10:06:14 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:06:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:06:15 --> user_edit_profile->{"first_name":"test","last_name":null,"email":"test1@gmail.com","user_id":"765","is_remove_pic":"0","current_password":null,"new_password":null,"con_new_password":null,"social_type":null,"user_image":"uploads\/user_profile\/1598004375"}
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:06:15 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
DEBUG - 2020-08-21 10:06:15 --> Total execution time: 0.1408
DEBUG - 2020-08-21 10:06:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:06:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-21 10:06:34 --> 404 Page Not Found: 0%22/index
DEBUG - 2020-08-21 10:10:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:10:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:10:52 --> user_edit_profile->{"first_name":"test","last_name":null,"email":"test1@gmail.com","user_id":"765","is_remove_pic":"0","current_password":null,"new_password":null,"con_new_password":null,"social_type":null,"user_image":"uploads\/user_profile\/1598004652"}
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:10:52 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
DEBUG - 2020-08-21 10:10:52 --> Total execution time: 0.1367
DEBUG - 2020-08-21 10:12:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:12:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:12:08 --> user_edit_profile->{"first_name":"test","last_name":null,"email":"test1@gmail.com","user_id":"765","is_remove_pic":"0","current_password":null,"new_password":null,"con_new_password":null,"social_type":null,"user_image":"uploads\/user_profile\/1598004728.png"}
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:12:08 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
DEBUG - 2020-08-21 10:12:08 --> Total execution time: 0.1456
DEBUG - 2020-08-21 10:13:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:13:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:13:01 --> Total execution time: 0.1118
DEBUG - 2020-08-21 10:13:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:13:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:13:39 --> Total execution time: 0.0919
DEBUG - 2020-08-21 10:13:56 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:13:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:13:56 --> user_edit_profile->{"first_name":"test","last_name":null,"email":"test1@gmail.com","user_id":"765","is_remove_pic":"0","current_password":null,"new_password":null,"con_new_password":null,"social_type":null,"user_image":"uploads\/user_profile\/1598004836.png"}
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:13:56 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
DEBUG - 2020-08-21 10:13:56 --> Total execution time: 0.1555
DEBUG - 2020-08-21 10:15:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:15:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:15:12 --> Total execution time: 0.1403
DEBUG - 2020-08-21 10:17:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:17:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:17:06 --> user_edit_profile->{"first_name":"test","last_name":null,"email":"test1@gmail.com","user_id":"765","is_remove_pic":"0","current_password":null,"new_password":null,"con_new_password":null,"social_type":null,"user_image":"uploads\/user_profile\/1598005026.png"}
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:06 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
DEBUG - 2020-08-21 10:17:06 --> Total execution time: 0.1425
DEBUG - 2020-08-21 10:17:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:17:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:17:44 --> user_edit_profile->{"first_name":"test","last_name":null,"email":"test1@gmail.com","user_id":"765","is_remove_pic":"0","current_password":null,"new_password":null,"con_new_password":null,"social_type":null,"user_image":"uploads\/user_profile\/1598005064.png"}
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:17:44 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
DEBUG - 2020-08-21 10:17:44 --> Total execution time: 0.1614
DEBUG - 2020-08-21 10:20:26 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:20:26 --> user_edit_profile->{"first_name":"","last_name":"","email":"","user_id":"","is_remove_pic":null,"current_password":null,"new_password":null,"con_new_password":null,"social_type":null,"user_image":""}
ERROR - 2020-08-21 10:20:26 --> {"status":0,"message":"Parameters not passed","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-21 10:20:26 --> Total execution time: 0.1382
DEBUG - 2020-08-21 10:21:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:21:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:21:09 --> user_edit_profile->{"first_name":"test","last_name":"tester","email":null,"user_id":"765","is_remove_pic":null,"current_password":null,"new_password":null,"con_new_password":null,"social_type":null,"user_image":""}
ERROR - 2020-08-21 10:21:09 --> {"status":0,"message":"Email Already Exist","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-21 10:21:09 --> Total execution time: 0.1662
DEBUG - 2020-08-21 10:22:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:22:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:22:40 --> user_edit_profile->{"first_name":"test","last_name":"tester","email":"test1@gmail.com","user_id":"765","is_remove_pic":null,"current_password":null,"new_password":null,"con_new_password":null,"social_type":null,"user_image":""}
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:22:40 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
DEBUG - 2020-08-21 10:22:40 --> Total execution time: 0.1616
DEBUG - 2020-08-21 10:24:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:24:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:24:11 --> user_edit_profile->{"first_name":"test","last_name":"tester","email":"test1@gmail.com","user_id":"765","is_remove_pic":null,"current_password":null,"new_password":null,"con_new_password":null,"social_type":null,"user_image":""}
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1959
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'user_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1963
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1966
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'first_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1970
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1973
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'last_name' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1977
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1980
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'email' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1984
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1987
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'password' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1991
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1994
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1998
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2001
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'profile_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2005
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2008
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_pic' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2012
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2015
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2019
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2022
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'social_type' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2026
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2029
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'is_active' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2033
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2036
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'reset_token' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2040
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2043
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'support_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2047
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2050
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'menu_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2054
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2057
ERROR - 2020-08-21 10:24:11 --> Severity: Warning --> Illegal string offset 'target_lang_id' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 2061
DEBUG - 2020-08-21 10:25:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:25:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:25:29 --> user_edit_profile->{"first_name":"test","last_name":"tester","email":"test1@gmail.com","user_id":"765","is_remove_pic":null,"current_password":null,"new_password":null,"con_new_password":null,"social_type":null,"user_image":""}
DEBUG - 2020-08-21 10:25:29 --> Total execution time: 0.1768
DEBUG - 2020-08-21 10:26:17 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:26:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:26:17 --> user_edit_profile->{"first_name":"test","last_name":null,"email":"test1@gmail.com","user_id":"765","is_remove_pic":"0","current_password":null,"new_password":null,"con_new_password":null,"social_type":null,"user_image":"uploads\/user_profile\/1598005577.png"}
DEBUG - 2020-08-21 10:26:17 --> Total execution time: 0.1009
DEBUG - 2020-08-21 10:27:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:27:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:27:36 --> Total execution time: 0.1509
DEBUG - 2020-08-21 10:27:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:27:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:27:43 --> Total execution time: 0.1284
DEBUG - 2020-08-21 10:28:03 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:28:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:28:04 --> Total execution time: 0.1222
DEBUG - 2020-08-21 10:28:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:28:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:28:09 --> Total execution time: 0.1054
DEBUG - 2020-08-21 10:28:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:28:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:28:26 --> user_edit_profile->{"first_name":"test","last_name":null,"email":"test1@gmail.com","user_id":"765","is_remove_pic":"0","current_password":null,"new_password":null,"con_new_password":null,"social_type":null,"user_image":"uploads\/user_profile\/1598005706.png"}
DEBUG - 2020-08-21 10:28:26 --> Total execution time: 0.1328
DEBUG - 2020-08-21 10:28:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:28:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:28:35 --> Total execution time: 0.1450
DEBUG - 2020-08-21 10:28:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:28:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:28:52 --> Total execution time: 0.1003
DEBUG - 2020-08-21 10:29:26 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:29:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:29:26 --> user_login->{"email":"test1@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2020-08-21 10:29:26 --> Total execution time: 0.1489
DEBUG - 2020-08-21 10:29:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:29:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:29:28 --> Total execution time: 0.1032
DEBUG - 2020-08-21 10:29:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 10:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 10:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 10:29:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 10:29:38 --> Total execution time: 0.1618
DEBUG - 2020-08-21 13:07:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 13:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 13:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 13:07:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 13:07:41 --> user_login->{"email":"rastech47@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2020-08-21 13:07:41 --> Total execution time: 0.1556
DEBUG - 2020-08-21 13:07:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 13:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 13:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 13:07:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 13:07:44 --> Total execution time: 0.1383
DEBUG - 2020-08-21 13:07:59 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 13:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 13:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 13:07:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 13:07:59 --> Total execution time: 0.1430
DEBUG - 2020-08-21 13:08:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 13:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 13:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 13:08:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 13:08:11 --> Total execution time: 0.1012
DEBUG - 2020-08-21 13:08:13 --> UTF-8 Support Enabled
DEBUG - 2020-08-21 13:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-21 13:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-21 13:08:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 13:08:14 --> Total execution time: 0.1364
