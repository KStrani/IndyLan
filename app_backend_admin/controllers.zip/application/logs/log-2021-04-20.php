<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-04-20 09:19:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-20 09:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-20 09:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-20 09:19:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-20 09:19:38 --> Total execution time: 0.1759
