<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-08-22 06:53:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 06:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 06:53:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 06:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 06:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 06:53:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 06:53:18 --> Total execution time: 0.1716
DEBUG - 2020-08-22 06:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 06:53:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 06:53:18 --> Total execution time: 0.1393
DEBUG - 2020-08-22 09:01:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 09:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 09:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 09:01:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 09:01:21 --> Total execution time: 0.1250
DEBUG - 2020-08-22 09:01:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 09:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 09:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 09:01:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 09:01:32 --> Total execution time: 0.1006
DEBUG - 2020-08-22 09:02:03 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 09:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 09:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 09:02:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 09:02:03 --> Total execution time: 0.1059
DEBUG - 2020-08-22 09:02:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 09:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 09:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 09:02:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 09:02:12 --> Total execution time: 0.1160
DEBUG - 2020-08-22 09:36:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 09:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 09:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 09:36:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 09:36:12 --> Total execution time: 0.1428
DEBUG - 2020-08-22 09:36:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 09:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 09:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 09:36:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 09:36:33 --> Total execution time: 0.1455
DEBUG - 2020-08-22 09:54:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 09:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 09:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 09:54:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 09:54:04 --> Total execution time: 0.0992
DEBUG - 2020-08-22 09:56:14 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 09:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 09:56:14 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 09:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 09:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 09:56:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 09:56:15 --> Total execution time: 0.1520
DEBUG - 2020-08-22 09:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 09:56:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 09:56:15 --> Total execution time: 0.1360
DEBUG - 2020-08-22 09:56:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 09:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 09:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 09:56:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 09:56:36 --> Total execution time: 0.1268
DEBUG - 2020-08-22 09:56:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 09:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 09:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 09:56:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 09:56:58 --> Total execution time: 0.1211
DEBUG - 2020-08-22 09:57:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 09:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 09:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 09:57:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 09:57:04 --> Total execution time: 0.1414
DEBUG - 2020-08-22 10:00:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:00:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:00:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:00:21 --> Total execution time: 0.1566
DEBUG - 2020-08-22 10:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:00:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:00:21 --> Total execution time: 0.1167
DEBUG - 2020-08-22 10:00:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:00:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:00:25 --> Total execution time: 0.1698
DEBUG - 2020-08-22 10:00:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:00:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:00:28 --> Total execution time: 0.1569
DEBUG - 2020-08-22 10:01:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:01:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:01:05 --> Total execution time: 0.1002
DEBUG - 2020-08-22 10:01:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:01:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:01:05 --> Total execution time: 0.1114
DEBUG - 2020-08-22 10:01:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:01:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:01:39 --> Total execution time: 0.1241
DEBUG - 2020-08-22 10:18:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:18:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:18:07 --> Total execution time: 0.1192
DEBUG - 2020-08-22 10:18:14 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:18:14 --> Total execution time: 0.1384
DEBUG - 2020-08-22 10:18:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:18:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:18:15 --> Total execution time: 0.1828
DEBUG - 2020-08-22 10:27:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:27:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:27:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:27:58 --> Total execution time: 0.1638
DEBUG - 2020-08-22 10:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:27:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:27:58 --> Total execution time: 0.1162
DEBUG - 2020-08-22 10:34:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:34:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:34:57 --> Total execution time: 0.1497
DEBUG - 2020-08-22 10:35:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:35:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:35:10 --> Total execution time: 0.1068
DEBUG - 2020-08-22 10:36:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:36:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:36:33 --> Total execution time: 0.1431
DEBUG - 2020-08-22 10:36:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:36:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:36:43 --> Total execution time: 0.1171
DEBUG - 2020-08-22 10:40:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:40:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:40:51 --> Total execution time: 0.1221
DEBUG - 2020-08-22 10:41:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:41:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:41:23 --> Total execution time: 0.1222
DEBUG - 2020-08-22 10:44:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:44:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:44:39 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
ERROR - 2020-08-22 10:44:39 --> Query error: Unknown column 'category_name_in_sct' in 'field list' - Invalid query: select exercise_mode_category_id,image,category_name_in_sct as category_name from tbl_exercise_mode_categories where support_lang_id='1' AND exercise_mode_id='1' AND is_active='1' AND is_delete='0' order by category_name_in_sct asc
ERROR - 2020-08-22 10:44:39 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 125
DEBUG - 2020-08-22 10:44:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:44:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:44:45 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"1"}
ERROR - 2020-08-22 10:44:45 --> Query error: Unknown column 'category_name_in_sct' in 'field list' - Invalid query: select exercise_mode_category_id,image,category_name_in_sct as category_name from tbl_exercise_mode_categories where support_lang_id='1' AND exercise_mode_id='2' AND is_active='1' AND is_delete='0' order by category_name_in_sct asc
ERROR - 2020-08-22 10:44:45 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 125
DEBUG - 2020-08-22 10:44:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:44:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:44:49 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"1"}
ERROR - 2020-08-22 10:44:49 --> Query error: Unknown column 'category_name_in_sct' in 'field list' - Invalid query: select exercise_mode_category_id,image,category_name_in_sct as category_name from tbl_exercise_mode_categories where support_lang_id='1' AND exercise_mode_id='3' AND is_active='1' AND is_delete='0' order by category_name_in_sct asc
ERROR - 2020-08-22 10:44:49 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 125
DEBUG - 2020-08-22 10:44:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:44:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:44:53 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"1"}
ERROR - 2020-08-22 10:44:53 --> Query error: Unknown column 'category_name_in_sct' in 'field list' - Invalid query: select exercise_mode_category_id,image,category_name_in_sct as category_name from tbl_exercise_mode_categories where support_lang_id='1' AND exercise_mode_id='5' AND is_active='1' AND is_delete='0' order by category_name_in_sct asc
ERROR - 2020-08-22 10:44:53 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 125
DEBUG - 2020-08-22 10:45:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:45:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:45:01 --> Total execution time: 0.1179
DEBUG - 2020-08-22 10:45:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:45:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:45:08 --> get_category_list->{"lang":"12","exercise_mode_id":"1","support_lang_id":"1"}
ERROR - 2020-08-22 10:45:08 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-22 10:45:08 --> Total execution time: 0.1617
DEBUG - 2020-08-22 10:56:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:56:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:56:30 --> Total execution time: 0.1541
DEBUG - 2020-08-22 10:57:13 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:57:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:57:13 --> Total execution time: 0.1102
DEBUG - 2020-08-22 10:59:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:59:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:59:05 --> Total execution time: 0.1237
DEBUG - 2020-08-22 10:59:26 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:59:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:59:26 --> Total execution time: 0.1326
DEBUG - 2020-08-22 10:59:26 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 10:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 10:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 10:59:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 10:59:26 --> Total execution time: 0.1161
DEBUG - 2020-08-22 11:01:50 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 11:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 11:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 11:01:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 11:01:50 --> Total execution time: 0.1296
DEBUG - 2020-08-22 11:01:50 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 11:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 11:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 11:01:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 11:01:51 --> Total execution time: 0.1203
DEBUG - 2020-08-22 12:15:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 12:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 12:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 12:15:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 12:15:09 --> Total execution time: 0.1306
DEBUG - 2020-08-22 12:16:00 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 12:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 12:16:00 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 12:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 12:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 12:16:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 12:16:00 --> Total execution time: 0.1260
DEBUG - 2020-08-22 12:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 12:16:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 12:16:00 --> Total execution time: 0.1032
DEBUG - 2020-08-22 12:16:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 12:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 12:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 12:16:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 12:16:10 --> Total execution time: 0.1380
DEBUG - 2020-08-22 12:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 12:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 12:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 12:22:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 12:22:20 --> Total execution time: 0.1143
DEBUG - 2020-08-22 12:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 12:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 12:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 12:22:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 12:22:21 --> Total execution time: 0.1335
DEBUG - 2020-08-22 12:23:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 12:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 12:23:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 12:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 12:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 12:23:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 12:23:39 --> Total execution time: 0.1668
DEBUG - 2020-08-22 12:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 12:23:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 12:23:39 --> Total execution time: 0.1287
DEBUG - 2020-08-22 12:30:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 12:30:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 12:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 12:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 12:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 12:30:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 12:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 12:30:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 12:30:53 --> Total execution time: 0.1324
DEBUG - 2020-08-22 12:30:53 --> Total execution time: 0.1437
DEBUG - 2020-08-22 12:32:56 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 12:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 12:32:56 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 12:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 12:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 12:32:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 12:32:56 --> Total execution time: 0.1714
DEBUG - 2020-08-22 12:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 12:32:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 12:32:56 --> Total execution time: 0.1018
DEBUG - 2020-08-22 13:37:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 13:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 13:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 13:37:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 13:37:06 --> Total execution time: 0.1419
DEBUG - 2020-08-22 13:37:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 13:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 13:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 13:37:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 13:37:06 --> Total execution time: 0.1097
DEBUG - 2020-08-22 13:49:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 13:49:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 13:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 13:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 13:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 13:49:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 13:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 13:49:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 13:49:08 --> Total execution time: 0.1130
DEBUG - 2020-08-22 13:49:08 --> Total execution time: 0.1349
DEBUG - 2020-08-22 13:50:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 13:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 13:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 13:50:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 13:50:38 --> Total execution time: 0.1512
DEBUG - 2020-08-22 13:50:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-22 13:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-22 13:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-22 13:50:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-22 13:50:46 --> Total execution time: 0.1449
