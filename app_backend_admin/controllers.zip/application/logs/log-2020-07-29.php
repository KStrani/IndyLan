<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-07-29 04:45:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-29 04:45:39 --> No URI present. Default controller set.
DEBUG - 2020-07-29 04:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-29 04:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-29 04:45:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 04:45:40 --> Total execution time: 1.2802
