<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-03-30 11:23:29 --> UTF-8 Support Enabled
DEBUG - 2021-03-30 11:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-30 11:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-03-30 11:23:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-03-30 11:23:32 --> UTF-8 Support Enabled
DEBUG - 2021-03-30 11:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-30 11:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-03-30 11:23:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-03-30 11:23:32 --> Total execution time: 0.1600
