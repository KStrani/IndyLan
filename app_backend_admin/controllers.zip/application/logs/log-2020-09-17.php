<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-09-17 05:05:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 05:05:09 --> No URI present. Default controller set.
DEBUG - 2020-09-17 05:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 05:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 05:05:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 05:05:10 --> Total execution time: 0.1283
DEBUG - 2020-09-17 05:12:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 05:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 05:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 05:12:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 05:12:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 05:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 05:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 05:12:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 05:12:50 --> Total execution time: 0.1670
DEBUG - 2020-09-17 05:12:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 05:12:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 05:12:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 05:12:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 05:12:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 05:12:55 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-17 05:12:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 05:12:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 05:12:56 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-09-17 05:58:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 05:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 05:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 05:58:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 05:58:38 --> Total execution time: 0.1550
DEBUG - 2020-09-17 05:58:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 05:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 05:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 05:58:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 05:58:41 --> Total execution time: 0.1796
DEBUG - 2020-09-17 05:58:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 05:58:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 05:58:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 06:02:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 06:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 06:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 06:02:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 06:02:28 --> Total execution time: 0.1325
DEBUG - 2020-09-17 06:02:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 06:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 06:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 06:02:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 06:02:30 --> Total execution time: 0.1629
DEBUG - 2020-09-17 06:02:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 06:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 06:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 06:02:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 06:02:35 --> Total execution time: 0.1833
DEBUG - 2020-09-17 06:02:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 06:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 06:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 06:02:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 06:02:48 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 06:02:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 06:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 06:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 06:02:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 06:02:51 --> Total execution time: 0.1512
DEBUG - 2020-09-17 06:02:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 06:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 06:02:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 06:03:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 06:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 06:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 06:03:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 06:03:07 --> Total execution time: 0.1289
DEBUG - 2020-09-17 06:03:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 06:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 06:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 06:03:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 06:03:12 --> Total execution time: 0.1472
DEBUG - 2020-09-17 06:03:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 06:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 06:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 06:03:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 06:03:16 --> Total execution time: 0.1895
DEBUG - 2020-09-17 06:03:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 06:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 06:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 06:03:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 06:03:30 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 06:03:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 06:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 06:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 06:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 06:03:33 --> Total execution time: 0.1364
DEBUG - 2020-09-17 06:03:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 06:03:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 06:03:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 06:04:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 06:04:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 06:04:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 06:04:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 06:04:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 06:04:53 --> 404 Page Not Found: Assets/js
DEBUG - 2020-09-17 07:06:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:06:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 07:06:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:06:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 07:06:43 --> Total execution time: 0.1211
DEBUG - 2020-09-17 07:06:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:06:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 07:06:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:06:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 07:06:51 --> Total execution time: 0.1545
DEBUG - 2020-09-17 07:06:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:06:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:06:54 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 07:06:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:06:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:06:54 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-17 07:06:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:06:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:06:55 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-09-17 07:07:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:07:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 07:07:01 --> Total execution time: 0.1418
DEBUG - 2020-09-17 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:07:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 07:07:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-17 07:07:03 --> Total execution time: 0.1603
DEBUG - 2020-09-17 07:07:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:07:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:07:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 07:07:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:07:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:07:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:07:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:07:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:07:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:07:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:07:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:07:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:07:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:07:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:07:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:07:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:07:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 07:07:13 --> Total execution time: 0.1360
DEBUG - 2020-09-17 07:07:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:07:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 07:07:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 07:07:16 --> Total execution time: 0.2376
DEBUG - 2020-09-17 07:07:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:07:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:07:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 07:08:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:08:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 07:08:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:08:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 07:08:32 --> Total execution time: 0.1470
DEBUG - 2020-09-17 07:08:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:08:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:08:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 07:09:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:09:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 07:09:32 --> Total execution time: 0.1477
DEBUG - 2020-09-17 07:09:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:09:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 07:09:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-17 07:09:35 --> Total execution time: 0.2180
DEBUG - 2020-09-17 07:09:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:09:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:09:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:09:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:09:38 --> UTF-8 Support Enabled
ERROR - 2020-09-17 07:09:38 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:09:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:09:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 07:09:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:09:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:09:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:09:38 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:09:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:09:38 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:09:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:09:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:09:38 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:09:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:09:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:09:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:09:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:09:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:09:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:09:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:09:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:09:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:09:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:09:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:09:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:11:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:11:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 07:11:31 --> Total execution time: 0.1737
DEBUG - 2020-09-17 07:11:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:11:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 07:11:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-17 07:11:34 --> Total execution time: 0.1663
DEBUG - 2020-09-17 07:11:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:11:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:11:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 07:11:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:11:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:11:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:11:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:11:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:11:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:11:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:11:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:11:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:11:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:11:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 07:11:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-17 07:11:43 --> Total execution time: 0.1479
DEBUG - 2020-09-17 07:11:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:11:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 07:11:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-17 07:11:45 --> Total execution time: 0.1377
DEBUG - 2020-09-17 07:11:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:11:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:11:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:11:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:11:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:11:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 07:11:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:11:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:11:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:11:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:11:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:11:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:11:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:11:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 07:11:56 --> Total execution time: 0.1613
DEBUG - 2020-09-17 07:12:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:12:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 07:12:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-17 07:12:00 --> Total execution time: 0.1427
DEBUG - 2020-09-17 07:12:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:12:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:12:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:12:03 --> UTF-8 Support Enabled
ERROR - 2020-09-17 07:12:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:12:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:12:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 07:12:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:12:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:12:03 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-17 07:12:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:12:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:12:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:12:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:12:05 --> UTF-8 Support Enabled
ERROR - 2020-09-17 07:12:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:12:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:12:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:12:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:12:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:12:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:12:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:12:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:12:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:12:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:12:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:12:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:12:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:12:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:12:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:12:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:12:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:12:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:12:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:12:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:12:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:12:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:12:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 07:12:36 --> Total execution time: 0.1550
DEBUG - 2020-09-17 07:12:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:12:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 07:12:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-17 07:12:39 --> Total execution time: 0.1306
DEBUG - 2020-09-17 07:12:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:12:41 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 07:12:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:12:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:12:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:12:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:12:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:12:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 07:12:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-17 07:12:50 --> Total execution time: 0.1227
DEBUG - 2020-09-17 07:12:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:12:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 07:12:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-17 07:12:52 --> Total execution time: 0.2086
DEBUG - 2020-09-17 07:12:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:12:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 07:12:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:12:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:12:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:12:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:12:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:13:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:13:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 07:13:47 --> Total execution time: 0.1402
DEBUG - 2020-09-17 07:13:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:13:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 07:13:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 07:13:50 --> Total execution time: 0.1251
DEBUG - 2020-09-17 07:13:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:13:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:13:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 07:14:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:14:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 07:14:05 --> Total execution time: 0.1483
DEBUG - 2020-09-17 07:14:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:14:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 07:14:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-17 07:14:08 --> Total execution time: 0.1840
DEBUG - 2020-09-17 07:14:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:14:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:14:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 07:14:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:14:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:14:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:14:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:14:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:14:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:14:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:14:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:14:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:14:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:14:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:14:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:14:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:14:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 07:14:52 --> Total execution time: 0.1490
DEBUG - 2020-09-17 07:14:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:14:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 07:14:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 07:14:56 --> Total execution time: 0.1765
DEBUG - 2020-09-17 07:14:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:14:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:14:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 07:56:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:56:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 07:56:29 --> Total execution time: 0.1277
DEBUG - 2020-09-17 07:56:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 07:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 07:56:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 07:56:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-17 07:56:32 --> Total execution time: 0.1600
DEBUG - 2020-09-17 07:56:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:56:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:56:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 07:56:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:56:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:56:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:56:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:56:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:56:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:56:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:56:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 07:56:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:56:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 07:56:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 07:56:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 08:09:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 08:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 08:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 08:09:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 08:09:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-17 08:09:49 --> Total execution time: 0.2192
DEBUG - 2020-09-17 08:09:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 08:09:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 08:09:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 08:09:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 08:09:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 08:09:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 08:09:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 08:09:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 08:09:54 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 08:09:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 08:09:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 08:09:54 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 08:09:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 08:09:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 08:09:54 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 08:17:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 08:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 08:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 08:17:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 08:17:47 --> Total execution time: 0.1791
DEBUG - 2020-09-17 08:17:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 08:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 08:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 08:17:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 08:17:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 08:17:50 --> Total execution time: 0.1689
DEBUG - 2020-09-17 08:17:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 08:17:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 08:17:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 08:49:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 08:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 08:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 08:49:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 08:49:28 --> Total execution time: 0.1654
DEBUG - 2020-09-17 08:49:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 08:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 08:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 08:49:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 08:49:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 08:49:31 --> Total execution time: 0.1890
DEBUG - 2020-09-17 08:49:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 08:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 08:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 08:49:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 08:49:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 08:49:33 --> Total execution time: 0.1636
DEBUG - 2020-09-17 08:49:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 08:49:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 08:49:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 08:49:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 08:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 08:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 08:49:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 08:49:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 08:49:39 --> Total execution time: 0.1395
DEBUG - 2020-09-17 08:49:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 08:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 08:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 08:49:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 08:49:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 08:49:42 --> Total execution time: 0.1660
DEBUG - 2020-09-17 08:49:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 08:49:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 08:49:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 08:50:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 08:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 08:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 08:50:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 09:14:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 09:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 09:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 09:14:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 09:15:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 09:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 09:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 09:15:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 09:15:30 --> Total execution time: 0.1449
DEBUG - 2020-09-17 09:15:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 09:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 09:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 09:15:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 09:15:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 09:15:33 --> Total execution time: 0.1218
DEBUG - 2020-09-17 09:15:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 09:15:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 09:15:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 10:01:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 10:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 10:01:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 10:01:21 --> Total execution time: 0.1741
DEBUG - 2020-09-17 10:01:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 10:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 10:01:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 10:01:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-17 10:01:24 --> Total execution time: 0.1326
DEBUG - 2020-09-17 10:01:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:01:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 10:01:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 10:01:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 10:01:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 10:01:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:01:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 10:01:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 10:01:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:01:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 10:01:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 10:01:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:01:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 10:01:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 10:01:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:01:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 10:01:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 10:01:32 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-17 10:01:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 10:01:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:01:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 10:01:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 10:01:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:01:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 10:01:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-17 10:05:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 10:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 10:05:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 10:10:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 10:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 10:10:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 10:10:32 --> Total execution time: 0.1117
DEBUG - 2020-09-17 10:10:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 10:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 10:10:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 10:10:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 10:10:34 --> Total execution time: 0.2068
DEBUG - 2020-09-17 10:10:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:10:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 10:10:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 10:12:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 10:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 10:12:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 10:39:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 10:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 10:39:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 10:39:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 10:39:29 --> Total execution time: 0.1572
DEBUG - 2020-09-17 10:39:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:39:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 10:39:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 10:39:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 10:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 10:39:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 10:39:42 --> Total execution time: 0.1800
DEBUG - 2020-09-17 10:39:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 10:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 10:39:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 10:39:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 10:39:44 --> Total execution time: 0.1224
DEBUG - 2020-09-17 10:39:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:39:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 10:39:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 10:39:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 10:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 10:39:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 10:39:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 10:39:53 --> Total execution time: 0.1526
DEBUG - 2020-09-17 10:39:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 10:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 10:39:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 10:39:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 10:39:56 --> Total execution time: 0.1607
DEBUG - 2020-09-17 10:39:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 10:39:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 10:39:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 11:21:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:21:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 11:21:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 11:21:09 --> Total execution time: 0.1772
DEBUG - 2020-09-17 11:21:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:21:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 11:21:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 11:21:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:21:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 11:21:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 11:21:27 --> Total execution time: 0.1936
DEBUG - 2020-09-17 11:21:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:21:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 11:21:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 11:21:30 --> Total execution time: 0.2038
DEBUG - 2020-09-17 11:21:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:21:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 11:21:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 11:21:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:21:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 11:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:22:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 11:22:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:22:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 11:22:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 11:22:27 --> Total execution time: 0.1601
DEBUG - 2020-09-17 11:22:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:22:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 11:22:29 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 11:22:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 11:22:43 --> Total execution time: 0.1657
DEBUG - 2020-09-17 11:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:22:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 11:22:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 11:22:47 --> Total execution time: 0.1662
DEBUG - 2020-09-17 11:22:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:22:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 11:22:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 11:22:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:22:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 11:22:59 --> Total execution time: 0.1247
DEBUG - 2020-09-17 11:23:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:23:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 11:23:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 11:23:02 --> Total execution time: 0.1389
DEBUG - 2020-09-17 11:23:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:23:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 11:23:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 11:23:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:23:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 11:23:13 --> Total execution time: 0.1322
DEBUG - 2020-09-17 11:23:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:23:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 11:23:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 11:23:17 --> Total execution time: 0.1316
DEBUG - 2020-09-17 11:23:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:23:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 11:23:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 11:23:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:23:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 11:23:54 --> Total execution time: 0.1600
DEBUG - 2020-09-17 11:23:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:23:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 11:23:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 11:23:56 --> Total execution time: 0.1316
DEBUG - 2020-09-17 11:23:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:23:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 11:23:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 11:30:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:30:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 11:30:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 11:30:47 --> Total execution time: 0.1645
DEBUG - 2020-09-17 11:30:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:30:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 11:30:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 11:31:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:31:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 11:31:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:31:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 11:31:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 11:31:21 --> Total execution time: 0.1390
DEBUG - 2020-09-17 11:31:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 11:31:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 11:33:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:33:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 11:33:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 11:33:56 --> Total execution time: 0.1640
DEBUG - 2020-09-17 11:33:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:33:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 11:33:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 11:34:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:34:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 11:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:34:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 11:34:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 11:34:18 --> Total execution time: 0.1584
DEBUG - 2020-09-17 11:34:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:34:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 11:34:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 11:42:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:42:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 11:42:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 11:42:23 --> Total execution time: 0.1910
DEBUG - 2020-09-17 11:42:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:42:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 11:42:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 11:42:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:42:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 11:45:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:45:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 11:48:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:48:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 11:51:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:51:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 11:51:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 11:51:33 --> Total execution time: 0.1425
DEBUG - 2020-09-17 11:51:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:51:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 11:51:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 11:51:38 --> Total execution time: 0.2012
DEBUG - 2020-09-17 11:51:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:51:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 11:51:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 11:51:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:51:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 11:52:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:52:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 11:52:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 11:52:03 --> Total execution time: 0.1829
DEBUG - 2020-09-17 11:52:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:52:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 11:52:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 11:53:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:53:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 11:53:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:53:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 11:53:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 11:53:13 --> Total execution time: 0.1371
DEBUG - 2020-09-17 11:53:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:53:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 11:53:15 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 11:54:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:54:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 11:54:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 11:54:51 --> Total execution time: 0.1626
DEBUG - 2020-09-17 11:54:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:54:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 11:54:54 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 11:55:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:55:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 11:55:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:55:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 11:55:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 11:55:15 --> Total execution time: 0.1598
DEBUG - 2020-09-17 11:55:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:55:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 11:55:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 11:59:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 11:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 11:59:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 11:59:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 11:59:42 --> Total execution time: 0.1687
DEBUG - 2020-09-17 11:59:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 11:59:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 11:59:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 12:00:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:00:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 12:00:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:00:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 12:00:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 12:00:09 --> Total execution time: 0.1430
DEBUG - 2020-09-17 12:00:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:00:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 12:00:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 12:02:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:02:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 12:02:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 12:02:22 --> Total execution time: 0.1375
DEBUG - 2020-09-17 12:02:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:02:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 12:02:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 12:02:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:02:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 12:05:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:05:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 12:05:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 12:05:05 --> Total execution time: 0.1286
DEBUG - 2020-09-17 12:05:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:05:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 12:05:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 12:05:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:05:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 12:05:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 12:05:13 --> Total execution time: 0.1321
DEBUG - 2020-09-17 12:05:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:05:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 12:05:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 12:05:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:05:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 12:05:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:05:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 12:05:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 12:05:36 --> Total execution time: 0.1667
DEBUG - 2020-09-17 12:05:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:05:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 12:05:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 12:12:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:12:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 12:12:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 12:12:00 --> Total execution time: 0.1710
DEBUG - 2020-09-17 12:12:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:12:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 12:12:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 12:15:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:15:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 12:16:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:16:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 12:16:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 12:16:01 --> Total execution time: 0.1240
DEBUG - 2020-09-17 12:16:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:16:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 12:16:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 12:17:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:17:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 12:17:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:17:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 12:17:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 12:17:18 --> Total execution time: 0.1355
DEBUG - 2020-09-17 12:17:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:17:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 12:17:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 12:19:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:19:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 12:19:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 12:19:18 --> Total execution time: 0.1469
DEBUG - 2020-09-17 12:19:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:19:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 12:19:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 12:19:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:19:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 12:19:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:19:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 12:19:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 12:19:41 --> Total execution time: 0.1488
DEBUG - 2020-09-17 12:19:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:19:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 12:19:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 12:21:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:21:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 12:21:58 --> Total execution time: 0.1405
DEBUG - 2020-09-17 12:22:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:22:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 12:25:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:25:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 12:30:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:30:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 12:30:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 12:30:52 --> Total execution time: 0.1476
DEBUG - 2020-09-17 12:30:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:30:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 12:30:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 12:30:57 --> Total execution time: 0.1629
DEBUG - 2020-09-17 12:31:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:31:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 12:31:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 12:31:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:31:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 12:31:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 12:31:58 --> Total execution time: 0.1438
DEBUG - 2020-09-17 12:32:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:32:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 12:32:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 12:32:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:32:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 12:32:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:32:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 12:32:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 12:32:58 --> Total execution time: 0.1635
DEBUG - 2020-09-17 12:33:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:33:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 12:33:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 12:36:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:36:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 12:36:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:36:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 12:36:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 12:36:15 --> Total execution time: 0.1178
DEBUG - 2020-09-17 12:36:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:36:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 12:36:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-17 12:37:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:37:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-17 12:37:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-17 12:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-17 12:37:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-17 12:37:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-17 12:37:09 --> Total execution time: 0.1227
DEBUG - 2020-09-17 12:37:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-17 12:37:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-17 12:37:12 --> 404 Page Not Found: Assets/chosen
