<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-04-29 06:13:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:13:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:13:07 --> Total execution time: 0.2616
DEBUG - 2021-04-29 06:14:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:14:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:14:49 --> Total execution time: 0.1489
DEBUG - 2021-04-29 06:15:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:15:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:15:20 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 06:15:20 --> Total execution time: 0.1476
DEBUG - 2021-04-29 06:15:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:15:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:15:58 --> Total execution time: 0.1503
DEBUG - 2021-04-29 06:17:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:17:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:17:24 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 06:17:24 --> Total execution time: 0.1544
DEBUG - 2021-04-29 06:17:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:17:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:17:30 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-04-29 06:17:30 --> Total execution time: 0.1645
DEBUG - 2021-04-29 06:17:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:17:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:17:36 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 06:17:36 --> Total execution time: 0.1446
DEBUG - 2021-04-29 06:17:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:17:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:17:58 --> get_sorce_lan_word_type_9->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 06:17:58 --> Total execution time: 0.1038
DEBUG - 2021-04-29 06:20:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:20:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:20:07 --> user_login->{"email":"ronak.doshi@voolsy.com","password":"e10adc3949ba59abbe56e057f20f883e"}
ERROR - 2021-04-29 06:20:07 --> {"status":0,"message":"Username or Password Wrong!!","message_en":"","result":[],"status_message":"OK"}
DEBUG - 2021-04-29 06:20:07 --> Total execution time: 0.1334
DEBUG - 2021-04-29 06:20:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:20:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:20:13 --> user_login->{"email":"ronak.doshi@voolsy.com","password":"b51dedb33ef8d983d741d5e035760a08"}
DEBUG - 2021-04-29 06:20:13 --> Total execution time: 0.1497
DEBUG - 2021-04-29 06:20:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:20:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:20:16 --> Total execution time: 0.1418
DEBUG - 2021-04-29 06:20:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:20:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:20:20 --> Total execution time: 0.1450
DEBUG - 2021-04-29 06:20:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:20:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:20:32 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 06:20:32 --> Total execution time: 0.1515
DEBUG - 2021-04-29 06:20:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:20:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:20:36 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-04-29 06:20:36 --> Total execution time: 0.1411
DEBUG - 2021-04-29 06:20:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:20:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:20:39 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 06:20:39 --> Total execution time: 0.1525
DEBUG - 2021-04-29 06:20:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:20:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:20:44 --> get_sorce_lan_word_type_9->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 06:20:44 --> Total execution time: 0.1202
DEBUG - 2021-04-29 06:21:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:21:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:21:04 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 06:21:04 --> Total execution time: 0.1609
DEBUG - 2021-04-29 06:21:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:21:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:21:30 --> get_sorce_lan_word_type_9->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 06:21:30 --> Total execution time: 0.1952
DEBUG - 2021-04-29 06:21:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:21:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:21:58 --> get_sorce_lan_word_type_9->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 06:21:58 --> Total execution time: 0.1518
DEBUG - 2021-04-29 06:23:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:23:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:23:09 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 06:23:09 --> Total execution time: 0.1316
DEBUG - 2021-04-29 06:23:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:23:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:23:18 --> get_sorce_lan_word_type_5->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 06:23:18 --> Total execution time: 0.1393
DEBUG - 2021-04-29 06:23:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:23:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 06:23:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 06:23:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:23:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:23:22 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 06:23:22 --> Total execution time: 0.1252
DEBUG - 2021-04-29 06:28:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:28:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:28:51 --> get_sorce_lan_word_type_9->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 06:28:51 --> Total execution time: 0.1223
DEBUG - 2021-04-29 06:32:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:32:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:32:09 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 06:32:09 --> Total execution time: 0.1444
DEBUG - 2021-04-29 06:32:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:32:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:32:23 --> get_sorce_lan_word_type_9->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 06:32:23 --> Total execution time: 0.1485
DEBUG - 2021-04-29 06:32:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:32:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:32:27 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 06:32:27 --> Total execution time: 0.1382
DEBUG - 2021-04-29 06:33:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:33:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:33:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:33:30 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-04-29 06:33:30 --> Total execution time: 0.1490
DEBUG - 2021-04-29 06:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:33:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:33:30 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 06:33:30 --> Total execution time: 0.1153
DEBUG - 2021-04-29 06:34:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:34:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:34:50 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 06:34:50 --> Total execution time: 0.1350
DEBUG - 2021-04-29 06:34:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:34:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:34:53 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-04-29 06:34:53 --> Total execution time: 0.1739
DEBUG - 2021-04-29 06:34:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:34:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:34:53 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 06:34:53 --> Total execution time: 0.1404
DEBUG - 2021-04-29 06:50:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:50:22 --> No URI present. Default controller set.
DEBUG - 2021-04-29 06:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:50:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:50:22 --> Total execution time: 0.1395
DEBUG - 2021-04-29 06:50:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:50:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:50:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:50:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:50:35 --> Total execution time: 0.1561
DEBUG - 2021-04-29 06:50:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:50:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 06:50:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 06:51:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:51:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:51:18 --> Total execution time: 0.1815
DEBUG - 2021-04-29 06:51:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:51:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 06:51:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 06:51:21 --> Total execution time: 0.1704
DEBUG - 2021-04-29 06:51:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:51:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 06:51:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 06:51:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:51:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 06:51:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 06:51:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:51:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 06:51:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 06:51:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:51:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:51:47 --> Total execution time: 0.1498
DEBUG - 2021-04-29 06:51:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:51:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:51:54 --> Total execution time: 0.1535
DEBUG - 2021-04-29 06:51:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:51:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:51:56 --> Total execution time: 0.1652
DEBUG - 2021-04-29 06:51:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:51:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:51:56 --> Total execution time: 0.1513
DEBUG - 2021-04-29 06:51:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:51:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:51:57 --> Total execution time: 0.1635
DEBUG - 2021-04-29 06:51:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:51:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:51:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:51:59 --> Total execution time: 0.1667
DEBUG - 2021-04-29 06:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:51:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:51:59 --> Total execution time: 0.1598
DEBUG - 2021-04-29 06:52:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:52:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:52:00 --> Total execution time: 0.1713
DEBUG - 2021-04-29 06:52:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:52:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 06:52:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 06:52:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:52:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:52:49 --> Total execution time: 0.1594
DEBUG - 2021-04-29 06:52:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:52:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 06:52:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 06:52:51 --> Total execution time: 0.1791
DEBUG - 2021-04-29 06:52:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:52:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:52:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 06:52:54 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 06:52:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 06:52:54 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 06:52:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:52:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 06:52:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 06:53:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:53:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:53:39 --> Total execution time: 0.1296
DEBUG - 2021-04-29 06:53:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:53:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:53:41 --> Total execution time: 0.1850
DEBUG - 2021-04-29 06:53:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:53:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 06:53:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 06:54:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:54:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:54:06 --> Total execution time: 0.1638
DEBUG - 2021-04-29 06:54:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:54:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:54:09 --> Total execution time: 0.1788
DEBUG - 2021-04-29 06:54:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:54:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 06:54:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 06:55:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:55:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:55:36 --> Total execution time: 0.1380
DEBUG - 2021-04-29 06:55:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:55:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:55:38 --> Total execution time: 0.1445
DEBUG - 2021-04-29 06:55:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:55:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 06:55:41 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 06:58:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:58:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:58:01 --> Total execution time: 0.1461
DEBUG - 2021-04-29 06:58:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:58:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 06:58:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 06:58:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:58:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:58:13 --> Total execution time: 0.1363
DEBUG - 2021-04-29 06:58:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:58:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 06:58:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 06:58:16 --> Total execution time: 0.1647
DEBUG - 2021-04-29 06:58:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:58:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 06:58:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 06:58:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:58:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 06:58:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 06:58:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:58:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 06:58:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 06:58:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:58:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:58:38 --> Total execution time: 0.1716
DEBUG - 2021-04-29 06:58:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:58:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 06:58:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 06:58:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 06:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 06:58:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 06:58:58 --> Total execution time: 0.1915
DEBUG - 2021-04-29 06:59:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 06:59:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 06:59:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 07:54:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 07:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 07:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 07:54:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 07:54:13 --> Total execution time: 0.1909
DEBUG - 2021-04-29 07:54:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 07:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 07:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 07:54:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 07:54:15 --> Total execution time: 0.1896
DEBUG - 2021-04-29 07:54:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 07:54:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 07:54:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 07:54:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 07:54:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 07:54:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 07:54:20 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-04-29 07:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 07:54:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 07:54:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 07:54:20 --> 404 Page Not Found: Uploads/icecream.jpg
ERROR - 2021-04-29 07:54:20 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-04-29 07:55:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 07:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 07:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 07:55:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 07:55:24 --> Total execution time: 0.1418
DEBUG - 2021-04-29 07:55:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 07:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 07:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 07:55:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 07:55:26 --> Total execution time: 0.2067
DEBUG - 2021-04-29 07:55:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 07:55:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 07:55:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 07:56:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 07:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 07:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 07:56:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 07:56:37 --> Total execution time: 0.1512
DEBUG - 2021-04-29 07:56:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 07:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 07:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 07:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 07:56:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 07:56:40 --> Total execution time: 0.1561
DEBUG - 2021-04-29 07:56:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 07:56:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 07:56:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 07:56:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 07:56:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 07:56:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 07:56:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 07:56:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 07:56:45 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 08:42:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 08:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 08:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 08:42:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 08:42:11 --> Total execution time: 0.1428
DEBUG - 2021-04-29 08:42:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 08:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 08:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 08:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 08:42:14 --> Total execution time: 0.1441
DEBUG - 2021-04-29 08:42:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 08:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 08:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 08:42:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 08:42:16 --> Total execution time: 0.1165
DEBUG - 2021-04-29 08:42:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 08:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 08:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 08:42:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 08:42:20 --> Total execution time: 0.1482
DEBUG - 2021-04-29 08:42:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 08:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 08:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 08:42:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 08:42:27 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 08:42:27 --> Total execution time: 0.1490
DEBUG - 2021-04-29 08:42:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 08:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 08:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 08:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 08:42:32 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-04-29 08:42:32 --> Total execution time: 0.1796
DEBUG - 2021-04-29 08:42:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 08:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 08:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 08:42:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 08:42:37 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 08:42:37 --> Total execution time: 0.1564
DEBUG - 2021-04-29 08:42:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 08:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 08:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 08:42:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 08:42:43 --> get_sorce_lan_word_type_9->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 08:42:43 --> Total execution time: 0.1761
DEBUG - 2021-04-29 08:42:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 08:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 08:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 08:42:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 08:42:54 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-04-29 08:42:54 --> Total execution time: 0.1554
DEBUG - 2021-04-29 09:15:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 09:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 09:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 09:15:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 09:15:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 09:15:58 --> Total execution time: 0.1712
DEBUG - 2021-04-29 09:16:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 09:16:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 09:16:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 09:16:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 09:16:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 09:16:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 09:16:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 09:16:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 09:16:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 11:51:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 11:51:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 11:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 11:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 11:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 11:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 11:51:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 11:51:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 11:51:07 --> Total execution time: 0.1393
DEBUG - 2021-04-29 11:51:07 --> Total execution time: 0.1399
DEBUG - 2021-04-29 11:51:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 11:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 11:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 11:51:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 11:51:12 --> Total execution time: 0.1196
DEBUG - 2021-04-29 11:51:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 11:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 11:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 11:51:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 11:51:18 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 11:51:18 --> Total execution time: 0.1257
DEBUG - 2021-04-29 11:51:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 11:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 11:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 11:51:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 11:51:22 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-04-29 11:51:22 --> Total execution time: 0.1006
DEBUG - 2021-04-29 11:51:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 11:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 11:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 11:51:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 11:51:25 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 11:51:25 --> Total execution time: 0.1619
DEBUG - 2021-04-29 11:51:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 11:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 11:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 11:51:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 11:51:55 --> get_exercise_type_list->{"lang":null,"subcategory_id":null,"support_lang_id":null}
ERROR - 2021-04-29 11:51:55 --> {"status":0,"message":"Parameters not passed","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2021-04-29 11:51:55 --> Total execution time: 0.1393
DEBUG - 2021-04-29 11:57:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 11:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 11:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 11:57:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 11:57:01 --> Total execution time: 0.1197
DEBUG - 2021-04-29 11:57:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 11:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 11:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 11:57:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 11:57:01 --> Total execution time: 0.1162
DEBUG - 2021-04-29 11:58:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 11:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 11:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 11:58:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 11:58:30 --> Total execution time: 0.1834
DEBUG - 2021-04-29 11:58:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 11:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 11:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 11:58:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 11:58:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 11:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 11:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 11:58:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 11:58:35 --> Total execution time: 0.1976
DEBUG - 2021-04-29 11:58:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 11:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 11:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 11:58:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 11:58:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 11:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 11:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 11:58:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 11:58:45 --> Total execution time: 0.1531
DEBUG - 2021-04-29 11:58:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 11:58:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 11:58:47 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 11:58:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 11:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 11:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 11:58:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 11:58:55 --> Total execution time: 0.1650
DEBUG - 2021-04-29 11:58:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 11:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 11:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 11:58:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 11:58:57 --> Total execution time: 0.1640
DEBUG - 2021-04-29 11:59:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 11:59:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 11:59:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 11:59:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 11:59:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 11:59:00 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-04-29 11:59:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 11:59:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 11:59:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 11:59:02 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-04-29 11:59:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 11:59:02 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-04-29 11:59:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 11:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 11:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 11:59:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 11:59:30 --> Total execution time: 0.1901
DEBUG - 2021-04-29 11:59:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 11:59:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 11:59:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 12:01:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:01:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:01:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:01:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:01:44 --> Total execution time: 0.1446
DEBUG - 2021-04-29 12:01:44 --> Total execution time: 0.1457
DEBUG - 2021-04-29 12:02:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:02:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:02:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 12:02:13 --> Query error: Unknown column 'mode_name' in 'order clause' - Invalid query: SELECT *
FROM `tbl_exercise_type`
WHERE `exercise_mode_id` = '1'
ORDER BY `mode_name` ASC
ERROR - 2021-04-29 12:02:13 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 980
DEBUG - 2021-04-29 12:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:02:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:02:13 --> Total execution time: 0.2267
DEBUG - 2021-04-29 12:02:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:02:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:02:57 --> Total execution time: 0.1712
DEBUG - 2021-04-29 12:03:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:03:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:03:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 12:03:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:03:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:03:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:03:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:03:45 --> Total execution time: 0.1464
DEBUG - 2021-04-29 12:03:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:03:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:03:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 12:03:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:03:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:03:49 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-04-29 12:03:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:03:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:03:51 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-04-29 12:03:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:03:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:03:51 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-04-29 12:05:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:05:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:05:51 --> Total execution time: 0.1818
DEBUG - 2021-04-29 12:05:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:05:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:05:54 --> Total execution time: 0.1527
DEBUG - 2021-04-29 12:05:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:05:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:05:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 12:06:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:06:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:06:15 --> Total execution time: 0.1772
DEBUG - 2021-04-29 12:06:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:06:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:06:18 --> Total execution time: 0.1608
DEBUG - 2021-04-29 12:06:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:06:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:06:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 12:07:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:07:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:07:18 --> Total execution time: 0.1964
DEBUG - 2021-04-29 12:07:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:07:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 12:07:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 12:07:20 --> Total execution time: 0.1717
DEBUG - 2021-04-29 12:07:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:07:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 12:07:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:07:23 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 12:07:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:07:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:07:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 12:07:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:07:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 12:07:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 12:07:30 --> Total execution time: 0.1283
DEBUG - 2021-04-29 12:07:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:07:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:07:43 --> Total execution time: 0.1772
DEBUG - 2021-04-29 12:07:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:07:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 12:07:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 12:07:46 --> Total execution time: 0.1591
DEBUG - 2021-04-29 12:07:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:07:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 12:07:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 12:07:47 --> Total execution time: 0.1675
DEBUG - 2021-04-29 12:07:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:07:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:07:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 12:08:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:08:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:08:02 --> Total execution time: 0.1371
DEBUG - 2021-04-29 12:08:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:08:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:08:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 12:08:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:08:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:08:10 --> Total execution time: 0.1794
DEBUG - 2021-04-29 12:08:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:08:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:08:14 --> Total execution time: 0.1598
DEBUG - 2021-04-29 12:15:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:15:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:15:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:15:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 12:15:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 12:15:53 --> Total execution time: 0.2098
DEBUG - 2021-04-29 12:15:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:15:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:15:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 12:19:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:19:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:22:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:22:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:22:34 --> Total execution time: 0.1269
DEBUG - 2021-04-29 12:22:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:22:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:22:37 --> Total execution time: 0.1564
DEBUG - 2021-04-29 12:22:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:22:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:22:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 12:22:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:22:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:22:40 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-04-29 12:22:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:22:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:22:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:22:42 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-04-29 12:22:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:22:42 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-04-29 12:22:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:38:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:38:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:38:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:38:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:38:40 --> Total execution time: 0.1422
DEBUG - 2021-04-29 12:38:40 --> Total execution time: 0.1639
DEBUG - 2021-04-29 12:38:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:38:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:38:45 --> Total execution time: 0.1461
DEBUG - 2021-04-29 12:38:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:38:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:38:52 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 12:38:52 --> Total execution time: 0.1461
DEBUG - 2021-04-29 12:38:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:38:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:38:55 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-04-29 12:38:55 --> Total execution time: 0.1516
DEBUG - 2021-04-29 12:39:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:39:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:39:04 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-29 12:39:04 --> Total execution time: 0.1454
DEBUG - 2021-04-29 12:40:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:40:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:40:03 --> get_sorce_lan_word_type_16->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
ERROR - 2021-04-29 12:40:03 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-04-29 12:40:03 --> Total execution time: 0.1410
DEBUG - 2021-04-29 12:41:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:41:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:41:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:41:56 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-04-29 12:41:56 --> Total execution time: 0.1487
DEBUG - 2021-04-29 12:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:41:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:41:56 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-29 12:41:56 --> Total execution time: 0.1163
DEBUG - 2021-04-29 12:41:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:41:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:41:56 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 12:41:56 --> Total execution time: 0.1180
DEBUG - 2021-04-29 12:41:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:41:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:41:58 --> Total execution time: 0.1255
DEBUG - 2021-04-29 12:41:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:41:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:41:59 --> Total execution time: 0.1357
DEBUG - 2021-04-29 12:42:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:42:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:42:03 --> Total execution time: 0.2052
DEBUG - 2021-04-29 12:42:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:42:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:42:10 --> Total execution time: 0.1447
DEBUG - 2021-04-29 12:42:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:42:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:42:15 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 12:42:15 --> Total execution time: 0.1374
DEBUG - 2021-04-29 12:42:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:42:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:42:24 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-04-29 12:42:24 --> Total execution time: 0.1503
DEBUG - 2021-04-29 12:42:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:42:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:42:28 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 12:42:28 --> Total execution time: 0.1242
DEBUG - 2021-04-29 12:42:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:42:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:42:34 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-04-29 12:42:34 --> Total execution time: 0.1295
DEBUG - 2021-04-29 12:42:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:42:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:42:40 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-29 12:42:40 --> Total execution time: 0.1143
DEBUG - 2021-04-29 12:42:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:42:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:42:44 --> get_sorce_lan_word_type_17->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
ERROR - 2021-04-29 12:42:44 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-04-29 12:42:44 --> Total execution time: 0.1581
DEBUG - 2021-04-29 12:42:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:42:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:42:49 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-29 12:42:49 --> Total execution time: 0.1169
DEBUG - 2021-04-29 12:42:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:42:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:42:53 --> get_sorce_lan_word_type_18->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
ERROR - 2021-04-29 12:42:53 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-04-29 12:42:53 --> Total execution time: 0.1436
DEBUG - 2021-04-29 12:43:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:43:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:43:13 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-29 12:43:13 --> Total execution time: 0.1669
DEBUG - 2021-04-29 12:43:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:43:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:43:16 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-04-29 12:43:16 --> Total execution time: 0.1497
DEBUG - 2021-04-29 12:43:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:43:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:43:26 --> Total execution time: 0.1692
DEBUG - 2021-04-29 12:43:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:43:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:43:28 --> Total execution time: 0.1988
DEBUG - 2021-04-29 12:43:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:43:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:43:31 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 12:44:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:44:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:44:04 --> Total execution time: 0.1486
DEBUG - 2021-04-29 12:44:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:44:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 12:44:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 12:44:07 --> Total execution time: 0.1800
DEBUG - 2021-04-29 12:44:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:44:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:44:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 12:44:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:44:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:44:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 12:44:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:44:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:44:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 12:44:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:44:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:44:28 --> Total execution time: 0.1665
DEBUG - 2021-04-29 12:44:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:44:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 12:44:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 12:44:31 --> Total execution time: 0.1669
DEBUG - 2021-04-29 12:44:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:44:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:44:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:44:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 12:44:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:44:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 12:44:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:44:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:44:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 12:44:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:44:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 12:44:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 12:44:38 --> Total execution time: 0.2113
DEBUG - 2021-04-29 12:44:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:44:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 12:44:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 12:44:40 --> Total execution time: 0.1591
DEBUG - 2021-04-29 12:44:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:44:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:44:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 12:49:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:49:36 --> No URI present. Default controller set.
DEBUG - 2021-04-29 12:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:49:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:49:36 --> Total execution time: 0.1647
DEBUG - 2021-04-29 12:50:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:50:03 --> No URI present. Default controller set.
DEBUG - 2021-04-29 12:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:50:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:50:03 --> Total execution time: 0.1594
DEBUG - 2021-04-29 12:50:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:50:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:50:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:50:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:50:18 --> Total execution time: 0.1095
DEBUG - 2021-04-29 12:50:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:50:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:50:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 12:50:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:50:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:50:35 --> Total execution time: 0.1551
DEBUG - 2021-04-29 12:50:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:50:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:50:35 --> Total execution time: 0.1641
DEBUG - 2021-04-29 12:50:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:50:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:50:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:50:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:50:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:50:38 --> Total execution time: 0.1900
DEBUG - 2021-04-29 12:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:50:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:50:38 --> Total execution time: 0.1370
DEBUG - 2021-04-29 12:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:50:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:50:38 --> Total execution time: 0.3145
DEBUG - 2021-04-29 12:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:50:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 12:50:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 12:50:38 --> Total execution time: 0.2925
DEBUG - 2021-04-29 12:50:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:50:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 12:50:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 12:50:38 --> Total execution time: 0.1569
DEBUG - 2021-04-29 12:50:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:50:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:50:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:50:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:50:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:50:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 12:50:40 --> Total execution time: 0.1461
DEBUG - 2021-04-29 12:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:50:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 12:50:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 12:50:40 --> Total execution time: 0.1938
DEBUG - 2021-04-29 12:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:50:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 12:50:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 12:50:40 --> Total execution time: 0.1652
DEBUG - 2021-04-29 12:50:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:50:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:50:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 12:50:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:50:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:50:45 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 12:50:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:50:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:50:45 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 12:51:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:51:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:51:03 --> Total execution time: 0.2133
DEBUG - 2021-04-29 12:51:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:51:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:51:05 --> Total execution time: 0.1658
DEBUG - 2021-04-29 12:51:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:51:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:51:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 12:51:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:51:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:51:19 --> Total execution time: 0.1794
DEBUG - 2021-04-29 12:51:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:51:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:51:19 --> Total execution time: 0.1654
DEBUG - 2021-04-29 12:51:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:51:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:51:19 --> Total execution time: 0.1221
DEBUG - 2021-04-29 12:51:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:51:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:51:19 --> Total execution time: 0.1666
DEBUG - 2021-04-29 12:51:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:51:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:51:20 --> Total execution time: 0.1569
DEBUG - 2021-04-29 12:51:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:51:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 12:51:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 12:51:21 --> Total execution time: 0.1857
DEBUG - 2021-04-29 12:51:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:51:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:51:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:51:21 --> Total execution time: 0.1711
DEBUG - 2021-04-29 12:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:51:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 12:51:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 12:51:21 --> Total execution time: 0.2240
DEBUG - 2021-04-29 12:51:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:51:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 12:51:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 12:51:22 --> Total execution time: 0.2119
DEBUG - 2021-04-29 12:51:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:51:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 12:51:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 12:51:22 --> Total execution time: 0.1326
DEBUG - 2021-04-29 12:51:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:51:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 12:51:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 12:51:23 --> Total execution time: 0.1698
DEBUG - 2021-04-29 12:51:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:51:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 12:51:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 12:51:24 --> Total execution time: 0.1696
DEBUG - 2021-04-29 12:51:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:51:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:51:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 12:51:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:51:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:51:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 12:51:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:51:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 12:51:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 12:55:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:55:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:55:54 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 12:55:54 --> Total execution time: 0.1547
DEBUG - 2021-04-29 12:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:55:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:55:55 --> Total execution time: 0.1370
DEBUG - 2021-04-29 12:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 12:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 12:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 12:55:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 12:55:55 --> Total execution time: 0.1496
DEBUG - 2021-04-29 13:05:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 13:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 13:05:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 13:05:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 13:05:16 --> Total execution time: 0.1692
DEBUG - 2021-04-29 13:05:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:05:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 13:05:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 13:05:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:05:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 13:05:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 13:05:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:05:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 13:05:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 13:09:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 13:09:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 13:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 13:09:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 13:09:28 --> Total execution time: 0.1740
DEBUG - 2021-04-29 13:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 13:09:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 13:09:28 --> Total execution time: 0.1443
DEBUG - 2021-04-29 13:09:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 13:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 13:09:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 13:09:33 --> Total execution time: 0.1485
DEBUG - 2021-04-29 13:09:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 13:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 13:09:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 13:09:41 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 13:09:41 --> Total execution time: 0.1751
DEBUG - 2021-04-29 13:09:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 13:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 13:09:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 13:09:44 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-04-29 13:09:44 --> Total execution time: 0.1508
DEBUG - 2021-04-29 13:09:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 13:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 13:09:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 13:09:48 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-29 13:09:48 --> Total execution time: 0.1457
DEBUG - 2021-04-29 13:09:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 13:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 13:09:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 13:09:54 --> get_sorce_lan_word_type_16->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
ERROR - 2021-04-29 13:09:54 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-04-29 13:09:54 --> Total execution time: 0.1457
DEBUG - 2021-04-29 13:23:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:23:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 13:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 13:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 13:23:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 13:23:46 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-04-29 13:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 13:23:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 13:23:46 --> Total execution time: 0.1221
DEBUG - 2021-04-29 13:23:46 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-29 13:23:46 --> Total execution time: 0.1348
DEBUG - 2021-04-29 13:23:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 13:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 13:23:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 13:23:46 --> Total execution time: 0.1434
DEBUG - 2021-04-29 13:23:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 13:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 13:23:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 13:23:47 --> Total execution time: 0.1333
DEBUG - 2021-04-29 13:53:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 13:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 13:53:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 13:53:04 --> Total execution time: 0.1161
DEBUG - 2021-04-29 13:53:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 13:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 13:53:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 13:53:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 13:53:06 --> Total execution time: 0.1422
DEBUG - 2021-04-29 13:53:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:53:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 13:53:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 13:53:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:53:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 13:53:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 13:53:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:53:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 13:53:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 13:53:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 13:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 13:53:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 13:53:16 --> Total execution time: 0.2037
DEBUG - 2021-04-29 13:53:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 13:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 13:53:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 13:53:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 13:53:18 --> Total execution time: 0.1705
DEBUG - 2021-04-29 13:53:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:53:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 13:53:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 13:53:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:53:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 13:53:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 13:53:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:53:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 13:53:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-29 13:53:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 13:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 13:53:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 13:53:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 13:53:26 --> Total execution time: 0.1651
DEBUG - 2021-04-29 13:53:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 13:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 13:53:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 13:53:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 13:53:29 --> Total execution time: 0.1742
DEBUG - 2021-04-29 13:53:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:53:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 13:53:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-29 13:53:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 13:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 13:53:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-29 13:53:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-29 13:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-29 13:53:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-29 13:53:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-04-29 13:53:57 --> Total execution time: 0.1730
DEBUG - 2021-04-29 13:53:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-29 13:53:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-29 13:53:59 --> 404 Page Not Found: Assets/chosen
