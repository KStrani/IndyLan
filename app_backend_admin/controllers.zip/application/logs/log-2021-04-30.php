<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-04-30 05:05:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:05:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:05:41 --> Total execution time: 0.2057
DEBUG - 2021-04-30 05:05:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:05:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:05:54 --> Total execution time: 0.1439
DEBUG - 2021-04-30 05:06:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:06:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:06:03 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 05:06:03 --> Total execution time: 0.2123
DEBUG - 2021-04-30 05:06:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:06:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:06:08 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-04-30 05:06:08 --> Total execution time: 0.1381
DEBUG - 2021-04-30 05:06:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:06:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:06:12 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:06:12 --> Total execution time: 0.1420
DEBUG - 2021-04-30 05:06:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:06:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:06:19 --> get_sorce_lan_word_type_16->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:06:19 --> Total execution time: 0.1651
DEBUG - 2021-04-30 05:20:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:20:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:20:24 --> Total execution time: 0.1194
DEBUG - 2021-04-30 05:20:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:20:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:20:28 --> Total execution time: 0.1433
DEBUG - 2021-04-30 05:20:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:20:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:20:34 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 05:20:34 --> Total execution time: 0.1419
DEBUG - 2021-04-30 05:20:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:20:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:20:38 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-04-30 05:20:38 --> Total execution time: 0.1544
DEBUG - 2021-04-30 05:20:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:20:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:20:42 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:20:42 --> Total execution time: 0.1993
DEBUG - 2021-04-30 05:20:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:20:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:20:46 --> get_sorce_lan_word_type_16->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:20:46 --> Total execution time: 0.1546
DEBUG - 2021-04-30 05:21:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:21:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:21:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:21:31 --> Total execution time: 0.1777
DEBUG - 2021-04-30 05:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:21:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:21:32 --> Total execution time: 0.1182
DEBUG - 2021-04-30 05:21:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:21:36 --> Total execution time: 0.1246
DEBUG - 2021-04-30 05:21:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:21:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:21:41 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 05:21:41 --> Total execution time: 0.0960
DEBUG - 2021-04-30 05:26:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:26:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:26:28 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-04-30 05:26:28 --> Total execution time: 0.1096
DEBUG - 2021-04-30 05:26:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:26:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:26:31 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:26:31 --> Total execution time: 0.1397
DEBUG - 2021-04-30 05:26:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:26:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:26:35 --> get_sorce_lan_word_type_16->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:26:35 --> Total execution time: 0.1541
DEBUG - 2021-04-30 05:29:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:29:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:29:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:29:37 --> Total execution time: 0.1504
DEBUG - 2021-04-30 05:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:29:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:29:37 --> Total execution time: 0.1214
DEBUG - 2021-04-30 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:29:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:29:43 --> Total execution time: 0.1468
DEBUG - 2021-04-30 05:29:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:29:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:29:47 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 05:29:47 --> Total execution time: 0.1321
DEBUG - 2021-04-30 05:29:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:29:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:29:51 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-04-30 05:29:51 --> Total execution time: 0.1462
DEBUG - 2021-04-30 05:29:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:29:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:29:54 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:29:54 --> Total execution time: 0.1409
DEBUG - 2021-04-30 05:29:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:29:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:29:58 --> get_sorce_lan_word_type_16->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:29:58 --> Total execution time: 0.1688
DEBUG - 2021-04-30 05:30:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:30:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:30:33 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:30:33 --> Total execution time: 0.1437
DEBUG - 2021-04-30 05:30:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:30:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:30:38 --> get_sorce_lan_word_type_17->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:30:38 --> Total execution time: 0.1529
DEBUG - 2021-04-30 05:38:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:38:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:38:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:38:29 --> Total execution time: 0.1456
DEBUG - 2021-04-30 05:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:38:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:38:29 --> Total execution time: 0.1362
DEBUG - 2021-04-30 05:38:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:38:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:38:33 --> Total execution time: 0.1522
DEBUG - 2021-04-30 05:38:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:38:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:38:38 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 05:38:38 --> Total execution time: 0.1438
DEBUG - 2021-04-30 05:38:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:38:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:38:41 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-04-30 05:38:41 --> Total execution time: 0.1595
DEBUG - 2021-04-30 05:38:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:38:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:38:44 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:38:44 --> Total execution time: 0.1457
DEBUG - 2021-04-30 05:38:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:38:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:38:50 --> get_sorce_lan_word_type_16->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:38:50 --> Total execution time: 0.1385
DEBUG - 2021-04-30 05:38:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:38:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:38:54 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:38:54 --> Total execution time: 0.1476
DEBUG - 2021-04-30 05:38:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:38:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:38:58 --> get_sorce_lan_word_type_17->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:38:58 --> Total execution time: 0.1803
DEBUG - 2021-04-30 05:40:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:40:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:40:49 --> Total execution time: 0.1439
DEBUG - 2021-04-30 05:40:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:40:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:40:54 --> Total execution time: 0.1384
DEBUG - 2021-04-30 05:40:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:40:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:40:59 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 05:40:59 --> Total execution time: 0.1514
DEBUG - 2021-04-30 05:41:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:41:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:41:03 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-04-30 05:41:03 --> Total execution time: 0.1728
DEBUG - 2021-04-30 05:41:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:41:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:41:07 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:41:07 --> Total execution time: 0.1354
DEBUG - 2021-04-30 05:41:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:41:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:41:12 --> get_sorce_lan_word_type_17->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:41:12 --> Total execution time: 0.1745
DEBUG - 2021-04-30 05:42:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:42:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:42:05 --> Total execution time: 0.1029
DEBUG - 2021-04-30 05:42:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:42:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:42:06 --> Total execution time: 0.0981
DEBUG - 2021-04-30 05:42:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:42:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:42:10 --> Total execution time: 0.1219
DEBUG - 2021-04-30 05:42:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:42:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:42:13 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 05:42:13 --> Total execution time: 0.1347
DEBUG - 2021-04-30 05:42:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:42:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:42:17 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-04-30 05:42:17 --> Total execution time: 0.1479
DEBUG - 2021-04-30 05:42:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:42:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:42:20 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:42:20 --> Total execution time: 0.1433
DEBUG - 2021-04-30 05:42:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:42:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:42:24 --> get_sorce_lan_word_type_17->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:42:24 --> Total execution time: 0.1485
DEBUG - 2021-04-30 05:42:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:42:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:42:33 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:42:33 --> Total execution time: 0.1491
DEBUG - 2021-04-30 05:42:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:42:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:42:35 --> get_sorce_lan_word_type_18->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:42:35 --> Total execution time: 0.1469
DEBUG - 2021-04-30 05:45:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:45:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:45:37 --> Total execution time: 0.1434
DEBUG - 2021-04-30 05:45:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:45:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:45:37 --> Total execution time: 0.1438
DEBUG - 2021-04-30 05:46:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:46:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:46:11 --> Total execution time: 0.1131
DEBUG - 2021-04-30 05:46:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:46:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:46:19 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 05:46:19 --> Total execution time: 0.1175
DEBUG - 2021-04-30 05:46:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:46:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:46:23 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-04-30 05:46:24 --> Total execution time: 0.1510
DEBUG - 2021-04-30 05:46:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:46:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:46:27 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:46:27 --> Total execution time: 0.1355
DEBUG - 2021-04-30 05:46:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:46:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:46:34 --> get_sorce_lan_word_type_17->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:46:34 --> Total execution time: 0.1013
DEBUG - 2021-04-30 05:46:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:46:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:46:42 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:46:42 --> Total execution time: 0.1267
DEBUG - 2021-04-30 05:47:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:47:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:47:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:47:39 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-04-30 05:47:40 --> Total execution time: 0.1548
DEBUG - 2021-04-30 05:47:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:47:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:47:40 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 05:47:40 --> Total execution time: 0.1393
DEBUG - 2021-04-30 05:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:47:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:47:40 --> Total execution time: 0.1316
DEBUG - 2021-04-30 05:47:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:47:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:47:40 --> Total execution time: 0.1701
DEBUG - 2021-04-30 05:54:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:54:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:54:16 --> Total execution time: 0.1164
DEBUG - 2021-04-30 05:54:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:54:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:54:20 --> Total execution time: 0.1489
DEBUG - 2021-04-30 05:54:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:54:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:54:21 --> Total execution time: 0.1417
DEBUG - 2021-04-30 05:54:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:54:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:54:44 --> Total execution time: 0.1254
DEBUG - 2021-04-30 05:54:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:55:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:55:00 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 05:55:00 --> Total execution time: 0.1408
DEBUG - 2021-04-30 05:55:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:55:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:55:06 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-04-30 05:55:06 --> Total execution time: 0.1125
DEBUG - 2021-04-30 05:55:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:55:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:55:17 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:55:17 --> Total execution time: 0.1151
DEBUG - 2021-04-30 05:55:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:55:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:55:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:55:45 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-04-30 05:55:45 --> Total execution time: 0.1760
DEBUG - 2021-04-30 05:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:55:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:55:45 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 05:55:45 --> Total execution time: 0.1831
DEBUG - 2021-04-30 05:55:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:55:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:55:46 --> Total execution time: 0.1314
DEBUG - 2021-04-30 05:55:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:55:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:55:46 --> Total execution time: 0.1481
DEBUG - 2021-04-30 05:55:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:55:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:55:49 --> user_login->{"email":"admin@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2021-04-30 05:55:49 --> Total execution time: 0.1140
DEBUG - 2021-04-30 05:55:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:55:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:55:51 --> Total execution time: 0.1362
DEBUG - 2021-04-30 05:55:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:55:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:55:57 --> Total execution time: 0.1427
DEBUG - 2021-04-30 05:56:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:56:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:56:02 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 05:56:02 --> Total execution time: 0.1219
DEBUG - 2021-04-30 05:56:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:56:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:56:06 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 05:56:06 --> Total execution time: 0.1455
DEBUG - 2021-04-30 05:56:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:56:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:56:12 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:56:12 --> Total execution time: 0.1197
DEBUG - 2021-04-30 05:56:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:56:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:56:19 --> get_sorce_lan_word_type_16->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:56:19 --> Total execution time: 0.1565
DEBUG - 2021-04-30 05:56:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:56:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:56:35 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:56:35 --> Total execution time: 0.1513
DEBUG - 2021-04-30 05:56:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:56:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:56:39 --> get_sorce_lan_word_type_17->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:56:39 --> Total execution time: 0.1533
DEBUG - 2021-04-30 05:56:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:56:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:56:51 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:56:51 --> Total execution time: 0.1669
DEBUG - 2021-04-30 05:56:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:56:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:56:56 --> get_sorce_lan_word_type_18->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:56:56 --> Total execution time: 0.1324
DEBUG - 2021-04-30 05:57:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:57:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:57:16 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 05:57:16 --> Total execution time: 0.1459
DEBUG - 2021-04-30 05:57:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:57:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:57:20 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 05:57:20 --> Total execution time: 0.1794
DEBUG - 2021-04-30 05:57:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 05:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 05:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 05:57:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 05:57:25 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 05:57:25 --> Total execution time: 0.1259
DEBUG - 2021-04-30 06:01:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:01:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:01:20 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 06:01:20 --> Total execution time: 0.1518
DEBUG - 2021-04-30 06:01:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:01:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:01:57 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 06:01:57 --> Total execution time: 0.1428
DEBUG - 2021-04-30 06:02:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:02:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:02:11 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 06:02:11 --> Total execution time: 0.1386
DEBUG - 2021-04-30 06:02:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:02:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:02:15 --> get_sorce_lan_word_type_18->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 06:02:15 --> Total execution time: 0.1492
DEBUG - 2021-04-30 06:25:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:25:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:25:05 --> Total execution time: 0.1272
DEBUG - 2021-04-30 06:25:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:25:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:25:10 --> Total execution time: 0.1508
DEBUG - 2021-04-30 06:25:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:25:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:25:16 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 06:25:16 --> Total execution time: 0.1477
DEBUG - 2021-04-30 06:25:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:25:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:25:19 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 06:25:19 --> Total execution time: 0.1588
DEBUG - 2021-04-30 06:25:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:25:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:25:24 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 06:25:24 --> Total execution time: 0.1437
DEBUG - 2021-04-30 06:32:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:32:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:32:47 --> user_login->{"email":"sofiaazo@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
ERROR - 2021-04-30 06:32:47 --> {"status":0,"message":"Username or Password Wrong!!","message_en":"","result":[],"status_message":"OK"}
DEBUG - 2021-04-30 06:32:47 --> Total execution time: 0.1829
DEBUG - 2021-04-30 06:34:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:34:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:34:13 --> user_login->{"email":"harsh.n@voolsy.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2021-04-30 06:34:13 --> Total execution time: 0.1233
DEBUG - 2021-04-30 06:34:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:34:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:34:16 --> Total execution time: 0.1667
DEBUG - 2021-04-30 06:34:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:34:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:34:22 --> Total execution time: 0.1351
DEBUG - 2021-04-30 06:34:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:34:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:34:30 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 06:34:30 --> Total execution time: 0.1460
DEBUG - 2021-04-30 06:34:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:34:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:34:36 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-04-30 06:34:36 --> Total execution time: 0.1510
DEBUG - 2021-04-30 06:34:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:34:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:34:43 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 06:34:43 --> Total execution time: 0.1157
DEBUG - 2021-04-30 06:34:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:34:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:34:50 --> get_sorce_lan_word_type_16->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 06:34:50 --> Total execution time: 0.1382
DEBUG - 2021-04-30 06:35:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:35:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:35:01 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 06:35:01 --> Total execution time: 0.1654
DEBUG - 2021-04-30 06:35:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:35:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:35:04 --> Total execution time: 0.1054
DEBUG - 2021-04-30 06:35:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:35:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:35:07 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 06:35:07 --> Total execution time: 0.1419
DEBUG - 2021-04-30 06:35:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:35:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:35:11 --> get_sorce_lan_word_type_18->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 06:35:11 --> Total execution time: 0.1814
DEBUG - 2021-04-30 06:35:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:35:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:35:31 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 06:35:31 --> Total execution time: 0.1451
DEBUG - 2021-04-30 06:35:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:35:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:35:50 --> get_sorce_lan_word_type_17->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 06:35:50 --> Total execution time: 0.1553
DEBUG - 2021-04-30 06:36:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:36:45 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 06:36:45 --> Total execution time: 0.1017
DEBUG - 2021-04-30 06:36:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:36:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:36:54 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-04-30 06:36:54 --> Total execution time: 0.1638
DEBUG - 2021-04-30 06:37:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:37:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:37:07 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 06:37:07 --> Total execution time: 0.1131
DEBUG - 2021-04-30 06:37:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:37:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:37:25 --> Total execution time: 0.1452
DEBUG - 2021-04-30 06:37:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:37:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:37:43 --> Total execution time: 0.1669
DEBUG - 2021-04-30 06:37:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:37:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:37:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 06:37:46 --> 404 Page Not Found: Uploads/words
ERROR - 2021-04-30 06:37:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-04-30 06:38:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:38:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:38:08 --> Total execution time: 0.1228
DEBUG - 2021-04-30 06:38:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:38:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:38:33 --> Total execution time: 0.1272
DEBUG - 2021-04-30 06:39:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:39:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:39:10 --> Total execution time: 0.1352
DEBUG - 2021-04-30 06:39:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:39:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:39:30 --> Total execution time: 0.1420
DEBUG - 2021-04-30 06:54:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:54:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:54:42 --> Total execution time: 0.1816
DEBUG - 2021-04-30 06:54:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:54:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:54:47 --> Total execution time: 0.1759
DEBUG - 2021-04-30 06:54:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:54:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:54:57 --> Total execution time: 0.1575
DEBUG - 2021-04-30 06:54:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:54:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:54:59 --> Total execution time: 0.1466
DEBUG - 2021-04-30 06:55:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:55:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:55:02 --> Total execution time: 0.1908
DEBUG - 2021-04-30 06:55:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:55:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:55:05 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 06:55:05 --> Total execution time: 0.1244
DEBUG - 2021-04-30 06:55:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:55:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:55:09 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 06:55:09 --> Total execution time: 0.1445
DEBUG - 2021-04-30 06:55:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:55:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:55:17 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 06:55:17 --> Total execution time: 0.1384
DEBUG - 2021-04-30 06:55:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:55:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:55:46 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 06:55:46 --> Total execution time: 0.1437
DEBUG - 2021-04-30 06:56:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:56:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:56:47 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 06:56:47 --> Total execution time: 0.1557
DEBUG - 2021-04-30 06:56:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:56:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:56:53 --> get_sorce_lan_word_type_16->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 06:56:53 --> Total execution time: 0.1315
DEBUG - 2021-04-30 06:56:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:56:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:56:58 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 06:56:58 --> Total execution time: 0.1243
DEBUG - 2021-04-30 06:57:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:57:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:57:02 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 06:57:02 --> Total execution time: 0.0979
DEBUG - 2021-04-30 06:57:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:57:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:57:06 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 06:57:06 --> Total execution time: 0.1469
DEBUG - 2021-04-30 06:57:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:57:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:57:10 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 06:57:10 --> Total execution time: 0.1676
DEBUG - 2021-04-30 06:57:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:57:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:57:14 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 06:57:14 --> Total execution time: 0.1483
DEBUG - 2021-04-30 06:57:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:57:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:57:19 --> get_sorce_lan_word_type_5->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 06:57:19 --> Total execution time: 0.1498
DEBUG - 2021-04-30 06:57:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:57:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:57:28 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 06:57:28 --> Total execution time: 0.1419
DEBUG - 2021-04-30 06:57:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:57:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:57:33 --> get_sorce_lan_word_type_7->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 06:57:33 --> Total execution time: 0.1044
DEBUG - 2021-04-30 06:57:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:57:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:57:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 06:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 06:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 06:57:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 06:57:50 --> Total execution time: 0.1194
DEBUG - 2021-04-30 07:01:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:01:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:01:23 --> Total execution time: 0.1454
DEBUG - 2021-04-30 07:01:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:01:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:01:41 --> Total execution time: 0.1117
DEBUG - 2021-04-30 07:01:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:01:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:01:46 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:01:46 --> Total execution time: 0.1741
DEBUG - 2021-04-30 07:01:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:01:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:01:50 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:01:50 --> Total execution time: 0.1347
DEBUG - 2021-04-30 07:01:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:01:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:01:54 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:01:54 --> Total execution time: 0.1419
DEBUG - 2021-04-30 07:03:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:03:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:03:31 --> Total execution time: 0.1691
DEBUG - 2021-04-30 07:03:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:03:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:03:35 --> Total execution time: 0.1154
DEBUG - 2021-04-30 07:03:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:03:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:03:42 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:03:42 --> Total execution time: 0.1484
DEBUG - 2021-04-30 07:03:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:03:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:03:46 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-04-30 07:03:46 --> Total execution time: 0.1159
DEBUG - 2021-04-30 07:04:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:04:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:04:30 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:04:30 --> Total execution time: 0.1359
DEBUG - 2021-04-30 07:05:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:05:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:05:41 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-04-30 07:05:41 --> Total execution time: 0.1462
DEBUG - 2021-04-30 07:06:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:06:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:06:36 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 07:06:36 --> Total execution time: 0.1695
DEBUG - 2021-04-30 07:06:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:06:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:06:40 --> Total execution time: 0.1304
DEBUG - 2021-04-30 07:06:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:06:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:06:44 --> Total execution time: 0.1428
DEBUG - 2021-04-30 07:06:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:06:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:06:49 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:06:49 --> Total execution time: 0.1711
DEBUG - 2021-04-30 07:06:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:06:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:06:56 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:06:56 --> Total execution time: 0.1083
DEBUG - 2021-04-30 07:07:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:07:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:07:01 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:07:01 --> Total execution time: 0.1438
DEBUG - 2021-04-30 07:10:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:10:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:10:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:10:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:10:03 --> Total execution time: 0.1188
DEBUG - 2021-04-30 07:10:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:10:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:10:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-30 07:10:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:10:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:10:29 --> Total execution time: 0.0984
DEBUG - 2021-04-30 07:10:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:10:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:10:31 --> Total execution time: 0.2183
DEBUG - 2021-04-30 07:10:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:10:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:10:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-30 07:10:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:10:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:10:34 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:10:34 --> Total execution time: 0.1476
DEBUG - 2021-04-30 07:10:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:10:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:10:34 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-04-30 07:10:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:10:36 --> UTF-8 Support Enabled
ERROR - 2021-04-30 07:10:36 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-04-30 07:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:10:36 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-04-30 07:10:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:10:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:10:39 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:10:39 --> Total execution time: 0.1457
DEBUG - 2021-04-30 07:10:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:10:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:10:41 --> Total execution time: 0.1286
DEBUG - 2021-04-30 07:10:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:10:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:10:43 --> Total execution time: 0.1654
DEBUG - 2021-04-30 07:10:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:10:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:10:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-30 07:10:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:10:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:10:48 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:10:48 --> Total execution time: 0.1439
DEBUG - 2021-04-30 07:10:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:10:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:10:51 --> Total execution time: 0.1586
DEBUG - 2021-04-30 07:10:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:10:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:10:53 --> Total execution time: 0.1134
DEBUG - 2021-04-30 07:10:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:10:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:10:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-30 07:10:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:10:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:10:58 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:10:58 --> Total execution time: 0.1680
DEBUG - 2021-04-30 07:11:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:11:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:11:13 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:11:13 --> Total execution time: 0.1471
DEBUG - 2021-04-30 07:11:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:11:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:11:36 --> Total execution time: 0.1428
DEBUG - 2021-04-30 07:11:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:11:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:11:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-30 07:11:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:11:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:11:45 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:11:45 --> Total execution time: 0.1605
DEBUG - 2021-04-30 07:11:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:11:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:11:58 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 07:11:58 --> Total execution time: 0.1755
DEBUG - 2021-04-30 07:12:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:12:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:12:00 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:12:00 --> Total execution time: 0.1594
DEBUG - 2021-04-30 07:12:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:12:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:12:04 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:12:04 --> Total execution time: 0.1441
DEBUG - 2021-04-30 07:12:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:12:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:12:56 --> Total execution time: 0.1757
DEBUG - 2021-04-30 07:12:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:12:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:12:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-30 07:13:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:13:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:13:19 --> Total execution time: 0.1797
DEBUG - 2021-04-30 07:13:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:13:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:13:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-30 07:13:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:13:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:13:24 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-04-30 07:13:24 --> Total execution time: 0.1598
DEBUG - 2021-04-30 07:13:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:13:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:13:28 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:13:28 --> Total execution time: 0.1437
DEBUG - 2021-04-30 07:13:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:13:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:13:34 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-04-30 07:13:34 --> Total execution time: 0.1412
DEBUG - 2021-04-30 07:13:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:13:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:13:35 --> Total execution time: 0.1709
DEBUG - 2021-04-30 07:13:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:13:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:13:38 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 07:13:38 --> Total execution time: 0.1788
DEBUG - 2021-04-30 07:13:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:13:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:13:42 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-04-30 07:13:42 --> Total execution time: 0.1500
DEBUG - 2021-04-30 07:13:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:13:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:13:43 --> Total execution time: 0.1378
DEBUG - 2021-04-30 07:13:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:13:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:13:47 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:13:47 --> Total execution time: 0.1189
DEBUG - 2021-04-30 07:13:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:13:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:13:51 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:13:51 --> Total execution time: 0.1614
DEBUG - 2021-04-30 07:13:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:13:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:13:55 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:13:55 --> Total execution time: 0.1448
DEBUG - 2021-04-30 07:14:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:14:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:14:04 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:14:04 --> Total execution time: 0.1706
DEBUG - 2021-04-30 07:14:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:14:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:14:08 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 07:14:08 --> Total execution time: 0.1169
DEBUG - 2021-04-30 07:14:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:14:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:14:14 --> get_sorce_lan_word_type_16->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 07:14:14 --> Total execution time: 0.1475
DEBUG - 2021-04-30 07:14:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:14:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:14:18 --> get_exercise_type_list->{"lang":"37","subcategory_id":"13","support_lang_id":"3"}
DEBUG - 2021-04-30 07:14:18 --> Total execution time: 0.1433
DEBUG - 2021-04-30 07:14:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:14:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:14:20 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:14:20 --> Total execution time: 0.1458
DEBUG - 2021-04-30 07:38:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:38:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:38:45 --> Total execution time: 0.1823
DEBUG - 2021-04-30 07:38:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:38:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:38:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-30 07:38:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:38:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:38:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-30 07:38:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:38:56 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-30 07:39:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:39:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:39:18 --> Total execution time: 0.1967
DEBUG - 2021-04-30 07:39:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:39:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:39:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-30 07:39:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:39:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:39:26 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-30 07:41:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:41:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:44:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:44:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:45:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:46:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:46:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:46:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:46:02 --> Total execution time: 0.1511
DEBUG - 2021-04-30 07:46:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:46:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:46:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-30 07:46:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:46:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:46:16 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-04-30 07:46:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:46:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:46:19 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-04-30 07:46:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:46:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:46:23 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-04-30 07:46:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:46:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:46:35 --> Total execution time: 0.1673
DEBUG - 2021-04-30 07:46:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:46:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:46:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-30 07:46:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:46:45 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-30 07:47:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:47:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:47:03 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-04-30 07:47:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:47:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:47:03 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-04-30 07:47:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:47:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:47:06 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-04-30 07:47:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:47:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:47:06 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-30 07:47:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:47:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-30 07:47:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/langoalphademo/public_html/indylan/application/controllers/Admin_master.php 943
DEBUG - 2021-04-30 07:47:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:47:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:47:21 --> Total execution time: 0.1568
DEBUG - 2021-04-30 07:47:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:47:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:47:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-30 07:47:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:47:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:47:41 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-04-30 07:47:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:47:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:47:42 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-30 07:47:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:47:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:47:42 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-04-30 07:47:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:47:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:47:42 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-04-30 07:47:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:47:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-30 07:47:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/langoalphademo/public_html/indylan/application/controllers/Admin_master.php 943
DEBUG - 2021-04-30 07:47:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:47:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:47:54 --> Total execution time: 0.1720
DEBUG - 2021-04-30 07:47:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:47:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:47:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-30 07:48:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:48:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:48:06 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-04-30 07:48:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:48:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:48:06 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-04-30 07:48:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:48:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:48:06 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-04-30 07:48:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:48:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:48:06 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-30 07:52:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:52:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:52:18 --> Total execution time: 0.1627
DEBUG - 2021-04-30 07:52:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:52:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:52:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-30 07:52:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:52:26 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-04-30 07:52:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:52:26 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-30 07:52:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:52:26 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-04-30 07:52:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:52:26 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-04-30 07:54:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:54:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:54:56 --> Total execution time: 0.1732
DEBUG - 2021-04-30 07:54:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:54:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-30 07:55:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:55:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:55:03 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-04-30 07:55:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:55:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:55:04 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-30 07:55:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:55:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:55:05 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-04-30 07:55:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:55:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:55:05 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-04-30 07:55:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:55:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-04-30 07:55:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/langoalphademo/public_html/indylan/application/controllers/Admin_master.php 946
DEBUG - 2021-04-30 07:55:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:55:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:55:13 --> Total execution time: 0.1465
DEBUG - 2021-04-30 07:55:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:55:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:55:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-30 07:55:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:55:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:55:26 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-30 07:55:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:55:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:55:26 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-04-30 07:55:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:55:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:55:26 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-04-30 07:55:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:55:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:55:27 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-04-30 07:57:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:57:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:57:22 --> Total execution time: 0.1619
DEBUG - 2021-04-30 07:57:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:57:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-30 07:57:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:57:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:57:39 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-30 07:57:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:57:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:57:39 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-04-30 07:57:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:57:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:57:40 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-04-30 07:57:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:57:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:57:42 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-04-30 07:57:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:57:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:57:47 --> Total execution time: 0.1804
DEBUG - 2021-04-30 07:57:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:57:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:57:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-30 07:57:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:57:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:57:55 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-30 07:58:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:58:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:58:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:58:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:58:58 --> Total execution time: 0.1610
DEBUG - 2021-04-30 07:59:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:59:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:59:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-30 07:59:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:59:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:59:05 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-04-30 07:59:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:59:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:59:05 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-30 07:59:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:59:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:59:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:59:06 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-04-30 07:59:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:59:06 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-04-30 07:59:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:59:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:59:23 --> Total execution time: 0.1729
DEBUG - 2021-04-30 07:59:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:59:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:59:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-04-30 07:59:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:59:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-30 07:59:30 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-30 07:59:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:59:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:59:48 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:59:48 --> Total execution time: 0.1416
DEBUG - 2021-04-30 07:59:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:59:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:59:51 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-04-30 07:59:51 --> Total execution time: 0.1468
DEBUG - 2021-04-30 07:59:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 07:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 07:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 07:59:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 07:59:55 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 07:59:55 --> Total execution time: 0.1788
DEBUG - 2021-04-30 08:00:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 08:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 08:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 08:00:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 08:00:05 --> get_sorce_lan_word_type_16->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 08:00:05 --> Total execution time: 0.1037
DEBUG - 2021-04-30 08:00:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-30 08:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-30 08:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-30 08:00:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-04-30 08:00:11 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-04-30 08:00:11 --> Total execution time: 0.1383
