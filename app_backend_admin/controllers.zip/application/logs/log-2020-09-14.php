<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-09-14 07:05:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 07:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 07:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 07:05:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 07:05:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 07:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 07:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 07:05:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 07:05:46 --> Total execution time: 0.1859
DEBUG - 2020-09-14 07:06:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 07:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 07:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 07:06:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 07:06:36 --> Total execution time: 0.1548
DEBUG - 2020-09-14 07:07:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 07:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 07:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 07:07:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 07:07:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 07:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 07:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 07:07:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 07:07:25 --> Total execution time: 0.1704
DEBUG - 2020-09-14 07:07:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 07:07:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 07:07:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-14 07:07:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 07:07:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 07:07:30 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-14 07:07:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 07:07:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 07:07:33 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-09-14 07:15:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 07:15:25 --> No URI present. Default controller set.
DEBUG - 2020-09-14 07:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 07:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 07:15:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 07:15:26 --> Total execution time: 0.1596
DEBUG - 2020-09-14 07:15:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 07:15:28 --> No URI present. Default controller set.
DEBUG - 2020-09-14 07:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 07:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 07:15:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 07:15:28 --> Total execution time: 0.1284
DEBUG - 2020-09-14 07:47:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 07:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 07:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 07:47:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 07:47:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 07:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 07:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 07:47:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 07:47:58 --> Total execution time: 0.1553
DEBUG - 2020-09-14 07:48:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 07:48:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 07:48:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-14 07:48:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 07:48:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 07:48:05 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-14 07:48:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 07:48:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 07:48:09 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-09-14 07:49:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 07:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 07:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 07:49:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 07:49:10 --> Total execution time: 0.1788
DEBUG - 2020-09-14 08:19:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 08:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 08:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 08:19:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 08:19:41 --> Total execution time: 0.1731
DEBUG - 2020-09-14 08:19:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 08:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 08:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 08:19:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 08:19:44 --> Total execution time: 0.1497
DEBUG - 2020-09-14 08:19:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 08:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 08:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 08:19:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 08:19:50 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2020-09-14 08:19:50 --> Total execution time: 0.1084
DEBUG - 2020-09-14 08:19:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 08:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 08:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 08:19:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 08:19:54 --> get_subcategory_list->{"lang":"37","category_id":"67","user_id":"1","support_lang_id":"1"}
DEBUG - 2020-09-14 08:19:54 --> Total execution time: 0.1427
DEBUG - 2020-09-14 08:19:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 08:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 08:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 08:19:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 08:19:57 --> get_exercise_type_list->{"lang":"37","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2020-09-14 08:19:57 --> Total execution time: 0.1424
DEBUG - 2020-09-14 08:20:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 08:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 08:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 08:20:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 08:20:03 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"1","exercise_mode_id":"1","category_id":"67","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2020-09-14 08:20:03 --> Total execution time: 0.1991
DEBUG - 2020-09-14 08:20:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 08:20:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 08:20:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 08:20:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 08:20:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 08:20:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 08:20:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 08:20:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 08:20:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 08:20:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 08:20:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 08:20:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 08:20:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 08:20:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 08:20:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 08:20:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 08:20:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 08:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 08:20:09 --> UTF-8 Support Enabled
ERROR - 2020-09-14 08:20:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 08:20:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 08:20:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 08:20:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 08:20:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 08:31:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 08:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 08:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 08:31:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 08:31:18 --> Total execution time: 0.1892
DEBUG - 2020-09-14 09:56:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:56:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:56:43 --> user_login->{"email":"admin@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2020-09-14 09:56:43 --> Total execution time: 0.1525
DEBUG - 2020-09-14 09:56:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:56:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:56:47 --> Total execution time: 0.1560
DEBUG - 2020-09-14 09:56:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:56:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:56:51 --> Total execution time: 0.1405
DEBUG - 2020-09-14 09:56:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:56:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:56:56 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2020-09-14 09:56:56 --> Total execution time: 0.1110
DEBUG - 2020-09-14 09:57:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:57:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:57:07 --> get_subcategory_list->{"lang":"37","category_id":"67","user_id":"1","support_lang_id":"1"}
DEBUG - 2020-09-14 09:57:07 --> Total execution time: 0.1639
DEBUG - 2020-09-14 09:57:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:57:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:57:11 --> get_exercise_type_list->{"lang":"37","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2020-09-14 09:57:11 --> Total execution time: 0.1316
DEBUG - 2020-09-14 09:57:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:57:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:57:21 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"1","exercise_mode_id":"1","category_id":"67","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2020-09-14 09:57:21 --> Total execution time: 0.2161
DEBUG - 2020-09-14 09:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 09:57:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 09:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 09:57:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 09:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 09:57:25 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 09:57:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 09:57:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:57:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:57:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 09:57:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 09:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:57:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:57:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:57:28 --> get_exercise_type_list->{"lang":"37","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2020-09-14 09:57:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:57:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 09:57:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 09:57:28 --> Total execution time: 0.1418
DEBUG - 2020-09-14 09:57:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:57:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 09:57:28 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 09:57:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 09:57:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:57:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:57:29 --> get_subcategory_list->{"lang":"37","category_id":"67","user_id":"1","support_lang_id":"1"}
DEBUG - 2020-09-14 09:57:29 --> Total execution time: 0.1076
DEBUG - 2020-09-14 09:57:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:57:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:57:30 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2020-09-14 09:57:30 --> Total execution time: 0.1197
DEBUG - 2020-09-14 09:57:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:57:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:57:31 --> Total execution time: 0.1581
DEBUG - 2020-09-14 09:57:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:57:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:57:42 --> Total execution time: 0.1725
DEBUG - 2020-09-14 09:57:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:57:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:57:46 --> Total execution time: 0.1007
DEBUG - 2020-09-14 09:57:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:57:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:57:51 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 09:57:51 --> Total execution time: 0.1031
DEBUG - 2020-09-14 09:57:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:57:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:57:55 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 09:57:55 --> Total execution time: 0.1452
DEBUG - 2020-09-14 09:57:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:57:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:57:59 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-14 09:57:59 --> Total execution time: 0.1744
DEBUG - 2020-09-14 09:58:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:58:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:58:03 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"3","exercise_mode_id":"1","category_id":"62","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-14 09:58:03 --> Total execution time: 0.1559
DEBUG - 2020-09-14 09:58:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 09:58:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 09:58:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:58:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 09:58:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 09:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 09:58:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 09:58:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 09:58:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 09:58:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:58:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:58:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:58:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:58:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 09:58:09 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 09:58:09 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 09:58:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 09:58:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 09:58:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 09:58:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:58:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:58:36 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-14 09:58:36 --> Total execution time: 0.1596
DEBUG - 2020-09-14 09:58:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:58:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:58:37 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 09:58:37 --> Total execution time: 0.1369
DEBUG - 2020-09-14 09:58:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:58:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:58:40 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 09:58:40 --> Total execution time: 0.1275
DEBUG - 2020-09-14 09:58:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:58:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:58:52 --> Total execution time: 0.1563
DEBUG - 2020-09-14 09:58:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:58:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:58:56 --> Total execution time: 0.1435
DEBUG - 2020-09-14 09:59:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:59:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:59:03 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 09:59:03 --> Total execution time: 0.1540
DEBUG - 2020-09-14 09:59:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:59:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:59:07 --> get_subcategory_list->{"lang":"37","category_id":"51","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 09:59:07 --> Total execution time: 0.1142
DEBUG - 2020-09-14 09:59:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:59:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:59:11 --> get_exercise_type_list->{"lang":"37","subcategory_id":"106","support_lang_id":"3"}
DEBUG - 2020-09-14 09:59:11 --> Total execution time: 0.1748
DEBUG - 2020-09-14 09:59:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:59:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:59:15 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"3","exercise_mode_id":"1","category_id":"51","subcategory_id":"106","support_lang_id":"3"}
DEBUG - 2020-09-14 09:59:15 --> Total execution time: 0.1465
DEBUG - 2020-09-14 09:59:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:59:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 09:59:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 09:59:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:59:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:59:19 --> get_exercise_type_list->{"lang":"37","subcategory_id":"106","support_lang_id":"3"}
DEBUG - 2020-09-14 09:59:19 --> Total execution time: 0.1570
DEBUG - 2020-09-14 09:59:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:59:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:59:20 --> get_subcategory_list->{"lang":"37","category_id":"51","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 09:59:20 --> Total execution time: 0.1176
DEBUG - 2020-09-14 09:59:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:59:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:59:20 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 09:59:20 --> Total execution time: 0.1161
DEBUG - 2020-09-14 09:59:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:59:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:59:23 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2020-09-14 09:59:23 --> Total execution time: 0.1170
DEBUG - 2020-09-14 09:59:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:59:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:59:24 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 09:59:24 --> Total execution time: 0.1280
DEBUG - 2020-09-14 09:59:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:59:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:59:25 --> get_exercise_type_list->{"lang":"37","subcategory_id":"106","support_lang_id":"3"}
DEBUG - 2020-09-14 09:59:25 --> Total execution time: 0.1413
DEBUG - 2020-09-14 09:59:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:59:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 09:59:26 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-09-14 09:59:26 --> Total execution time: 0.1611
DEBUG - 2020-09-14 09:59:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:59:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:59:29 --> get_exercise_type_list->{"lang":"37","subcategory_id":"106","support_lang_id":"3"}
DEBUG - 2020-09-14 09:59:29 --> Total execution time: 0.1413
DEBUG - 2020-09-14 09:59:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:59:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:59:29 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 09:59:29 --> Total execution time: 0.1513
DEBUG - 2020-09-14 09:59:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:59:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:59:30 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2020-09-14 09:59:30 --> Total execution time: 0.1000
DEBUG - 2020-09-14 09:59:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:59:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:59:33 --> get_subcategory_list->{"lang":"37","category_id":"98","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 09:59:33 --> Total execution time: 0.1349
DEBUG - 2020-09-14 09:59:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:59:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:59:35 --> get_exercise_type_list->{"lang":"37","subcategory_id":"102","support_lang_id":"3"}
DEBUG - 2020-09-14 09:59:35 --> Total execution time: 0.1278
DEBUG - 2020-09-14 09:59:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:59:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 09:59:36 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-09-14 09:59:36 --> Total execution time: 0.1429
DEBUG - 2020-09-14 09:59:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:59:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:59:38 --> get_exercise_type_list->{"lang":"37","subcategory_id":"102","support_lang_id":"3"}
DEBUG - 2020-09-14 09:59:38 --> Total execution time: 0.1195
DEBUG - 2020-09-14 09:59:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:59:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 09:59:45 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-09-14 09:59:45 --> Total execution time: 0.1451
DEBUG - 2020-09-14 09:59:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:59:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 09:59:49 --> get_exercise_type_list->{"lang":"37","subcategory_id":"102","support_lang_id":"3"}
DEBUG - 2020-09-14 09:59:49 --> Total execution time: 0.1440
DEBUG - 2020-09-14 09:59:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 09:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 09:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 09:59:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 09:59:53 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-09-14 09:59:53 --> Total execution time: 0.1461
DEBUG - 2020-09-14 10:26:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 10:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 10:26:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 10:26:47 --> Total execution time: 0.1158
DEBUG - 2020-09-14 10:26:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 10:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 10:26:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 10:26:58 --> Total execution time: 0.1348
DEBUG - 2020-09-14 10:27:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 10:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 10:27:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 10:27:06 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-14 10:27:06 --> Total execution time: 0.1405
DEBUG - 2020-09-14 10:27:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:27:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 10:27:19 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-14 10:27:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 10:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 10:27:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 10:27:22 --> get_subcategory_list->{"lang":"37","category_id":"68","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-14 10:27:22 --> Total execution time: 0.1555
DEBUG - 2020-09-14 10:27:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 10:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 10:27:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 10:27:26 --> get_exercise_type_list->{"lang":"37","subcategory_id":"119","support_lang_id":"2"}
DEBUG - 2020-09-14 10:27:26 --> Total execution time: 0.1498
DEBUG - 2020-09-14 10:27:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 10:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 10:27:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 10:27:32 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"2","exercise_mode_id":"1","category_id":"68","subcategory_id":"119","support_lang_id":"2"}
DEBUG - 2020-09-14 10:27:32 --> Total execution time: 0.1644
DEBUG - 2020-09-14 10:27:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:27:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 10:27:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 10:27:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:27:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 10:27:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 10:27:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:27:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 10:27:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 10:27:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:27:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 10:27:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 10:27:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 10:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 10:27:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 10:27:43 --> get_exercise_type_list->{"lang":"37","subcategory_id":"119","support_lang_id":"2"}
DEBUG - 2020-09-14 10:27:43 --> Total execution time: 0.1393
DEBUG - 2020-09-14 10:27:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 10:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 10:27:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 10:27:44 --> get_subcategory_list->{"lang":"37","category_id":"68","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-14 10:27:44 --> Total execution time: 0.1306
DEBUG - 2020-09-14 10:27:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 10:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 10:27:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 10:27:45 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-14 10:27:45 --> Total execution time: 0.1341
DEBUG - 2020-09-14 10:27:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:27:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 10:27:50 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-14 10:27:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:27:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 10:27:52 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-14 10:27:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 10:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 10:27:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 10:27:58 --> get_subcategory_list->{"lang":"37","category_id":"128","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-14 10:27:58 --> Total execution time: 0.0962
DEBUG - 2020-09-14 10:28:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 10:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 10:28:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 10:28:03 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-14 10:28:03 --> Total execution time: 0.1134
DEBUG - 2020-09-14 10:28:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:28:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 10:28:05 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-14 10:28:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 10:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 10:28:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 10:28:08 --> get_subcategory_list->{"lang":"37","category_id":"111","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-14 10:28:08 --> Total execution time: 0.1128
DEBUG - 2020-09-14 10:28:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:28:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 10:28:09 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-14 10:28:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 10:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 10:28:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 10:28:13 --> get_exercise_type_list->{"lang":"37","subcategory_id":"268","support_lang_id":"2"}
DEBUG - 2020-09-14 10:28:13 --> Total execution time: 0.1341
DEBUG - 2020-09-14 10:28:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 10:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 10:28:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 10:28:17 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"2","exercise_mode_id":"1","category_id":"111","subcategory_id":"268","support_lang_id":"2"}
DEBUG - 2020-09-14 10:28:17 --> Total execution time: 0.1483
DEBUG - 2020-09-14 10:28:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 10:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 10:28:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 10:28:22 --> get_exercise_type_list->{"lang":"37","subcategory_id":"268","support_lang_id":"2"}
DEBUG - 2020-09-14 10:28:22 --> Total execution time: 0.2118
DEBUG - 2020-09-14 10:33:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:33:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 10:33:15 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-14 10:33:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 10:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 10:33:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 10:33:16 --> get_subcategory_list->{"lang":"37","category_id":"111","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-14 10:33:16 --> Total execution time: 0.1068
DEBUG - 2020-09-14 10:33:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:33:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 10:33:17 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-14 10:33:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 10:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 10:33:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 10:33:18 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-14 10:33:18 --> Total execution time: 0.1142
DEBUG - 2020-09-14 10:33:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 10:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 10:33:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 10:33:21 --> Total execution time: 0.1270
DEBUG - 2020-09-14 10:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 10:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 10:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 10:49:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 10:49:37 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"123","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-09-14 10:49:37 --> Total execution time: 0.1565
DEBUG - 2020-09-14 11:01:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:01:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:01:06 --> Total execution time: 0.1684
DEBUG - 2020-09-14 11:01:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:01:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:01:25 --> Total execution time: 0.1232
DEBUG - 2020-09-14 11:03:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:03:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:03:16 --> Total execution time: 0.1464
DEBUG - 2020-09-14 11:03:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:03:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:03:39 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 11:03:39 --> Total execution time: 0.1060
DEBUG - 2020-09-14 11:03:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:03:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:03:49 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-14 11:03:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:03:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:03:51 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-14 11:04:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:04:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:04:07 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 11:04:07 --> Total execution time: 0.1734
DEBUG - 2020-09-14 11:04:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:04:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:04:12 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-14 11:04:12 --> Total execution time: 0.1259
DEBUG - 2020-09-14 11:04:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:04:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:04:18 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"3","exercise_mode_id":"1","category_id":"62","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-14 11:04:18 --> Total execution time: 0.1414
DEBUG - 2020-09-14 11:04:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:04:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:04:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:04:21 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:04:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:04:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:04:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:04:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:04:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:04:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:04:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:04:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:04:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:04:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:04:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:04:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:04:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:04:24 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:04:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:05:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:05:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:05:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:05:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:05:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:05:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:05:29 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:05:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:05:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:05:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:05:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:05:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:05:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:05:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:05:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:05:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:05:33 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:05:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:05:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:05:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:06:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:06:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:06:08 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-14 11:06:08 --> Total execution time: 0.1089
DEBUG - 2020-09-14 11:06:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:06:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:06:11 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 11:06:11 --> Total execution time: 0.1445
DEBUG - 2020-09-14 11:06:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:06:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:06:20 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 11:06:20 --> Total execution time: 0.1460
DEBUG - 2020-09-14 11:06:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:06:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:06:34 --> get_subcategory_list->{"lang":"37","category_id":"51","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 11:06:34 --> Total execution time: 0.1036
DEBUG - 2020-09-14 11:07:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:07:15 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"123","subcategory_id":"106","support_lang_id":"3"}
DEBUG - 2020-09-14 11:07:15 --> Total execution time: 0.1189
DEBUG - 2020-09-14 11:07:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:07:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:07:21 --> get_exercise_type_list->{"lang":"37","subcategory_id":"106","support_lang_id":"3"}
DEBUG - 2020-09-14 11:07:21 --> Total execution time: 0.1635
DEBUG - 2020-09-14 11:07:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:07:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:07:25 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"3","exercise_mode_id":"1","category_id":"51","subcategory_id":"106","support_lang_id":"3"}
DEBUG - 2020-09-14 11:07:25 --> Total execution time: 0.1634
DEBUG - 2020-09-14 11:07:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:07:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:07:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:07:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:07:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:07:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:07:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:07:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:07:32 --> get_exercise_type_list->{"lang":"37","subcategory_id":"106","support_lang_id":"3"}
DEBUG - 2020-09-14 11:07:32 --> Total execution time: 0.1320
DEBUG - 2020-09-14 11:07:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:07:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:07:49 --> get_subcategory_list->{"lang":"37","category_id":"51","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 11:07:49 --> Total execution time: 0.1329
DEBUG - 2020-09-14 11:07:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:07:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:07:52 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 11:07:52 --> Total execution time: 0.1428
DEBUG - 2020-09-14 11:08:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:08:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:08:16 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"3","subcategory_id":"106","support_lang_id":"3"}
DEBUG - 2020-09-14 11:08:16 --> Total execution time: 0.1974
DEBUG - 2020-09-14 11:08:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:08:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:08:24 --> get_subcategory_list->{"lang":"37","category_id":"51","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 11:08:24 --> Total execution time: 0.1370
DEBUG - 2020-09-14 11:08:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:08:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:08:30 --> get_exercise_type_list->{"lang":"37","subcategory_id":"106","support_lang_id":"3"}
DEBUG - 2020-09-14 11:08:30 --> Total execution time: 0.1617
DEBUG - 2020-09-14 11:09:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:09:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:09:28 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"51","subcategory_id":"106","support_lang_id":"3"}
DEBUG - 2020-09-14 11:09:28 --> Total execution time: 0.1614
DEBUG - 2020-09-14 11:09:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:09:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:09:49 --> get_subcategory_list->{"lang":"37","category_id":"51","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 11:09:49 --> Total execution time: 0.1424
DEBUG - 2020-09-14 11:09:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:09:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:09:51 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 11:09:51 --> Total execution time: 0.1416
DEBUG - 2020-09-14 11:10:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:10:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:10:04 --> Total execution time: 0.1042
DEBUG - 2020-09-14 11:10:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:10:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:10:07 --> Total execution time: 0.1293
DEBUG - 2020-09-14 11:10:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:10:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:10:11 --> Total execution time: 0.1721
DEBUG - 2020-09-14 11:10:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:10:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:10:18 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-14 11:10:18 --> Total execution time: 0.2022
DEBUG - 2020-09-14 11:10:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:10:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:10:28 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-14 11:10:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:10:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:10:31 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-14 11:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:11:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:11:22 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"14","subcategory_id":"57","support_lang_id":"3"}
DEBUG - 2020-09-14 11:11:22 --> Total execution time: 0.1524
DEBUG - 2020-09-14 11:11:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:11:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:11:52 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-14 11:11:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:11:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:11:53 --> get_subcategory_list->{"lang":"37","category_id":"75","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-14 11:11:53 --> Total execution time: 0.1048
DEBUG - 2020-09-14 11:11:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:11:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:11:55 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-14 11:11:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:11:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:11:58 --> get_exercise_type_list->{"lang":"37","subcategory_id":"162","support_lang_id":"2"}
DEBUG - 2020-09-14 11:11:58 --> Total execution time: 0.1393
DEBUG - 2020-09-14 11:12:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:12:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:12:02 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"2","exercise_mode_id":"1","category_id":"75","subcategory_id":"162","support_lang_id":"2"}
DEBUG - 2020-09-14 11:12:02 --> Total execution time: 0.1303
DEBUG - 2020-09-14 11:12:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:12:06 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:12:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:12:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:12:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:12:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:12:06 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:12:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:12:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:12:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:12:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:12:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:12:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:12:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:12:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:12:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:12:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:12:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:12:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:12:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:12:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:12:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:12:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:12:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:12:20 --> get_exercise_type_list->{"lang":"37","subcategory_id":"162","support_lang_id":"2"}
DEBUG - 2020-09-14 11:12:20 --> Total execution time: 0.1257
DEBUG - 2020-09-14 11:12:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:12:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:12:21 --> get_subcategory_list->{"lang":"37","category_id":"75","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-14 11:12:21 --> Total execution time: 0.1577
DEBUG - 2020-09-14 11:13:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:13:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:13:16 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"55","subcategory_id":"154","support_lang_id":"3"}
DEBUG - 2020-09-14 11:13:16 --> Total execution time: 0.1482
DEBUG - 2020-09-14 11:13:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:13:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:13:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:19:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:19:00 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-14 11:19:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:19:03 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-14 11:19:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:11 --> No URI present. Default controller set.
DEBUG - 2020-09-14 11:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:19:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:19:11 --> Total execution time: 0.1596
DEBUG - 2020-09-14 11:19:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:19:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:19:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:19:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:19:27 --> Total execution time: 0.1558
DEBUG - 2020-09-14 11:19:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:19:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-14 11:19:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:19:30 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-14 11:19:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:19:32 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-09-14 11:19:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:19:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:19:38 --> Total execution time: 0.2028
DEBUG - 2020-09-14 11:19:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:19:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:19:40 --> Total execution time: 0.1368
DEBUG - 2020-09-14 11:19:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:19:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-14 11:19:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:19:44 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-14 11:19:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:19:44 --> 404 Page Not Found: Uploads/At__the_dentists.JPG
DEBUG - 2020-09-14 11:19:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:19:46 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-09-14 11:19:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:19:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:19:50 --> Total execution time: 0.1885
DEBUG - 2020-09-14 11:19:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:19:50 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-09-14 11:19:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:19:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 11:19:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-14 11:19:52 --> Total execution time: 0.2386
DEBUG - 2020-09-14 11:19:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:19:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-14 11:19:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:19:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:19:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:19:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:19:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:19:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:19:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:19:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:19:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:19:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:19:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:19:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:19:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:19:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:19:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:19:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:19:58 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:19:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:19:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:19:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:19:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:19:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:19:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:20:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:20:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:20:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:20:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:20:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:20:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:20:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:20:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:20:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:20:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:20:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:20:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:20:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:20:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:20:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:20:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:20:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:20:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:20:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:20:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:20:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:20:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:20:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:20:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:20:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:20:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:20:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:20:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:20:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:20:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:20:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:20:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:20:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:20:03 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:20:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:20:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:20:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:20:06 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:20:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:20:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:20:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:20:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:20:06 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:20:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:20:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:20:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:20:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:20:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:20:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:20:09 --> Total execution time: 0.1661
DEBUG - 2020-09-14 11:20:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:20:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:20:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-14 11:20:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:20:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:20:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:22:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:22:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:22:11 --> Total execution time: 0.1851
DEBUG - 2020-09-14 11:22:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:22:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:22:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-14 11:22:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:22:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:22:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:22:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:22:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:22:26 --> Total execution time: 0.1447
DEBUG - 2020-09-14 11:22:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:22:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:22:30 --> Total execution time: 0.1854
DEBUG - 2020-09-14 11:22:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:22:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:22:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-14 11:22:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:22:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:22:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:22:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:22:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:22:48 --> Total execution time: 0.1564
DEBUG - 2020-09-14 11:22:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:22:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:22:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:22:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 11:22:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-14 11:22:54 --> Total execution time: 0.2756
DEBUG - 2020-09-14 11:22:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:22:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:22:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:22:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:22:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:22:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:22:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:22:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:22:57 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:22:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-14 11:22:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:22:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:22:57 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:22:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:22:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:22:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:23:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:03 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:23:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:23:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:03 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:23:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:23:06 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:23:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:23:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:08 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:23:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:23:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:23:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:10 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:23:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:10 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:23:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:23:13 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:23:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:23:16 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:23:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:23:19 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:23:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:23:21 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:23:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:23:21 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:23:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:23:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:24 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:23:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:23:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:23:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:23:36 --> Total execution time: 0.1418
DEBUG - 2020-09-14 11:23:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-14 11:23:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:23:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:23:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:24:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:24:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:24:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 11:24:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-14 11:24:13 --> Total execution time: 0.2880
DEBUG - 2020-09-14 11:24:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-14 11:24:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:24:18 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:24:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:18 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:24:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:23 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:23 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:23 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:24:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:23 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:24:23 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:23 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:24:26 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:24:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:24:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:29 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:24:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:24:31 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:24:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:24:31 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:24:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:24:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:34 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:24:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:24:37 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:24:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:24:39 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:24:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:24:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:24:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:24:41 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:24:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:27:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 11:27:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-14 11:27:38 --> Total execution time: 0.2500
DEBUG - 2020-09-14 11:27:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:27:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 11:27:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-14 11:27:44 --> Total execution time: 0.3194
DEBUG - 2020-09-14 11:27:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-14 11:27:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:27:48 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:27:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:27:48 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:27:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:53 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:53 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:53 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:27:53 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:27:53 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:53 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:54 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:27:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:27:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:56 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:27:56 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:27:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:27:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:59 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:27:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:27:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:27:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:27:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:28:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:04 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:28:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:28:07 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:28:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:28:12 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:28:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:28:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:12 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:28:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:28:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 11:28:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-14 11:28:13 --> Total execution time: 0.4341
DEBUG - 2020-09-14 11:28:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:28:16 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:28:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:28:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:16 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:28:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-14 11:28:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:28:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:22 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:28:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:28:25 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:28:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:28:27 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:28:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:33 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:28:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:28:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 11:28:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-14 11:28:38 --> Total execution time: 0.4690
DEBUG - 2020-09-14 11:28:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:38 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:38 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:38 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:28:38 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:28:38 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:38 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:28:41 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:28:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:28:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 11:28:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-14 11:28:43 --> Total execution time: 0.2592
DEBUG - 2020-09-14 11:28:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:28:46 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:28:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:28:46 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:28:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-14 11:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:28:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:46 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:28:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:28:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:48 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:28:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:28:51 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:28:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:28:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:54 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:28:54 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:54 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:54 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:54 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:54 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:28:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:28:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:28:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:29:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:01 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:29:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:04 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:29:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:29:09 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:29:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:29:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 11:29:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-14 11:29:10 --> Total execution time: 0.2901
DEBUG - 2020-09-14 11:29:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-14 11:29:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:29:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 11:29:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-14 11:29:23 --> Total execution time: 0.2821
DEBUG - 2020-09-14 11:29:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-14 11:29:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:29:26 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:29:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:29:26 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:29:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:29:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:35 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:29:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:29:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:29:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:29:39 --> Total execution time: 0.1204
DEBUG - 2020-09-14 11:29:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:29:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:43 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:29:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:29:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 11:29:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-14 11:29:44 --> Total execution time: 0.2071
DEBUG - 2020-09-14 11:29:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:47 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-14 11:29:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:29:49 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:29:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:53 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:54 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:29:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:55 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:29:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:29:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:57 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:29:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:29:59 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:29:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:29:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:29:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:29:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:30:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:03 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:30:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:30:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:03 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:30:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:30:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:05 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:30:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:30:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:08 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:30:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:08 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:30:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:30:10 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:30:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:30:10 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:30:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:30:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:30:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:10 --> Total execution time: 0.1394
DEBUG - 2020-09-14 11:30:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:30:13 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:30:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:30:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:13 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:30:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:30:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 11:30:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-14 11:30:14 --> Total execution time: 0.2336
DEBUG - 2020-09-14 11:30:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-14 11:30:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:30:17 --> UTF-8 Support Enabled
ERROR - 2020-09-14 11:30:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:23 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:23 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:30:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:30 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:30:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:38 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:38 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:38 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:30:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:39 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-14 11:30:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:44 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:44 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:44 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:30:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:30:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:30:44 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:40:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:40:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:40:00 --> Total execution time: 0.1905
DEBUG - 2020-09-14 11:40:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:40:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:40:07 --> Total execution time: 0.1480
DEBUG - 2020-09-14 11:40:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:40:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:40:09 --> Total execution time: 0.1120
DEBUG - 2020-09-14 11:40:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:40:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:40:13 --> Total execution time: 0.1149
DEBUG - 2020-09-14 11:40:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:40:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:40:16 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 11:40:16 --> Total execution time: 0.1737
DEBUG - 2020-09-14 11:40:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:40:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:40:20 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 11:40:20 --> Total execution time: 0.1173
DEBUG - 2020-09-14 11:40:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:40:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:40:25 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-14 11:40:25 --> Total execution time: 0.1265
DEBUG - 2020-09-14 11:44:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:44:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:44:34 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"3","exercise_mode_id":"1","category_id":"62","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-14 11:44:34 --> Total execution time: 0.1530
DEBUG - 2020-09-14 11:44:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:44:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:44:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:44:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:44:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:44:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:44:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:44:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:44:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:44:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:44:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:44:38 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:44:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:44:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:44:39 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-14 11:44:39 --> Total execution time: 0.1791
DEBUG - 2020-09-14 11:44:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:44:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:44:46 --> get_sorce_lan_word_type_5->{"slang":"37","tlang":"3","exercise_mode_id":"1","category_id":"62","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-14 11:44:46 --> Total execution time: 0.1428
DEBUG - 2020-09-14 11:44:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:44:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:44:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:44:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:44:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:44:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:44:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:44:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:44:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:44:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-14 11:44:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-14 11:44:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:44:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:44:52 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-14 11:44:52 --> Total execution time: 0.1430
DEBUG - 2020-09-14 11:44:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-14 11:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-14 11:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-14 11:44:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 11:44:53 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-14 11:44:53 --> Total execution time: 0.1145
