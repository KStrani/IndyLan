<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-07-23 04:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:16:34 --> No URI present. Default controller set.
DEBUG - 2020-07-23 04:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:16:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:16:35 --> Total execution time: 0.9741
DEBUG - 2020-07-23 04:16:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:16:39 --> No URI present. Default controller set.
DEBUG - 2020-07-23 04:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:16:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:16:39 --> Total execution time: 0.1700
DEBUG - 2020-07-23 04:16:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:16:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-23 04:16:55 --> Query error: Unknown column 'statusc' in 'where clause' - Invalid query: select * from tbl_master_language WHERE statusc='1'
ERROR - 2020-07-23 04:16:55 --> Severity: error --> Exception: Call to a member function result_array() on boolean E:\xampp\htdocs\voolsy\langoadmin\application\models\Admin_model.php 32
DEBUG - 2020-07-23 04:17:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:17:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:17:00 --> Total execution time: 0.1411
DEBUG - 2020-07-23 04:17:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:17:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-23 04:17:16 --> Query error: Unknown column 'statusc' in 'where clause' - Invalid query: select * from tbl_master_language WHERE statusc='1'
ERROR - 2020-07-23 04:17:16 --> Severity: error --> Exception: Call to a member function result_array() on boolean E:\xampp\htdocs\voolsy\langoadmin\application\models\Admin_model.php 32
DEBUG - 2020-07-23 04:18:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:18:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:18:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:18:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-23 04:18:51 --> Query error: Unknown column 'statusc' in 'where clause' - Invalid query: select * from tbl_master_language WHERE statusc='1'
ERROR - 2020-07-23 04:18:51 --> Severity: error --> Exception: Call to a member function result_array() on boolean E:\xampp\htdocs\voolsy\langoadmin\application\models\Admin_model.php 32
DEBUG - 2020-07-23 04:19:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:19:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-23 04:19:06 --> Query error: Unknown column 'statusc' in 'where clause' - Invalid query: select * from tbl_master_language WHERE statusc='1'
ERROR - 2020-07-23 04:19:06 --> Severity: error --> Exception: Call to a member function result_array() on boolean E:\xampp\htdocs\voolsy\langoadmin\application\models\Admin_model.php 32
DEBUG - 2020-07-23 04:20:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:20:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:21:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:21:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:22:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:23:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:23:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:23:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:23:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:23:03 --> Total execution time: 0.3121
DEBUG - 2020-07-23 04:23:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:23:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:23:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:23:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:23:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:23:09 --> Total execution time: 0.1478
DEBUG - 2020-07-23 04:23:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:23:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-23 04:23:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\header.php 86
DEBUG - 2020-07-23 04:23:09 --> Total execution time: 0.1684
DEBUG - 2020-07-23 04:23:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:23:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:23:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:23:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:23:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:23:10 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-23 04:23:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:23:10 --> No URI present. Default controller set.
DEBUG - 2020-07-23 04:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:23:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:23:10 --> Total execution time: 0.2165
DEBUG - 2020-07-23 04:23:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:23:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:23:10 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-23 04:23:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:23:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:23:11 --> No URI present. Default controller set.
DEBUG - 2020-07-23 04:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:23:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:23:11 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-23 04:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:23:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:23:11 --> Total execution time: 0.1635
DEBUG - 2020-07-23 04:23:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:23:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:23:12 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-23 04:24:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:24:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:24:07 --> Total execution time: 0.1474
DEBUG - 2020-07-23 04:24:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:24:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:24:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:24:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:24:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:24:07 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-23 04:24:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:24:07 --> No URI present. Default controller set.
DEBUG - 2020-07-23 04:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:24:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:24:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:24:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:24:07 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-23 04:24:07 --> Total execution time: 0.2566
DEBUG - 2020-07-23 04:24:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:24:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:24:08 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-23 04:24:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:24:08 --> No URI present. Default controller set.
DEBUG - 2020-07-23 04:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:24:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:24:08 --> Total execution time: 0.1409
DEBUG - 2020-07-23 04:24:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:24:09 --> No URI present. Default controller set.
DEBUG - 2020-07-23 04:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:24:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:24:09 --> Total execution time: 0.1369
DEBUG - 2020-07-23 04:24:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:24:09 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-23 04:24:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:24:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:24:14 --> Total execution time: 0.1293
DEBUG - 2020-07-23 04:24:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:24:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:24:14 --> Total execution time: 0.1132
DEBUG - 2020-07-23 04:24:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:24:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:24:15 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:36:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:36:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:36:12 --> Total execution time: 0.1514
DEBUG - 2020-07-23 04:36:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:36:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:36:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:36:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:36:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:36:58 --> Total execution time: 0.1429
DEBUG - 2020-07-23 04:36:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:36:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:36:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:37:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:37:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:37:17 --> Total execution time: 0.1125
DEBUG - 2020-07-23 04:37:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:37:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:37:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:37:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:37:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:37:20 --> Total execution time: 0.1455
DEBUG - 2020-07-23 04:37:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:37:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:37:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:43:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:43:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:43:26 --> Total execution time: 0.2198
DEBUG - 2020-07-23 04:43:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:43:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:43:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:43:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:43:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:43:30 --> Total execution time: 0.1986
DEBUG - 2020-07-23 04:43:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:43:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:43:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:43:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:43:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:43:32 --> Total execution time: 0.1768
DEBUG - 2020-07-23 04:43:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:43:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:43:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:43:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:43:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:43:34 --> Total execution time: 0.1728
DEBUG - 2020-07-23 04:43:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:43:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:43:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:43:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:43:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:43:36 --> Total execution time: 0.2163
DEBUG - 2020-07-23 04:43:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:43:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:43:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:43:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:43:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:43:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:43:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:43:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:43:52 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-23 04:44:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:44:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:44:07 --> Total execution time: 0.1365
DEBUG - 2020-07-23 04:44:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:44:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:44:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:44:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:44:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:44:08 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-23 04:44:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:44:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:44:21 --> Total execution time: 0.1862
DEBUG - 2020-07-23 04:44:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:44:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:44:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:44:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:44:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:44:26 --> Total execution time: 0.1283
DEBUG - 2020-07-23 04:44:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:44:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:44:27 --> Total execution time: 0.1201
DEBUG - 2020-07-23 04:44:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:44:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:44:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:44:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:44:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:44:30 --> Total execution time: 0.2064
DEBUG - 2020-07-23 04:44:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:44:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:44:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:44:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:44:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:44:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:44:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:44:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:44:35 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-23 04:46:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:46:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:46:09 --> Total execution time: 0.1374
DEBUG - 2020-07-23 04:46:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:46:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:46:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:46:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:46:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:46:10 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-23 04:48:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:48:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:48:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:48:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:48:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:48:19 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-23 04:52:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:52:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:52:40 --> Total execution time: 0.1258
DEBUG - 2020-07-23 04:52:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:52:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:52:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:52:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:52:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:52:41 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-23 04:57:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:57:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:57:30 --> Total execution time: 0.1613
DEBUG - 2020-07-23 04:57:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:57:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:57:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:57:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:57:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:57:31 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-23 04:57:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:57:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:57:54 --> Total execution time: 0.1353
DEBUG - 2020-07-23 04:57:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:57:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:57:55 --> Total execution time: 0.1519
DEBUG - 2020-07-23 04:57:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:57:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:57:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:57:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:57:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:57:56 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-23 04:57:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:58:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:58:00 --> Total execution time: 0.1631
DEBUG - 2020-07-23 04:58:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:58:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:58:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 04:58:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 04:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 04:58:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 04:58:03 --> Total execution time: 0.1545
DEBUG - 2020-07-23 04:58:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 04:58:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 04:58:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 05:04:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:04:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:04:28 --> Total execution time: 0.1679
DEBUG - 2020-07-23 05:04:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:04:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:04:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 05:05:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:05:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:05:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:05:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:05:39 --> Total execution time: 0.1467
DEBUG - 2020-07-23 05:05:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:05:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:05:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 05:06:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:06:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:06:59 --> Total execution time: 0.1585
DEBUG - 2020-07-23 05:06:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:06:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:06:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 05:07:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:07:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:07:02 --> Total execution time: 0.1371
DEBUG - 2020-07-23 05:07:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:07:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 05:07:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:07:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:07:39 --> Total execution time: 0.1177
DEBUG - 2020-07-23 05:07:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:07:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:07:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 05:11:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:11:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:11:18 --> Total execution time: 0.2381
DEBUG - 2020-07-23 05:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:11:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 05:11:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:11:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:11:24 --> Total execution time: 0.1482
DEBUG - 2020-07-23 05:11:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:11:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:11:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 05:11:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:11:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:11:46 --> Total execution time: 0.1166
DEBUG - 2020-07-23 05:11:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:11:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:11:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 05:12:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:12:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:12:15 --> Total execution time: 0.1384
DEBUG - 2020-07-23 05:12:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:12:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:12:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 05:13:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:13:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:15:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:15:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-23 05:15:23 --> Query error: Unknown column 'confirm_password' in 'field list' - Invalid query: INSERT INTO `tbl_admin` (`username`, `first_name`, `last_name`, `email`, `phone`, `password`, `confirm_password`, `support_lang_ids`, `save`) VALUES ('Testj', 'jhon ', 'doe', 'jhon@test.com', '9519519519', '123456', '123456', '3,4,5,6,7', 'save')
DEBUG - 2020-07-23 05:15:23 --> Total execution time: 0.2027
DEBUG - 2020-07-23 05:15:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:15:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:15:31 --> Total execution time: 0.1439
DEBUG - 2020-07-23 05:15:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:15:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:15:31 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 05:15:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:15:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:15:35 --> Total execution time: 0.1627
DEBUG - 2020-07-23 05:15:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:15:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:15:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 05:15:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:15:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:15:45 --> Total execution time: 0.1576
DEBUG - 2020-07-23 05:15:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:15:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:15:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 05:16:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:16:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-23 05:16:23 --> Query error: Unknown column 'confirm_password' in 'field list' - Invalid query: INSERT INTO `tbl_admin` (`username`, `first_name`, `last_name`, `email`, `phone`, `password`, `confirm_password`, `support_lang_ids`, `save`) VALUES ('tester', 'jhon', 'doe', 'jhondoe@test.com', '9519519519', '123456', '123456', '3,4,5,6', 'save')
DEBUG - 2020-07-23 05:16:23 --> Total execution time: 0.1230
DEBUG - 2020-07-23 05:18:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:18:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-23 05:18:21 --> Query error: Unknown column 'confirm_password' in 'field list' - Invalid query: INSERT INTO `tbl_admin` (`username`, `first_name`, `last_name`, `email`, `phone`, `password`, `confirm_password`, `support_lang_ids`, `save`) VALUES ('tester', 'jhon', 'doe', 'jhondoe@test.com', '9519519519', '123456', '123456', '3,4,5,6', 'save')
DEBUG - 2020-07-23 05:19:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:19:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:21:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:21:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-23 05:21:42 --> Severity: error --> Exception: syntax error, unexpected ',', expecting :: (T_PAAMAYIM_NEKUDOTAYIM) E:\xampp\htdocs\voolsy\langoadmin\application\models\Admin_model.php 101
DEBUG - 2020-07-23 05:23:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:23:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:23:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:24:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:24:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:24:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:24:47 --> Total execution time: 0.1373
DEBUG - 2020-07-23 05:24:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:24:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:24:47 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 05:24:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:24:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:24:54 --> Total execution time: 0.1586
DEBUG - 2020-07-23 05:24:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:24:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 05:25:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:25:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:25:29 --> Total execution time: 0.1283
DEBUG - 2020-07-23 05:25:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:25:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:25:29 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 05:25:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:25:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:25:53 --> Total execution time: 0.1584
DEBUG - 2020-07-23 05:25:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:25:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:25:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 05:26:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:26:01 --> 404 Page Not Found: Admin_master/edit_portaluser
DEBUG - 2020-07-23 05:28:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:28:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:28:47 --> Total execution time: 0.1249
DEBUG - 2020-07-23 05:28:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:28:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:28:49 --> Total execution time: 0.1724
DEBUG - 2020-07-23 05:28:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:28:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:28:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 05:30:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:30:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:30:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 05:30:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:30:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:30:21 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-23 05:35:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:35:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:35:22 --> Total execution time: 0.1341
DEBUG - 2020-07-23 05:35:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:35:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:35:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 05:35:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:35:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:35:23 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-23 05:35:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:35:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:35:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:35:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:35:38 --> Total execution time: 0.1354
DEBUG - 2020-07-23 05:35:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:35:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 05:35:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:35:38 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-23 05:36:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:36:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 05:36:03 --> Total execution time: 0.1196
DEBUG - 2020-07-23 05:36:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:36:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:36:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 05:36:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:36:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:36:04 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-23 05:42:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:42:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-23 05:42:22 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\edit_category.php 44
ERROR - 2020-07-23 05:42:22 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\edit_category.php 51
ERROR - 2020-07-23 05:42:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\edit_category.php 93
ERROR - 2020-07-23 05:42:22 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\edit_category.php 94
DEBUG - 2020-07-23 05:42:22 --> Total execution time: 0.1333
DEBUG - 2020-07-23 05:42:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:42:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:42:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 05:43:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 05:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 05:43:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-23 05:43:45 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\edit_users.php 79
DEBUG - 2020-07-23 05:43:45 --> Total execution time: 0.1517
DEBUG - 2020-07-23 05:43:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 05:43:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 05:43:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 06:25:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 06:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 06:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 06:25:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 06:25:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 06:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 06:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 06:25:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 06:26:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 06:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 06:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 06:26:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 06:34:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 06:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 06:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 06:34:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 06:34:31 --> Total execution time: 0.1442
DEBUG - 2020-07-23 06:34:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 06:34:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 06:34:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 06:34:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 06:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 06:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 06:34:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 06:34:36 --> Total execution time: 0.1707
DEBUG - 2020-07-23 06:34:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 06:34:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 06:34:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 06:36:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 06:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 06:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 06:36:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 06:37:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 06:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 06:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 06:37:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 06:37:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 06:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 06:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 06:37:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 06:37:46 --> Total execution time: 0.1460
DEBUG - 2020-07-23 06:37:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 06:37:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 06:37:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 06:54:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 06:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 06:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 06:54:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 06:54:38 --> Total execution time: 0.1277
DEBUG - 2020-07-23 06:54:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 06:54:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 06:54:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 07:37:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:37:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:37:04 --> Total execution time: 0.1364
DEBUG - 2020-07-23 07:37:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:37:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 07:38:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:38:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:38:06 --> Total execution time: 0.1653
DEBUG - 2020-07-23 07:38:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:38:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:38:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 07:40:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:40:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:40:00 --> Total execution time: 0.1604
DEBUG - 2020-07-23 07:40:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:40:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 07:40:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:40:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:40:05 --> Total execution time: 0.1948
DEBUG - 2020-07-23 07:40:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:40:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:40:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 07:40:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:40:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:40:24 --> Total execution time: 0.1499
DEBUG - 2020-07-23 07:40:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:40:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:40:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 07:40:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:40:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:40:40 --> Total execution time: 0.1519
DEBUG - 2020-07-23 07:40:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:40:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:40:41 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 07:42:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:42:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:42:27 --> Total execution time: 0.1676
DEBUG - 2020-07-23 07:42:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:42:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:42:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 07:42:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:42:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:42:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 07:42:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:42:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:42:34 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-23 07:42:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:42:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:42:51 --> Total execution time: 0.1689
DEBUG - 2020-07-23 07:42:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:42:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:42:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 07:42:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:42:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:42:52 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-23 07:43:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:43:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:43:50 --> Total execution time: 0.1589
DEBUG - 2020-07-23 07:43:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:43:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:43:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 07:43:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:43:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:43:51 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-23 07:45:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:45:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:45:49 --> Total execution time: 0.1764
DEBUG - 2020-07-23 07:45:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:45:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:45:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 07:45:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:45:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:45:52 --> Total execution time: 0.1557
DEBUG - 2020-07-23 07:45:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:45:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:45:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 07:45:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:45:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-23 07:45:57 --> Severity: error --> Exception: Too few arguments to function Admin_master::edit_portaluser(), 0 passed in E:\xampp\htdocs\voolsy\langoadmin\system\core\CodeIgniter.php on line 529 and exactly 1 expected E:\xampp\htdocs\voolsy\langoadmin\application\controllers\Admin_master.php 612
DEBUG - 2020-07-23 07:46:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:46:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-23 07:46:40 --> Severity: error --> Exception: Too few arguments to function Admin_master::edit_portaluser(), 0 passed in E:\xampp\htdocs\voolsy\langoadmin\system\core\CodeIgniter.php on line 529 and exactly 1 expected E:\xampp\htdocs\voolsy\langoadmin\application\controllers\Admin_master.php 612
DEBUG - 2020-07-23 07:47:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:47:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-23 07:47:14 --> Severity: error --> Exception: Too few arguments to function Admin_master::edit_portaluser(), 0 passed in E:\xampp\htdocs\voolsy\langoadmin\system\core\CodeIgniter.php on line 529 and exactly 1 expected E:\xampp\htdocs\voolsy\langoadmin\application\controllers\Admin_master.php 612
DEBUG - 2020-07-23 07:47:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:47:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-23 07:47:29 --> Severity: error --> Exception: Too few arguments to function Admin_master::edit_portaluser(), 0 passed in E:\xampp\htdocs\voolsy\langoadmin\system\core\CodeIgniter.php on line 529 and exactly 1 expected E:\xampp\htdocs\voolsy\langoadmin\application\controllers\Admin_master.php 612
DEBUG - 2020-07-23 07:48:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:48:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-23 07:48:17 --> Severity: error --> Exception: Too few arguments to function Admin_master::edit_portaluser(), 0 passed in E:\xampp\htdocs\voolsy\langoadmin\system\core\CodeIgniter.php on line 529 and exactly 1 expected E:\xampp\htdocs\voolsy\langoadmin\application\controllers\Admin_master.php 612
DEBUG - 2020-07-23 07:48:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:48:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:48:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:48:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:48:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:48:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:48:23 --> Total execution time: 0.1759
DEBUG - 2020-07-23 07:48:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:48:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:49:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:49:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:49:05 --> Total execution time: 0.1397
DEBUG - 2020-07-23 07:49:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:49:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:49:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 07:49:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:49:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-23 07:49:08 --> Severity: error --> Exception: Too few arguments to function Admin_master::edit_portaluser(), 0 passed in E:\xampp\htdocs\voolsy\langoadmin\system\core\CodeIgniter.php on line 529 and exactly 1 expected E:\xampp\htdocs\voolsy\langoadmin\application\controllers\Admin_master.php 612
DEBUG - 2020-07-23 07:49:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:49:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:49:13 --> Total execution time: 0.1569
DEBUG - 2020-07-23 07:49:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:49:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:49:15 --> Total execution time: 0.1766
DEBUG - 2020-07-23 07:49:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:49:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:49:15 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 07:51:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:51:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:51:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:51:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:51:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:51:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:51:25 --> Total execution time: 0.2240
DEBUG - 2020-07-23 07:51:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:51:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:51:26 --> Total execution time: 0.1725
DEBUG - 2020-07-23 07:51:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:51:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:51:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 07:51:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:51:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:51:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:51:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:51:41 --> Total execution time: 0.1335
DEBUG - 2020-07-23 07:51:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:51:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:51:41 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 07:51:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:51:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:52:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:52:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:52:25 --> Total execution time: 0.1659
DEBUG - 2020-07-23 07:52:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:52:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:52:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 07:53:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:53:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:53:00 --> Total execution time: 0.1645
DEBUG - 2020-07-23 07:53:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:53:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:53:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 07:54:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:54:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:54:38 --> Total execution time: 0.1773
DEBUG - 2020-07-23 07:54:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:54:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:54:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 07:54:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:54:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:54:44 --> Total execution time: 0.1677
DEBUG - 2020-07-23 07:54:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:54:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:54:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 07:55:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:55:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:55:09 --> Total execution time: 0.1217
DEBUG - 2020-07-23 07:55:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:55:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 07:55:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 07:55:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:55:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:56:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:56:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 07:59:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 07:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 07:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 07:59:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 08:03:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 08:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 08:03:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-23 08:03:23 --> Query error: Unknown column 'username' in 'field list' - Invalid query: UPDATE `tbl_exercise_mode_categories` SET `username` = 'tester', `first_name` = 'jhon', `last_name` = 'doe', `email` = 'jhondoe@test.com', `phone` = '9519519519', `support_lang_ids` = '3,4,5,6,7', `password` = 'e10adc3949ba59abbe56e057f20f883e'
WHERE `exercise_mode_category_id` = '3'
DEBUG - 2020-07-23 08:03:23 --> Total execution time: 0.1963
DEBUG - 2020-07-23 08:03:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 08:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 08:03:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 08:03:49 --> Total execution time: 0.1170
DEBUG - 2020-07-23 08:03:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:03:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 08:03:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 08:04:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 08:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 08:04:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 08:04:28 --> Total execution time: 0.1224
DEBUG - 2020-07-23 08:04:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:04:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 08:04:29 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 08:05:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 08:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 08:05:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 08:05:13 --> Total execution time: 0.1669
DEBUG - 2020-07-23 08:05:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:05:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 08:05:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 08:05:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 08:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 08:05:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 08:05:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 08:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 08:05:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 08:05:23 --> Total execution time: 0.1833
DEBUG - 2020-07-23 08:05:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 08:05:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 08:05:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 08:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 08:05:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 08:05:27 --> Total execution time: 0.1582
DEBUG - 2020-07-23 08:05:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:05:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 08:05:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 08:07:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 08:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 08:07:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 08:07:04 --> Total execution time: 0.1785
DEBUG - 2020-07-23 08:07:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:07:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 08:07:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 08:07:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 08:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 08:07:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 08:07:08 --> Total execution time: 0.1652
DEBUG - 2020-07-23 08:07:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:07:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 08:07:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 08:07:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 08:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 08:07:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 08:07:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 08:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 08:07:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 08:07:47 --> Total execution time: 0.1763
DEBUG - 2020-07-23 08:07:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:07:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 08:07:47 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 08:07:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 08:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 08:07:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 08:07:52 --> Total execution time: 0.1575
DEBUG - 2020-07-23 08:07:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:07:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 08:07:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 08:08:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 08:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 08:08:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 08:08:17 --> Total execution time: 0.1296
DEBUG - 2020-07-23 08:08:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:08:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 08:08:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 08:08:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 08:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 08:08:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 08:08:54 --> Total execution time: 0.1569
DEBUG - 2020-07-23 08:08:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:08:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 08:08:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 08:13:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 08:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 08:13:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 08:13:30 --> Total execution time: 0.1456
DEBUG - 2020-07-23 08:13:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:13:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 08:13:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 08:20:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 08:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 08:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 08:20:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 08:20:00 --> Total execution time: 0.1643
DEBUG - 2020-07-23 10:31:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 10:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 10:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 10:31:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 10:31:41 --> Total execution time: 0.2192
DEBUG - 2020-07-23 10:43:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 10:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 10:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 10:43:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 10:43:44 --> Total execution time: 0.1624
DEBUG - 2020-07-23 10:43:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 10:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 10:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 10:43:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 10:43:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 10:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 10:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 10:43:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 10:43:44 --> Total execution time: 0.1283
DEBUG - 2020-07-23 10:43:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 10:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 10:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 10:43:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 10:43:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 10:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 10:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 10:43:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 10:43:55 --> Total execution time: 0.1876
DEBUG - 2020-07-23 10:43:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 10:43:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 10:43:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 10:43:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 10:43:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 10:43:56 --> 404 Page Not Found: Assets/plugin
DEBUG - 2020-07-23 10:43:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 10:43:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 10:43:56 --> 404 Page Not Found: Assets/plugin
DEBUG - 2020-07-23 10:44:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 10:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 10:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 10:44:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 10:44:06 --> Total execution time: 0.1276
DEBUG - 2020-07-23 10:44:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 10:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 10:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 10:44:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 10:44:06 --> Total execution time: 0.1251
DEBUG - 2020-07-23 10:44:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 10:44:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 10:44:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 10:44:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 10:44:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 10:44:06 --> 404 Page Not Found: Assets/plugin
DEBUG - 2020-07-23 10:44:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 10:44:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 10:44:07 --> 404 Page Not Found: Assets/plugin
DEBUG - 2020-07-23 10:44:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 10:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 10:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 10:44:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 10:44:09 --> Total execution time: 0.1491
DEBUG - 2020-07-23 10:44:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 10:44:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 10:44:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 10:44:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 10:44:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 10:44:09 --> 404 Page Not Found: Assets/plugin
DEBUG - 2020-07-23 10:44:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 10:44:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 10:44:10 --> 404 Page Not Found: Assets/plugin
DEBUG - 2020-07-23 10:44:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 10:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 10:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 10:44:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 10:44:11 --> Total execution time: 0.2716
DEBUG - 2020-07-23 10:44:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 10:44:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 10:44:22 --> 404 Page Not Found: Assets/plugin
DEBUG - 2020-07-23 10:45:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 10:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 10:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 10:45:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 10:45:14 --> Total execution time: 0.1580
DEBUG - 2020-07-23 10:57:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 10:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 10:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 10:57:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 10:57:27 --> Total execution time: 0.1537
DEBUG - 2020-07-23 10:57:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 10:57:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 10:57:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 11:39:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 11:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 11:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 11:39:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 11:39:06 --> Total execution time: 0.7439
DEBUG - 2020-07-23 11:39:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 11:39:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 11:39:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 11:40:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 11:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 11:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 11:40:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 11:40:26 --> Total execution time: 0.2103
DEBUG - 2020-07-23 11:40:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 11:40:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 11:40:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 11:40:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 11:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 11:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 11:40:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 11:40:37 --> Total execution time: 0.1214
DEBUG - 2020-07-23 11:40:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 11:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 11:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 11:40:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 11:40:38 --> Total execution time: 0.1672
DEBUG - 2020-07-23 11:40:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 11:40:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 11:40:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 11:55:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 11:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 11:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 11:55:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 11:55:39 --> Total execution time: 0.8782
DEBUG - 2020-07-23 11:55:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 11:55:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 11:55:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 11:56:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 11:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 11:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 11:56:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 11:56:24 --> Total execution time: 0.1887
DEBUG - 2020-07-23 11:56:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 11:56:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 11:56:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 11:56:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 11:56:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 11:56:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 11:56:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 11:56:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 11:56:33 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-23 11:57:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 11:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 11:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 11:57:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 11:57:43 --> Total execution time: 0.6745
DEBUG - 2020-07-23 11:57:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 11:57:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 11:57:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 11:57:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 11:57:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 11:57:44 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-23 12:03:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 12:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 12:03:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 12:03:57 --> Total execution time: 0.4893
DEBUG - 2020-07-23 12:03:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:03:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 12:03:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 12:03:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:04:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 12:04:00 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-23 12:04:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 12:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 12:04:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 12:04:19 --> Total execution time: 0.2342
DEBUG - 2020-07-23 12:04:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:04:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 12:04:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 12:04:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 12:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 12:04:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 12:04:23 --> Total execution time: 0.1652
DEBUG - 2020-07-23 12:04:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:04:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 12:04:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 12:04:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 12:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 12:04:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 12:04:33 --> Total execution time: 0.1423
DEBUG - 2020-07-23 12:04:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:04:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 12:04:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 12:05:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 12:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 12:05:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 12:06:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 12:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 12:06:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 12:06:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 12:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 12:06:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 12:08:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 12:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 12:08:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 12:09:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 12:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 12:09:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 12:09:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 12:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 12:09:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 12:09:28 --> Total execution time: 0.2521
DEBUG - 2020-07-23 12:09:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:09:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 12:09:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 12:09:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:09:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 12:09:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 12:09:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:09:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 12:09:39 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-23 12:09:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 12:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 12:09:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 12:09:51 --> Total execution time: 0.1926
DEBUG - 2020-07-23 12:09:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:09:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 12:09:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 12:09:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:09:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 12:09:52 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-23 12:10:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 12:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 12:10:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 12:10:22 --> Total execution time: 0.1654
DEBUG - 2020-07-23 12:10:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:10:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 12:10:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 12:10:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:10:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 12:10:24 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-23 12:12:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 12:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 12:12:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 12:12:16 --> Total execution time: 0.1480
DEBUG - 2020-07-23 12:12:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:12:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 12:12:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 12:12:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:12:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 12:12:17 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-23 12:36:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 12:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 12:36:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 12:36:34 --> Total execution time: 2.7162
DEBUG - 2020-07-23 12:36:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 12:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 12:36:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 12:36:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 12:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 12:36:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 12:36:47 --> Total execution time: 0.4606
DEBUG - 2020-07-23 12:36:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:36:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 12:36:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-23 12:36:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 12:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 12:36:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 12:36:57 --> Total execution time: 0.1527
DEBUG - 2020-07-23 12:36:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-23 12:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-23 12:36:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-23 12:36:58 --> Total execution time: 1.5428
DEBUG - 2020-07-23 12:36:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-23 12:36:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-23 12:36:59 --> 404 Page Not Found: Assets/chosen
