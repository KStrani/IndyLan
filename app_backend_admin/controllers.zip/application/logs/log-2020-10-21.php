<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-10-21 05:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-21 05:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-21 05:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-21 05:37:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-21 05:37:09 --> Total execution time: 0.2195
DEBUG - 2020-10-21 05:50:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-21 05:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-21 05:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-21 05:50:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-21 05:50:04 --> Total execution time: 0.1220
DEBUG - 2020-10-21 05:52:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-21 05:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-21 05:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-21 05:52:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-21 05:52:39 --> Total execution time: 0.1181
