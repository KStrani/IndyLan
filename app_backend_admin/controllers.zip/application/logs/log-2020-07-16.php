<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-07-16 05:28:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:28:16 --> No URI present. Default controller set.
DEBUG - 2020-07-16 05:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-16 05:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-16 05:28:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-16 05:28:18 --> Total execution time: 1.3784
DEBUG - 2020-07-16 05:35:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-16 05:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-16 05:35:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-16 05:35:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-16 05:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-16 05:35:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-16 05:35:20 --> Total execution time: 0.1178
DEBUG - 2020-07-16 05:52:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-16 05:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-16 05:52:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-16 05:52:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-16 05:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-16 05:52:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-16 05:52:22 --> Total execution time: 0.3665
DEBUG - 2020-07-16 05:52:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-16 05:52:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-16 05:52:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-16 05:52:23 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-16 05:52:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-16 05:52:23 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-16 05:52:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-16 05:52:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-16 05:52:25 --> 404 Page Not Found: Uploads/clothes.jpg
ERROR - 2020-07-16 05:52:25 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-16 05:52:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-16 05:52:25 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-16 05:52:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-16 05:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-16 05:52:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-16 05:52:25 --> 404 Page Not Found: Uploads/employment.jpg
ERROR - 2020-07-16 05:52:25 --> 404 Page Not Found: Uploads/countries.jpg
ERROR - 2020-07-16 05:52:25 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-16 05:52:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-16 05:52:25 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-16 05:52:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-16 05:52:25 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-16 05:52:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-16 05:52:25 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-16 05:52:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-16 05:52:26 --> UTF-8 Support Enabled
ERROR - 2020-07-16 05:52:26 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-16 05:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-16 05:52:26 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-16 05:52:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-16 05:52:26 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-16 05:52:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-16 05:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-16 05:52:26 --> 404 Page Not Found: Uploads/legal_terminology.jpg
ERROR - 2020-07-16 05:52:26 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-16 05:52:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-16 05:52:26 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-16 05:52:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-16 05:52:26 --> UTF-8 Support Enabled
ERROR - 2020-07-16 05:52:26 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-16 05:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-16 05:52:26 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-16 05:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-16 05:52:26 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-16 05:52:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-16 05:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-16 05:52:26 --> UTF-8 Support Enabled
ERROR - 2020-07-16 05:52:26 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
ERROR - 2020-07-16 05:52:26 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-16 05:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-16 05:52:26 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-16 05:52:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-16 05:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-16 05:52:26 --> 404 Page Not Found: Uploads/shapes.png
ERROR - 2020-07-16 05:52:26 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-16 05:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-16 05:52:26 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-16 05:52:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-16 05:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-16 05:52:26 --> UTF-8 Support Enabled
ERROR - 2020-07-16 05:52:26 --> 404 Page Not Found: Uploads/supermarket.jpg
ERROR - 2020-07-16 05:52:26 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-16 05:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-16 05:52:26 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-16 05:52:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 05:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-16 05:52:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-16 05:52:27 --> 404 Page Not Found: Uploads/weather.jpg
ERROR - 2020-07-16 05:52:27 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-16 11:26:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-16 11:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-16 11:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-16 11:26:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-16 11:26:26 --> Total execution time: 2.3548
