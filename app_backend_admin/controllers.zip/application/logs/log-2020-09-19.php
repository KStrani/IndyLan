<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-09-19 06:15:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:15:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-19 06:15:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:15:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-19 06:15:13 --> Total execution time: 0.1060
DEBUG - 2020-09-19 06:15:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:15:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-19 06:15:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-19 06:15:27 --> Total execution time: 0.1436
DEBUG - 2020-09-19 06:15:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:15:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:15:30 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-09-19 06:15:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:15:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:15:30 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-19 06:15:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:15:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:15:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-19 06:15:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:15:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:15:32 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-19 06:15:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:15:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-19 06:15:50 --> Total execution time: 0.1178
DEBUG - 2020-09-19 06:15:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:15:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-19 06:15:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-19 06:15:52 --> Total execution time: 0.1313
DEBUG - 2020-09-19 06:15:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:15:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:15:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-19 06:16:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:16:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-19 06:16:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-19 06:16:04 --> Total execution time: 0.1243
DEBUG - 2020-09-19 06:16:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:16:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-19 06:16:07 --> Total execution time: 0.1248
DEBUG - 2020-09-19 06:16:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:16:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-19 06:16:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-19 06:16:07 --> Total execution time: 0.1672
DEBUG - 2020-09-19 06:16:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:16:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:16:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-19 06:16:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:16:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-19 06:16:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-19 06:16:15 --> Total execution time: 0.1440
DEBUG - 2020-09-19 06:16:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:16:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-19 06:16:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-19 06:16:18 --> Total execution time: 0.1401
DEBUG - 2020-09-19 06:16:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:16:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:16:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-19 06:16:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:16:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-19 06:16:26 --> Total execution time: 0.1381
DEBUG - 2020-09-19 06:16:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:16:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-19 06:16:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-19 06:16:28 --> Total execution time: 0.1320
DEBUG - 2020-09-19 06:16:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:16:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:16:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-19 06:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:16:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-19 06:16:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-19 06:16:35 --> Total execution time: 0.1114
DEBUG - 2020-09-19 06:16:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:16:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-19 06:16:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-19 06:16:37 --> Total execution time: 0.1357
DEBUG - 2020-09-19 06:16:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:16:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:16:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-19 06:16:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:16:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-19 06:16:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-19 06:16:49 --> Total execution time: 0.1746
DEBUG - 2020-09-19 06:16:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:16:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-19 06:16:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-19 06:16:51 --> Total execution time: 0.1598
DEBUG - 2020-09-19 06:16:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:16:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:16:54 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-19 06:17:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:17:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-19 06:17:01 --> Total execution time: 0.1491
DEBUG - 2020-09-19 06:17:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:17:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-19 06:17:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-19 06:17:03 --> Total execution time: 0.1194
DEBUG - 2020-09-19 06:17:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:17:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-19 06:17:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:17:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-19 06:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:17:06 --> UTF-8 Support Enabled
ERROR - 2020-09-19 06:17:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-19 06:17:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:17:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-19 06:17:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:17:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-19 06:17:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:17:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-19 06:17:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:17:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-19 06:17:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:17:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-19 06:17:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:17:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-19 06:17:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:17:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-19 06:17:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:17:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:17:09 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-19 06:17:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-19 06:17:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:17:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-19 06:17:18 --> Total execution time: 0.1296
DEBUG - 2020-09-19 06:17:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:17:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-19 06:17:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:17:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-19 06:17:27 --> Total execution time: 0.1699
DEBUG - 2020-09-19 06:17:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:17:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-19 06:17:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-19 06:17:30 --> Total execution time: 0.1820
DEBUG - 2020-09-19 06:17:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:17:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-19 06:17:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:17:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-19 06:17:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:17:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-19 06:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:17:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:17:33 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-19 06:17:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-19 06:17:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:17:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-19 06:17:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:17:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-19 06:17:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:17:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-19 06:17:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:17:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-19 06:17:42 --> Total execution time: 0.1313
DEBUG - 2020-09-19 06:17:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-19 06:17:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-19 06:17:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-19 06:17:45 --> Total execution time: 0.1492
DEBUG - 2020-09-19 06:17:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:17:47 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-19 06:17:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:17:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:48 --> UTF-8 Support Enabled
ERROR - 2020-09-19 06:17:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-19 06:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-19 06:17:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:17:48 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-19 06:17:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-19 06:17:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-19 06:17:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-19 06:17:48 --> 404 Page Not Found: Uploads/words
