<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-08-24 05:28:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 05:28:47 --> No URI present. Default controller set.
DEBUG - 2020-08-24 05:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 05:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 05:28:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 05:28:47 --> Total execution time: 0.1971
DEBUG - 2020-08-24 05:37:26 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 05:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 05:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 05:37:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 05:37:26 --> get_category_list->{"lang":null,"exercise_mode_id":null,"support_lang_id":null}
ERROR - 2020-08-24 05:37:26 --> {"status":0,"message":"Parameters not passed","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-24 05:37:26 --> Total execution time: 0.1322
DEBUG - 2020-08-24 05:39:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 05:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 05:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 05:39:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 05:39:39 --> get_category_list->{"lang":"","exercise_mode_id":"1","support_lang_id":""}
ERROR - 2020-08-24 05:39:39 --> {"status":0,"message":"Parameters not passed","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-24 05:39:39 --> Total execution time: 0.1416
DEBUG - 2020-08-24 05:40:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 05:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 05:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 05:40:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 05:40:58 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
ERROR - 2020-08-24 05:40:58 --> Query error: Unknown column 'category_name_in_seh' in 'field list' - Invalid query: select exercise_mode_category_id,image,category_name_in_seh as category_name from tbl_exercise_mode_categories where support_lang_id='3' AND exercise_mode_id='1' AND is_active='1' AND is_delete='0' order by category_name_in_seh asc
ERROR - 2020-08-24 05:40:58 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 125
DEBUG - 2020-08-24 05:41:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 05:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 05:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 05:41:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 05:41:12 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
ERROR - 2020-08-24 05:41:12 --> Query error: Unknown column 'category_name_in_seh' in 'field list' - Invalid query: select exercise_mode_category_id,image,category_name_in_seh as category_name from tbl_exercise_mode_categories where support_lang_id='3' AND exercise_mode_id='1' AND is_active='1' AND is_delete='0' order by category_name_in_seh asc
ERROR - 2020-08-24 05:41:12 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 125
DEBUG - 2020-08-24 05:41:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 05:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 05:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 05:41:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 05:41:21 --> get_category_list->{"lang":"37","exercise_mode_id":"8","support_lang_id":"3"}
ERROR - 2020-08-24 05:41:21 --> Query error: Unknown column 'category_name_in_seh' in 'field list' - Invalid query: select exercise_mode_category_id,image,category_name_in_seh as category_name from tbl_exercise_mode_categories where support_lang_id='3' AND exercise_mode_id='8' AND is_active='1' AND is_delete='0' order by category_name_in_seh asc
ERROR - 2020-08-24 05:41:21 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 125
DEBUG - 2020-08-24 05:41:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 05:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 05:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 05:41:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 05:41:30 --> get_category_list->{"lang":"9","exercise_mode_id":"8","support_lang_id":"3"}
ERROR - 2020-08-24 05:41:30 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-24 05:41:30 --> Total execution time: 0.1198
DEBUG - 2020-08-24 06:04:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 06:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 06:04:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 06:04:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 06:04:55 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
ERROR - 2020-08-24 06:04:55 --> Query error: Unknown column 'category_name_in_seh' in 'field list' - Invalid query: select exercise_mode_category_id,image,category_name_in_seh as category_name from tbl_exercise_mode_categories where support_lang_id='3' AND exercise_mode_id='1' AND is_active='1' AND is_delete='0' order by category_name_in_seh asc
ERROR - 2020-08-24 06:04:55 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 125
DEBUG - 2020-08-24 06:24:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 06:24:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-24 06:24:22 --> 404 Page Not Found: Admin/index
DEBUG - 2020-08-24 06:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 06:24:28 --> No URI present. Default controller set.
DEBUG - 2020-08-24 06:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 06:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 06:24:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 06:24:29 --> Total execution time: 0.1472
DEBUG - 2020-08-24 06:24:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 06:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 06:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 06:24:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 06:24:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 06:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 06:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 06:24:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 06:24:52 --> Total execution time: 0.1375
DEBUG - 2020-08-24 06:24:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 06:24:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-24 06:24:54 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-24 06:25:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 06:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 06:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 06:25:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 06:25:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 06:25:09 --> Total execution time: 0.1603
DEBUG - 2020-08-24 06:25:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 06:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 06:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 06:25:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 06:25:12 --> Total execution time: 0.1304
DEBUG - 2020-08-24 06:25:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 06:25:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-24 06:25:15 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-24 06:25:19 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 06:25:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-24 06:25:19 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-08-24 06:25:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 06:25:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-24 06:25:29 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-08-24 06:25:50 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 06:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 06:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 06:25:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 06:25:50 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
ERROR - 2020-08-24 06:25:50 --> Query error: Unknown column 'category_name_in_seh' in 'field list' - Invalid query: select exercise_mode_category_id,image,category_name_in_seh as category_name from tbl_exercise_mode_categories where support_lang_id='3' AND exercise_mode_id='1' AND is_active='1' AND is_delete='0' order by category_name_in_seh asc
ERROR - 2020-08-24 06:25:50 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 125
DEBUG - 2020-08-24 06:31:50 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 06:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 06:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 06:31:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 06:31:50 --> Total execution time: 0.1544
DEBUG - 2020-08-24 06:31:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 06:31:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-24 06:31:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-24 06:37:03 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 06:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 06:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 06:37:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 06:37:03 --> Upload class already loaded. Second attempt ignored.
ERROR - 2020-08-24 06:37:03 --> Query error: Unknown column 'category_name_in_pas' in 'field list' - Invalid query: INSERT INTO `tbl_exercise_mode_categories` (`exercise_mode_id`, `image`, `category_name_in_en`, `category_name_in_fi`, `category_name_in_sw`, `category_name_in_de`, `category_name_in_it`, `category_name_in_es`, `category_name_in_ru`, `category_name_in_pt`, `category_name_in_fr`, `category_name_in_ar`, `category_name_in_est`, `category_name_in_sr`, `category_name_in_cr`, `category_name_in_bg`, `category_name_in_chi`, `category_name_in_hu`, `category_name_in_sor`, `category_name_in_pu`, `category_name_in_so`, `category_name_in_ti`, `category_name_in_ur`, `category_name_in_pl`, `category_name_in_tr`, `category_name_in_ro`, `category_name_in_ukr`, `category_name_in_alb`, `category_name_in_pas`, `category_name_in_far`, `category_name_in_kur`, `category_name_in_bar`, `category_name_in_seh`, `category_name_in_gd`, `category_name_in_se-FI`, `category_name_in_kw`, `category_name_in_gl`, `category_name_in_eu`, `support_lang_id`) VALUES ('1', 'IMG-20200625-WA0015.jpg', 'Test Category English', 'New test finish', 'New test swidish', 'New test german', 'New test italian', 'New test spanish', 'New test russian', 'New test  portu', 'New test french', 'New test arabic', 'New test estonian', 'New test serbian', 'New test croatian', 'New test bul', 'New test chine', 'New test hung', 'New test sorani', 'New test punjabi', 'New test Somali', 'New test tigirgna', 'New test urdu', 'New test polish', 'New test turkish', 'New test romania', 'New test ukrain', 'New test albania', 'New test Pashto', 'New test farsi', 'New test Kurmanji', 'New test Bardini', 'New Test scots', 'New test Gaelic', 'New test Nothern Saami', 'New test Cornish', 'New test Galician', 'New test Basque', '3')
DEBUG - 2020-08-24 06:37:03 --> Total execution time: 0.1686
DEBUG - 2020-08-24 06:37:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 06:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 06:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 06:37:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 06:37:39 --> Total execution time: 0.1290
DEBUG - 2020-08-24 06:37:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 06:37:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-24 06:37:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-24 06:37:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 06:37:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-24 06:37:58 --> 404 Page Not Found: Assets/js
DEBUG - 2020-08-24 07:02:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 07:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 07:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 07:02:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 07:02:09 --> Upload class already loaded. Second attempt ignored.
ERROR - 2020-08-24 07:02:09 --> Query error: Unknown column 'category_name_in_pas' in 'field list' - Invalid query: INSERT INTO `tbl_exercise_mode_categories` (`exercise_mode_id`, `image`, `category_name_in_en`, `category_name_in_fi`, `category_name_in_sw`, `category_name_in_de`, `category_name_in_it`, `category_name_in_es`, `category_name_in_ru`, `category_name_in_pt`, `category_name_in_fr`, `category_name_in_ar`, `category_name_in_est`, `category_name_in_sr`, `category_name_in_cr`, `category_name_in_bg`, `category_name_in_chi`, `category_name_in_hu`, `category_name_in_sor`, `category_name_in_pu`, `category_name_in_so`, `category_name_in_ti`, `category_name_in_ur`, `category_name_in_pl`, `category_name_in_tr`, `category_name_in_ro`, `category_name_in_ukr`, `category_name_in_alb`, `category_name_in_pas`, `category_name_in_far`, `category_name_in_kur`, `category_name_in_bar`, `category_name_in_seh`, `category_name_in_gd`, `category_name_in_se-FI`, `category_name_in_kw`, `category_name_in_gl`, `category_name_in_eu`, `support_lang_id`) VALUES ('1', 'IMG-20200625-WA0015.jpg', 'Test Category English', 'New test finish', 'New test swidish', 'New test german', 'New test italian', 'New test spanish', 'New test russian', 'New test  portu', 'New test french', 'New test arabic', 'New test estonian', 'New test serbian', 'New test croatian', 'New test bul', 'New test chine', 'New test hung', 'New test sorani', 'New test punjabi', 'New test Somali', 'New test tigirgna', 'New test urdu', 'New test polish', 'New test turkish', 'New test romania', 'New test ukrain', 'New test albania', 'New test Pashto', 'New test farsi', 'New test Kurmanji', 'New test Bardini', 'New Test scots', 'New test Gaelic', 'New test Nothern Saami', 'New test Cornish', 'New test Galician', 'New test Basque', '3')
DEBUG - 2020-08-24 07:02:09 --> Total execution time: 0.1291
DEBUG - 2020-08-24 07:22:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 07:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 07:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 07:22:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 07:22:40 --> Total execution time: 0.1354
DEBUG - 2020-08-24 07:22:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 07:22:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-24 07:22:44 --> 404 Page Not Found: Assets/js
DEBUG - 2020-08-24 11:05:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 11:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 11:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 11:05:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 11:06:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 11:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 11:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 11:06:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 11:06:01 --> Total execution time: 0.1955
DEBUG - 2020-08-24 11:14:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 11:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 11:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 11:14:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 11:14:42 --> Total execution time: 0.1309
DEBUG - 2020-08-24 11:15:03 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 11:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 11:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 11:15:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 11:15:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 11:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 11:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 11:15:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 11:15:06 --> Total execution time: 0.1306
DEBUG - 2020-08-24 11:15:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 11:15:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-24 11:15:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-24 11:15:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 11:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 11:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 11:15:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 11:15:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 11:15:25 --> Total execution time: 0.1613
DEBUG - 2020-08-24 11:15:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 11:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 11:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 11:15:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 11:15:27 --> Total execution time: 0.1194
DEBUG - 2020-08-24 11:15:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 11:15:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-24 11:15:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-24 11:15:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 11:15:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-24 11:15:30 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-08-24 11:15:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 11:15:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-24 11:15:33 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-08-24 11:15:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 11:15:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-24 11:15:33 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-08-24 11:15:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 11:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 11:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 11:15:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 11:15:42 --> Total execution time: 0.1590
DEBUG - 2020-08-24 11:15:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 11:15:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-24 11:15:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-24 11:19:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 11:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 11:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 11:19:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 11:19:29 --> Upload class already loaded. Second attempt ignored.
ERROR - 2020-08-24 11:19:29 --> Query error: Unknown column 'category_name_in_kw' in 'field list' - Invalid query: INSERT INTO `tbl_exercise_mode_categories` (`exercise_mode_id`, `image`, `category_name_in_en`, `category_name_in_fi`, `category_name_in_sw`, `category_name_in_de`, `category_name_in_it`, `category_name_in_es`, `category_name_in_ru`, `category_name_in_pt`, `category_name_in_fr`, `category_name_in_ar`, `category_name_in_est`, `category_name_in_sr`, `category_name_in_cr`, `category_name_in_bg`, `category_name_in_chi`, `category_name_in_hu`, `category_name_in_sor`, `category_name_in_pu`, `category_name_in_so`, `category_name_in_ti`, `category_name_in_ur`, `category_name_in_pl`, `category_name_in_tr`, `category_name_in_ro`, `category_name_in_ukr`, `category_name_in_alb`, `category_name_in_pas`, `category_name_in_far`, `category_name_in_kur`, `category_name_in_bar`, `category_name_in_seh`, `category_name_in_gd`, `category_name_in_se-FI`, `category_name_in_kw`, `category_name_in_gl`, `category_name_in_eu`, `support_lang_id`) VALUES ('1', '', 'New Testting Category English', 'New Testting Category Finish', 'New Testting Category swidish', 'New test german', 'New test italian', 'New test spanish', 'New test russian', 'New test  portu', 'test french', 'test arabic', 'New test estonian', 'New test serbian', 'New test croatian', 'New test bul', 'New test chine', 'New test hung', 'test sorani ', 'test punjabi', 'test somali', 'New test tigirgna', 'New test urdu', 'test polish', 'New test turkish', 'New test romania', 'New test ukrain', 'test albanian', 'New test Pashto', 'New test farsi', 'New test Kurmanji', 'New test Bardini', 'New Test scots', 'New test Gaelic', 'New test Nothern Saami', 'New test Cornish', 'New test Galician', 'New test Basque', '3')
DEBUG - 2020-08-24 11:19:29 --> Total execution time: 0.1848
DEBUG - 2020-08-24 11:35:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 11:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 11:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 11:35:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 11:35:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 11:35:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 11:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 11:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 11:35:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 11:35:57 --> Total execution time: 0.1794
DEBUG - 2020-08-24 11:35:59 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 11:35:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-24 11:35:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-24 11:36:00 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 11:36:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-24 11:36:00 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-08-24 11:36:02 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 11:36:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-24 11:36:02 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-08-24 11:36:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-24 11:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-24 11:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-24 11:36:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 11:36:34 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-08-24 11:36:34 --> Total execution time: 0.1592
