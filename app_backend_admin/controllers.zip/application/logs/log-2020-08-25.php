<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-08-25 04:08:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:08:38 --> No URI present. Default controller set.
DEBUG - 2020-08-25 04:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:08:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:08:39 --> Total execution time: 0.1647
DEBUG - 2020-08-25 04:09:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:09:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:09:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:09:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:09:19 --> Total execution time: 0.1695
DEBUG - 2020-08-25 04:09:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:09:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-25 04:09:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-25 04:10:14 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:10:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:10:14 --> Total execution time: 0.1181
DEBUG - 2020-08-25 04:10:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:10:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:10:16 --> Total execution time: 0.1340
DEBUG - 2020-08-25 04:10:17 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:10:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:10:18 --> Total execution time: 0.1751
DEBUG - 2020-08-25 04:10:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:10:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:10:19 --> Total execution time: 0.1607
DEBUG - 2020-08-25 04:10:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:10:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-25 04:10:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-25 04:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:29:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:29:04 --> user_login->{"email":"rastech47@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2020-08-25 04:29:04 --> Total execution time: 0.1160
DEBUG - 2020-08-25 04:29:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:29:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:29:08 --> Total execution time: 0.1282
DEBUG - 2020-08-25 04:29:13 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:29:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:29:13 --> Total execution time: 0.1057
DEBUG - 2020-08-25 04:29:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:29:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:29:31 --> get_category_list->{"lang":"12","exercise_mode_id":"1","support_lang_id":"1"}
ERROR - 2020-08-25 04:29:31 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-25 04:29:31 --> Total execution time: 0.1484
DEBUG - 2020-08-25 04:29:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:29:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:29:38 --> get_category_list->{"lang":"12","exercise_mode_id":"2","support_lang_id":"1"}
ERROR - 2020-08-25 04:29:38 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-25 04:29:38 --> Total execution time: 0.1492
DEBUG - 2020-08-25 04:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:29:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:29:43 --> get_category_list->{"lang":"12","exercise_mode_id":"3","support_lang_id":"1"}
ERROR - 2020-08-25 04:29:43 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-25 04:29:43 --> Total execution time: 0.1141
DEBUG - 2020-08-25 04:29:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:29:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:29:46 --> get_category_list->{"lang":"12","exercise_mode_id":"4","support_lang_id":"1"}
ERROR - 2020-08-25 04:29:46 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-25 04:29:46 --> Total execution time: 0.1408
DEBUG - 2020-08-25 04:29:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:29:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:29:49 --> get_category_list->{"lang":"12","exercise_mode_id":"5","support_lang_id":"1"}
ERROR - 2020-08-25 04:29:49 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-25 04:29:49 --> Total execution time: 0.1404
DEBUG - 2020-08-25 04:29:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:29:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:29:54 --> get_category_list->{"lang":"12","exercise_mode_id":"5","support_lang_id":"1"}
ERROR - 2020-08-25 04:29:54 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-25 04:29:54 --> Total execution time: 0.2022
DEBUG - 2020-08-25 04:29:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:29:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:29:58 --> Total execution time: 0.1148
DEBUG - 2020-08-25 04:37:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:37:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:37:46 --> user_register->{"first_name":"Dimpy","last_name":"","email":"dimpy.sojitra@voolsy.com","password":"Dimpii123","confirm_password":"Dimpii123","social_id":null,"social_type":"0","user_image":null}
DEBUG - 2020-08-25 04:37:46 --> Total execution time: 0.1843
DEBUG - 2020-08-25 04:37:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:37:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:37:53 --> Total execution time: 0.1400
DEBUG - 2020-08-25 04:38:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:38:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:38:43 --> Total execution time: 0.1258
DEBUG - 2020-08-25 04:38:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:38:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:38:55 --> Total execution time: 0.1263
DEBUG - 2020-08-25 04:39:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:39:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:39:25 --> Total execution time: 0.1492
DEBUG - 2020-08-25 04:39:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:39:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:39:34 --> Total execution time: 0.1202
DEBUG - 2020-08-25 04:39:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:39:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:39:39 --> get_category_list->{"lang":"12","exercise_mode_id":"1","support_lang_id":"1"}
ERROR - 2020-08-25 04:39:39 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-25 04:39:39 --> Total execution time: 0.1589
DEBUG - 2020-08-25 04:39:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:39:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:39:49 --> get_category_list->{"lang":"12","exercise_mode_id":"2","support_lang_id":"1"}
ERROR - 2020-08-25 04:39:49 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-25 04:39:49 --> Total execution time: 0.1557
DEBUG - 2020-08-25 04:39:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:39:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:39:57 --> Total execution time: 0.1505
DEBUG - 2020-08-25 04:40:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:40:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:40:01 --> Total execution time: 0.1389
DEBUG - 2020-08-25 04:40:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:40:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:40:06 --> Total execution time: 0.1116
DEBUG - 2020-08-25 04:42:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:42:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:42:53 --> Total execution time: 0.1381
DEBUG - 2020-08-25 04:43:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:43:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:43:05 --> Total execution time: 0.1147
DEBUG - 2020-08-25 04:43:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:43:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:43:37 --> Total execution time: 0.0991
DEBUG - 2020-08-25 04:50:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 04:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 04:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 04:50:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 04:50:45 --> Total execution time: 0.1442
DEBUG - 2020-08-25 05:01:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 05:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 05:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 05:01:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 05:01:46 --> Total execution time: 0.1342
DEBUG - 2020-08-25 05:01:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 05:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 05:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 05:01:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 05:01:48 --> Total execution time: 0.1163
DEBUG - 2020-08-25 05:01:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 05:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-25 05:01:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-25 05:10:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 05:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 05:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 05:10:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 05:10:08 --> Total execution time: 0.1248
DEBUG - 2020-08-25 05:17:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 05:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 05:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 05:17:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 05:17:50 --> Total execution time: 0.1396
DEBUG - 2020-08-25 05:19:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 05:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 05:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 05:19:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 05:19:46 --> Total execution time: 0.1524
DEBUG - 2020-08-25 05:23:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 05:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 05:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 05:23:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 05:23:29 --> Total execution time: 0.1441
DEBUG - 2020-08-25 05:23:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 05:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 05:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 05:23:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 05:23:36 --> Total execution time: 0.1415
DEBUG - 2020-08-25 05:25:14 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 05:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 05:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 05:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 05:25:14 --> Total execution time: 0.1397
DEBUG - 2020-08-25 05:26:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 05:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 05:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 05:26:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 05:26:52 --> Total execution time: 0.1446
DEBUG - 2020-08-25 05:26:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 05:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 05:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 05:26:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 05:26:57 --> Total execution time: 0.1406
DEBUG - 2020-08-25 05:27:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 05:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 05:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 05:27:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 05:27:18 --> Total execution time: 0.1400
DEBUG - 2020-08-25 16:04:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 16:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 16:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 16:04:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 16:04:33 --> Total execution time: 0.1410
DEBUG - 2020-08-25 16:04:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 16:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 16:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 16:04:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 16:04:41 --> Total execution time: 0.1452
DEBUG - 2020-08-25 16:05:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 16:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 16:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 16:05:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 16:05:39 --> Total execution time: 0.1789
DEBUG - 2020-08-25 16:07:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 16:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 16:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 16:07:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 16:07:12 --> Total execution time: 0.1551
DEBUG - 2020-08-25 16:07:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 16:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 16:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 16:07:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 16:07:54 --> Total execution time: 0.1757
DEBUG - 2020-08-25 18:49:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:49:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:49:39 --> Total execution time: 0.1231
DEBUG - 2020-08-25 18:49:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:49:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:49:43 --> Total execution time: 0.1554
DEBUG - 2020-08-25 18:49:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:49:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:49:51 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
ERROR - 2020-08-25 18:49:51 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-25 18:49:51 --> Total execution time: 0.1421
DEBUG - 2020-08-25 18:50:00 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:50:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:50:00 --> Total execution time: 0.1408
DEBUG - 2020-08-25 18:50:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:50:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:50:04 --> Total execution time: 0.0988
DEBUG - 2020-08-25 18:50:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:50:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:50:08 --> Total execution time: 0.1532
DEBUG - 2020-08-25 18:50:13 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:50:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:50:13 --> get_category_list->{"lang":"12","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-08-25 18:50:13 --> Total execution time: 0.1112
DEBUG - 2020-08-25 18:50:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:50:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:50:18 --> get_subcategory_list->{"lang":"12","category_id":"50","user_id":"767","support_lang_id":"3"}
DEBUG - 2020-08-25 18:50:18 --> Total execution time: 0.1646
DEBUG - 2020-08-25 18:50:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:50:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:50:25 --> get_exercise_type_list->{"lang":"12","subcategory_id":"58","support_lang_id":"3"}
DEBUG - 2020-08-25 18:50:25 --> Total execution time: 0.1139
DEBUG - 2020-08-25 18:50:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:50:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:50:32 --> get_sorce_lan_word_type_8->{"slang":"12","tlang":"3","exercise_mode_id":"1","category_id":"50","subcategory_id":"58","support_lang_id":"3"}
DEBUG - 2020-08-25 18:50:32 --> Total execution time: 0.1890
DEBUG - 2020-08-25 18:50:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:50:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:50:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:50:51 --> get_exercise_type_list->{"lang":"12","subcategory_id":"58","support_lang_id":"3"}
DEBUG - 2020-08-25 18:50:51 --> Total execution time: 0.1020
DEBUG - 2020-08-25 18:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:50:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:50:51 --> get_subcategory_list->{"lang":"12","category_id":"50","user_id":"767","support_lang_id":"3"}
DEBUG - 2020-08-25 18:50:51 --> Total execution time: 0.1601
DEBUG - 2020-08-25 18:50:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:50:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:50:53 --> get_category_list->{"lang":"12","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-08-25 18:50:53 --> Total execution time: 0.1476
DEBUG - 2020-08-25 18:51:03 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:51:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:51:04 --> Total execution time: 0.1275
DEBUG - 2020-08-25 18:51:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:51:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:51:08 --> Total execution time: 0.1222
DEBUG - 2020-08-25 18:51:14 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:51:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:51:14 --> get_category_list->{"lang":"12","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-08-25 18:51:14 --> Total execution time: 0.1031
DEBUG - 2020-08-25 18:51:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:51:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:51:23 --> get_subcategory_list->{"lang":"12","category_id":"50","user_id":"767","support_lang_id":"3"}
DEBUG - 2020-08-25 18:51:23 --> Total execution time: 0.1407
DEBUG - 2020-08-25 18:51:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:51:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:51:28 --> get_exercise_type_list->{"lang":"12","subcategory_id":"58","support_lang_id":"3"}
DEBUG - 2020-08-25 18:51:28 --> Total execution time: 0.1392
DEBUG - 2020-08-25 18:51:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:51:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:51:32 --> get_sorce_lan_word_type_8->{"slang":"12","tlang":"3","exercise_mode_id":"1","category_id":"50","subcategory_id":"58","support_lang_id":"3"}
DEBUG - 2020-08-25 18:51:32 --> Total execution time: 0.1507
DEBUG - 2020-08-25 18:51:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:51:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:51:37 --> get_exercise_type_list->{"lang":"12","subcategory_id":"58","support_lang_id":"3"}
DEBUG - 2020-08-25 18:51:37 --> Total execution time: 0.1556
DEBUG - 2020-08-25 18:51:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:51:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:51:40 --> get_sorce_lan_word_type_3->{"slang":"12","tlang":"3","exercise_mode_id":"1","category_id":"50","subcategory_id":"58","support_lang_id":"3"}
DEBUG - 2020-08-25 18:51:40 --> Total execution time: 0.2194
DEBUG - 2020-08-25 18:52:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:52:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:52:25 --> get_exercise_type_list->{"lang":"12","subcategory_id":"58","support_lang_id":"3"}
DEBUG - 2020-08-25 18:52:25 --> Total execution time: 0.1395
DEBUG - 2020-08-25 18:52:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:52:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:52:31 --> get_sorce_lan_word_type_7->{"slang":"12","tlang":"3","exercise_mode_id":"1","category_id":"50","subcategory_id":"58","support_lang_id":"3"}
DEBUG - 2020-08-25 18:52:31 --> Total execution time: 0.2448
DEBUG - 2020-08-25 18:53:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:53:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:53:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:53:23 --> get_exercise_type_list->{"lang":"12","subcategory_id":"58","support_lang_id":"3"}
DEBUG - 2020-08-25 18:53:23 --> Total execution time: 0.1597
DEBUG - 2020-08-25 18:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:53:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:53:23 --> get_subcategory_list->{"lang":"12","category_id":"50","user_id":"767","support_lang_id":"3"}
DEBUG - 2020-08-25 18:53:23 --> Total execution time: 0.1504
DEBUG - 2020-08-25 18:53:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:53:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-25 18:53:29 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-08-25 18:53:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:53:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-25 18:53:31 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-08-25 18:53:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:53:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:53:33 --> get_exercise_type_list->{"lang":"12","subcategory_id":"269","support_lang_id":"3"}
DEBUG - 2020-08-25 18:53:33 --> Total execution time: 0.1270
DEBUG - 2020-08-25 18:53:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:53:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:53:34 --> get_sorce_lan_word_type_8->{"slang":"12","tlang":"3","exercise_mode_id":"1","category_id":"50","subcategory_id":"269","support_lang_id":"3"}
DEBUG - 2020-08-25 18:53:34 --> Total execution time: 0.1314
DEBUG - 2020-08-25 18:53:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:53:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:53:38 --> get_exercise_type_list->{"lang":"12","subcategory_id":"269","support_lang_id":"3"}
DEBUG - 2020-08-25 18:53:38 --> Total execution time: 0.1472
DEBUG - 2020-08-25 18:53:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:53:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:53:39 --> get_subcategory_list->{"lang":"12","category_id":"50","user_id":"767","support_lang_id":"3"}
DEBUG - 2020-08-25 18:53:39 --> Total execution time: 0.1323
DEBUG - 2020-08-25 18:53:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:53:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:53:42 --> get_category_list->{"lang":"12","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-08-25 18:53:42 --> Total execution time: 0.1160
DEBUG - 2020-08-25 18:53:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:53:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-25 18:53:42 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-08-25 18:53:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:53:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:53:44 --> get_category_list->{"lang":"12","exercise_mode_id":"3","support_lang_id":"3"}
DEBUG - 2020-08-25 18:53:44 --> Total execution time: 0.1141
DEBUG - 2020-08-25 18:53:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:53:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-25 18:53:45 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-08-25 18:53:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:53:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:53:45 --> get_subcategory_list->{"lang":"12","category_id":"50","user_id":"767","support_lang_id":"3"}
DEBUG - 2020-08-25 18:53:45 --> Total execution time: 0.1269
DEBUG - 2020-08-25 18:53:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:53:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:53:49 --> get_exercise_type_list->{"lang":"12","subcategory_id":"58","support_lang_id":"3"}
DEBUG - 2020-08-25 18:53:49 --> Total execution time: 0.1423
DEBUG - 2020-08-25 18:53:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:53:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-25 18:53:54 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-08-25 18:53:54 --> Total execution time: 0.1076
DEBUG - 2020-08-25 18:53:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:53:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:53:58 --> get_exercise_type_list->{"lang":"12","subcategory_id":"58","support_lang_id":"3"}
DEBUG - 2020-08-25 18:53:58 --> Total execution time: 0.1057
DEBUG - 2020-08-25 18:54:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:54:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-25 18:54:05 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-08-25 18:54:05 --> Total execution time: 0.1472
DEBUG - 2020-08-25 18:54:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:54:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:54:08 --> get_exercise_type_list->{"lang":"12","subcategory_id":"58","support_lang_id":"3"}
DEBUG - 2020-08-25 18:54:08 --> Total execution time: 0.1133
DEBUG - 2020-08-25 18:54:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:54:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:54:09 --> get_subcategory_list->{"lang":"12","category_id":"50","user_id":"767","support_lang_id":"3"}
DEBUG - 2020-08-25 18:54:09 --> Total execution time: 0.1544
DEBUG - 2020-08-25 18:54:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:54:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:54:12 --> get_category_list->{"lang":"12","exercise_mode_id":"3","support_lang_id":"3"}
DEBUG - 2020-08-25 18:54:12 --> Total execution time: 0.1571
DEBUG - 2020-08-25 18:54:14 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:54:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:54:14 --> Total execution time: 0.1309
DEBUG - 2020-08-25 18:54:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:54:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:54:16 --> Total execution time: 0.1594
DEBUG - 2020-08-25 18:54:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:54:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:54:22 --> Total execution time: 0.1286
DEBUG - 2020-08-25 18:54:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:54:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:54:32 --> get_category_list->{"lang":"12","exercise_mode_id":"1","support_lang_id":"10"}
ERROR - 2020-08-25 18:54:32 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-25 18:54:32 --> Total execution time: 0.1137
DEBUG - 2020-08-25 18:54:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:54:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:54:37 --> Total execution time: 0.1745
DEBUG - 2020-08-25 18:54:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:54:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:54:40 --> Total execution time: 0.1400
DEBUG - 2020-08-25 18:54:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:54:48 --> Total execution time: 0.1551
DEBUG - 2020-08-25 18:54:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:54:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:54:53 --> Total execution time: 0.1451
DEBUG - 2020-08-25 18:55:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:55:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:55:01 --> get_category_list->{"lang":"12","exercise_mode_id":"1","support_lang_id":"9"}
ERROR - 2020-08-25 18:55:01 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-25 18:55:01 --> Total execution time: 0.1836
DEBUG - 2020-08-25 18:55:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:55:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:55:07 --> Total execution time: 0.1399
DEBUG - 2020-08-25 18:55:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:55:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:55:12 --> Total execution time: 0.1706
DEBUG - 2020-08-25 18:55:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:55:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:55:22 --> Total execution time: 0.1715
DEBUG - 2020-08-25 18:55:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:55:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:55:33 --> get_category_list->{"lang":"12","exercise_mode_id":"1","support_lang_id":"8"}
ERROR - 2020-08-25 18:55:33 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-25 18:55:33 --> Total execution time: 0.1209
DEBUG - 2020-08-25 18:55:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:55:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:55:38 --> Total execution time: 0.1395
DEBUG - 2020-08-25 18:55:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-25 18:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-25 18:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-25 18:55:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-25 18:55:41 --> Total execution time: 0.1594
