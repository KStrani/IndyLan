<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-07-21 07:25:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:25:34 --> No URI present. Default controller set.
DEBUG - 2020-07-21 07:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:25:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:25:37 --> Total execution time: 3.6380
DEBUG - 2020-07-21 07:25:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:25:38 --> No URI present. Default controller set.
DEBUG - 2020-07-21 07:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:25:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:25:38 --> Total execution time: 0.1998
DEBUG - 2020-07-21 07:26:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:26:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:26:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:26:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:26:05 --> Total execution time: 0.3700
DEBUG - 2020-07-21 07:26:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:26:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-21 07:26:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-21 07:33:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:33:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:33:23 --> Total execution time: 0.1410
DEBUG - 2020-07-21 07:33:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:33:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:33:24 --> Total execution time: 0.4269
DEBUG - 2020-07-21 07:33:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-21 07:33:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-21 07:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:33:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:33:25 --> Total execution time: 0.1649
DEBUG - 2020-07-21 07:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:33:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:33:26 --> Total execution time: 0.2098
DEBUG - 2020-07-21 07:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-21 07:33:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-21 07:33:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:33:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:33:33 --> Total execution time: 0.1437
DEBUG - 2020-07-21 07:33:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:33:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:33:34 --> Total execution time: 0.1177
DEBUG - 2020-07-21 07:33:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-21 07:33:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-21 07:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:33:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:33:41 --> Total execution time: 0.1587
DEBUG - 2020-07-21 07:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-21 07:33:41 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-21 07:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:33:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:33:43 --> Total execution time: 0.1586
DEBUG - 2020-07-21 07:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:33:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:33:43 --> Total execution time: 0.1492
DEBUG - 2020-07-21 07:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-21 07:33:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-21 07:33:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:33:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:33:44 --> Total execution time: 0.1151
DEBUG - 2020-07-21 07:33:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:33:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:33:44 --> Total execution time: 0.1290
DEBUG - 2020-07-21 07:33:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-21 07:33:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-21 07:33:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:33:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:33:46 --> Total execution time: 0.1568
DEBUG - 2020-07-21 07:33:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:33:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:33:47 --> Total execution time: 0.1205
DEBUG - 2020-07-21 07:33:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-21 07:33:47 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-21 07:33:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:33:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:33:50 --> Total execution time: 0.2548
DEBUG - 2020-07-21 07:33:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-21 07:33:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-21 07:33:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:33:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:33:54 --> Total execution time: 0.1443
DEBUG - 2020-07-21 07:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:33:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-21 07:33:54 --> Query error: Unknown column 'mode_name' in 'order clause' - Invalid query: SELECT *
FROM `tbl_exercise_type`
WHERE `exercise_mode_id` = '1'
ORDER BY `mode_name` ASC
ERROR - 2020-07-21 07:33:54 --> Severity: error --> Exception: Call to a member function result_array() on boolean E:\xampp\htdocs\voolsy\langoadmin\application\models\Admin_model.php 822
DEBUG - 2020-07-21 07:38:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:38:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:38:55 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:38:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:38:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:38:56 --> Total execution time: 0.1943
DEBUG - 2020-07-21 07:38:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-21 07:38:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-21 07:39:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:39:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:39:01 --> Total execution time: 0.1262
DEBUG - 2020-07-21 07:39:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:39:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:39:01 --> Total execution time: 0.1492
DEBUG - 2020-07-21 07:39:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:39:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-21 07:39:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-21 07:39:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:39:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:39:04 --> Total execution time: 0.1741
DEBUG - 2020-07-21 07:39:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:39:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-21 07:39:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-21 07:39:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:39:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:39:08 --> Total execution time: 0.1341
DEBUG - 2020-07-21 07:39:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:39:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:39:13 --> Total execution time: 0.1339
DEBUG - 2020-07-21 07:41:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:41:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:41:33 --> Upload class already loaded. Second attempt ignored.
ERROR - 2020-07-21 07:41:33 --> Severity: error --> Exception: Call to undefined function finfo_open() E:\xampp\htdocs\voolsy\langoadmin\system\libraries\Upload.php 1222
DEBUG - 2020-07-21 07:51:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:51:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:51:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:51:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:53:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:53:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:53:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:53:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:55:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:55:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 07:55:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 07:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 07:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 07:55:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 08:39:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 08:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 08:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 08:39:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 08:40:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 08:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 08:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 08:40:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 08:40:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 08:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 08:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 08:40:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 08:40:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 08:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 08:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 08:40:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 08:40:35 --> Total execution time: 0.2441
DEBUG - 2020-07-21 08:40:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 08:40:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-21 08:40:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-21 09:40:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 09:40:29 --> No URI present. Default controller set.
DEBUG - 2020-07-21 09:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 09:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 09:40:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 09:40:29 --> Total execution time: 0.1368
DEBUG - 2020-07-21 09:40:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 09:40:33 --> No URI present. Default controller set.
DEBUG - 2020-07-21 09:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 09:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 09:40:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 09:40:33 --> Total execution time: 0.1860
DEBUG - 2020-07-21 09:40:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 09:40:37 --> No URI present. Default controller set.
DEBUG - 2020-07-21 09:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 09:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 09:40:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 09:40:37 --> Total execution time: 0.1561
DEBUG - 2020-07-21 12:12:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 12:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 12:12:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 12:12:59 --> Total execution time: 0.5068
DEBUG - 2020-07-21 12:13:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 12:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 12:13:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 12:13:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 12:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 12:13:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 12:13:00 --> Total execution time: 0.1381
DEBUG - 2020-07-21 12:13:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 12:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 12:13:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 12:13:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 12:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 12:13:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 12:13:14 --> Total execution time: 0.2290
DEBUG - 2020-07-21 12:13:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:13:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-21 12:13:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-21 12:13:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 12:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 12:13:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 12:13:19 --> Total execution time: 0.1378
DEBUG - 2020-07-21 12:13:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 12:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 12:13:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-21 12:13:19 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\header.php 86
DEBUG - 2020-07-21 12:13:19 --> Total execution time: 0.1537
DEBUG - 2020-07-21 12:13:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:13:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-21 12:13:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-21 12:14:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 12:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 12:14:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 12:14:02 --> Total execution time: 0.1185
DEBUG - 2020-07-21 12:14:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 12:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 12:14:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 12:14:03 --> Total execution time: 0.1917
DEBUG - 2020-07-21 12:14:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:14:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-21 12:14:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-21 12:14:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 12:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 12:14:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 12:14:06 --> Total execution time: 0.1981
DEBUG - 2020-07-21 12:14:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:14:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-21 12:14:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-21 12:14:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 12:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 12:14:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 12:14:16 --> Total execution time: 0.1256
DEBUG - 2020-07-21 12:14:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 12:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 12:14:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 12:14:17 --> Total execution time: 0.1504
DEBUG - 2020-07-21 12:14:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:14:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-21 12:14:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-21 12:14:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 12:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 12:14:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 12:14:20 --> Total execution time: 0.1984
DEBUG - 2020-07-21 12:14:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:14:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-21 12:14:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-21 12:14:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 12:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 12:14:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 12:14:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 12:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 12:14:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 12:14:43 --> Total execution time: 0.1646
DEBUG - 2020-07-21 12:14:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-21 12:14:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-21 12:15:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-21 12:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-21 12:15:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-21 12:15:01 --> Total execution time: 0.1488
DEBUG - 2020-07-21 12:15:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-21 12:15:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-21 12:15:01 --> 404 Page Not Found: Assets/chosen
