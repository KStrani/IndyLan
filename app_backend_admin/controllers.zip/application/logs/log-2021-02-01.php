<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-02-01 04:59:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 04:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 04:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 04:59:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 05:00:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 05:00:02 --> Total execution time: 0.1130
DEBUG - 2021-02-01 05:10:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 05:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 05:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 05:10:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 05:10:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 05:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 05:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 05:10:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 05:10:43 --> Total execution time: 0.1395
DEBUG - 2021-02-01 06:10:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 06:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 06:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 06:10:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-01 06:10:55 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-02-01 06:10:55 --> Total execution time: 0.1223
DEBUG - 2021-02-01 06:11:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 06:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 06:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 06:11:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 06:11:04 --> Total execution time: 0.1467
DEBUG - 2021-02-01 06:11:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 06:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 06:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 06:11:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 06:11:09 --> Total execution time: 0.0988
DEBUG - 2021-02-01 06:11:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 06:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 06:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 06:11:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 06:11:21 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-01 06:11:21 --> Total execution time: 0.0994
DEBUG - 2021-02-01 06:11:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 06:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 06:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 06:11:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 06:11:26 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-01 06:11:26 --> Total execution time: 0.1158
DEBUG - 2021-02-01 06:11:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 06:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 06:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 06:11:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 06:11:28 --> get_exercise_type_list->{"lang":"37","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-01 06:11:28 --> Total execution time: 0.1188
DEBUG - 2021-02-01 06:11:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 06:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 06:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 06:11:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-01 06:11:33 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-02-01 06:11:33 --> Total execution time: 0.1343
DEBUG - 2021-02-01 09:05:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 09:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 09:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 09:05:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 09:05:04 --> Total execution time: 0.1003
DEBUG - 2021-02-01 09:05:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 09:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 09:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 09:05:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 09:05:09 --> Total execution time: 0.1972
DEBUG - 2021-02-01 09:05:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 09:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 09:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 09:05:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 09:05:16 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-01 09:05:16 --> Total execution time: 0.1112
DEBUG - 2021-02-01 09:05:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 09:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 09:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 09:05:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 09:05:20 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-01 09:05:20 --> Total execution time: 0.1056
DEBUG - 2021-02-01 09:05:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 09:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 09:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 09:05:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 09:05:25 --> get_exercise_type_list->{"lang":"37","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-01 09:05:25 --> Total execution time: 0.1934
DEBUG - 2021-02-01 09:05:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 09:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 09:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 09:05:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-01 09:05:29 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-02-01 09:05:29 --> Total execution time: 0.1521
DEBUG - 2021-02-01 10:15:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 10:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 10:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 10:15:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 10:15:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 10:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 10:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 10:15:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 10:15:36 --> Total execution time: 0.1113
DEBUG - 2021-02-01 10:19:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 10:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 10:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 10:19:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 10:19:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 10:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 10:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 10:19:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 10:19:32 --> Total execution time: 0.1538
DEBUG - 2021-02-01 10:19:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 10:19:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-01 10:19:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-01 10:19:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 10:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 10:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 10:19:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 10:19:54 --> Total execution time: 0.1201
DEBUG - 2021-02-01 10:19:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 10:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 10:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 10:19:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 10:19:54 --> Total execution time: 0.1272
DEBUG - 2021-02-01 10:19:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 10:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 10:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 10:19:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 10:19:55 --> Total execution time: 0.1257
DEBUG - 2021-02-01 10:19:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 10:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 10:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 10:19:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 10:19:56 --> Total execution time: 0.1445
DEBUG - 2021-02-01 10:19:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 10:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 10:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 10:19:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-01 10:19:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-01 10:19:57 --> Total execution time: 0.1588
DEBUG - 2021-02-01 10:19:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 10:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 10:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 10:19:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-01 10:19:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-01 10:19:58 --> Total execution time: 0.1213
DEBUG - 2021-02-01 10:19:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 10:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 10:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 10:19:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-01 10:19:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-01 10:19:58 --> Total execution time: 0.1328
DEBUG - 2021-02-01 10:19:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 10:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 10:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 10:19:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-01 10:19:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-01 10:19:59 --> Total execution time: 0.1303
DEBUG - 2021-02-01 10:20:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 10:20:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-01 10:20:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-01 10:20:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 10:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 10:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 10:20:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 11:21:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 11:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 11:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 11:21:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-01 11:21:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-01 11:21:41 --> Total execution time: 0.1594
DEBUG - 2021-02-01 11:21:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 11:21:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-01 11:21:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-01 12:03:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 12:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 12:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 12:03:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-01 12:03:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-01 12:03:41 --> Total execution time: 0.1518
DEBUG - 2021-02-01 12:03:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 12:03:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-01 12:03:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-01 12:26:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 12:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 12:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 12:26:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 12:26:22 --> Total execution time: 0.1334
DEBUG - 2021-02-01 12:26:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 12:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 12:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 12:26:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 12:26:26 --> Total execution time: 0.1289
DEBUG - 2021-02-01 12:26:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 12:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 12:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 12:26:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 12:26:32 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-01 12:26:32 --> Total execution time: 0.1125
DEBUG - 2021-02-01 12:26:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 12:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 12:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 12:26:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 12:26:40 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-01 12:26:40 --> Total execution time: 0.1309
DEBUG - 2021-02-01 12:26:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 12:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 12:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 12:26:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 12:26:54 --> get_exercise_type_list->{"lang":"37","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-01 12:26:54 --> Total execution time: 0.1514
DEBUG - 2021-02-01 12:26:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 12:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 12:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 12:26:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-01 12:26:58 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-02-01 12:26:58 --> Total execution time: 0.1035
DEBUG - 2021-02-01 12:27:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 12:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 12:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 12:27:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 12:27:03 --> get_exercise_type_list->{"lang":"37","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-01 12:27:03 --> Total execution time: 0.1059
DEBUG - 2021-02-01 12:27:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-01 12:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-01 12:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-01 12:27:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-01 12:27:03 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-01 12:27:03 --> Total execution time: 0.0983
