<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-09-09 04:26:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:26:37 --> No URI present. Default controller set.
DEBUG - 2020-09-09 04:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:26:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:26:38 --> Total execution time: 0.1627
DEBUG - 2020-09-09 04:26:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:26:40 --> No URI present. Default controller set.
DEBUG - 2020-09-09 04:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:26:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:26:40 --> Total execution time: 0.2014
DEBUG - 2020-09-09 04:27:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:27:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:27:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:27:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:27:24 --> Total execution time: 0.1691
DEBUG - 2020-09-09 04:27:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:27:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:27:29 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 04:27:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:27:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:27:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:27:41 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 04:27:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:27:41 --> 404 Page Not Found: Assets/js
DEBUG - 2020-09-09 04:30:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:30:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:30:55 --> Total execution time: 0.1183
DEBUG - 2020-09-09 04:30:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:30:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:30:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 04:31:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:31:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:31:01 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-09 04:31:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:31:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:31:12 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-09-09 04:31:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:31:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:31:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 04:31:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:31:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:31:18 --> 404 Page Not Found: Assets/js
DEBUG - 2020-09-09 04:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:32:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:32:24 --> Total execution time: 0.1974
DEBUG - 2020-09-09 04:32:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:32:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:32:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 04:32:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:32:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:32:27 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-09 04:32:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:32:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:32:30 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-09-09 04:32:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:32:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:32:30 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-09 04:32:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:32:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:32:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:32:40 --> Total execution time: 0.1525
DEBUG - 2020-09-09 04:32:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:32:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:32:43 --> Total execution time: 0.1439
DEBUG - 2020-09-09 04:32:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:32:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 04:32:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:32:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:32:47 --> 404 Page Not Found: Uploads/badger.jpg
DEBUG - 2020-09-09 04:32:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:32:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:32:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:32:56 --> Total execution time: 0.1615
DEBUG - 2020-09-09 04:32:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:32:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:32:59 --> Total execution time: 0.1420
DEBUG - 2020-09-09 04:33:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:33:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:33:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:33:02 --> 404 Page Not Found: Assets/chosen
ERROR - 2020-09-09 04:33:02 --> 404 Page Not Found: Uploads/unnamed.png
DEBUG - 2020-09-09 04:34:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:34:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:34:34 --> Total execution time: 0.1656
DEBUG - 2020-09-09 04:34:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:34:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:34:37 --> Total execution time: 0.1409
DEBUG - 2020-09-09 04:34:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:34:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:34:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 04:34:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:34:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:34:40 --> 404 Page Not Found: Uploads/unnamed.png
DEBUG - 2020-09-09 04:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:34:43 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-09 04:34:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:34:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:34:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:34:47 --> Total execution time: 0.1773
DEBUG - 2020-09-09 04:34:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:34:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:34:51 --> Total execution time: 0.1512
DEBUG - 2020-09-09 04:34:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:34:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:34:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 04:35:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:35:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:35:05 --> Total execution time: 0.1437
DEBUG - 2020-09-09 04:35:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:35:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 04:35:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-09 04:35:07 --> Total execution time: 0.1471
DEBUG - 2020-09-09 04:35:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:35:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:35:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 04:36:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:36:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:36:25 --> Total execution time: 0.1594
DEBUG - 2020-09-09 04:36:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:36:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 04:36:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-09 04:36:28 --> Total execution time: 0.1986
DEBUG - 2020-09-09 04:36:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:36:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:36:31 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 04:36:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:36:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:36:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:36:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:36:45 --> Total execution time: 0.1493
DEBUG - 2020-09-09 04:36:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:36:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 04:36:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-09 04:36:48 --> Total execution time: 0.2618
DEBUG - 2020-09-09 04:36:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:36:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:36:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 04:36:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:36:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:36:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:36:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:36:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:36:54 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:36:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:36:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:36:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:36:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:36:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:36:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:36:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:36:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:36:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:36:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:36:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:36:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:36:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:36:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:36:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:36:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:36:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:36:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:36:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:36:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:36:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:36:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:36:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:36:59 --> UTF-8 Support Enabled
ERROR - 2020-09-09 04:36:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:36:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:36:59 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-09 04:36:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:36:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:36:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:36:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:37:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:37:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:37:09 --> Total execution time: 0.1545
DEBUG - 2020-09-09 04:37:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:37:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:37:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 04:37:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-09 04:37:12 --> Total execution time: 0.1779
DEBUG - 2020-09-09 04:37:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:37:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:37:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:16 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-09 04:37:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 04:37:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:37:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:37:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 04:45:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:45:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:45:29 --> Total execution time: 0.1364
DEBUG - 2020-09-09 04:45:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:45:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 04:45:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-09 04:45:35 --> Total execution time: 0.1655
DEBUG - 2020-09-09 04:45:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:45:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:45:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 04:45:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 04:45:47 --> Total execution time: 0.1048
DEBUG - 2020-09-09 04:45:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 04:45:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 04:45:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-09 04:45:51 --> Total execution time: 0.1841
DEBUG - 2020-09-09 04:45:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:45:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 04:45:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 05:30:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:30:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 05:30:19 --> Total execution time: 0.1600
DEBUG - 2020-09-09 05:30:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:30:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 05:30:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-09 05:30:21 --> Total execution time: 0.1265
DEBUG - 2020-09-09 05:30:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:30:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 05:30:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 05:30:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:30:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:30:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 05:30:26 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-09 05:30:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 05:30:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:30:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:30:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 05:30:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 05:30:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:30:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 05:30:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 05:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:30:27 --> UTF-8 Support Enabled
ERROR - 2020-09-09 05:30:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 05:30:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 05:30:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 05:30:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:30:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 05:30:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 05:31:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:31:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 05:31:37 --> Total execution time: 0.1712
DEBUG - 2020-09-09 05:31:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:31:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 05:31:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2020-09-09 05:31:39 --> Total execution time: 0.1745
DEBUG - 2020-09-09 05:31:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:31:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 05:31:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 05:33:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:33:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 05:33:29 --> Total execution time: 0.1526
DEBUG - 2020-09-09 05:33:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:33:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 05:33:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-09-09 05:33:32 --> Total execution time: 0.1321
DEBUG - 2020-09-09 05:33:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:33:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 05:33:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 05:34:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:34:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 05:34:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-09-09 05:34:53 --> Total execution time: 0.2124
DEBUG - 2020-09-09 05:34:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:34:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 05:34:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 05:35:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:35:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 05:35:49 --> Total execution time: 0.1915
DEBUG - 2020-09-09 05:36:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:36:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 05:36:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 05:36:40 --> Total execution time: 0.1475
DEBUG - 2020-09-09 05:36:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:36:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 05:36:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-09-09 05:36:43 --> Total execution time: 0.1427
DEBUG - 2020-09-09 05:36:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 05:36:47 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 05:36:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:36:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 05:36:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 05:36:58 --> Total execution time: 0.1340
DEBUG - 2020-09-09 05:37:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:37:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 05:37:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-09-09 05:37:01 --> Total execution time: 0.1646
DEBUG - 2020-09-09 05:37:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:37:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 05:37:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 05:37:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:37:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 05:37:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-09-09 05:37:13 --> Total execution time: 0.1643
DEBUG - 2020-09-09 05:37:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:37:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 05:37:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 05:37:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:37:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 05:37:34 --> Total execution time: 0.1565
DEBUG - 2020-09-09 05:37:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:37:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 05:37:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2020-09-09 05:37:36 --> Total execution time: 0.1716
DEBUG - 2020-09-09 05:37:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:37:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 05:37:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 05:37:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:37:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 05:37:57 --> Total execution time: 0.1425
DEBUG - 2020-09-09 05:38:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:38:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 05:38:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-09-09 05:38:00 --> Total execution time: 0.1559
DEBUG - 2020-09-09 05:38:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:38:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 05:38:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 05:38:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:38:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 05:38:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-09-09 05:38:38 --> Total execution time: 0.1958
DEBUG - 2020-09-09 05:38:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:38:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 05:38:41 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 05:39:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:39:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 05:39:48 --> Total execution time: 0.1334
DEBUG - 2020-09-09 05:39:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:39:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 05:39:51 --> Total execution time: 0.1462
DEBUG - 2020-09-09 05:39:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:39:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 05:39:54 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 05:40:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:40:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 05:40:43 --> Total execution time: 0.1245
DEBUG - 2020-09-09 05:40:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:40:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 05:40:46 --> Total execution time: 0.1480
DEBUG - 2020-09-09 05:40:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:40:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 05:40:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-09 05:43:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:43:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 05:43:48 --> Total execution time: 0.1678
DEBUG - 2020-09-09 05:43:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:43:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 05:43:58 --> Total execution time: 0.1256
DEBUG - 2020-09-09 05:44:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:44:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 05:44:04 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
ERROR - 2020-09-09 05:44:04 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-09-09 05:44:04 --> Total execution time: 0.1201
DEBUG - 2020-09-09 05:44:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:44:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 05:44:27 --> Total execution time: 0.1472
DEBUG - 2020-09-09 05:45:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 05:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 05:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 05:45:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 05:45:24 --> get_category_list->{"lang":"42","exercise_mode_id":"5","support_lang_id":"2"}
ERROR - 2020-09-09 05:45:24 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-09-09 05:45:24 --> Total execution time: 0.1306
DEBUG - 2020-09-09 06:12:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 06:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 06:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 06:12:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 06:12:38 --> get_category_list->{"lang":"42","exercise_mode_id":"1","support_lang_id":"2"}
ERROR - 2020-09-09 06:12:38 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-09-09 06:12:38 --> Total execution time: 0.1357
DEBUG - 2020-09-09 06:12:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 06:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 06:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 06:12:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 06:12:42 --> Total execution time: 0.1695
DEBUG - 2020-09-09 06:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 06:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 06:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 06:22:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 06:22:02 --> Total execution time: 0.1108
DEBUG - 2020-09-09 06:22:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 06:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 06:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 06:22:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 06:22:38 --> Total execution time: 0.1385
DEBUG - 2020-09-09 06:22:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 06:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 06:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 06:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 06:22:43 --> Total execution time: 0.1665
DEBUG - 2020-09-09 06:22:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 06:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 06:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 06:22:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 06:22:50 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-09 06:22:50 --> Total execution time: 0.1153
DEBUG - 2020-09-09 06:23:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 06:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 06:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 06:23:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 06:23:02 --> get_subcategory_list->{"lang":"37","category_id":"68","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-09 06:23:02 --> Total execution time: 0.1013
DEBUG - 2020-09-09 06:23:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 06:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 06:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 06:23:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 06:23:06 --> get_exercise_type_list->{"lang":"37","subcategory_id":"119","support_lang_id":"2"}
DEBUG - 2020-09-09 06:23:06 --> Total execution time: 0.1136
DEBUG - 2020-09-09 06:23:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 06:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 06:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 06:23:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 06:23:11 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"2","exercise_mode_id":"1","category_id":"68","subcategory_id":"119","support_lang_id":"2"}
DEBUG - 2020-09-09 06:23:11 --> Total execution time: 0.1439
DEBUG - 2020-09-09 06:23:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 06:23:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 06:23:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 06:23:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 06:23:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-09 06:23:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-09 06:23:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 06:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 06:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 06:23:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 06:23:19 --> get_exercise_type_list->{"lang":"37","subcategory_id":"119","support_lang_id":"2"}
DEBUG - 2020-09-09 06:23:19 --> Total execution time: 0.1398
DEBUG - 2020-09-09 06:23:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 06:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 06:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-09 06:23:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 06:23:22 --> get_subcategory_list->{"lang":"37","category_id":"68","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-09 06:23:22 --> Total execution time: 0.1213
