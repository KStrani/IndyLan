<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-09-10 17:36:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-10 17:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-10 17:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-10 17:36:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 17:36:44 --> Total execution time: 0.1329
DEBUG - 2020-09-10 17:36:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-10 17:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-10 17:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-10 17:36:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 17:36:57 --> Total execution time: 0.1377
DEBUG - 2020-09-10 17:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-10 17:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-10 17:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-10 17:37:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 17:37:09 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2020-09-10 17:37:09 --> Total execution time: 0.1421
DEBUG - 2020-09-10 17:37:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-10 17:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-10 17:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-10 17:37:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 17:37:13 --> get_subcategory_list->{"lang":"37","category_id":"67","user_id":"1","support_lang_id":"1"}
DEBUG - 2020-09-10 17:37:13 --> Total execution time: 0.1508
DEBUG - 2020-09-10 17:37:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-10 17:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-10 17:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-10 17:37:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 17:37:17 --> get_exercise_type_list->{"lang":"37","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2020-09-10 17:37:17 --> Total execution time: 0.1788
DEBUG - 2020-09-10 17:37:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-10 17:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-10 17:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-10 17:37:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 17:37:21 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"1","exercise_mode_id":"1","category_id":"67","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2020-09-10 17:37:21 --> Total execution time: 0.2273
DEBUG - 2020-09-10 17:37:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-10 17:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-10 17:37:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-10 17:37:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-10 17:37:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-10 17:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-10 17:37:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-10 17:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-10 17:37:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-10 17:37:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-10 17:37:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-10 17:37:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-10 17:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-10 17:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-10 17:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-10 17:37:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-10 17:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-10 17:37:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-10 17:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-10 17:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-10 17:37:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-10 17:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-10 17:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-10 17:37:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-10 17:37:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-10 17:37:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-10 17:37:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-10 17:37:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-10 17:37:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-10 17:37:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-10 17:37:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-10 17:37:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-10 17:37:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-10 17:37:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-10 17:37:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-10 17:37:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-10 17:37:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-10 17:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-10 17:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-10 17:37:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 17:37:38 --> get_exercise_type_list->{"lang":"37","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2020-09-10 17:37:38 --> Total execution time: 0.1091
DEBUG - 2020-09-10 17:37:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-10 17:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-10 17:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-10 17:37:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 17:37:38 --> get_subcategory_list->{"lang":"37","category_id":"67","user_id":"1","support_lang_id":"1"}
DEBUG - 2020-09-10 17:37:38 --> Total execution time: 0.1944
