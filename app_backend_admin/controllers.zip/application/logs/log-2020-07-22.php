<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-07-22 04:48:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 04:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 04:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 04:48:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 04:48:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 04:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 04:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 04:48:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 04:48:38 --> Total execution time: 0.6397
DEBUG - 2020-07-22 04:52:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 04:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 04:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 04:52:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 04:52:55 --> Total execution time: 0.1293
DEBUG - 2020-07-22 05:35:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 05:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 05:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 05:35:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 05:35:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 05:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 05:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 05:35:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 05:35:44 --> Total execution time: 0.3497
DEBUG - 2020-07-22 05:35:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 05:35:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 05:35:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 05:35:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 05:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 05:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 05:35:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 05:35:54 --> Total execution time: 0.4855
DEBUG - 2020-07-22 05:35:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 05:35:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 05:35:54 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 05:36:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 05:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 05:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 05:36:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 05:36:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 05:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 05:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 05:36:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 05:36:09 --> Total execution time: 0.1589
DEBUG - 2020-07-22 05:36:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 05:36:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 05:36:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 05:36:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 05:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 05:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 05:36:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 05:36:13 --> Total execution time: 0.1467
DEBUG - 2020-07-22 05:36:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 05:36:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 05:36:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 05:36:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 05:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 05:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 05:36:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 05:36:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 05:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 05:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 05:36:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 05:36:20 --> Total execution time: 0.1497
DEBUG - 2020-07-22 05:36:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 05:36:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 05:36:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 05:36:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 05:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 05:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 05:36:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 05:36:31 --> Total execution time: 1.4644
DEBUG - 2020-07-22 05:40:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 05:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 05:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 05:40:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 05:40:44 --> Total execution time: 0.1681
DEBUG - 2020-07-22 05:40:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 05:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 05:40:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 05:40:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 05:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 05:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 05:40:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 05:40:47 --> Total execution time: 0.2562
DEBUG - 2020-07-22 05:42:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 05:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 05:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 05:42:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 05:42:16 --> Total execution time: 0.1144
DEBUG - 2020-07-22 05:42:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 05:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 05:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 05:42:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 05:42:16 --> Total execution time: 0.2002
DEBUG - 2020-07-22 05:42:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 05:42:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 05:42:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 05:42:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 05:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 05:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 05:42:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 05:42:20 --> Total execution time: 0.2247
DEBUG - 2020-07-22 05:59:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 05:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 05:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 05:59:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 05:59:46 --> Total execution time: 0.1623
DEBUG - 2020-07-22 05:59:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 05:59:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 05:59:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:11:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:11:19 --> Total execution time: 0.1508
DEBUG - 2020-07-22 06:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:11:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:11:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:11:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:11:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:11:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:11:38 --> Total execution time: 0.1534
DEBUG - 2020-07-22 06:11:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:11:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:11:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:11:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:11:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:11:41 --> Total execution time: 0.1570
DEBUG - 2020-07-22 06:11:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:11:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:11:41 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:11:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:11:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:11:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:11:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:11:47 --> Total execution time: 0.1542
DEBUG - 2020-07-22 06:11:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:11:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:11:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:11:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:11:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:11:48 --> 404 Page Not Found: Uploads/unnamed.png
DEBUG - 2020-07-22 06:11:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:11:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:11:57 --> Total execution time: 0.1582
DEBUG - 2020-07-22 06:11:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:11:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:11:58 --> Total execution time: 0.3067
DEBUG - 2020-07-22 06:11:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:11:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:12:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:12:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:12:02 --> Total execution time: 0.1764
DEBUG - 2020-07-22 06:12:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:12:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:12:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:12:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:12:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:12:11 --> Total execution time: 0.1446
DEBUG - 2020-07-22 06:12:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:12:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:12:11 --> Total execution time: 0.1462
DEBUG - 2020-07-22 06:12:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:12:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:12:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:12:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:12:14 --> Total execution time: 0.1612
DEBUG - 2020-07-22 06:12:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:12:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:12:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:12:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:12:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:12:26 --> Upload class already loaded. Second attempt ignored.
ERROR - 2020-07-22 06:12:26 --> Severity: error --> Exception: Call to undefined function finfo_open() E:\xampp\htdocs\voolsy\langoadmin\system\libraries\Upload.php 1222
DEBUG - 2020-07-22 06:12:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:12:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:12:30 --> Total execution time: 0.1538
DEBUG - 2020-07-22 06:15:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:15:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:15:28 --> Total execution time: 0.1515
DEBUG - 2020-07-22 06:15:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:15:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:15:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:15:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:15:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:15:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:15:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:15:40 --> Total execution time: 0.2032
DEBUG - 2020-07-22 06:15:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:15:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:15:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:15:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:15:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:15:45 --> Total execution time: 0.1580
DEBUG - 2020-07-22 06:15:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:15:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:15:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:15:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:15:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:15:49 --> Total execution time: 0.1326
DEBUG - 2020-07-22 06:15:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:15:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:15:50 --> Total execution time: 0.3002
DEBUG - 2020-07-22 06:15:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:15:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:15:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:17:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:17:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:17:47 --> Total execution time: 0.1529
DEBUG - 2020-07-22 06:17:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:17:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:17:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:18:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:18:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:18:16 --> Total execution time: 0.1102
DEBUG - 2020-07-22 06:18:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:18:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:18:17 --> Total execution time: 0.1942
DEBUG - 2020-07-22 06:18:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:18:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:18:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:18:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:18:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:18:21 --> Total execution time: 0.2228
DEBUG - 2020-07-22 06:18:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:18:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:18:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:19:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:19:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:19:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:19:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:19:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:19:12 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-22 06:19:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:19:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:19:30 --> Total execution time: 0.1328
DEBUG - 2020-07-22 06:19:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:19:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:19:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:19:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:19:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:19:30 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-22 06:19:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:19:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:19:38 --> Total execution time: 0.1404
DEBUG - 2020-07-22 06:19:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:19:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:19:38 --> Total execution time: 0.2761
DEBUG - 2020-07-22 06:19:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:19:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:19:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:19:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:19:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-22 06:19:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\add_phrases.php 41
DEBUG - 2020-07-22 06:19:42 --> Total execution time: 0.2372
DEBUG - 2020-07-22 06:19:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:19:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:19:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:19:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:19:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:19:48 --> Total execution time: 0.1567
DEBUG - 2020-07-22 06:19:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:19:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:19:48 --> Total execution time: 0.3490
DEBUG - 2020-07-22 06:19:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:19:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:19:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:19:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:19:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:19:52 --> Total execution time: 0.1936
DEBUG - 2020-07-22 06:19:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:19:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:19:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:19:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:19:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:19:59 --> Total execution time: 0.1380
DEBUG - 2020-07-22 06:19:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:20:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:20:00 --> Total execution time: 0.1526
DEBUG - 2020-07-22 06:20:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:20:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:20:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:20:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:20:10 --> Total execution time: 0.1368
DEBUG - 2020-07-22 06:20:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:20:10 --> Total execution time: 0.1539
DEBUG - 2020-07-22 06:20:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:20:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:20:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:20:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:20:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:20:15 --> Total execution time: 0.1372
DEBUG - 2020-07-22 06:20:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:20:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-22 06:20:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\header.php 86
DEBUG - 2020-07-22 06:20:15 --> Total execution time: 0.1499
DEBUG - 2020-07-22 06:20:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:20:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:20:15 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:20:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:20:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:20:19 --> Total execution time: 0.1597
DEBUG - 2020-07-22 06:20:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:20:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-22 06:20:19 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\header.php 86
DEBUG - 2020-07-22 06:20:19 --> Total execution time: 0.2055
DEBUG - 2020-07-22 06:20:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:20:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:20:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 06:20:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:20:20 --> No URI present. Default controller set.
DEBUG - 2020-07-22 06:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:20:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:20:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:20:20 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-22 06:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:20:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:20:20 --> Total execution time: 0.3490
DEBUG - 2020-07-22 06:20:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:20:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:20:31 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-22 06:20:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 06:20:35 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-22 06:20:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 06:20:35 --> No URI present. Default controller set.
DEBUG - 2020-07-22 06:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 06:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 06:20:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 06:20:36 --> Total execution time: 0.1241
DEBUG - 2020-07-22 08:12:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:12:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-22 08:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\header.php 86
DEBUG - 2020-07-22 08:12:03 --> Total execution time: 0.5578
DEBUG - 2020-07-22 08:12:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:12:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 08:12:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 08:12:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:12:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 08:12:04 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-22 08:12:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:12:04 --> No URI present. Default controller set.
DEBUG - 2020-07-22 08:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:12:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:12:04 --> Total execution time: 0.2126
DEBUG - 2020-07-22 08:12:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:12:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 08:12:04 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-22 08:12:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:12:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 08:12:05 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-22 08:12:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:12:05 --> No URI present. Default controller set.
DEBUG - 2020-07-22 08:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:12:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:12:05 --> Total execution time: 0.1418
DEBUG - 2020-07-22 08:12:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:12:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:12:09 --> Total execution time: 0.2506
DEBUG - 2020-07-22 08:12:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:12:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:12:13 --> Total execution time: 0.1650
DEBUG - 2020-07-22 08:12:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:12:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:12:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:12:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:12:16 --> Total execution time: 0.1480
DEBUG - 2020-07-22 08:12:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:12:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:12:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:12:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:12:27 --> Total execution time: 0.1549
DEBUG - 2020-07-22 08:12:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:12:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:12:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:12:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:12:39 --> Total execution time: 0.1694
DEBUG - 2020-07-22 08:12:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:12:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:12:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:12:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:12:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:12:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:12:51 --> Total execution time: 0.1381
DEBUG - 2020-07-22 08:12:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:12:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:12:56 --> Total execution time: 0.1516
DEBUG - 2020-07-22 08:13:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:13:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:13:53 --> Total execution time: 0.1722
DEBUG - 2020-07-22 08:14:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:14:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:14:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:14:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:14:09 --> Total execution time: 0.1949
DEBUG - 2020-07-22 08:14:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:14:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 08:14:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 08:38:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:39:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:39:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:40:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:40:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:40:22 --> Total execution time: 0.1334
DEBUG - 2020-07-22 08:40:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:40:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 08:40:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 08:40:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:40:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:40:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:40:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:40:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:40:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:40:48 --> Total execution time: 0.1595
DEBUG - 2020-07-22 08:41:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:41:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:41:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:41:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:53:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:53:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:53:07 --> Total execution time: 0.4665
DEBUG - 2020-07-22 08:53:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:53:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:53:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:53:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:54:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:54:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:54:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:55:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:56:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:56:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:57:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:57:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:58:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:58:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 08:58:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 08:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 08:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 08:58:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:04:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:04:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:04:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:04:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:04:44 --> Total execution time: 0.1676
DEBUG - 2020-07-22 09:04:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:04:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 09:04:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 09:04:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:04:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:04:51 --> Total execution time: 0.1550
DEBUG - 2020-07-22 09:05:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:05:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:05:06 --> Total execution time: 0.1260
DEBUG - 2020-07-22 09:05:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:05:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:05:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:05:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:05:21 --> Total execution time: 0.1230
DEBUG - 2020-07-22 09:05:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:05:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 09:05:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 09:05:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:05:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:05:27 --> Total execution time: 0.1791
DEBUG - 2020-07-22 09:53:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:53:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:53:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:53:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:53:55 --> Total execution time: 0.2256
DEBUG - 2020-07-22 09:54:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:54:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:54:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:54:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:54:09 --> Total execution time: 0.2085
DEBUG - 2020-07-22 09:54:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 09:54:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 09:54:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:54:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:54:16 --> Total execution time: 0.1461
DEBUG - 2020-07-22 09:54:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:54:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:54:16 --> Total execution time: 0.2224
DEBUG - 2020-07-22 09:54:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 09:54:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 09:54:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 09:54:16 --> 404 Page Not Found: Uploads/unnamed.png
DEBUG - 2020-07-22 09:54:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:54:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:54:18 --> Total execution time: 0.1517
DEBUG - 2020-07-22 09:54:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:54:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:54:19 --> Total execution time: 0.6209
DEBUG - 2020-07-22 09:54:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 09:54:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 09:54:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:54:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:54:21 --> Total execution time: 0.1756
DEBUG - 2020-07-22 09:54:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:54:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:54:21 --> Total execution time: 0.3416
DEBUG - 2020-07-22 09:54:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 09:54:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 09:54:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:54:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:54:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:54:26 --> Total execution time: 0.1546
DEBUG - 2020-07-22 09:54:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:54:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:54:27 --> Total execution time: 0.1537
DEBUG - 2020-07-22 09:54:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 09:54:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 09:54:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:54:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:54:30 --> Total execution time: 0.1381
DEBUG - 2020-07-22 09:54:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:54:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:54:30 --> Total execution time: 0.1560
DEBUG - 2020-07-22 09:54:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 09:54:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 09:54:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:54:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:54:32 --> Total execution time: 0.1698
DEBUG - 2020-07-22 09:54:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:54:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:54:32 --> Total execution time: 0.1582
DEBUG - 2020-07-22 09:54:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 09:54:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 09:54:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:54:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:54:34 --> Total execution time: 0.1634
DEBUG - 2020-07-22 09:54:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:54:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:54:34 --> Total execution time: 0.1674
DEBUG - 2020-07-22 09:54:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 09:54:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 09:54:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 09:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 09:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 09:54:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 09:54:38 --> Total execution time: 0.1701
DEBUG - 2020-07-22 11:29:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:29:38 --> No URI present. Default controller set.
DEBUG - 2020-07-22 11:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 11:29:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 11:29:39 --> Total execution time: 0.6101
DEBUG - 2020-07-22 11:29:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:29:41 --> No URI present. Default controller set.
DEBUG - 2020-07-22 11:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 11:29:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 11:29:41 --> Total execution time: 0.1442
DEBUG - 2020-07-22 11:30:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 11:30:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 11:30:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 11:30:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 11:30:17 --> Total execution time: 0.1927
DEBUG - 2020-07-22 11:30:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:30:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 11:30:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 11:30:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 11:30:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 11:30:46 --> Total execution time: 0.2418
DEBUG - 2020-07-22 11:30:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:30:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 11:30:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 11:30:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 11:30:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 11:30:51 --> Total execution time: 0.1642
DEBUG - 2020-07-22 11:30:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:30:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 11:30:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 11:49:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 11:49:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 11:49:21 --> Total execution time: 0.1134
DEBUG - 2020-07-22 11:49:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 11:49:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 11:49:21 --> Total execution time: 0.1302
DEBUG - 2020-07-22 11:49:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:49:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 11:49:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 11:49:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 11:49:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 11:49:23 --> Total execution time: 0.1127
DEBUG - 2020-07-22 11:49:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 11:49:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 11:49:24 --> Total execution time: 0.1326
DEBUG - 2020-07-22 11:49:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:49:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 11:49:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 11:49:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 11:49:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 11:49:35 --> Total execution time: 0.1309
DEBUG - 2020-07-22 11:50:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 11:50:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 11:50:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 11:50:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 11:50:02 --> Total execution time: 0.1604
DEBUG - 2020-07-22 11:50:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:50:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 11:50:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 11:50:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 11:50:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 11:50:08 --> Total execution time: 0.1281
DEBUG - 2020-07-22 11:50:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 11:50:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 11:50:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 11:50:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 11:50:18 --> Total execution time: 0.1381
DEBUG - 2020-07-22 11:50:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:50:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 11:50:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 11:53:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 11:53:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 11:53:35 --> Total execution time: 0.1413
DEBUG - 2020-07-22 11:53:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 11:53:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-22 11:53:36 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\header.php 86
DEBUG - 2020-07-22 11:53:36 --> Total execution time: 0.2666
DEBUG - 2020-07-22 11:53:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:53:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 11:53:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 11:53:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:53:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:53:36 --> No URI present. Default controller set.
ERROR - 2020-07-22 11:53:36 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-22 11:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 11:53:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 11:53:36 --> Total execution time: 0.2647
DEBUG - 2020-07-22 11:53:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:53:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 11:53:37 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-22 11:53:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:53:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 11:53:37 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-22 11:53:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:53:37 --> No URI present. Default controller set.
DEBUG - 2020-07-22 11:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 11:53:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 11:53:37 --> Total execution time: 0.1668
DEBUG - 2020-07-22 11:53:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:53:38 --> No URI present. Default controller set.
DEBUG - 2020-07-22 11:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 11:53:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 11:53:38 --> Total execution time: 0.1399
DEBUG - 2020-07-22 11:53:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:53:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 11:53:39 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-22 11:53:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 11:53:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 11:53:43 --> Total execution time: 0.1243
DEBUG - 2020-07-22 11:53:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 11:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 11:53:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 11:53:43 --> Total execution time: 0.1255
DEBUG - 2020-07-22 11:53:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 11:53:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 11:53:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 12:11:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 12:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 12:11:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 12:11:35 --> Total execution time: 0.2153
DEBUG - 2020-07-22 12:15:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 12:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 12:15:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 12:15:20 --> Total execution time: 0.1706
DEBUG - 2020-07-22 12:15:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 12:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 12:15:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-22 12:15:20 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ',' or ';' E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\portaluser_list.php 130
DEBUG - 2020-07-22 12:21:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 12:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 12:21:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 12:21:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 12:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 12:21:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 12:22:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 12:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 12:22:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 12:23:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 12:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 12:23:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-22 12:23:48 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ',' or ';' E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\portaluser_list.php 130
DEBUG - 2020-07-22 12:24:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 12:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 12:24:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 12:24:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 12:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 12:24:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-22 12:24:54 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ',' or ';' E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\portaluser_list.php 69
DEBUG - 2020-07-22 12:24:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 12:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 12:24:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-22 12:24:56 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ',' or ';' E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\portaluser_list.php 69
DEBUG - 2020-07-22 12:24:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 12:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 12:24:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-22 12:24:56 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ',' or ';' E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\portaluser_list.php 69
DEBUG - 2020-07-22 12:30:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 12:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 12:30:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-22 12:30:43 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ',' or ';' E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\portaluser_list.php 69
DEBUG - 2020-07-22 12:31:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 12:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 12:31:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-22 12:31:50 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ',' or ';' E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\portaluser_list.php 69
DEBUG - 2020-07-22 12:31:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 12:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 12:31:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-22 12:31:52 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ',' or ';' E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\portaluser_list.php 69
DEBUG - 2020-07-22 12:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 12:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 12:32:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-22 12:32:24 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ',' or ';' E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\portaluser_list.php 68
DEBUG - 2020-07-22 12:33:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 12:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 12:33:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 12:35:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 12:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 12:35:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 12:35:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 12:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 12:35:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 12:35:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 12:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 12:35:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 12:35:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 12:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 12:35:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-22 12:35:42 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ',' or ';' E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\portaluser_list.php 68
DEBUG - 2020-07-22 12:47:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 12:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 12:47:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 12:48:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 12:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 12:48:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 12:48:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 12:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 12:48:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 12:48:55 --> Total execution time: 0.1616
DEBUG - 2020-07-22 12:48:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 12:48:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 12:48:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 13:01:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 13:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 13:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 13:01:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 13:01:56 --> Total execution time: 0.1300
DEBUG - 2020-07-22 13:01:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 13:01:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 13:01:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 13:02:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 13:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 13:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 13:02:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 13:02:02 --> Total execution time: 0.1404
DEBUG - 2020-07-22 14:05:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 14:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 14:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 14:05:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 14:05:29 --> Total execution time: 0.1164
DEBUG - 2020-07-22 14:05:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 14:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 14:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 14:05:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 14:05:29 --> Total execution time: 0.1825
DEBUG - 2020-07-22 14:05:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 14:05:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 14:05:29 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 14:05:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 14:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 14:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 14:05:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 14:05:32 --> Total execution time: 0.1319
DEBUG - 2020-07-22 14:05:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 14:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 14:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 14:05:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 14:05:33 --> Total execution time: 0.1634
DEBUG - 2020-07-22 14:05:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 14:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 14:05:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 14:05:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 14:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 14:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 14:05:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 14:05:35 --> Total execution time: 0.1796
DEBUG - 2020-07-22 14:05:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 14:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 14:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 14:05:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 14:05:35 --> Total execution time: 0.3116
DEBUG - 2020-07-22 14:05:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 14:05:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 14:05:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 14:07:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 14:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 14:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 14:07:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 14:07:24 --> Total execution time: 0.1027
DEBUG - 2020-07-22 14:07:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 14:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 14:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 14:07:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-22 14:07:24 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\header.php 86
DEBUG - 2020-07-22 14:07:24 --> Total execution time: 0.1463
DEBUG - 2020-07-22 14:07:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 14:07:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 14:07:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 14:07:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 14:07:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 14:07:24 --> No URI present. Default controller set.
DEBUG - 2020-07-22 14:07:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 14:07:24 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-22 14:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 14:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 14:07:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 14:07:25 --> Total execution time: 0.2420
DEBUG - 2020-07-22 14:07:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 14:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 14:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 14:07:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 14:07:29 --> Total execution time: 0.1755
DEBUG - 2020-07-22 14:07:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 14:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 14:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 14:07:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 14:07:29 --> Total execution time: 0.1716
DEBUG - 2020-07-22 14:07:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 14:07:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 14:07:29 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 14:07:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 14:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 14:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 14:07:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 14:07:35 --> Total execution time: 0.1447
DEBUG - 2020-07-22 14:07:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 14:07:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 14:07:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-22 14:08:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 14:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 14:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 14:08:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 14:08:10 --> Total execution time: 0.1580
DEBUG - 2020-07-22 14:08:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 14:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 14:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 14:08:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 14:20:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 14:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-22 14:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-22 14:20:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-22 14:20:02 --> Total execution time: 0.1269
DEBUG - 2020-07-22 14:20:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-22 14:20:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-22 14:20:02 --> 404 Page Not Found: Assets/chosen
