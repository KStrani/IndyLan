<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-01-29 05:28:00 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 05:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 05:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 05:28:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 05:28:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 05:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 05:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 05:28:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 05:28:04 --> Total execution time: 0.1159
DEBUG - 2021-01-29 05:40:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 05:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 05:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 05:40:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 05:40:49 --> Total execution time: 0.1394
DEBUG - 2021-01-29 05:40:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 05:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 05:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 05:40:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 05:40:59 --> Total execution time: 0.1664
DEBUG - 2021-01-29 05:46:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 05:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 05:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 05:46:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 05:46:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 05:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 05:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 05:46:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 05:46:13 --> Total execution time: 0.1506
DEBUG - 2021-01-29 05:46:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 05:46:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 05:46:15 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 05:46:19 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 05:46:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 05:46:19 --> 404 Page Not Found: Uploads/badger.jpg
DEBUG - 2021-01-29 05:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 05:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 05:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 05:48:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 05:48:32 --> Total execution time: 0.1650
DEBUG - 2021-01-29 05:48:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 05:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 05:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 05:48:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 05:48:34 --> Total execution time: 0.1624
DEBUG - 2021-01-29 05:48:36 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 05:48:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 05:48:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 05:49:25 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 05:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 05:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 05:49:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 05:49:25 --> Total execution time: 0.1256
DEBUG - 2021-01-29 05:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 05:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 05:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 05:49:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 05:49:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 05:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 05:49:27 --> Total execution time: 0.1494
DEBUG - 2021-01-29 05:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 05:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 05:49:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 05:49:27 --> Total execution time: 0.1211
DEBUG - 2021-01-29 05:49:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 05:49:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 05:49:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 05:49:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 05:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 05:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 05:49:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 05:49:42 --> Total execution time: 0.1381
DEBUG - 2021-01-29 05:49:45 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 05:49:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 05:49:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:03:45 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:03:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:03:45 --> Total execution time: 0.1527
DEBUG - 2021-01-29 06:03:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:03:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:03:47 --> Total execution time: 0.1654
DEBUG - 2021-01-29 06:03:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:03:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:03:47 --> Total execution time: 0.1787
DEBUG - 2021-01-29 06:03:50 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:03:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:03:50 --> Total execution time: 0.1989
DEBUG - 2021-01-29 06:03:53 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:03:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:03:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:04:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:04:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:04:11 --> Total execution time: 0.1570
DEBUG - 2021-01-29 06:04:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:04:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:04:13 --> Total execution time: 0.1801
DEBUG - 2021-01-29 06:04:14 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:04:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 06:04:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 06:04:14 --> Total execution time: 0.1927
DEBUG - 2021-01-29 06:04:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:04:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:04:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:04:15 --> Total execution time: 0.1572
DEBUG - 2021-01-29 06:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:04:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 06:04:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 06:04:15 --> Total execution time: 0.1941
DEBUG - 2021-01-29 06:04:18 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:04:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:04:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:04:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:04:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:04:33 --> Total execution time: 0.1353
DEBUG - 2021-01-29 06:04:35 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:04:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:04:35 --> Total execution time: 0.1301
DEBUG - 2021-01-29 06:04:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:04:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:04:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:04:38 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:04:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:04:38 --> 404 Page Not Found: Uploads/badger.jpg
DEBUG - 2021-01-29 06:06:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:06:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:06:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:06:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:06:33 --> Total execution time: 0.1433
DEBUG - 2021-01-29 06:06:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:06:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:06:58 --> Total execution time: 0.1522
DEBUG - 2021-01-29 06:07:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:07:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:07:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:07:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:07:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:07:07 --> Total execution time: 0.0968
DEBUG - 2021-01-29 06:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:07:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:07:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:07:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:07:10 --> Total execution time: 0.1357
DEBUG - 2021-01-29 06:07:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:07:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:07:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:07:16 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:07:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:07:16 --> 404 Page Not Found: Uploads/badger.jpg
DEBUG - 2021-01-29 06:07:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:07:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:07:52 --> Total execution time: 0.1142
DEBUG - 2021-01-29 06:08:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:08:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:08:20 --> user_login->{"email":"admin@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2021-01-29 06:08:20 --> Total execution time: 0.1329
DEBUG - 2021-01-29 06:08:23 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:08:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:08:23 --> Total execution time: 0.1243
DEBUG - 2021-01-29 06:09:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:09:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:09:04 --> Total execution time: 0.1538
DEBUG - 2021-01-29 06:09:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:09:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:09:07 --> Total execution time: 0.1406
DEBUG - 2021-01-29 06:09:09 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:09:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:09:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:09:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:09:10 --> No URI present. Default controller set.
DEBUG - 2021-01-29 06:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:09:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:09:10 --> Total execution time: 0.1204
DEBUG - 2021-01-29 06:09:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:09:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:09:15 --> 404 Page Not Found: Admin_master/null
DEBUG - 2021-01-29 06:09:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:09:20 --> No URI present. Default controller set.
DEBUG - 2021-01-29 06:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:09:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:09:20 --> Total execution time: 0.1384
DEBUG - 2021-01-29 06:09:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:09:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:09:57 --> user_login->{"email":"qaorig1@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
ERROR - 2021-01-29 06:09:57 --> {"status":0,"message":"Username or Password Wrong!!","message_en":"","result":[],"status_message":"OK"}
DEBUG - 2021-01-29 06:09:57 --> Total execution time: 0.1154
DEBUG - 2021-01-29 06:10:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:10:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:10:08 --> user_login->{"email":"qaorig1@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
ERROR - 2021-01-29 06:10:08 --> {"status":0,"message":"Username or Password Wrong!!","message_en":"","result":[],"status_message":"OK"}
DEBUG - 2021-01-29 06:10:08 --> Total execution time: 0.1162
DEBUG - 2021-01-29 06:10:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:10:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:10:26 --> Total execution time: 0.1222
DEBUG - 2021-01-29 06:10:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:10:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:10:49 --> Total execution time: 0.1138
DEBUG - 2021-01-29 06:10:53 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:10:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:10:53 --> Total execution time: 0.1450
DEBUG - 2021-01-29 06:10:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:10:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:10:58 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 06:10:58 --> Total execution time: 0.0958
DEBUG - 2021-01-29 06:11:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:11:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:11:01 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 06:11:01 --> Total execution time: 0.1047
DEBUG - 2021-01-29 06:11:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:11:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:11:04 --> user_login->{"email":"rastech47@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2021-01-29 06:11:04 --> Total execution time: 0.1531
DEBUG - 2021-01-29 06:11:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:11:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:11:06 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 06:11:06 --> Total execution time: 0.1025
DEBUG - 2021-01-29 06:11:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:11:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:11:08 --> Total execution time: 0.1198
DEBUG - 2021-01-29 06:11:25 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:11:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:11:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:11:25 --> Total execution time: 0.1414
DEBUG - 2021-01-29 06:11:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:11:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:11:28 --> Total execution time: 0.1759
DEBUG - 2021-01-29 06:11:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:11:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:11:31 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:11:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:11:31 --> No URI present. Default controller set.
DEBUG - 2021-01-29 06:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:11:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:11:32 --> Total execution time: 0.1317
DEBUG - 2021-01-29 06:11:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:11:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:11:35 --> 404 Page Not Found: Admin_master/null
DEBUG - 2021-01-29 06:11:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:11:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:11:37 --> Total execution time: 0.1193
DEBUG - 2021-01-29 06:11:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:11:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:11:39 --> Total execution time: 0.1318
DEBUG - 2021-01-29 06:11:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:11:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:11:41 --> Total execution time: 0.1281
DEBUG - 2021-01-29 06:11:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:11:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:11:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:11:43 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:11:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:11:43 --> 404 Page Not Found: Uploads/badger.jpg
DEBUG - 2021-01-29 06:11:43 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:11:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:11:43 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 06:11:43 --> Total execution time: 0.1508
DEBUG - 2021-01-29 06:12:09 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:12:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:12:09 --> Total execution time: 0.1081
DEBUG - 2021-01-29 06:12:53 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:12:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:12:53 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 06:12:53 --> Total execution time: 0.1529
DEBUG - 2021-01-29 06:13:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:13:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:13:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:13:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:13:15 --> Total execution time: 0.1328
DEBUG - 2021-01-29 06:13:18 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:13:18 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:13:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:13:18 --> 404 Page Not Found: Uploads/badger.jpg
ERROR - 2021-01-29 06:13:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:13:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:13:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:13:20 --> 404 Page Not Found: Uploads/badger.jpg
DEBUG - 2021-01-29 06:13:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:13:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:13:34 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 06:13:34 --> Total execution time: 0.1143
DEBUG - 2021-01-29 06:13:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:13:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:13:39 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"1"}
DEBUG - 2021-01-29 06:13:39 --> Total execution time: 0.1309
DEBUG - 2021-01-29 06:13:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:13:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:13:47 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 06:13:47 --> Total execution time: 0.1123
DEBUG - 2021-01-29 06:13:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:13:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:13:52 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"1"}
DEBUG - 2021-01-29 06:13:52 --> Total execution time: 0.1317
DEBUG - 2021-01-29 06:15:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:15:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:15:03 --> Total execution time: 0.1529
DEBUG - 2021-01-29 06:15:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:15:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:15:06 --> Total execution time: 0.1231
DEBUG - 2021-01-29 06:15:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:15:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:15:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:26:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:26:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:28:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:28:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:28:06 --> Total execution time: 0.1208
DEBUG - 2021-01-29 06:28:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:28:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:28:06 --> Total execution time: 0.1128
DEBUG - 2021-01-29 06:28:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:28:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:28:07 --> Total execution time: 0.1275
DEBUG - 2021-01-29 06:28:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:28:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:28:08 --> Total execution time: 0.1134
DEBUG - 2021-01-29 06:28:09 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:28:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 06:28:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 06:28:09 --> Total execution time: 0.1176
DEBUG - 2021-01-29 06:28:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:28:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:28:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 06:28:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 06:28:10 --> Total execution time: 0.1356
DEBUG - 2021-01-29 06:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:28:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 06:28:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 06:28:10 --> Total execution time: 0.1503
DEBUG - 2021-01-29 06:28:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:28:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 06:28:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 06:28:10 --> Total execution time: 0.1439
DEBUG - 2021-01-29 06:28:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:28:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:28:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:28:25 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:28:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:32:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:32:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:32:57 --> Total execution time: 0.1364
DEBUG - 2021-01-29 06:32:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:32:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:32:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:33:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:33:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:33:04 --> Total execution time: 0.1246
DEBUG - 2021-01-29 06:33:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:33:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:33:06 --> Total execution time: 0.1550
DEBUG - 2021-01-29 06:33:09 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:33:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:33:17 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:33:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:33:17 --> Total execution time: 0.1297
DEBUG - 2021-01-29 06:33:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:33:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:33:20 --> Total execution time: 0.1598
DEBUG - 2021-01-29 06:33:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:33:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:33:21 --> Total execution time: 0.1365
DEBUG - 2021-01-29 06:33:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:33:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:33:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:33:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:33:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:33:27 --> Total execution time: 0.1377
DEBUG - 2021-01-29 06:33:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:33:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:33:30 --> Total execution time: 0.1845
DEBUG - 2021-01-29 06:33:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:33:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:33:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:33:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:33:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:33:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:33:46 --> Total execution time: 0.1439
DEBUG - 2021-01-29 06:33:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:33:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:33:49 --> Total execution time: 0.1321
DEBUG - 2021-01-29 06:33:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:33:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:33:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:33:56 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:33:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:33:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:33:56 --> Total execution time: 0.1215
DEBUG - 2021-01-29 06:33:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:33:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:33:59 --> Total execution time: 0.1602
DEBUG - 2021-01-29 06:34:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:34:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:34:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:34:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:34:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:34:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:34:10 --> Total execution time: 0.1438
DEBUG - 2021-01-29 06:34:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:34:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:34:13 --> Total execution time: 0.1577
DEBUG - 2021-01-29 06:34:16 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:34:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:34:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:34:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:34:21 --> Total execution time: 0.1532
DEBUG - 2021-01-29 06:34:24 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:34:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:34:24 --> Total execution time: 0.1301
DEBUG - 2021-01-29 06:34:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:34:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:34:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:34:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:34:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:34:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:34:32 --> Total execution time: 0.1355
DEBUG - 2021-01-29 06:34:35 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:34:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:34:35 --> Total execution time: 0.1234
DEBUG - 2021-01-29 06:34:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:34:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:34:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:37:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:37:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:37:07 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 06:37:07 --> Total execution time: 0.1332
DEBUG - 2021-01-29 06:37:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:37:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:37:11 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"1"}
DEBUG - 2021-01-29 06:37:11 --> Total execution time: 0.1274
DEBUG - 2021-01-29 06:37:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:37:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:37:15 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 06:37:15 --> Total execution time: 0.1500
DEBUG - 2021-01-29 06:37:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:37:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:37:21 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 06:37:21 --> Total execution time: 0.1235
DEBUG - 2021-01-29 06:37:24 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:37:24 --> 404 Page Not Found: Fi/uploads
DEBUG - 2021-01-29 06:37:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:37:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:37:27 --> 404 Page Not Found: Fi/uploads
DEBUG - 2021-01-29 06:37:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:37:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:37:34 --> Total execution time: 0.1201
DEBUG - 2021-01-29 06:39:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:39:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:39:07 --> Total execution time: 0.1069
DEBUG - 2021-01-29 06:39:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:39:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:39:11 --> Total execution time: 0.0967
DEBUG - 2021-01-29 06:39:16 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:39:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:39:16 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 06:39:16 --> Total execution time: 0.1470
DEBUG - 2021-01-29 06:39:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:39:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:39:20 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 06:39:20 --> Total execution time: 0.1220
DEBUG - 2021-01-29 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:39:22 --> Total execution time: 0.1465
DEBUG - 2021-01-29 06:39:23 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:39:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:39:23 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 06:39:23 --> Total execution time: 0.1114
DEBUG - 2021-01-29 06:39:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:39:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:39:26 --> Total execution time: 0.1517
DEBUG - 2021-01-29 06:39:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:39:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:39:27 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 06:39:27 --> Total execution time: 0.1208
DEBUG - 2021-01-29 06:39:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:39:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:39:30 --> 404 Page Not Found: En/uploads
DEBUG - 2021-01-29 06:39:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:39:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:39:33 --> 404 Page Not Found: En/uploads
DEBUG - 2021-01-29 06:39:35 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:39:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:39:36 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 06:39:36 --> Total execution time: 0.1356
DEBUG - 2021-01-29 06:39:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:39:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:39:39 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"1"}
DEBUG - 2021-01-29 06:39:39 --> Total execution time: 0.1328
DEBUG - 2021-01-29 06:39:43 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:39:43 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 06:39:43 --> Total execution time: 0.1421
DEBUG - 2021-01-29 06:39:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:39:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:39:47 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 06:39:47 --> Total execution time: 0.1207
DEBUG - 2021-01-29 06:39:50 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:39:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:39:50 --> 404 Page Not Found: Fi/uploads
DEBUG - 2021-01-29 06:39:53 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:39:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:39:53 --> 404 Page Not Found: Fi/uploads
DEBUG - 2021-01-29 06:39:54 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:39:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:39:54 --> Total execution time: 0.1489
DEBUG - 2021-01-29 06:40:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:40:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:40:55 --> 404 Page Not Found: En/uploads
DEBUG - 2021-01-29 06:40:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:40:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:40:58 --> 404 Page Not Found: En/uploads
DEBUG - 2021-01-29 06:41:00 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:41:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:41:00 --> Total execution time: 0.1355
DEBUG - 2021-01-29 06:41:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:41:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 06:41:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 06:41:03 --> Total execution time: 0.1697
DEBUG - 2021-01-29 06:41:05 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:41:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:41:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:41:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:41:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:41:13 --> Total execution time: 0.1364
DEBUG - 2021-01-29 06:41:16 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:41:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 06:41:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 06:41:16 --> Total execution time: 0.1698
DEBUG - 2021-01-29 06:41:19 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:41:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:41:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:41:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:41:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:41:34 --> Total execution time: 0.1211
DEBUG - 2021-01-29 06:41:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:41:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:41:42 --> Total execution time: 0.1830
DEBUG - 2021-01-29 06:41:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:41:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:41:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:43:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:43:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:43:21 --> Total execution time: 0.1180
DEBUG - 2021-01-29 06:43:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:43:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:43:22 --> Total execution time: 0.1077
DEBUG - 2021-01-29 06:43:23 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:43:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:43:23 --> Total execution time: 0.1495
DEBUG - 2021-01-29 06:43:24 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:43:24 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:43:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:43:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:43:24 --> Total execution time: 0.1302
DEBUG - 2021-01-29 06:43:24 --> Total execution time: 0.1276
DEBUG - 2021-01-29 06:43:24 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:43:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:43:24 --> Total execution time: 0.1578
DEBUG - 2021-01-29 06:43:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:43:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:43:26 --> Total execution time: 0.1363
DEBUG - 2021-01-29 06:43:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:43:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:43:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:43:26 --> Total execution time: 0.1192
DEBUG - 2021-01-29 06:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:43:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:43:27 --> Total execution time: 0.1597
DEBUG - 2021-01-29 06:43:29 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:43:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:43:29 --> Total execution time: 0.1550
DEBUG - 2021-01-29 06:43:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:43:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:43:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:44:45 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:44:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:44:45 --> Total execution time: 0.1075
DEBUG - 2021-01-29 06:46:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:46:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:46:45 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:46:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 06:46:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 06:46:45 --> Total execution time: 0.1520
DEBUG - 2021-01-29 06:46:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:46:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:46:47 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:47:09 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:47:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:47:09 --> Total execution time: 0.1250
DEBUG - 2021-01-29 06:47:14 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:47:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:47:14 --> Total execution time: 0.1260
DEBUG - 2021-01-29 06:47:19 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:47:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:47:19 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 06:47:19 --> Total execution time: 0.1382
DEBUG - 2021-01-29 06:47:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:47:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:47:22 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"1"}
DEBUG - 2021-01-29 06:47:22 --> Total execution time: 0.1270
DEBUG - 2021-01-29 06:47:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:47:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:47:26 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 06:47:26 --> Total execution time: 0.1656
DEBUG - 2021-01-29 06:47:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:47:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:47:31 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 06:47:31 --> Total execution time: 0.1357
DEBUG - 2021-01-29 06:47:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:47:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:47:33 --> 404 Page Not Found: Fi/uploads
DEBUG - 2021-01-29 06:47:36 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:47:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:47:36 --> 404 Page Not Found: Fi/uploads
DEBUG - 2021-01-29 06:47:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:47:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:47:55 --> Total execution time: 0.1643
DEBUG - 2021-01-29 06:48:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:48:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:48:08 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 06:48:08 --> Total execution time: 0.1164
DEBUG - 2021-01-29 06:48:14 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:48:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:48:14 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 06:48:14 --> Total execution time: 0.1298
DEBUG - 2021-01-29 06:48:17 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:48:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:48:17 --> 404 Page Not Found: Fi/uploads
DEBUG - 2021-01-29 06:48:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:48:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:48:20 --> 404 Page Not Found: Fi/uploads
DEBUG - 2021-01-29 06:48:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:48:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:48:21 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 06:48:21 --> Total execution time: 0.1536
DEBUG - 2021-01-29 06:48:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:48:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:48:21 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"1"}
DEBUG - 2021-01-29 06:48:21 --> Total execution time: 0.1191
DEBUG - 2021-01-29 06:48:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:48:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:48:22 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 06:48:22 --> Total execution time: 0.1183
DEBUG - 2021-01-29 06:48:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:48:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:48:26 --> Total execution time: 0.1484
DEBUG - 2021-01-29 06:48:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:48:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:48:37 --> get_category_list->{"lang":"38","exercise_mode_id":"1","support_lang_id":"1"}
ERROR - 2021-01-29 06:48:37 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2021-01-29 06:48:37 --> Total execution time: 0.1249
DEBUG - 2021-01-29 06:48:38 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:48:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:48:38 --> get_exercise_type_list->{"lang":"38","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 06:48:38 --> Total execution time: 0.1652
DEBUG - 2021-01-29 06:48:38 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:48:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:48:38 --> get_subcategory_list->{"lang":"38","category_id":"1","user_id":"745","support_lang_id":"1"}
DEBUG - 2021-01-29 06:48:38 --> Total execution time: 0.1449
DEBUG - 2021-01-29 06:48:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:48:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:48:39 --> get_sorce_lan_word_type_1->{"slang":"38","tlang":"38","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 06:48:39 --> Total execution time: 0.1492
DEBUG - 2021-01-29 06:48:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:48:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:48:42 --> 404 Page Not Found: Fi/uploads
DEBUG - 2021-01-29 06:48:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:48:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:48:42 --> Total execution time: 0.1339
DEBUG - 2021-01-29 06:48:45 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:48:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:48:45 --> 404 Page Not Found: Fi/uploads
DEBUG - 2021-01-29 06:48:45 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:48:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:48:45 --> Total execution time: 0.1173
DEBUG - 2021-01-29 06:48:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:48:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:48:49 --> get_exercise_type_list->{"lang":"38","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 06:48:49 --> Total execution time: 0.1103
DEBUG - 2021-01-29 06:48:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:48:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:48:52 --> get_subcategory_list->{"lang":"38","category_id":"1","user_id":"745","support_lang_id":"1"}
DEBUG - 2021-01-29 06:48:52 --> Total execution time: 0.1614
DEBUG - 2021-01-29 06:48:53 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:48:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:48:53 --> get_category_list->{"lang":"38","exercise_mode_id":"1","support_lang_id":"1"}
ERROR - 2021-01-29 06:48:53 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2021-01-29 06:48:53 --> Total execution time: 0.1119
DEBUG - 2021-01-29 06:48:54 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:48:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:48:54 --> Total execution time: 0.1093
DEBUG - 2021-01-29 06:48:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:48:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:48:55 --> Total execution time: 0.1991
DEBUG - 2021-01-29 06:49:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:49:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:49:04 --> Total execution time: 0.1172
DEBUG - 2021-01-29 06:49:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:49:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:49:12 --> Total execution time: 0.1138
DEBUG - 2021-01-29 06:49:17 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:49:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:49:17 --> get_category_list->{"lang":"42","exercise_mode_id":"1","support_lang_id":"2"}
ERROR - 2021-01-29 06:49:17 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2021-01-29 06:49:17 --> Total execution time: 0.1148
DEBUG - 2021-01-29 06:49:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:49:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:49:22 --> Total execution time: 0.0960
DEBUG - 2021-01-29 06:49:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:49:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:49:26 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2021-01-29 06:49:26 --> Total execution time: 0.1008
DEBUG - 2021-01-29 06:49:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:49:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:49:31 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"2"}
DEBUG - 2021-01-29 06:49:31 --> Total execution time: 0.1485
DEBUG - 2021-01-29 06:49:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:49:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:49:32 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"2"}
DEBUG - 2021-01-29 06:49:32 --> Total execution time: 0.1510
DEBUG - 2021-01-29 06:49:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:49:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:49:32 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"2"}
DEBUG - 2021-01-29 06:49:32 --> Total execution time: 0.1121
DEBUG - 2021-01-29 06:49:35 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:49:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:49:35 --> 404 Page Not Found: Sv/uploads
DEBUG - 2021-01-29 06:49:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:49:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:49:37 --> 404 Page Not Found: Sv/uploads
DEBUG - 2021-01-29 06:49:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:49:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:49:37 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"2"}
DEBUG - 2021-01-29 06:49:37 --> Total execution time: 0.1150
DEBUG - 2021-01-29 06:49:38 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:49:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:49:38 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"2"}
DEBUG - 2021-01-29 06:49:38 --> Total execution time: 0.1273
DEBUG - 2021-01-29 06:49:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:49:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:49:40 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2021-01-29 06:49:40 --> Total execution time: 0.1010
DEBUG - 2021-01-29 06:49:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:49:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:49:41 --> Total execution time: 0.2201
DEBUG - 2021-01-29 06:49:41 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:49:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:49:42 --> Total execution time: 0.0970
DEBUG - 2021-01-29 06:49:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:49:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:49:46 --> Total execution time: 0.1472
DEBUG - 2021-01-29 06:49:50 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:49:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:49:50 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 06:49:50 --> Total execution time: 0.1413
DEBUG - 2021-01-29 06:49:53 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:49:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:49:53 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"3"}
DEBUG - 2021-01-29 06:49:53 --> Total execution time: 0.1263
DEBUG - 2021-01-29 06:49:54 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:49:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:49:55 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 06:49:55 --> Total execution time: 0.1265
DEBUG - 2021-01-29 06:49:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:49:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:49:57 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 06:49:57 --> Total execution time: 0.1127
DEBUG - 2021-01-29 06:50:00 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:50:00 --> 404 Page Not Found: En/uploads
DEBUG - 2021-01-29 06:50:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:50:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:50:02 --> 404 Page Not Found: En/uploads
DEBUG - 2021-01-29 06:50:16 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:50:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:50:17 --> Total execution time: 0.1107
DEBUG - 2021-01-29 06:50:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:50:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:50:31 --> Total execution time: 0.1526
DEBUG - 2021-01-29 06:50:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:50:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:50:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:50:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:50:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:50:47 --> Total execution time: 0.1177
DEBUG - 2021-01-29 06:50:50 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:50:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 06:50:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 06:50:50 --> Total execution time: 0.1615
DEBUG - 2021-01-29 06:50:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:50:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:50:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:51:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:51:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:51:15 --> Total execution time: 0.1547
DEBUG - 2021-01-29 06:52:24 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:52:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:52:24 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 06:52:24 --> Total execution time: 0.1494
DEBUG - 2021-01-29 06:52:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:52:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:52:31 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 06:52:31 --> Total execution time: 0.0981
DEBUG - 2021-01-29 06:52:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:52:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:52:34 --> 404 Page Not Found: En/uploads
DEBUG - 2021-01-29 06:52:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:52:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:52:37 --> 404 Page Not Found: En/uploads
DEBUG - 2021-01-29 06:53:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:53:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:53:57 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 06:53:57 --> Total execution time: 0.1666
DEBUG - 2021-01-29 06:54:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:54:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:54:03 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 06:54:03 --> Total execution time: 0.0997
DEBUG - 2021-01-29 06:54:05 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:54:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:54:05 --> 404 Page Not Found: En/uploads
DEBUG - 2021-01-29 06:54:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:54:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:54:07 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 06:54:07 --> Total execution time: 0.0976
DEBUG - 2021-01-29 06:54:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:54:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:54:08 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"3"}
DEBUG - 2021-01-29 06:54:08 --> Total execution time: 0.1395
DEBUG - 2021-01-29 06:54:09 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:54:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:54:09 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 06:54:09 --> Total execution time: 0.1122
DEBUG - 2021-01-29 06:54:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:54:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:54:10 --> Total execution time: 0.1414
DEBUG - 2021-01-29 06:54:16 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:54:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:54:16 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 06:54:16 --> Total execution time: 0.1332
DEBUG - 2021-01-29 06:54:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:54:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:54:21 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"3"}
DEBUG - 2021-01-29 06:54:21 --> Total execution time: 0.1402
DEBUG - 2021-01-29 06:54:24 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:54:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:54:24 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 06:54:24 --> Total execution time: 0.1745
DEBUG - 2021-01-29 06:54:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:54:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:54:31 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 06:54:31 --> Total execution time: 0.1518
DEBUG - 2021-01-29 06:54:35 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:54:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:54:35 --> 404 Page Not Found: En/uploads
DEBUG - 2021-01-29 06:54:38 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:54:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:54:38 --> 404 Page Not Found: En/uploads
DEBUG - 2021-01-29 06:57:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:57:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:57:54 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:57:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:57:54 --> Total execution time: 0.1319
DEBUG - 2021-01-29 06:57:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:57:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:57:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:57:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:57:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:57:57 --> 404 Page Not Found: Uploads/badger.jpg
DEBUG - 2021-01-29 06:58:23 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:58:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:58:23 --> Total execution time: 0.1995
DEBUG - 2021-01-29 06:58:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:58:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:58:26 --> Total execution time: 0.2074
DEBUG - 2021-01-29 06:58:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:58:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:58:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:58:44 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:58:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:58:44 --> Total execution time: 0.1129
DEBUG - 2021-01-29 06:58:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:58:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 06:58:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 06:58:47 --> Total execution time: 0.1713
DEBUG - 2021-01-29 06:58:50 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:58:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:58:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:59:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:59:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:59:26 --> Total execution time: 0.1186
DEBUG - 2021-01-29 06:59:29 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:59:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:59:29 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 06:59:44 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:59:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 06:59:44 --> Total execution time: 0.1283
DEBUG - 2021-01-29 06:59:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 06:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 06:59:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 06:59:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 06:59:47 --> Total execution time: 0.1616
DEBUG - 2021-01-29 06:59:50 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 06:59:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 06:59:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 07:01:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:01:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:01:43 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:01:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:01:43 --> Total execution time: 0.1258
DEBUG - 2021-01-29 07:01:45 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 07:01:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 07:01:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 07:01:46 --> 404 Page Not Found: Uploads/badger.jpg
DEBUG - 2021-01-29 07:01:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:01:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:01:57 --> Total execution time: 0.1223
DEBUG - 2021-01-29 07:02:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:02:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 07:02:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 07:02:01 --> Total execution time: 0.1454
DEBUG - 2021-01-29 07:02:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:02:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 07:02:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 07:02:09 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:02:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:02:09 --> Total execution time: 0.1523
DEBUG - 2021-01-29 07:02:09 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:02:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:02:09 --> Total execution time: 0.1276
DEBUG - 2021-01-29 07:02:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:02:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:02:10 --> Total execution time: 0.1342
DEBUG - 2021-01-29 07:02:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:02:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:02:12 --> Total execution time: 0.1634
DEBUG - 2021-01-29 07:02:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:02:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:02:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 07:02:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 07:02:12 --> Total execution time: 0.1352
DEBUG - 2021-01-29 07:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:02:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:02:12 --> Total execution time: 0.1245
DEBUG - 2021-01-29 07:02:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:02:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 07:02:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 07:02:12 --> Total execution time: 0.1184
DEBUG - 2021-01-29 07:02:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:02:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 07:02:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 07:02:13 --> Total execution time: 0.1262
DEBUG - 2021-01-29 07:02:14 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:02:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 07:02:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 07:02:14 --> Total execution time: 0.1551
DEBUG - 2021-01-29 07:02:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:02:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 07:02:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 07:02:15 --> Total execution time: 0.1206
DEBUG - 2021-01-29 07:02:17 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:02:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 07:02:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 07:02:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:02:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:02:48 --> Total execution time: 0.1223
DEBUG - 2021-01-29 07:02:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:02:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:02:51 --> Total execution time: 0.1594
DEBUG - 2021-01-29 07:02:53 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 07:02:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 07:03:09 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:03:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:03:09 --> Total execution time: 0.1171
DEBUG - 2021-01-29 07:03:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:03:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:03:11 --> Total execution time: 0.1428
DEBUG - 2021-01-29 07:03:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:03:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:03:26 --> Total execution time: 0.1645
DEBUG - 2021-01-29 07:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:03:26 --> Total execution time: 0.1707
DEBUG - 2021-01-29 07:03:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:03:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:03:28 --> UTF-8 Support Enabled
ERROR - 2021-01-29 07:03:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 07:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:03:28 --> Total execution time: 0.1682
ERROR - 2021-01-29 07:03:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 07:03:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:03:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 07:03:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 07:05:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:05:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:05:58 --> Total execution time: 0.1124
DEBUG - 2021-01-29 07:06:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:06:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 07:06:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 07:06:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:06:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:06:12 --> Total execution time: 0.1990
DEBUG - 2021-01-29 07:06:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:06:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:06:15 --> Total execution time: 0.1711
DEBUG - 2021-01-29 07:06:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:06:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:06:31 --> Total execution time: 0.1562
DEBUG - 2021-01-29 07:06:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:06:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 07:06:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 07:06:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:06:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:06:39 --> Total execution time: 0.1521
DEBUG - 2021-01-29 07:06:41 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:06:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:06:41 --> Total execution time: 0.1331
DEBUG - 2021-01-29 07:06:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:06:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:06:48 --> Total execution time: 0.1157
DEBUG - 2021-01-29 07:07:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:07:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:07:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:07:05 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:07:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:07:05 --> Total execution time: 0.1313
DEBUG - 2021-01-29 07:07:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:07:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 07:07:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 07:08:41 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:08:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:08:41 --> Total execution time: 0.1593
DEBUG - 2021-01-29 07:08:44 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:08:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:08:45 --> Total execution time: 0.1282
DEBUG - 2021-01-29 07:08:50 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:08:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:08:50 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 07:08:50 --> Total execution time: 0.1558
DEBUG - 2021-01-29 07:08:53 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:08:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:08:53 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"1"}
DEBUG - 2021-01-29 07:08:53 --> Total execution time: 0.1396
DEBUG - 2021-01-29 07:08:56 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:08:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:08:56 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 07:08:56 --> Total execution time: 0.1573
DEBUG - 2021-01-29 07:09:00 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:09:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:09:00 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 07:09:00 --> Total execution time: 0.1178
DEBUG - 2021-01-29 07:09:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:09:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 07:09:04 --> 404 Page Not Found: Fi/uploads
DEBUG - 2021-01-29 07:09:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:09:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 07:09:06 --> 404 Page Not Found: Fi/uploads
DEBUG - 2021-01-29 07:09:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:09:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:09:47 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 07:09:47 --> Total execution time: 0.1270
DEBUG - 2021-01-29 07:10:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:10:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:10:27 --> Total execution time: 0.1438
DEBUG - 2021-01-29 07:10:29 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:10:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:10:29 --> Total execution time: 0.1726
DEBUG - 2021-01-29 07:10:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:10:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 07:10:31 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 07:10:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:10:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 07:10:31 --> 404 Page Not Found: Uploads/badger.jpg
DEBUG - 2021-01-29 07:10:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:10:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:10:48 --> Total execution time: 0.1375
DEBUG - 2021-01-29 07:10:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:10:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:10:51 --> Total execution time: 0.1619
DEBUG - 2021-01-29 07:10:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:10:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 07:10:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 07:11:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:11:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:11:08 --> Total execution time: 0.1319
DEBUG - 2021-01-29 07:11:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:11:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 07:11:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 07:11:25 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:11:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:11:25 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 07:11:25 --> Total execution time: 0.1345
DEBUG - 2021-01-29 07:11:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:11:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 07:11:28 --> 404 Page Not Found: Fi/uploads
DEBUG - 2021-01-29 07:11:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:11:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:11:30 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 07:11:30 --> Total execution time: 0.1384
DEBUG - 2021-01-29 07:11:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:11:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:11:31 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"1"}
DEBUG - 2021-01-29 07:11:31 --> Total execution time: 0.1540
DEBUG - 2021-01-29 07:11:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:11:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:11:46 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 07:11:46 --> Total execution time: 0.1504
DEBUG - 2021-01-29 07:11:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:11:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:11:55 --> Total execution time: 0.1494
DEBUG - 2021-01-29 07:11:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:11:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:11:58 --> Total execution time: 0.1727
DEBUG - 2021-01-29 07:12:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:12:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 07:12:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 07:12:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:12:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:12:46 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"1"}
DEBUG - 2021-01-29 07:12:46 --> Total execution time: 0.1459
DEBUG - 2021-01-29 07:12:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:12:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:12:47 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 07:12:47 --> Total execution time: 0.1343
DEBUG - 2021-01-29 07:12:56 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:12:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:12:56 --> Total execution time: 0.1321
DEBUG - 2021-01-29 07:13:14 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:13:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:13:14 --> Total execution time: 0.1674
DEBUG - 2021-01-29 07:54:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:54:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:54:52 --> Total execution time: 0.1094
DEBUG - 2021-01-29 07:55:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:55:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:55:03 --> Total execution time: 0.1179
DEBUG - 2021-01-29 07:55:09 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:55:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:55:09 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 07:55:09 --> Total execution time: 0.1123
DEBUG - 2021-01-29 07:55:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:55:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:55:13 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"1"}
DEBUG - 2021-01-29 07:55:13 --> Total execution time: 0.1443
DEBUG - 2021-01-29 07:55:16 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:55:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:55:16 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 07:55:16 --> Total execution time: 0.1281
DEBUG - 2021-01-29 07:55:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:55:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:55:20 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 07:55:20 --> Total execution time: 0.0983
DEBUG - 2021-01-29 07:55:23 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:55:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 07:55:23 --> 404 Page Not Found: Fi/uploads
DEBUG - 2021-01-29 07:55:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:55:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 07:55:26 --> 404 Page Not Found: Fi/uploads
DEBUG - 2021-01-29 07:55:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:55:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:55:59 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 07:55:59 --> Total execution time: 0.1234
DEBUG - 2021-01-29 07:56:24 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:56:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:56:25 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"1"}
DEBUG - 2021-01-29 07:56:25 --> Total execution time: 0.1233
DEBUG - 2021-01-29 07:56:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:56:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:56:39 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 07:56:39 --> Total execution time: 0.0966
DEBUG - 2021-01-29 07:56:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:56:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:56:40 --> Total execution time: 0.1173
DEBUG - 2021-01-29 07:56:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 07:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 07:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 07:56:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 07:56:40 --> Total execution time: 0.1000
DEBUG - 2021-01-29 08:07:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 08:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 08:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 08:07:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 08:07:41 --> Total execution time: 0.1595
DEBUG - 2021-01-29 08:07:43 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 08:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 08:07:43 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 08:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 08:07:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 08:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 08:07:43 --> Total execution time: 0.1452
DEBUG - 2021-01-29 08:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 08:07:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 08:07:43 --> Total execution time: 0.1325
DEBUG - 2021-01-29 08:07:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 08:07:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 08:07:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 08:30:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 08:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 08:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 08:30:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 08:30:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 08:30:52 --> Total execution time: 0.2110
DEBUG - 2021-01-29 08:30:56 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 08:30:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 08:30:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 08:54:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 08:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 08:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 08:54:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 08:54:47 --> Total execution time: 0.1320
DEBUG - 2021-01-29 08:54:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 08:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 08:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 08:54:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 08:54:58 --> Total execution time: 0.1183
DEBUG - 2021-01-29 08:55:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 08:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 08:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 08:55:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 08:55:03 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 08:55:03 --> Total execution time: 0.0971
DEBUG - 2021-01-29 08:55:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 08:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 08:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 08:55:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 08:55:07 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"1"}
DEBUG - 2021-01-29 08:55:07 --> Total execution time: 0.1018
DEBUG - 2021-01-29 08:55:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 08:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 08:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 08:55:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 08:55:11 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 08:55:11 --> Total execution time: 0.0952
DEBUG - 2021-01-29 08:55:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 08:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 08:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 08:55:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 08:55:15 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 08:55:15 --> Total execution time: 0.1121
DEBUG - 2021-01-29 08:55:18 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 08:55:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 08:55:18 --> 404 Page Not Found: Fi/uploads
DEBUG - 2021-01-29 08:55:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 08:55:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 08:55:21 --> 404 Page Not Found: Fi/uploads
DEBUG - 2021-01-29 08:59:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 08:59:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 08:59:40 --> 404 Page Not Found: Fi/uploads
DEBUG - 2021-01-29 08:59:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 08:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 08:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 08:59:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 08:59:42 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 08:59:42 --> Total execution time: 0.1572
DEBUG - 2021-01-29 08:59:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 08:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 08:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 08:59:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 08:59:43 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"1"}
DEBUG - 2021-01-29 08:59:43 --> Total execution time: 0.1287
DEBUG - 2021-01-29 09:00:35 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 09:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 09:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 09:00:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 09:00:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 09:00:36 --> Total execution time: 0.1495
DEBUG - 2021-01-29 09:00:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 09:00:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 09:00:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 09:04:00 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 09:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 09:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 09:04:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 09:04:00 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 09:04:00 --> Total execution time: 0.1004
DEBUG - 2021-01-29 09:04:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 09:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 09:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 09:04:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 09:04:01 --> Total execution time: 0.1168
DEBUG - 2021-01-29 09:04:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 09:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 09:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 09:04:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 09:04:03 --> Total execution time: 0.1252
DEBUG - 2021-01-29 09:32:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 09:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 09:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 09:32:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 09:32:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 09:32:49 --> Total execution time: 0.1393
DEBUG - 2021-01-29 09:32:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 09:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 09:32:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 10:01:16 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:01:16 --> No URI present. Default controller set.
DEBUG - 2021-01-29 10:01:16 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:01:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:01:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:01:16 --> Total execution time: 0.1270
DEBUG - 2021-01-29 10:01:16 --> Total execution time: 0.1431
DEBUG - 2021-01-29 10:01:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:01:28 --> No URI present. Default controller set.
DEBUG - 2021-01-29 10:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:01:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:01:28 --> Total execution time: 0.1772
DEBUG - 2021-01-29 10:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:01:53 --> No URI present. Default controller set.
DEBUG - 2021-01-29 10:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:01:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:01:53 --> Total execution time: 0.1153
DEBUG - 2021-01-29 10:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:01:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:01:53 --> Total execution time: 0.1282
DEBUG - 2021-01-29 10:01:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:01:59 --> No URI present. Default controller set.
DEBUG - 2021-01-29 10:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:01:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:01:59 --> Total execution time: 0.1257
DEBUG - 2021-01-29 10:02:14 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:02:14 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:02:14 --> No URI present. Default controller set.
DEBUG - 2021-01-29 10:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:02:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:02:14 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 10:02:14 --> Total execution time: 0.1192
DEBUG - 2021-01-29 10:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:02:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:02:14 --> Total execution time: 0.1349
DEBUG - 2021-01-29 10:02:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:02:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:02:37 --> No URI present. Default controller set.
DEBUG - 2021-01-29 10:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:02:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:02:37 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-01-29 10:02:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:02:37 --> Total execution time: 0.1192
DEBUG - 2021-01-29 10:02:37 --> Total execution time: 0.1335
DEBUG - 2021-01-29 10:02:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:02:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:02:47 --> No URI present. Default controller set.
DEBUG - 2021-01-29 10:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:02:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:02:47 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 10:02:47 --> Total execution time: 0.1061
DEBUG - 2021-01-29 10:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:02:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:02:47 --> Total execution time: 0.1290
DEBUG - 2021-01-29 10:02:54 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:02:54 --> No URI present. Default controller set.
DEBUG - 2021-01-29 10:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:02:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:02:54 --> Total execution time: 0.1103
DEBUG - 2021-01-29 10:02:54 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:02:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:02:54 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 10:02:54 --> Total execution time: 0.1078
DEBUG - 2021-01-29 10:02:56 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:02:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:02:57 --> 404 Page Not Found: En/uploads
DEBUG - 2021-01-29 10:02:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:02:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:02:59 --> 404 Page Not Found: En/uploads
DEBUG - 2021-01-29 10:03:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:03:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:03:06 --> 404 Page Not Found: En/uploads
DEBUG - 2021-01-29 10:03:23 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:03:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:03:23 --> 404 Page Not Found: En/uploads
DEBUG - 2021-01-29 10:03:38 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:03:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 10:03:39 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-01-29 10:03:39 --> Total execution time: 0.1179
DEBUG - 2021-01-29 10:04:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:04:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 10:04:29 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-01-29 10:04:29 --> Total execution time: 0.1259
DEBUG - 2021-01-29 10:07:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:07:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:07:10 --> 404 Page Not Found: En/uploads
DEBUG - 2021-01-29 10:07:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:07:10 --> No URI present. Default controller set.
DEBUG - 2021-01-29 10:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:07:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:07:10 --> Total execution time: 0.1567
DEBUG - 2021-01-29 10:07:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:07:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:07:12 --> 404 Page Not Found: En/uploads
DEBUG - 2021-01-29 10:07:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:07:12 --> No URI present. Default controller set.
DEBUG - 2021-01-29 10:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:07:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:07:12 --> Total execution time: 0.1197
DEBUG - 2021-01-29 10:07:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:07:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:07:57 --> 404 Page Not Found: En/uploads
DEBUG - 2021-01-29 10:07:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:07:57 --> No URI present. Default controller set.
DEBUG - 2021-01-29 10:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:07:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:07:58 --> Total execution time: 0.1296
DEBUG - 2021-01-29 10:08:00 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:08:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:08:00 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 10:08:00 --> Total execution time: 0.1355
DEBUG - 2021-01-29 10:08:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:08:01 --> No URI present. Default controller set.
DEBUG - 2021-01-29 10:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:08:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:08:01 --> Total execution time: 0.1459
DEBUG - 2021-01-29 10:08:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:08:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:08:01 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-01-29 10:08:01 --> Total execution time: 0.1089
DEBUG - 2021-01-29 10:08:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:08:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:08:02 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 10:08:02 --> Total execution time: 0.1302
DEBUG - 2021-01-29 10:08:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:08:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:08:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:08:03 --> Total execution time: 0.1184
DEBUG - 2021-01-29 10:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:08:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:08:03 --> Total execution time: 0.1067
DEBUG - 2021-01-29 10:08:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:08:03 --> No URI present. Default controller set.
DEBUG - 2021-01-29 10:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:08:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:08:04 --> Total execution time: 0.1407
DEBUG - 2021-01-29 10:09:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:09:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:09:33 --> 404 Page Not Found: En/uploads
DEBUG - 2021-01-29 10:10:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:10:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:10:22 --> Total execution time: 0.1139
DEBUG - 2021-01-29 10:10:23 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:10:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:10:23 --> Total execution time: 0.1349
DEBUG - 2021-01-29 10:10:23 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:10:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:10:25 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:10:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:10:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:10:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:10:28 --> Total execution time: 0.1486
DEBUG - 2021-01-29 10:11:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:11:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:11:16 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:11:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:11:16 --> Total execution time: 0.1338
DEBUG - 2021-01-29 10:11:19 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:11:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 10:11:19 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:11:19 --> 404 Page Not Found: Uploads/badger.jpg
DEBUG - 2021-01-29 10:11:24 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:11:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:11:25 --> Total execution time: 0.1630
DEBUG - 2021-01-29 10:11:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:11:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 10:11:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 10:11:27 --> Total execution time: 0.1424
DEBUG - 2021-01-29 10:11:29 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:11:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:11:29 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 10:11:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:11:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:11:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 10:11:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:11:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:11:42 --> 404 Page Not Found: Assets/js
DEBUG - 2021-01-29 10:15:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:15:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:15:34 --> Total execution time: 0.0990
DEBUG - 2021-01-29 10:15:38 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:15:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:15:38 --> Total execution time: 0.1299
DEBUG - 2021-01-29 10:15:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:15:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:15:42 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 10:15:42 --> Total execution time: 0.1422
DEBUG - 2021-01-29 10:15:45 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:15:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:15:45 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"1"}
DEBUG - 2021-01-29 10:15:45 --> Total execution time: 0.1244
DEBUG - 2021-01-29 10:15:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:15:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:15:48 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 10:15:48 --> Total execution time: 0.1051
DEBUG - 2021-01-29 10:15:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:15:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:15:52 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 10:15:52 --> Total execution time: 0.1296
DEBUG - 2021-01-29 10:16:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:16:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 10:16:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 10:16:15 --> Total execution time: 0.1406
DEBUG - 2021-01-29 10:16:18 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:16:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:16:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 10:25:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:25:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:25:55 --> Total execution time: 0.1602
DEBUG - 2021-01-29 10:25:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:25:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 10:25:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 10:25:58 --> Total execution time: 0.1487
DEBUG - 2021-01-29 10:26:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:26:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 10:26:35 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:26:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:26:35 --> Total execution time: 0.2312
DEBUG - 2021-01-29 10:26:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:26:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 10:34:36 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:34:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:34:36 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 10:34:36 --> Total execution time: 0.1328
DEBUG - 2021-01-29 10:34:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:34:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:34:40 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 10:34:40 --> Total execution time: 0.1084
DEBUG - 2021-01-29 10:34:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:34:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:34:53 --> Total execution time: 0.1341
DEBUG - 2021-01-29 10:43:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:43:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:43:34 --> Total execution time: 0.1372
DEBUG - 2021-01-29 10:43:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:43:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:43:39 --> Total execution time: 0.1138
DEBUG - 2021-01-29 10:43:44 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:43:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:43:44 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 10:43:44 --> Total execution time: 0.0994
DEBUG - 2021-01-29 10:43:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:43:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:43:48 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 10:43:48 --> Total execution time: 0.1286
DEBUG - 2021-01-29 10:43:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:43:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:43:51 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 10:43:51 --> Total execution time: 0.1002
DEBUG - 2021-01-29 10:43:54 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:43:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:43:54 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 10:43:54 --> Total execution time: 0.1274
DEBUG - 2021-01-29 10:46:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:46:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:46:46 --> Total execution time: 0.1223
DEBUG - 2021-01-29 10:49:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:49:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 10:49:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 10:49:12 --> Total execution time: 0.1366
DEBUG - 2021-01-29 10:49:16 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:49:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:49:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 10:49:16 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:49:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 10:49:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 10:49:16 --> Total execution time: 0.1581
DEBUG - 2021-01-29 10:49:19 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:49:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 10:49:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 10:49:19 --> Total execution time: 0.1227
DEBUG - 2021-01-29 10:49:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:49:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:49:22 --> Total execution time: 0.1611
DEBUG - 2021-01-29 10:49:23 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:49:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:49:23 --> Total execution time: 0.1342
DEBUG - 2021-01-29 10:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:49:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:49:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 10:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:49:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:49:27 --> 404 Page Not Found: Uploads/badger.jpg
DEBUG - 2021-01-29 10:50:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:50:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:50:10 --> Total execution time: 0.2123
DEBUG - 2021-01-29 10:50:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:50:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:50:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:50:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:50:34 --> Total execution time: 0.1408
DEBUG - 2021-01-29 10:50:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:50:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:50:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 10:50:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:50:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:50:37 --> 404 Page Not Found: Uploads/badger.jpg
DEBUG - 2021-01-29 10:50:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:50:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:50:48 --> Total execution time: 0.1434
DEBUG - 2021-01-29 10:50:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:50:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:50:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 10:51:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:51:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:51:08 --> Total execution time: 0.1437
DEBUG - 2021-01-29 10:51:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:51:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:51:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 10:56:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:56:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:56:27 --> Total execution time: 0.1144
DEBUG - 2021-01-29 10:56:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:56:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:56:30 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"null"}
ERROR - 2021-01-29 10:56:30 --> Query error: Unknown column 'type.type_' in 'field list' - Invalid query: select type.id, type.type_ as type_name,type.image  from tbl_exercise_type type LEFT JOIN tbl_exercise_mode_categories_exercise ex ON type.id=ex.exercise_type_id where ex.category_id='1' AND ex.is_active='1' order by type.sequence asc
ERROR - 2021-01-29 10:56:30 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 288
DEBUG - 2021-01-29 10:56:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:56:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:56:32 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"null"}
ERROR - 2021-01-29 10:56:32 --> Query error: Unknown column 'subcategory_name_in_' in 'field list' - Invalid query: select exercise_mode_subcategory_id,category_id,difficulty_level_id,image,subcategory_name_in_ as subcategory_name from tbl_exercise_mode_subcategories where category_id='1' AND is_active='1' AND is_delete='0' order by subcategory_name_in_ asc
ERROR - 2021-01-29 10:56:32 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 183
DEBUG - 2021-01-29 10:56:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:56:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:56:34 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"null"}
ERROR - 2021-01-29 10:56:34 --> Query error: Unknown column 'category_name_in_' in 'field list' - Invalid query: select exercise_mode_category_id,image,category_name_in_ as category_name from tbl_exercise_mode_categories where support_lang_id='37' AND exercise_mode_id='1' AND is_active='1' AND is_delete='0' order by category_name_in_ asc
ERROR - 2021-01-29 10:56:34 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 126
DEBUG - 2021-01-29 10:56:36 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:56:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:56:37 --> Total execution time: 0.1522
DEBUG - 2021-01-29 10:56:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:56:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:56:38 --> Total execution time: 0.1142
DEBUG - 2021-01-29 10:56:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:56:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:56:42 --> Total execution time: 0.1124
DEBUG - 2021-01-29 10:56:44 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:56:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:56:44 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 10:56:44 --> Total execution time: 0.1433
DEBUG - 2021-01-29 10:56:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:56:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:56:48 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"1"}
DEBUG - 2021-01-29 10:56:48 --> Total execution time: 0.1520
DEBUG - 2021-01-29 10:56:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:56:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:56:52 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 10:56:52 --> Total execution time: 0.1451
DEBUG - 2021-01-29 10:57:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:57:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:57:11 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 10:57:11 --> Total execution time: 0.1105
DEBUG - 2021-01-29 10:57:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:57:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:57:21 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 10:57:21 --> Total execution time: 0.1533
DEBUG - 2021-01-29 10:57:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:57:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:57:26 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 10:57:26 --> Total execution time: 0.1389
DEBUG - 2021-01-29 10:57:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:57:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:57:32 --> Total execution time: 0.1137
DEBUG - 2021-01-29 10:57:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:57:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:57:37 --> Total execution time: 0.1304
DEBUG - 2021-01-29 10:57:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:57:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:57:40 --> Total execution time: 0.1338
DEBUG - 2021-01-29 10:57:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:57:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:57:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 10:57:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:57:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:57:42 --> 404 Page Not Found: Uploads/badger.jpg
DEBUG - 2021-01-29 10:58:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:58:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:58:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:58:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:58:04 --> Total execution time: 0.1405
DEBUG - 2021-01-29 10:58:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:58:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:58:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 10:58:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:58:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:58:07 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-01-29 10:58:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:58:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:58:10 --> 404 Page Not Found: Uploads/brush.jpg
DEBUG - 2021-01-29 10:58:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:58:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:58:10 --> 404 Page Not Found: Uploads/baloon.jpg
DEBUG - 2021-01-29 10:58:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:58:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:58:10 --> 404 Page Not Found: Uploads/badger.jpg
DEBUG - 2021-01-29 10:58:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:58:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 10:58:12 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-01-29 10:59:00 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:59:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:59:01 --> Total execution time: 0.1246
DEBUG - 2021-01-29 10:59:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:59:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:59:06 --> Total execution time: 0.1180
DEBUG - 2021-01-29 10:59:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:59:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:59:11 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 10:59:11 --> Total execution time: 0.1002
DEBUG - 2021-01-29 10:59:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:59:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:59:15 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 10:59:15 --> Total execution time: 0.1133
DEBUG - 2021-01-29 10:59:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:59:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:59:20 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 10:59:20 --> Total execution time: 0.1146
DEBUG - 2021-01-29 10:59:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:59:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:59:55 --> Total execution time: 0.1683
DEBUG - 2021-01-29 10:59:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 10:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 10:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 10:59:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 10:59:57 --> Total execution time: 0.1633
DEBUG - 2021-01-29 11:00:00 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:00:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:00:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:00:00 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:00:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:00:00 --> 404 Page Not Found: Uploads/badger.jpg
DEBUG - 2021-01-29 11:00:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:00:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:00:12 --> Total execution time: 0.1487
DEBUG - 2021-01-29 11:00:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:00:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:00:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:00:13 --> Total execution time: 0.1093
DEBUG - 2021-01-29 11:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:00:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:00:13 --> Total execution time: 0.1418
DEBUG - 2021-01-29 11:00:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:00:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:00:13 --> Total execution time: 0.1198
DEBUG - 2021-01-29 11:00:14 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:00:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:00:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 11:00:14 --> Total execution time: 0.1454
DEBUG - 2021-01-29 11:00:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:00:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:00:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 11:00:16 --> Total execution time: 0.1187
DEBUG - 2021-01-29 11:00:16 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:00:16 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:00:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:00:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 11:00:16 --> Total execution time: 0.1475
DEBUG - 2021-01-29 11:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:00:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:00:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 11:00:16 --> Total execution time: 0.1635
DEBUG - 2021-01-29 11:00:19 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:00:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:00:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:00:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:00:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:00:33 --> Total execution time: 0.1706
DEBUG - 2021-01-29 11:00:35 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:00:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:00:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 11:00:35 --> Total execution time: 0.1199
DEBUG - 2021-01-29 11:00:36 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:00:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:00:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 11:00:36 --> Total execution time: 0.1777
DEBUG - 2021-01-29 11:00:38 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:00:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:00:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 11:00:38 --> Total execution time: 0.1328
DEBUG - 2021-01-29 11:00:41 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:00:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:00:41 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:01:00 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:01:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:01:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:01:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:01:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 11:01:03 --> Total execution time: 0.1201
DEBUG - 2021-01-29 11:01:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:01:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:01:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:01:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:01:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:01:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-29 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:01:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-29 11:01:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:01:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:01:39 --> Total execution time: 0.1282
DEBUG - 2021-01-29 11:03:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:03:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:03:53 --> Total execution time: 0.1512
DEBUG - 2021-01-29 11:03:54 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:03:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:03:54 --> Total execution time: 0.1139
DEBUG - 2021-01-29 11:03:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:03:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:03:55 --> Total execution time: 0.1654
DEBUG - 2021-01-29 11:03:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:03:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:03:57 --> Total execution time: 0.1459
DEBUG - 2021-01-29 11:04:00 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:04:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:04:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:04:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:04:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:04:07 --> Total execution time: 0.1189
DEBUG - 2021-01-29 11:04:09 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:04:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:04:10 --> Total execution time: 0.1305
DEBUG - 2021-01-29 11:04:25 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:04:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:04:25 --> Total execution time: 0.2008
DEBUG - 2021-01-29 11:04:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:04:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:04:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:04:36 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:04:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:04:36 --> Total execution time: 0.1322
DEBUG - 2021-01-29 11:04:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:04:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:04:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 11:04:39 --> Total execution time: 0.1404
DEBUG - 2021-01-29 11:04:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:04:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:04:39 --> Total execution time: 0.1294
DEBUG - 2021-01-29 11:04:41 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:04:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:04:41 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:04:41 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:04:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:04:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-29 11:04:44 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:04:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:04:44 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-29 11:04:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:04:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:04:51 --> Total execution time: 0.1701
DEBUG - 2021-01-29 11:04:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:04:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:04:52 --> Total execution time: 0.1527
DEBUG - 2021-01-29 11:04:53 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:04:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:04:53 --> Total execution time: 0.1484
DEBUG - 2021-01-29 11:04:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:04:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:04:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:04:55 --> Total execution time: 0.1314
DEBUG - 2021-01-29 11:04:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:04:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:04:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:05:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:05:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:05:03 --> Total execution time: 0.1315
DEBUG - 2021-01-29 11:05:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:05:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:05:20 --> Total execution time: 0.1472
DEBUG - 2021-01-29 11:05:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:05:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:05:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:05:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:05:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:05:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:05:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:05:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:05:52 --> Total execution time: 0.1194
DEBUG - 2021-01-29 11:05:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:05:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:05:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:06:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:06:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:06:07 --> Total execution time: 0.1133
DEBUG - 2021-01-29 11:06:09 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:06:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:06:09 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"null"}
ERROR - 2021-01-29 11:06:09 --> Query error: Unknown column 'type.type_' in 'field list' - Invalid query: select type.id, type.type_ as type_name,type.image  from tbl_exercise_type type LEFT JOIN tbl_exercise_mode_categories_exercise ex ON type.id=ex.exercise_type_id where ex.category_id='1' AND ex.is_active='1' order by type.sequence asc
ERROR - 2021-01-29 11:06:09 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 288
DEBUG - 2021-01-29 11:06:09 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:06:09 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:06:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:06:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:06:10 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"null"}
ERROR - 2021-01-29 11:06:10 --> Query error: Unknown column 'subcategory_name_in_' in 'field list' - Invalid query: select exercise_mode_subcategory_id,category_id,difficulty_level_id,image,subcategory_name_in_ as subcategory_name from tbl_exercise_mode_subcategories where category_id='1' AND is_active='1' AND is_delete='0' order by subcategory_name_in_ asc
DEBUG - 2021-01-29 11:06:10 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"null"}
ERROR - 2021-01-29 11:06:10 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 183
ERROR - 2021-01-29 11:06:10 --> Query error: Unknown column 'category_name_in_' in 'field list' - Invalid query: select exercise_mode_category_id,image,category_name_in_ as category_name from tbl_exercise_mode_categories where support_lang_id='37' AND exercise_mode_id='1' AND is_active='1' AND is_delete='0' order by category_name_in_ asc
ERROR - 2021-01-29 11:06:10 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 126
DEBUG - 2021-01-29 11:06:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:06:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:06:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:06:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:06:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:06:13 --> Total execution time: 0.1422
DEBUG - 2021-01-29 11:06:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:06:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:06:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:06:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:06:15 --> Total execution time: 0.1272
DEBUG - 2021-01-29 11:06:15 --> Total execution time: 0.1500
DEBUG - 2021-01-29 11:06:17 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:06:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:06:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:06:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:06:21 --> Total execution time: 0.1380
DEBUG - 2021-01-29 11:06:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:06:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:06:22 --> Total execution time: 0.1492
DEBUG - 2021-01-29 11:06:23 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:06:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:06:23 --> Total execution time: 0.1112
DEBUG - 2021-01-29 11:06:24 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:06:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:06:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 11:06:24 --> Total execution time: 0.1262
DEBUG - 2021-01-29 11:06:25 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:06:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:06:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 11:06:25 --> Total execution time: 0.1321
DEBUG - 2021-01-29 11:06:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:06:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:06:26 --> Total execution time: 0.0972
DEBUG - 2021-01-29 11:06:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:06:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:06:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:06:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:06:37 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 11:06:37 --> Total execution time: 0.1397
DEBUG - 2021-01-29 11:06:38 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:06:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:06:38 --> Total execution time: 0.1114
DEBUG - 2021-01-29 11:06:41 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:06:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:06:41 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"1"}
DEBUG - 2021-01-29 11:06:41 --> Total execution time: 0.1313
DEBUG - 2021-01-29 11:06:43 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:06:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:06:43 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 11:06:43 --> Total execution time: 0.1116
DEBUG - 2021-01-29 11:06:44 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:06:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:06:44 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 11:06:44 --> Total execution time: 0.1304
DEBUG - 2021-01-29 11:06:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:06:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:06:46 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 11:06:46 --> Total execution time: 0.1451
DEBUG - 2021-01-29 11:06:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:06:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:06:49 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 11:06:49 --> Total execution time: 0.1197
DEBUG - 2021-01-29 11:06:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:06:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:06:52 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 11:06:52 --> Total execution time: 0.1215
DEBUG - 2021-01-29 11:06:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:06:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:06:57 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 11:06:57 --> Total execution time: 0.1134
DEBUG - 2021-01-29 11:07:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:07:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:07:03 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 11:07:03 --> Total execution time: 0.1215
DEBUG - 2021-01-29 11:07:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:07:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:07:04 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 11:07:04 --> Total execution time: 0.1162
DEBUG - 2021-01-29 11:07:05 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:07:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:07:05 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-29 11:07:05 --> Total execution time: 0.1213
DEBUG - 2021-01-29 11:07:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:07:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:07:10 --> Total execution time: 0.1472
DEBUG - 2021-01-29 11:07:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:07:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:07:13 --> Total execution time: 0.1291
DEBUG - 2021-01-29 11:07:16 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:07:16 --> Total execution time: 0.1198
DEBUG - 2021-01-29 11:07:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:07:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:07:20 --> Total execution time: 0.1218
DEBUG - 2021-01-29 11:07:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:07:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:07:22 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 11:07:22 --> Total execution time: 0.1662
DEBUG - 2021-01-29 11:07:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:07:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:07:26 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 11:07:26 --> Total execution time: 0.1023
DEBUG - 2021-01-29 11:07:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:07:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:07:27 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 11:07:27 --> Total execution time: 0.1047
DEBUG - 2021-01-29 11:07:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:07:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:07:34 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 11:07:34 --> Total execution time: 0.1512
DEBUG - 2021-01-29 11:07:41 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:07:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:07:41 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 11:07:41 --> Total execution time: 0.1544
DEBUG - 2021-01-29 11:07:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:07:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:07:46 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 11:07:46 --> Total execution time: 0.1650
DEBUG - 2021-01-29 11:08:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:08:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:08:12 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 11:08:12 --> Total execution time: 0.1395
DEBUG - 2021-01-29 11:08:23 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:08:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:08:23 --> get_sorce_lan_word_type_6->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 11:08:23 --> Total execution time: 0.1148
DEBUG - 2021-01-29 11:08:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:08:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:08:53 --> Total execution time: 0.1231
DEBUG - 2021-01-29 11:09:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:09:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:09:06 --> Total execution time: 0.1423
DEBUG - 2021-01-29 11:09:29 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:09:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:09:30 --> Total execution time: 0.1370
DEBUG - 2021-01-29 11:09:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:09:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:09:40 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 11:09:40 --> Total execution time: 0.1455
DEBUG - 2021-01-29 11:09:45 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:09:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:09:45 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 11:09:45 --> Total execution time: 0.1247
DEBUG - 2021-01-29 11:09:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:09:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:09:48 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 11:09:48 --> Total execution time: 0.1536
DEBUG - 2021-01-29 11:09:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:09:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:09:57 --> get_sorce_lan_word_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 11:09:57 --> Total execution time: 0.1443
DEBUG - 2021-01-29 11:10:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:10:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:10:08 --> Total execution time: 0.1154
DEBUG - 2021-01-29 11:10:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:10:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:10:49 --> Total execution time: 0.1234
DEBUG - 2021-01-29 11:10:53 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:10:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:10:53 --> Total execution time: 0.1190
DEBUG - 2021-01-29 11:11:09 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:11:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:11:09 --> Total execution time: 0.1217
DEBUG - 2021-01-29 11:11:19 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:11:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:11:19 --> Total execution time: 0.1195
DEBUG - 2021-01-29 11:11:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:11:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:11:29 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 11:11:29 --> Total execution time: 0.1169
DEBUG - 2021-01-29 11:11:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:11:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:11:33 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 11:11:33 --> Total execution time: 0.1180
DEBUG - 2021-01-29 11:11:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:11:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:11:37 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 11:11:37 --> Total execution time: 0.1074
DEBUG - 2021-01-29 11:11:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:11:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:11:42 --> get_sorce_lan_word_type_3->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 11:11:42 --> Total execution time: 0.1524
DEBUG - 2021-01-29 11:11:54 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:11:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:11:54 --> Total execution time: 0.1314
DEBUG - 2021-01-29 11:12:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:12:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:12:13 --> Total execution time: 0.1094
DEBUG - 2021-01-29 11:29:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:29:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:29:26 --> Total execution time: 0.1167
DEBUG - 2021-01-29 11:29:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:29:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:29:27 --> Total execution time: 0.1355
DEBUG - 2021-01-29 11:29:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:29:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:29:28 --> Total execution time: 0.1277
DEBUG - 2021-01-29 11:29:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:29:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:29:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:29:28 --> Total execution time: 0.1436
DEBUG - 2021-01-29 11:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:29:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:29:28 --> Total execution time: 0.1523
DEBUG - 2021-01-29 11:29:29 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:29:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:29:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 11:29:29 --> Total execution time: 0.1403
DEBUG - 2021-01-29 11:29:29 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:29:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:29:29 --> Total execution time: 0.1480
DEBUG - 2021-01-29 11:29:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:29:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:29:30 --> Total execution time: 0.1492
DEBUG - 2021-01-29 11:29:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:29:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:29:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:29:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:29:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 11:29:30 --> Total execution time: 0.1331
DEBUG - 2021-01-29 11:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:29:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:29:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 11:29:30 --> Total execution time: 0.1135
DEBUG - 2021-01-29 11:29:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:29:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:29:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 11:29:30 --> Total execution time: 0.1418
DEBUG - 2021-01-29 11:29:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:29:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:29:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 11:29:31 --> Total execution time: 0.1159
DEBUG - 2021-01-29 11:29:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:29:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:29:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 11:29:32 --> Total execution time: 0.1669
DEBUG - 2021-01-29 11:29:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:29:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:29:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 11:29:33 --> Total execution time: 0.1594
DEBUG - 2021-01-29 11:29:36 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:29:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:29:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:30:36 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:30:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:31:19 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:31:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:31:19 --> Total execution time: 0.1650
DEBUG - 2021-01-29 11:31:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:31:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:31:20 --> Total execution time: 0.1721
DEBUG - 2021-01-29 11:31:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:31:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:31:21 --> Total execution time: 0.1555
DEBUG - 2021-01-29 11:31:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:31:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:31:21 --> Total execution time: 0.1409
DEBUG - 2021-01-29 11:31:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:31:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:31:21 --> Total execution time: 0.1328
DEBUG - 2021-01-29 11:31:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:31:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:31:21 --> Total execution time: 0.1467
DEBUG - 2021-01-29 11:31:23 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:31:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:31:23 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:31:23 --> Total execution time: 0.1466
DEBUG - 2021-01-29 11:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:31:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:31:23 --> Total execution time: 0.1464
DEBUG - 2021-01-29 11:31:23 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:31:23 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:31:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:31:23 --> Total execution time: 0.1442
DEBUG - 2021-01-29 11:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:31:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:31:23 --> Total execution time: 0.2085
DEBUG - 2021-01-29 11:31:25 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:31:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:31:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:31:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:31:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:31:26 --> 404 Page Not Found: Uploads/badger.jpg
DEBUG - 2021-01-29 11:31:38 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:31:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:31:38 --> Total execution time: 0.1647
DEBUG - 2021-01-29 11:31:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:31:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:31:40 --> Total execution time: 0.1650
DEBUG - 2021-01-29 11:31:41 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:31:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:31:41 --> Total execution time: 0.1486
DEBUG - 2021-01-29 11:31:44 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:31:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:31:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:32:35 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:32:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:32:35 --> Total execution time: 0.1519
DEBUG - 2021-01-29 11:32:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:32:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:32:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:34:05 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:34:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:34:06 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:34:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:34:08 --> Total execution time: 0.1237
DEBUG - 2021-01-29 11:34:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:34:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:34:25 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:34:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:34:25 --> Total execution time: 0.1175
DEBUG - 2021-01-29 11:34:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:34:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:34:27 --> Total execution time: 0.1134
DEBUG - 2021-01-29 11:34:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:34:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:34:28 --> Total execution time: 0.1417
DEBUG - 2021-01-29 11:34:29 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:34:29 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:34:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:34:29 --> Total execution time: 0.1298
DEBUG - 2021-01-29 11:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:34:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:34:29 --> Total execution time: 0.1988
DEBUG - 2021-01-29 11:34:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:34:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:34:30 --> Total execution time: 0.1453
DEBUG - 2021-01-29 11:34:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:34:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:34:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:34:32 --> Total execution time: 0.1159
DEBUG - 2021-01-29 11:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:34:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:34:32 --> Total execution time: 0.1251
DEBUG - 2021-01-29 11:34:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:34:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:34:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:34:44 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:34:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:34:44 --> Total execution time: 0.1613
DEBUG - 2021-01-29 11:34:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:34:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:34:47 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:34:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:34:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:34:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:34:58 --> Total execution time: 0.1590
DEBUG - 2021-01-29 11:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:34:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:34:59 --> Query error: Unknown column 'mode_name' in 'order clause' - Invalid query: SELECT *
FROM `tbl_exercise_type`
WHERE `exercise_mode_id` = '5'
ORDER BY `mode_name` ASC
ERROR - 2021-01-29 11:34:59 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 970
DEBUG - 2021-01-29 11:36:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:36:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:36:05 --> Total execution time: 0.1233
DEBUG - 2021-01-29 11:36:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:36:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:36:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:36:18 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:36:18 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:36:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:36:18 --> Total execution time: 0.1469
DEBUG - 2021-01-29 11:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:36:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:36:18 --> Query error: Unknown column 'mode_name' in 'order clause' - Invalid query: SELECT *
FROM `tbl_exercise_type`
WHERE `exercise_mode_id` = '5'
ORDER BY `mode_name` ASC
ERROR - 2021-01-29 11:36:18 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 970
DEBUG - 2021-01-29 11:36:43 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:36:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:36:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:36:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:36:46 --> Total execution time: 0.1947
DEBUG - 2021-01-29 11:36:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:36:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:36:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:36:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:36:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:36:59 --> Total execution time: 0.1628
DEBUG - 2021-01-29 11:37:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:37:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:37:01 --> Total execution time: 0.1123
DEBUG - 2021-01-29 11:37:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:37:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:37:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 11:37:02 --> Total execution time: 0.1448
DEBUG - 2021-01-29 11:37:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:37:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:37:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 11:37:03 --> Total execution time: 0.1263
DEBUG - 2021-01-29 11:37:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:37:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:37:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:37:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:37:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:40:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:40:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:40:51 --> Total execution time: 0.1572
DEBUG - 2021-01-29 11:40:54 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:40:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:40:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 11:40:54 --> Total execution time: 0.1601
DEBUG - 2021-01-29 11:40:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:40:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:40:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:41:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:41:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:41:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 11:41:03 --> Total execution time: 0.1251
DEBUG - 2021-01-29 11:41:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:41:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:41:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 11:41:06 --> Total execution time: 0.1387
DEBUG - 2021-01-29 11:41:09 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:41:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:41:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:41:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:41:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:41:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 11:41:40 --> Total execution time: 0.1743
DEBUG - 2021-01-29 11:41:43 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:41:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:41:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:42:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:42:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:42:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 11:42:31 --> Total execution time: 0.1756
DEBUG - 2021-01-29 11:42:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:42:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:42:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:44:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:44:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:44:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 11:44:31 --> Total execution time: 0.1559
DEBUG - 2021-01-29 11:44:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:44:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:44:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:47:45 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:47:45 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:47:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:47:45 --> Total execution time: 0.1401
DEBUG - 2021-01-29 11:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:47:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:47:45 --> Total execution time: 0.1809
DEBUG - 2021-01-29 11:47:45 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:47:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:47:45 --> Total execution time: 0.1354
DEBUG - 2021-01-29 11:47:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:47:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:47:46 --> Total execution time: 0.1233
DEBUG - 2021-01-29 11:47:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:47:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:47:46 --> Total execution time: 0.1214
DEBUG - 2021-01-29 11:47:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:47:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:47:47 --> Total execution time: 0.1396
DEBUG - 2021-01-29 11:47:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:47:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:47:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:47:48 --> Total execution time: 0.1379
DEBUG - 2021-01-29 11:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:47:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:47:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 11:47:48 --> Total execution time: 0.1345
DEBUG - 2021-01-29 11:47:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:47:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:47:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:47:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 11:47:48 --> Total execution time: 0.1246
DEBUG - 2021-01-29 11:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:47:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:47:48 --> Total execution time: 0.1657
DEBUG - 2021-01-29 11:47:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:47:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:47:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:47:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 11:47:48 --> Total execution time: 0.1334
DEBUG - 2021-01-29 11:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:47:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:47:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:47:48 --> Total execution time: 0.1781
DEBUG - 2021-01-29 11:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:47:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:47:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:47:48 --> Total execution time: 0.1282
DEBUG - 2021-01-29 11:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:47:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:47:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 11:47:49 --> Total execution time: 0.1145
DEBUG - 2021-01-29 11:47:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:47:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:47:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 11:47:49 --> Total execution time: 0.1847
DEBUG - 2021-01-29 11:47:50 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:47:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:47:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 11:47:50 --> Total execution time: 0.1717
DEBUG - 2021-01-29 11:47:50 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:47:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:47:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 11:47:51 --> Total execution time: 0.1568
DEBUG - 2021-01-29 11:47:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:47:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:47:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 11:47:51 --> Total execution time: 0.1593
DEBUG - 2021-01-29 11:47:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:47:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:47:52 --> UTF-8 Support Enabled
ERROR - 2021-01-29 11:47:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 11:47:52 --> Total execution time: 0.1245
DEBUG - 2021-01-29 11:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:47:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:47:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 11:47:52 --> Total execution time: 0.1329
DEBUG - 2021-01-29 11:47:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:47:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:47:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:48:19 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:48:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:48:19 --> Total execution time: 0.1469
DEBUG - 2021-01-29 11:48:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:48:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:48:22 --> Total execution time: 0.1452
DEBUG - 2021-01-29 11:48:24 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:48:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:48:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:52:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:52:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:52:47 --> Total execution time: 0.1734
DEBUG - 2021-01-29 11:52:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:52:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:52:50 --> Total execution time: 0.1600
DEBUG - 2021-01-29 11:52:53 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:52:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:52:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:52:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:52:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:52:59 --> Total execution time: 0.1528
DEBUG - 2021-01-29 11:53:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:53:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:53:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:55:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:55:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:55:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:55:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:55:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:55:15 --> Total execution time: 0.1376
DEBUG - 2021-01-29 11:55:18 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:55:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:55:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:55:24 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:55:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 11:55:24 --> Total execution time: 0.1471
DEBUG - 2021-01-29 11:55:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:55:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 11:55:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 11:55:27 --> Total execution time: 0.1273
DEBUG - 2021-01-29 11:55:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:55:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 11:55:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 11:55:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 11:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 11:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 11:55:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:03:54 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:03:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:03:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:03:54 --> Total execution time: 0.1591
DEBUG - 2021-01-29 12:03:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:03:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:03:56 --> Total execution time: 0.1407
DEBUG - 2021-01-29 12:03:56 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:03:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:03:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:03:56 --> Total execution time: 0.1509
DEBUG - 2021-01-29 12:03:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:03:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:03:58 --> Total execution time: 0.1421
DEBUG - 2021-01-29 12:04:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:04:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:04:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:04:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:04:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:04:11 --> Total execution time: 0.1689
DEBUG - 2021-01-29 12:04:14 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:04:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:04:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:04:24 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:04:24 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:04:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:04:25 --> Total execution time: 0.1398
DEBUG - 2021-01-29 12:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:04:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:04:25 --> Query error: Unknown column 'mode_name' in 'order clause' - Invalid query: SELECT *
FROM `tbl_exercise_type`
WHERE `exercise_mode_id` = '4'
ORDER BY `mode_name` ASC
ERROR - 2021-01-29 12:04:25 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 970
DEBUG - 2021-01-29 12:04:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:04:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:04:33 --> Total execution time: 0.1499
DEBUG - 2021-01-29 12:04:36 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:04:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:04:36 --> Total execution time: 0.1313
DEBUG - 2021-01-29 12:04:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:04:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:04:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:04:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:04:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:04:51 --> Total execution time: 0.2023
DEBUG - 2021-01-29 12:04:54 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:04:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:04:54 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:07:05 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:07:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:07:05 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:07:09 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:07:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:07:09 --> Total execution time: 0.1310
DEBUG - 2021-01-29 12:07:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:07:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:07:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:07:29 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:07:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:07:29 --> Total execution time: 0.1439
DEBUG - 2021-01-29 12:07:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:07:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:07:31 --> Total execution time: 0.1305
DEBUG - 2021-01-29 12:07:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:07:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:07:32 --> Total execution time: 0.1512
DEBUG - 2021-01-29 12:07:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:07:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:07:33 --> Total execution time: 0.1548
DEBUG - 2021-01-29 12:07:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:07:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:07:35 --> Total execution time: 0.2068
DEBUG - 2021-01-29 12:07:36 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:07:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:07:36 --> Total execution time: 0.1756
DEBUG - 2021-01-29 12:07:38 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:07:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:07:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:07:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:07:52 --> Total execution time: 0.1407
DEBUG - 2021-01-29 12:07:54 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:07:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:07:54 --> Total execution time: 0.1542
DEBUG - 2021-01-29 12:07:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:07:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:07:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:08:05 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:08:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:08:05 --> Total execution time: 0.1265
DEBUG - 2021-01-29 12:08:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:08:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:08:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:08:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:08:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:08:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:08:27 --> Total execution time: 0.1487
DEBUG - 2021-01-29 12:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:08:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:08:27 --> Query error: Unknown column 'mode_name' in 'order clause' - Invalid query: SELECT *
FROM `tbl_exercise_type`
WHERE `exercise_mode_id` = '4'
ORDER BY `mode_name` ASC
ERROR - 2021-01-29 12:08:27 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 970
DEBUG - 2021-01-29 12:09:19 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:09:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:09:20 --> Total execution time: 0.1448
DEBUG - 2021-01-29 12:09:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:09:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:09:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:10:14 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:10:15 --> Total execution time: 0.1359
DEBUG - 2021-01-29 12:11:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:11:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:11:37 --> Total execution time: 0.1487
DEBUG - 2021-01-29 12:11:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:11:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:11:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:11:56 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:11:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:11:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:11:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:11:59 --> Total execution time: 0.1385
DEBUG - 2021-01-29 12:12:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:12:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:12:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:12:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:12:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:12:13 --> Total execution time: 0.1357
DEBUG - 2021-01-29 12:12:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:12:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:12:13 --> Total execution time: 0.1308
DEBUG - 2021-01-29 12:12:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:12:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:12:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:12:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:12:15 --> Total execution time: 0.1294
DEBUG - 2021-01-29 12:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:12:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:12:15 --> Total execution time: 0.1602
DEBUG - 2021-01-29 12:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:12:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:12:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:12:15 --> Total execution time: 0.1359
DEBUG - 2021-01-29 12:12:16 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:12:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:12:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:12:16 --> Total execution time: 0.1420
DEBUG - 2021-01-29 12:12:16 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:12:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:12:16 --> Total execution time: 0.1336
DEBUG - 2021-01-29 12:12:17 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:12:17 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:12:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:12:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:12:18 --> Total execution time: 0.1347
DEBUG - 2021-01-29 12:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:12:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:12:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:12:18 --> Total execution time: 0.1912
DEBUG - 2021-01-29 12:12:19 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:12:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:12:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:12:19 --> Total execution time: 0.1337
DEBUG - 2021-01-29 12:12:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:12:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:12:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:12:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:12:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:12:52 --> Total execution time: 0.1555
DEBUG - 2021-01-29 12:12:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:12:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:12:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:12:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:12:55 --> Total execution time: 0.1778
DEBUG - 2021-01-29 12:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:12:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:12:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:12:55 --> Total execution time: 0.1463
DEBUG - 2021-01-29 12:12:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:12:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:12:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:12:57 --> Total execution time: 0.1399
DEBUG - 2021-01-29 12:13:00 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:13:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:13:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:13:24 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:13:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:13:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:13:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:13:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:13:27 --> Total execution time: 0.1410
DEBUG - 2021-01-29 12:13:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:13:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:13:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:13:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:13:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:13:47 --> Total execution time: 0.1328
DEBUG - 2021-01-29 12:13:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:13:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:13:48 --> Total execution time: 0.1236
DEBUG - 2021-01-29 12:13:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:13:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:13:49 --> Total execution time: 0.1533
DEBUG - 2021-01-29 12:13:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:13:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:13:49 --> Total execution time: 0.1257
DEBUG - 2021-01-29 12:13:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:13:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:13:50 --> Total execution time: 0.1241
DEBUG - 2021-01-29 12:13:50 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:13:50 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:13:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:13:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 12:13:50 --> Total execution time: 0.1610
DEBUG - 2021-01-29 12:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:13:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:13:50 --> Total execution time: 0.2245
DEBUG - 2021-01-29 12:13:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:13:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:13:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 12:13:51 --> Total execution time: 0.1685
DEBUG - 2021-01-29 12:13:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:13:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:13:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 12:13:52 --> Total execution time: 0.1371
DEBUG - 2021-01-29 12:13:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:13:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:13:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 12:13:52 --> Total execution time: 0.1251
DEBUG - 2021-01-29 12:13:53 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:13:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:13:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-29 12:13:53 --> Total execution time: 0.1421
DEBUG - 2021-01-29 12:13:56 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:13:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:13:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:14:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:14:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:14:01 --> Total execution time: 0.1348
DEBUG - 2021-01-29 12:14:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:14:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:14:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:14:04 --> Total execution time: 0.1227
DEBUG - 2021-01-29 12:14:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:14:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:14:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:14:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:14:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:14:13 --> Total execution time: 0.1289
DEBUG - 2021-01-29 12:14:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:14:16 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:14:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:14:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:14:16 --> Total execution time: 0.1474
DEBUG - 2021-01-29 12:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:14:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:14:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:14:16 --> Total execution time: 0.1289
DEBUG - 2021-01-29 12:14:18 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:14:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:14:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:14:18 --> Total execution time: 0.1553
DEBUG - 2021-01-29 12:14:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:14:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:14:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:14:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:14:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:14:35 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:14:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:14:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:14:36 --> Total execution time: 0.1542
DEBUG - 2021-01-29 12:14:38 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:14:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:14:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:24:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:24:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:24:28 --> 404 Page Not Found: Admin/index
DEBUG - 2021-01-29 12:24:35 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:24:35 --> No URI present. Default controller set.
DEBUG - 2021-01-29 12:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:24:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:24:35 --> Total execution time: 0.1822
DEBUG - 2021-01-29 12:24:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:24:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:24:50 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:24:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:24:50 --> Total execution time: 0.1699
DEBUG - 2021-01-29 12:24:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:24:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:24:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:25:17 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:25:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:25:17 --> Total execution time: 0.1270
DEBUG - 2021-01-29 12:25:19 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:25:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:25:19 --> Total execution time: 0.1488
DEBUG - 2021-01-29 12:25:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:25:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:25:21 --> Total execution time: 0.1206
DEBUG - 2021-01-29 12:25:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:25:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:25:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:25:29 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:25:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:25:29 --> Total execution time: 0.1231
DEBUG - 2021-01-29 12:25:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:25:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:25:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 12:25:32 --> Total execution time: 0.1534
DEBUG - 2021-01-29 12:25:35 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:25:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:25:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:26:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:26:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:26:46 --> Total execution time: 0.1395
DEBUG - 2021-01-29 12:26:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:26:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:26:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:26:48 --> Total execution time: 0.1526
DEBUG - 2021-01-29 12:26:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:26:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:26:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:27:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:27:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:27:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:27:07 --> Total execution time: 0.1206
DEBUG - 2021-01-29 12:27:09 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:27:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:27:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:27:09 --> Total execution time: 0.1321
DEBUG - 2021-01-29 12:27:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:27:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:27:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:27:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:27:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:27:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:27:21 --> Total execution time: 0.1721
DEBUG - 2021-01-29 12:27:23 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:27:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:27:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:27:23 --> Total execution time: 0.1702
DEBUG - 2021-01-29 12:27:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:27:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:27:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:27:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:27:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:27:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:27:33 --> Total execution time: 0.1629
DEBUG - 2021-01-29 12:27:35 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:27:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:27:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:27:35 --> Total execution time: 0.1408
DEBUG - 2021-01-29 12:27:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:27:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:27:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:27:45 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:27:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:27:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:27:45 --> Total execution time: 0.1687
DEBUG - 2021-01-29 12:27:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:27:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:27:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:27:48 --> Total execution time: 0.1882
DEBUG - 2021-01-29 12:27:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:27:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:27:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:31:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:31:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:31:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:31:04 --> Total execution time: 0.1449
DEBUG - 2021-01-29 12:31:05 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:31:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:31:06 --> Total execution time: 0.1814
DEBUG - 2021-01-29 12:31:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:31:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:31:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:31:07 --> Total execution time: 0.1277
DEBUG - 2021-01-29 12:31:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:31:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:31:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:31:08 --> Total execution time: 0.1360
DEBUG - 2021-01-29 12:31:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:31:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:31:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:31:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:31:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:31:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:31:22 --> Total execution time: 0.1558
DEBUG - 2021-01-29 12:31:24 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:31:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:31:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:31:24 --> Total execution time: 0.1475
DEBUG - 2021-01-29 12:31:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:31:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:31:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:32:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:32:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:32:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:32:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:32:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:32:28 --> 404 Page Not Found: Assets/js
DEBUG - 2021-01-29 12:32:45 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:32:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:32:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:32:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:32:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:32:48 --> Total execution time: 0.1953
DEBUG - 2021-01-29 12:32:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:32:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:32:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:32:56 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:32:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:32:56 --> 404 Page Not Found: Assets/js
DEBUG - 2021-01-29 12:33:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:33:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:33:44 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:33:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:33:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:33:44 --> Total execution time: 0.1755
DEBUG - 2021-01-29 12:33:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:33:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:33:47 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:33:50 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:33:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:33:50 --> 404 Page Not Found: Assets/js
DEBUG - 2021-01-29 12:34:17 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:34:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:34:19 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:34:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:34:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:34:20 --> Total execution time: 0.1435
DEBUG - 2021-01-29 12:34:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:34:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:34:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:34:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:34:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:34:30 --> 404 Page Not Found: Assets/js
DEBUG - 2021-01-29 12:36:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:36:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:39:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:39:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:39:08 --> Total execution time: 0.1590
DEBUG - 2021-01-29 12:39:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:39:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:43:36 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:43:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:48:38 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:48:38 --> No URI present. Default controller set.
DEBUG - 2021-01-29 12:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:48:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:48:38 --> Total execution time: 0.1537
DEBUG - 2021-01-29 12:48:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:48:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:48:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:48:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:48:52 --> Total execution time: 0.1570
DEBUG - 2021-01-29 12:48:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:48:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:48:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:49:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:49:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:49:02 --> Total execution time: 0.1169
DEBUG - 2021-01-29 12:49:05 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:49:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:49:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:49:05 --> Total execution time: 0.1123
DEBUG - 2021-01-29 12:49:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:49:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:49:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:49:19 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:49:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:49:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:49:19 --> Total execution time: 0.1437
DEBUG - 2021-01-29 12:49:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:49:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:49:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:49:21 --> Total execution time: 0.1203
DEBUG - 2021-01-29 12:49:23 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:49:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:49:23 --> Total execution time: 0.1476
DEBUG - 2021-01-29 12:49:24 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:49:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:49:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:49:29 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:49:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:49:30 --> Total execution time: 0.1925
DEBUG - 2021-01-29 12:49:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:49:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:49:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:49:33 --> Total execution time: 0.1653
DEBUG - 2021-01-29 12:49:35 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:49:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:49:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:49:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:49:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:49:41 --> Total execution time: 0.1566
DEBUG - 2021-01-29 12:49:43 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:49:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:49:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:49:43 --> Total execution time: 0.1489
DEBUG - 2021-01-29 12:49:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:49:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:50:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:50:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:50:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:50:29 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:50:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:50:29 --> 404 Page Not Found: Assets/js
DEBUG - 2021-01-29 12:53:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:53:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:53:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:53:02 --> Total execution time: 0.1478
DEBUG - 2021-01-29 12:53:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:53:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 12:53:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:53:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 12:53:40 --> Total execution time: 0.1464
DEBUG - 2021-01-29 12:53:41 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 12:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 12:53:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 12:53:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 12:53:41 --> Total execution time: 0.1362
DEBUG - 2021-01-29 12:53:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 12:53:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 12:53:47 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:10:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:10:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:10:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 13:10:55 --> Total execution time: 0.1349
DEBUG - 2021-01-29 13:10:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:10:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:10:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:12:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:12:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:12:12 --> Total execution time: 0.1264
DEBUG - 2021-01-29 13:12:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:12:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:12:21 --> Total execution time: 0.1304
DEBUG - 2021-01-29 13:12:25 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:12:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:12:26 --> Total execution time: 0.1409
DEBUG - 2021-01-29 13:12:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:12:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:12:31 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 13:12:31 --> Total execution time: 0.1242
DEBUG - 2021-01-29 13:12:35 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:12:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:12:35 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 13:12:35 --> Total execution time: 0.1651
DEBUG - 2021-01-29 13:12:38 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:12:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:12:38 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 13:12:38 --> Total execution time: 0.1074
DEBUG - 2021-01-29 13:12:44 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:12:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:12:44 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 13:12:44 --> Total execution time: 0.1229
DEBUG - 2021-01-29 13:12:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:12:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:12:47 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 13:12:47 --> Total execution time: 0.1271
DEBUG - 2021-01-29 13:12:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:12:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:12:49 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-01-29 13:12:49 --> Total execution time: 0.1265
DEBUG - 2021-01-29 13:12:50 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:12:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:12:50 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 13:12:50 --> Total execution time: 0.1108
DEBUG - 2021-01-29 13:12:53 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:12:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:12:53 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 13:12:53 --> Total execution time: 0.1478
DEBUG - 2021-01-29 13:13:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:13:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:13:04 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-01-29 13:13:04 --> Total execution time: 0.1382
DEBUG - 2021-01-29 13:13:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:13:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:13:08 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 13:13:08 --> Total execution time: 0.1772
DEBUG - 2021-01-29 13:13:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:13:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:13:12 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-01-29 13:13:12 --> Total execution time: 0.1391
DEBUG - 2021-01-29 13:13:16 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:13:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:13:16 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 13:13:16 --> Total execution time: 0.1295
DEBUG - 2021-01-29 13:13:36 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:13:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:13:36 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-01-29 13:13:36 --> Total execution time: 0.1392
DEBUG - 2021-01-29 13:13:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:13:40 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 13:13:40 --> Total execution time: 0.0970
DEBUG - 2021-01-29 13:18:00 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:18:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:18:00 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 13:18:00 --> Total execution time: 0.1212
DEBUG - 2021-01-29 13:18:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:18:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:18:02 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-01-29 13:18:02 --> Total execution time: 0.1237
DEBUG - 2021-01-29 13:18:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:18:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:18:04 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 13:18:04 --> Total execution time: 0.1124
DEBUG - 2021-01-29 13:18:05 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:18:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:18:05 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 13:18:05 --> Total execution time: 0.1212
DEBUG - 2021-01-29 13:18:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:18:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:18:11 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 13:18:11 --> Total execution time: 0.1177
DEBUG - 2021-01-29 13:18:14 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:18:14 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-01-29 13:18:14 --> Total execution time: 0.1112
DEBUG - 2021-01-29 13:19:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:19:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:19:11 --> Total execution time: 0.1284
DEBUG - 2021-01-29 13:19:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:19:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:19:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:19:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-01-29 13:19:13 --> Total execution time: 0.1370
DEBUG - 2021-01-29 13:19:13 --> Total execution time: 0.1340
DEBUG - 2021-01-29 13:19:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:19:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:19:14 --> Total execution time: 0.1653
DEBUG - 2021-01-29 13:19:16 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:19:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:19:25 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:19:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:19:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/langoalphademo/public_html/indylan/application/views/admin/add_phrases.php 41
DEBUG - 2021-01-29 13:19:25 --> Total execution time: 0.1475
DEBUG - 2021-01-29 13:19:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:19:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:19:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:19:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:19:34 --> Total execution time: 0.1960
DEBUG - 2021-01-29 13:19:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:19:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:19:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:19:35 --> Total execution time: 0.2148
DEBUG - 2021-01-29 13:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:19:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:19:35 --> Total execution time: 0.1833
DEBUG - 2021-01-29 13:19:36 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:19:36 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:19:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:19:36 --> Total execution time: 0.1454
DEBUG - 2021-01-29 13:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:19:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:19:36 --> Total execution time: 0.1569
DEBUG - 2021-01-29 13:19:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:19:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:19:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:19:37 --> Total execution time: 0.1469
DEBUG - 2021-01-29 13:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:19:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:19:37 --> Total execution time: 0.1501
DEBUG - 2021-01-29 13:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:19:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:19:37 --> Total execution time: 0.2079
DEBUG - 2021-01-29 13:19:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:19:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:19:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:19:37 --> Total execution time: 0.1255
DEBUG - 2021-01-29 13:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:19:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:19:37 --> Total execution time: 0.1221
DEBUG - 2021-01-29 13:19:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:19:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:19:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:19:39 --> Total execution time: 0.1441
DEBUG - 2021-01-29 13:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:19:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:19:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:39 --> Total execution time: 0.1606
DEBUG - 2021-01-29 13:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:19:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:19:40 --> Total execution time: 0.1326
DEBUG - 2021-01-29 13:19:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:19:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:19:40 --> Total execution time: 0.1283
DEBUG - 2021-01-29 13:19:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:19:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:19:43 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:19:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:19:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:19:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:19:46 --> Total execution time: 0.1656
DEBUG - 2021-01-29 13:19:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:19:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:19:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:19:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:19:55 --> Total execution time: 0.1304
DEBUG - 2021-01-29 13:19:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:19:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:19:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:20:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:20:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:20:02 --> Total execution time: 0.1278
DEBUG - 2021-01-29 13:20:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:20:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:20:03 --> Total execution time: 0.1178
DEBUG - 2021-01-29 13:20:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:20:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:20:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:20:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:20:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:20:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 13:20:05 --> Total execution time: 0.1463
DEBUG - 2021-01-29 13:20:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:20:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:20:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:20:17 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:20:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:20:17 --> Total execution time: 0.1329
DEBUG - 2021-01-29 13:20:19 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:20:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:20:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 13:20:20 --> Total execution time: 0.1151
DEBUG - 2021-01-29 13:20:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:20:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:20:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:20:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:20:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:20:27 --> Total execution time: 0.1789
DEBUG - 2021-01-29 13:20:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:20:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:20:28 --> Total execution time: 0.1258
DEBUG - 2021-01-29 13:20:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:20:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:20:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 13:20:30 --> Total execution time: 0.1346
DEBUG - 2021-01-29 13:20:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:20:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:20:30 --> Total execution time: 0.1423
DEBUG - 2021-01-29 13:20:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:20:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:20:31 --> Total execution time: 0.1296
DEBUG - 2021-01-29 13:20:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:20:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:20:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 13:20:33 --> Total execution time: 0.1323
DEBUG - 2021-01-29 13:20:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:20:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:20:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:20:36 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:20:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:20:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:21:25 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:21:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:21:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:21:25 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:21:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:21:25 --> 404 Page Not Found: Assets/js
DEBUG - 2021-01-29 13:21:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:21:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:21:40 --> Total execution time: 0.1624
DEBUG - 2021-01-29 13:21:43 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:21:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:21:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 13:21:43 --> Total execution time: 0.1315
DEBUG - 2021-01-29 13:21:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:21:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:21:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:21:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:21:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:21:49 --> 404 Page Not Found: Assets/js
DEBUG - 2021-01-29 13:21:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:21:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:21:52 --> Total execution time: 0.1331
DEBUG - 2021-01-29 13:21:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:21:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:21:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 13:21:55 --> Total execution time: 0.1116
DEBUG - 2021-01-29 13:21:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:21:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:21:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:22:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:22:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:22:02 --> 404 Page Not Found: Assets/js
DEBUG - 2021-01-29 13:22:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:22:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:22:08 --> Total execution time: 0.1154
DEBUG - 2021-01-29 13:22:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:22:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:22:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 13:22:08 --> Total execution time: 0.1374
DEBUG - 2021-01-29 13:22:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:22:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:22:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:22:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:22:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:22:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 13:22:11 --> Total execution time: 0.1823
DEBUG - 2021-01-29 13:22:14 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:22:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:22:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:22:18 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:22:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:22:18 --> 404 Page Not Found: Assets/js
DEBUG - 2021-01-29 13:22:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:22:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:22:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 13:22:30 --> Total execution time: 0.1591
DEBUG - 2021-01-29 13:22:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:22:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:22:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:23:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:23:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:23:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:23:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:23:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:23:07 --> 404 Page Not Found: Assets/js
DEBUG - 2021-01-29 13:24:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:24:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:24:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:24:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:24:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:24:06 --> Total execution time: 0.1139
DEBUG - 2021-01-29 13:24:09 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:24:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:24:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:24:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:24:12 --> Total execution time: 0.1381
DEBUG - 2021-01-29 13:24:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:24:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:24:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-29 13:24:15 --> Total execution time: 0.1692
DEBUG - 2021-01-29 13:24:18 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:24:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:24:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:24:21 --> 404 Page Not Found: Assets/js
DEBUG - 2021-01-29 13:24:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:24:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:24:52 --> Total execution time: 0.1435
DEBUG - 2021-01-29 13:24:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:24:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:24:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-01-29 13:24:55 --> Total execution time: 0.1505
DEBUG - 2021-01-29 13:24:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:24:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:24:56 --> Total execution time: 0.1253
DEBUG - 2021-01-29 13:24:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:24:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:25:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:25:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:25:11 --> Total execution time: 0.1331
DEBUG - 2021-01-29 13:25:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:25:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:25:11 --> Total execution time: 0.1228
DEBUG - 2021-01-29 13:25:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:25:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:25:12 --> Total execution time: 0.1242
DEBUG - 2021-01-29 13:25:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:25:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:25:12 --> Total execution time: 0.1464
DEBUG - 2021-01-29 13:25:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:25:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:25:13 --> Total execution time: 0.1285
DEBUG - 2021-01-29 13:25:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:25:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:25:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:25:13 --> Total execution time: 0.1651
DEBUG - 2021-01-29 13:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:25:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:25:13 --> Total execution time: 0.1349
DEBUG - 2021-01-29 13:25:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:25:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:25:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:25:15 --> Total execution time: 0.1233
DEBUG - 2021-01-29 13:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:25:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:25:15 --> Total execution time: 0.2019
DEBUG - 2021-01-29 13:25:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:25:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:25:15 --> Total execution time: 0.1326
DEBUG - 2021-01-29 13:25:18 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:25:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:25:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:25:29 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:25:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:25:30 --> Total execution time: 0.1378
DEBUG - 2021-01-29 13:25:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:25:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:25:30 --> Total execution time: 0.1554
DEBUG - 2021-01-29 13:25:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:25:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:25:32 --> Total execution time: 0.1501
DEBUG - 2021-01-29 13:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:25:33 --> Total execution time: 0.2359
DEBUG - 2021-01-29 13:25:35 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:25:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:25:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:26:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:26:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:26:09 --> Total execution time: 0.1515
DEBUG - 2021-01-29 13:26:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:26:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:26:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:26:17 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:26:17 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:26:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:26:17 --> Total execution time: 0.1295
DEBUG - 2021-01-29 13:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:26:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:26:17 --> Query error: Unknown column 'mode_name' in 'order clause' - Invalid query: SELECT *
FROM `tbl_exercise_type`
WHERE `exercise_mode_id` = '3'
ORDER BY `mode_name` ASC
ERROR - 2021-01-29 13:26:17 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 970
DEBUG - 2021-01-29 13:28:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:28:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:28:04 --> Total execution time: 0.1569
DEBUG - 2021-01-29 13:28:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:28:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:28:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:28:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:28:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:28:34 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"3"}
DEBUG - 2021-01-29 13:28:34 --> Total execution time: 0.1344
DEBUG - 2021-01-29 13:28:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:28:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:28:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 13:28:53 --> Total execution time: 0.1331
DEBUG - 2021-01-29 13:28:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:28:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:28:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:28:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:28:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:28:58 --> 404 Page Not Found: Assets/js
DEBUG - 2021-01-29 13:29:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:29:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:29:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:29:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:29:11 --> Total execution time: 0.1620
DEBUG - 2021-01-29 13:29:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:29:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:29:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:33:18 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:33:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:33:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 13:33:18 --> Total execution time: 0.1437
DEBUG - 2021-01-29 13:33:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:33:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:33:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:33:23 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:33:23 --> 404 Page Not Found: Assets/js
DEBUG - 2021-01-29 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:33:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:33:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 13:33:28 --> Total execution time: 0.1561
DEBUG - 2021-01-29 13:33:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:33:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:33:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 13:33:31 --> Total execution time: 0.1566
DEBUG - 2021-01-29 13:33:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:33:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:33:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:33:35 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:33:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:33:35 --> 404 Page Not Found: Assets/js
DEBUG - 2021-01-29 13:36:43 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:36:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:36:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-29 13:36:43 --> Total execution time: 0.1466
DEBUG - 2021-01-29 13:36:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:36:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:36:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:36:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:36:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:36:48 --> 404 Page Not Found: Assets/js
DEBUG - 2021-01-29 13:36:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:36:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:36:59 --> Total execution time: 0.1559
DEBUG - 2021-01-29 13:56:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:56:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:56:34 --> Total execution time: 0.1577
DEBUG - 2021-01-29 13:56:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:56:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:56:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 13:56:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:56:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:56:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 13:56:46 --> Query error: Unknown column 'mode_name' in 'order clause' - Invalid query: SELECT *
FROM `tbl_exercise_type`
WHERE `exercise_mode_id` = '3'
ORDER BY `mode_name` ASC
ERROR - 2021-01-29 13:56:46 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 970
DEBUG - 2021-01-29 13:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:56:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:56:46 --> Total execution time: 0.2021
DEBUG - 2021-01-29 13:57:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:57:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:58:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 13:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 13:58:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 13:58:01 --> Total execution time: 0.1694
DEBUG - 2021-01-29 13:58:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 13:58:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 13:58:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 14:07:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 14:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 14:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 14:07:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 14:07:02 --> Total execution time: 0.1173
DEBUG - 2021-01-29 14:07:05 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 14:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 14:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 14:07:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 14:07:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-01-29 14:07:05 --> Total execution time: 0.1606
DEBUG - 2021-01-29 14:07:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 14:07:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 14:07:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 14:07:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 14:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 14:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 14:07:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 14:07:26 --> Total execution time: 0.1410
DEBUG - 2021-01-29 14:07:29 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 14:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 14:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 14:07:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 14:07:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-01-29 14:07:29 --> Total execution time: 0.1358
DEBUG - 2021-01-29 14:07:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 14:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 14:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 14:07:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 14:07:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-01-29 14:07:31 --> Total execution time: 0.1153
DEBUG - 2021-01-29 14:07:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 14:07:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 14:07:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 14:07:41 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 14:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 14:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 14:07:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 14:17:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 14:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 14:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 14:17:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 14:17:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-01-29 14:17:32 --> Total execution time: 0.1604
DEBUG - 2021-01-29 14:17:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 14:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 14:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 14:17:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 14:17:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-01-29 14:17:34 --> Total execution time: 0.1322
DEBUG - 2021-01-29 14:17:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 14:17:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 14:17:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 14:17:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 14:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 14:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 14:17:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 14:18:00 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 14:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 14:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 14:18:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 14:18:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-01-29 14:18:01 --> Total execution time: 0.1726
DEBUG - 2021-01-29 14:18:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 14:18:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-29 14:18:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-29 14:18:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 14:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 14:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 14:18:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 14:18:26 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"3"}
DEBUG - 2021-01-29 14:18:26 --> Total execution time: 0.1389
DEBUG - 2021-01-29 14:18:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 14:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 14:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 14:18:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 14:18:30 --> get_subcategory_list->{"lang":"37","category_id":"9","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-29 14:18:30 --> Total execution time: 0.1192
DEBUG - 2021-01-29 14:18:36 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 14:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 14:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 14:18:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 14:18:36 --> get_exercise_type_list->{"lang":"37","subcategory_id":"4","support_lang_id":"3"}
DEBUG - 2021-01-29 14:18:36 --> Total execution time: 0.1530
DEBUG - 2021-01-29 14:18:41 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 14:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 14:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 14:18:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-29 14:18:41 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-01-29 14:18:41 --> Total execution time: 0.1421
DEBUG - 2021-01-29 14:18:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-29 14:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-29 14:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-29 14:18:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-29 14:18:46 --> get_exercise_type_list->{"lang":"37","subcategory_id":"4","support_lang_id":"3"}
DEBUG - 2021-01-29 14:18:46 --> Total execution time: 0.1286
