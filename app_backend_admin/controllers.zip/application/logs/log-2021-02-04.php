<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-02-04 11:08:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-04 11:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-04 11:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-04 11:08:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-04 11:08:28 --> Total execution time: 0.1388
DEBUG - 2021-02-04 11:08:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-04 11:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-04 11:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-04 11:08:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-04 11:08:39 --> Total execution time: 0.1163
