<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-02-02 06:44:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:44:04 --> No URI present. Default controller set.
DEBUG - 2021-02-02 06:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:44:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:44:04 --> Total execution time: 0.1680
DEBUG - 2021-02-02 06:44:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:44:22 --> No URI present. Default controller set.
DEBUG - 2021-02-02 06:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:44:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:44:22 --> Total execution time: 0.1201
DEBUG - 2021-02-02 06:44:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:44:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:44:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:44:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:44:31 --> Total execution time: 0.1400
DEBUG - 2021-02-02 06:44:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:44:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 06:44:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 06:44:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:44:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:44:57 --> Total execution time: 0.1528
DEBUG - 2021-02-02 06:44:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:44:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:44:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 06:44:59 --> Total execution time: 0.1253
DEBUG - 2021-02-02 06:45:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:45:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 06:45:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 06:45:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:45:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:45:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 06:45:21 --> Total execution time: 0.1552
DEBUG - 2021-02-02 06:45:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:45:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:45:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 06:45:24 --> Total execution time: 0.1497
DEBUG - 2021-02-02 06:45:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:45:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 06:45:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 06:45:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:45:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:45:43 --> Total execution time: 0.1301
DEBUG - 2021-02-02 06:45:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:45:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:45:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 06:45:45 --> Total execution time: 0.1733
DEBUG - 2021-02-02 06:45:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:45:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 06:45:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 06:45:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:45:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:45:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 06:45:53 --> Total execution time: 0.1626
DEBUG - 2021-02-02 06:45:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:45:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:45:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 06:45:56 --> Total execution time: 0.1642
DEBUG - 2021-02-02 06:45:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:45:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 06:45:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 06:46:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:46:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:46:04 --> Query error: Undeclared variable: undefined - Invalid query: select g.*,c.category_name from tbl_culture_master g  LEFT JOIN tbl_exercise_mode_categories c ON c.exercise_mode_category_id=g.category_id where g.is_active='1' AND g.is_delete='0' AND g.category_id='6' AND g.support_lang_id='1' AND g.target_language_id='37' limit undefined,10 
ERROR - 2021-02-02 06:46:04 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 639
DEBUG - 2021-02-02 06:46:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:46:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:46:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 06:46:18 --> Total execution time: 0.1606
DEBUG - 2021-02-02 06:46:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:46:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:46:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 06:46:20 --> Total execution time: 0.1956
DEBUG - 2021-02-02 06:46:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:46:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:46:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 06:46:23 --> Total execution time: 0.1358
DEBUG - 2021-02-02 06:46:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:46:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 06:46:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 06:46:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:46:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:46:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 06:46:34 --> Total execution time: 0.1350
DEBUG - 2021-02-02 06:46:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:46:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:46:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 06:46:36 --> Total execution time: 0.1784
DEBUG - 2021-02-02 06:46:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:46:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 06:46:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 06:46:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:46:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:46:54 --> Total execution time: 0.1249
DEBUG - 2021-02-02 06:46:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:46:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:46:57 --> Total execution time: 0.1559
DEBUG - 2021-02-02 06:47:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:47:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 06:47:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 06:47:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:47:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:47:13 --> Total execution time: 0.1497
DEBUG - 2021-02-02 06:47:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:47:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:47:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 06:47:16 --> Total execution time: 0.1511
DEBUG - 2021-02-02 06:47:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:47:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 06:47:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 06:47:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:47:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:47:23 --> Total execution time: 0.1411
DEBUG - 2021-02-02 06:47:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:47:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:47:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 06:47:25 --> Total execution time: 0.1397
DEBUG - 2021-02-02 06:47:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:47:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 06:47:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 06:47:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:47:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:47:38 --> Total execution time: 0.1626
DEBUG - 2021-02-02 06:47:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:47:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:47:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 06:47:41 --> Total execution time: 0.1238
DEBUG - 2021-02-02 06:47:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:47:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 06:47:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 06:47:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:47:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:47:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 06:47:48 --> Total execution time: 0.1312
DEBUG - 2021-02-02 06:47:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:47:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:47:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 06:47:51 --> Total execution time: 0.1603
DEBUG - 2021-02-02 06:47:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 06:47:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 06:47:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:47:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:47:58 --> Total execution time: 0.1331
DEBUG - 2021-02-02 06:48:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:48:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:48:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 06:48:01 --> Total execution time: 0.1659
DEBUG - 2021-02-02 06:48:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:48:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 06:48:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 06:48:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:48:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:48:10 --> Total execution time: 0.1296
DEBUG - 2021-02-02 06:48:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:48:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:48:17 --> Total execution time: 0.1561
DEBUG - 2021-02-02 06:48:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:48:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:48:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:48:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:48:26 --> Total execution time: 0.1397
DEBUG - 2021-02-02 06:48:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:48:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 06:48:29 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 06:49:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:49:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:49:35 --> Total execution time: 0.1277
DEBUG - 2021-02-02 06:49:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:49:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:49:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 06:49:38 --> Total execution time: 0.1627
DEBUG - 2021-02-02 06:49:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 06:49:41 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 06:49:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:49:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:49:54 --> Total execution time: 0.1331
DEBUG - 2021-02-02 06:49:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:49:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:49:56 --> Total execution time: 0.1097
DEBUG - 2021-02-02 06:49:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 06:49:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 06:50:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:50:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:50:25 --> Total execution time: 0.1340
DEBUG - 2021-02-02 06:50:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:50:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:50:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 06:50:28 --> Total execution time: 0.1316
DEBUG - 2021-02-02 06:50:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:50:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 06:50:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 06:50:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:50:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:50:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 06:50:36 --> Total execution time: 0.2030
DEBUG - 2021-02-02 06:50:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:50:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:50:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 06:50:38 --> Total execution time: 0.1539
DEBUG - 2021-02-02 06:50:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:50:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 06:50:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 06:50:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:50:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:50:45 --> Total execution time: 0.1465
DEBUG - 2021-02-02 06:50:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:50:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:50:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 06:50:47 --> Total execution time: 0.1171
DEBUG - 2021-02-02 06:50:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:50:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 06:50:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 06:50:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:50:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:50:57 --> Query error: Undeclared variable: undefined - Invalid query: select g.*,c.category_name from tbl_culture_master g  LEFT JOIN tbl_exercise_mode_categories c ON c.exercise_mode_category_id=g.category_id where g.is_active='1' AND g.is_delete='0' AND g.category_id='6' AND g.target_language_id='37' limit undefined,10 
ERROR - 2021-02-02 06:50:57 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 639
DEBUG - 2021-02-02 06:51:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:51:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:51:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 06:51:05 --> Total execution time: 0.1543
DEBUG - 2021-02-02 06:51:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:51:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:51:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 06:51:08 --> Total execution time: 0.1532
DEBUG - 2021-02-02 06:51:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:51:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 06:51:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 06:57:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:57:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:57:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:57:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:57:15 --> Total execution time: 0.1387
DEBUG - 2021-02-02 06:57:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:57:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:57:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:57:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:57:31 --> Total execution time: 0.1481
DEBUG - 2021-02-02 06:57:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:57:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 06:57:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 06:57:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:57:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:57:43 --> Total execution time: 0.1781
DEBUG - 2021-02-02 06:57:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:57:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 06:57:44 --> Total execution time: 0.1408
DEBUG - 2021-02-02 06:57:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:57:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:57:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 06:57:46 --> Total execution time: 0.1470
DEBUG - 2021-02-02 06:57:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 06:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 06:57:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 06:57:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 06:57:46 --> Total execution time: 0.1449
DEBUG - 2021-02-02 06:57:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 06:57:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 06:57:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:01:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:01:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:01:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 07:01:52 --> Total execution time: 0.1230
DEBUG - 2021-02-02 07:01:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:01:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 07:01:55 --> Total execution time: 0.1384
DEBUG - 2021-02-02 07:01:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:01:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:01:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 07:01:55 --> Total execution time: 0.1362
DEBUG - 2021-02-02 07:01:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:01:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:01:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 07:01:57 --> Total execution time: 0.1591
DEBUG - 2021-02-02 07:01:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:01:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:01:59 --> Query error: Undeclared variable: undefined - Invalid query: select g.*,c.category_name from tbl_culture_master g  LEFT JOIN tbl_exercise_mode_categories c ON c.exercise_mode_category_id=g.category_id where g.is_active='1' AND g.is_delete='0' AND g.category_id='6' AND g.target_language_id='37' limit undefined,10 
ERROR - 2021-02-02 07:01:59 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 639
DEBUG - 2021-02-02 07:02:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:02:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:02:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:02:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:02:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 07:02:12 --> Total execution time: 0.1554
DEBUG - 2021-02-02 07:02:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:02:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:02:15 --> Query error: Undeclared variable: undefined - Invalid query: select g.*,c.category_name from tbl_culture_master g  LEFT JOIN tbl_exercise_mode_categories c ON c.exercise_mode_category_id=g.category_id where g.is_active='1' AND g.is_delete='0' AND g.support_lang_id='2' AND g.target_language_id='37' limit undefined,10 
ERROR - 2021-02-02 07:02:15 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 639
DEBUG - 2021-02-02 07:02:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:02:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:02:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 07:02:15 --> Total execution time: 0.1566
DEBUG - 2021-02-02 07:02:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:02:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:02:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:02:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:02:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:02:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 07:02:34 --> Total execution time: 0.1351
DEBUG - 2021-02-02 07:02:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:02:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:02:36 --> Query error: Undeclared variable: undefined - Invalid query: select g.*,c.category_name from tbl_culture_master g  LEFT JOIN tbl_exercise_mode_categories c ON c.exercise_mode_category_id=g.category_id where g.is_active='1' AND g.is_delete='0' AND g.support_lang_id='3' AND g.target_language_id='37' limit undefined,10 
ERROR - 2021-02-02 07:02:36 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 639
DEBUG - 2021-02-02 07:02:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:02:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:02:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 07:02:37 --> Total execution time: 0.1475
DEBUG - 2021-02-02 07:02:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:02:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:02:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:02:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:02:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:02:46 --> Query error: Undeclared variable: undefined - Invalid query: select g.*,c.category_name from tbl_culture_master g  LEFT JOIN tbl_exercise_mode_categories c ON c.exercise_mode_category_id=g.category_id where g.is_active='1' AND g.is_delete='0' AND g.category_id='6' AND g.support_lang_id='3' AND g.target_language_id='37' limit undefined,10 
ERROR - 2021-02-02 07:02:46 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 639
DEBUG - 2021-02-02 07:02:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:02:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 07:03:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:03:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:03:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 07:03:00 --> Total execution time: 0.1630
DEBUG - 2021-02-02 07:03:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:03:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:03:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:03:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:03:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:03:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 07:03:56 --> Total execution time: 0.1687
DEBUG - 2021-02-02 07:03:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:03:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:03:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:04:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:04:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 07:04:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:04:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 07:04:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:04:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:04:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 07:04:42 --> Total execution time: 0.1924
DEBUG - 2021-02-02 07:04:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:04:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:04:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:05:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:05:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 07:05:18 --> Total execution time: 0.1459
DEBUG - 2021-02-02 07:05:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:05:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:05:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:05:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:05:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 07:05:32 --> Total execution time: 0.1300
DEBUG - 2021-02-02 07:05:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:05:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:05:59 --> Query error: Undeclared variable: undefined - Invalid query: select g.*,c.category_name from tbl_culture_master g  LEFT JOIN tbl_exercise_mode_categories c ON c.exercise_mode_category_id=g.category_id where g.is_active='1' AND g.is_delete='0' AND g.category_id='6' AND g.support_lang_id='3' AND g.target_language_id='37' limit undefined,10 
ERROR - 2021-02-02 07:05:59 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 639
DEBUG - 2021-02-02 07:06:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:06:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 07:06:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:06:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:06:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 07:06:25 --> Total execution time: 0.1617
DEBUG - 2021-02-02 07:06:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:06:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:06:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:06:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:06:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 07:06:57 --> Total execution time: 0.1376
DEBUG - 2021-02-02 07:07:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:07:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:07:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:07:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 07:07:15 --> Total execution time: 0.1278
DEBUG - 2021-02-02 07:07:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:07:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:07:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:07:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:07:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:07:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 07:07:26 --> Total execution time: 0.1156
DEBUG - 2021-02-02 07:07:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:07:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:07:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:07:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:07:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 07:07:35 --> Total execution time: 0.1385
DEBUG - 2021-02-02 07:07:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:07:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:07:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:07:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 07:07:43 --> Total execution time: 0.1533
DEBUG - 2021-02-02 07:07:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:07:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 07:07:54 --> Total execution time: 0.1122
DEBUG - 2021-02-02 07:07:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:07:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:07:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 07:07:56 --> Total execution time: 0.1119
DEBUG - 2021-02-02 07:07:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:07:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:07:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:08:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:08:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 07:08:04 --> Total execution time: 0.1287
DEBUG - 2021-02-02 07:08:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:08:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:08:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 07:08:07 --> Total execution time: 0.1595
DEBUG - 2021-02-02 07:08:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:08:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:08:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:08:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:08:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:08:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 07:08:15 --> Total execution time: 0.1541
DEBUG - 2021-02-02 07:08:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:08:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:08:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 07:08:17 --> Total execution time: 0.1621
DEBUG - 2021-02-02 07:08:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:08:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:08:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:08:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:08:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 07:08:24 --> Total execution time: 0.1636
DEBUG - 2021-02-02 07:08:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:08:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:08:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:08:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:08:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 07:08:33 --> Total execution time: 0.1155
DEBUG - 2021-02-02 07:08:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:08:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 07:08:48 --> Total execution time: 0.1617
DEBUG - 2021-02-02 07:08:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:08:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:08:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 07:08:51 --> Total execution time: 0.1479
DEBUG - 2021-02-02 07:08:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:08:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:08:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:08:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:08:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 07:08:58 --> Total execution time: 0.1390
DEBUG - 2021-02-02 07:09:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:09:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:09:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 07:09:01 --> Total execution time: 0.1753
DEBUG - 2021-02-02 07:09:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:09:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:09:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:09:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:09:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:09:07 --> Query error: Undeclared variable: undefined - Invalid query: select g.*,c.category_name from tbl_culture_master g  LEFT JOIN tbl_exercise_mode_categories c ON c.exercise_mode_category_id=g.category_id where g.is_active='1' AND g.is_delete='0' AND g.category_id='6' AND g.target_language_id='37' limit undefined,10 
ERROR - 2021-02-02 07:09:07 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 639
DEBUG - 2021-02-02 07:09:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:09:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:09:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 07:09:14 --> Total execution time: 0.1510
DEBUG - 2021-02-02 07:09:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:09:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:09:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 07:09:16 --> Total execution time: 0.1121
DEBUG - 2021-02-02 07:09:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:09:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 07:09:18 --> Total execution time: 0.1737
DEBUG - 2021-02-02 07:09:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:09:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:09:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:09:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:09:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 07:09:30 --> Total execution time: 0.1717
DEBUG - 2021-02-02 07:10:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:10:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 07:10:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:10:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:10:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 07:10:06 --> Total execution time: 0.1560
DEBUG - 2021-02-02 07:10:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:10:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:10:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 07:10:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:10:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:10:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:10:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:10:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:10:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 07:10:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:10:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 07:10:23 --> Total execution time: 0.1359
DEBUG - 2021-02-02 07:10:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:10:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:10:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:10:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 07:10:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:10:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:10:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:10:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:10:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 07:10:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:10:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 07:10:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:10:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:10:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 07:10:57 --> Total execution time: 0.1340
DEBUG - 2021-02-02 07:10:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:10:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:10:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:16:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:16:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:16:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 07:16:30 --> Total execution time: 0.1380
DEBUG - 2021-02-02 07:16:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:16:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:16:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 07:18:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:18:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 07:18:48 --> Total execution time: 0.1509
DEBUG - 2021-02-02 07:18:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 07:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 07:18:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 07:18:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 07:18:50 --> Total execution time: 0.1895
DEBUG - 2021-02-02 07:18:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 07:18:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 07:18:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 11:36:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 11:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 11:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 11:36:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 11:36:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 11:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 11:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 11:36:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 11:36:59 --> Total execution time: 0.1102
DEBUG - 2021-02-02 11:38:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 11:38:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 11:38:25 --> 404 Page Not Found: Login/index
DEBUG - 2021-02-02 11:38:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 11:38:30 --> No URI present. Default controller set.
DEBUG - 2021-02-02 11:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 11:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 11:38:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 11:38:30 --> Total execution time: 0.1609
DEBUG - 2021-02-02 11:38:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 11:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 11:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 11:38:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 11:38:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 11:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 11:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 11:38:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 11:38:43 --> Total execution time: 0.1382
DEBUG - 2021-02-02 11:38:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 11:38:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 11:38:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 11:39:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 11:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 11:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 11:39:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 11:39:14 --> Total execution time: 0.1104
DEBUG - 2021-02-02 11:39:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 11:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 11:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 11:39:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 11:39:20 --> Total execution time: 0.1196
DEBUG - 2021-02-02 11:39:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 11:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 11:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 11:39:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 11:39:28 --> Total execution time: 0.1170
DEBUG - 2021-02-02 11:40:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 11:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 11:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 11:40:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 11:40:11 --> Total execution time: 0.1502
DEBUG - 2021-02-02 11:40:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 11:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 11:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 11:40:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 11:40:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 11:40:14 --> Total execution time: 0.1328
DEBUG - 2021-02-02 11:40:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 11:40:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 11:40:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 11:56:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 11:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 11:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 11:56:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 11:56:59 --> Total execution time: 0.1993
DEBUG - 2021-02-02 12:07:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:07:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:07:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 12:07:43 --> Total execution time: 0.1730
DEBUG - 2021-02-02 12:07:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:07:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:07:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 12:07:46 --> Total execution time: 0.1553
DEBUG - 2021-02-02 12:07:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:07:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:07:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:08:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:08:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 12:08:09 --> Total execution time: 0.1574
DEBUG - 2021-02-02 12:08:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:08:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:08:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 12:08:11 --> Total execution time: 0.1377
DEBUG - 2021-02-02 12:08:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:08:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:08:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:08:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:08:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:08:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 12:08:19 --> Total execution time: 0.1396
DEBUG - 2021-02-02 12:08:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:08:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:08:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 12:08:21 --> Total execution time: 0.1519
DEBUG - 2021-02-02 12:08:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:08:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:08:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:08:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:08:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 12:09:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:09:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 12:09:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:09:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:09:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 12:09:59 --> Total execution time: 0.1346
DEBUG - 2021-02-02 12:10:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:10:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:10:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:10:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:10:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 12:10:12 --> Total execution time: 0.1325
DEBUG - 2021-02-02 12:10:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:10:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:10:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:10:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:10:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 12:10:29 --> Total execution time: 0.1515
DEBUG - 2021-02-02 12:11:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:11:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 12:11:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:11:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:11:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 12:11:13 --> Total execution time: 0.1200
DEBUG - 2021-02-02 12:11:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:11:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:11:15 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:11:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:11:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:11:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 12:11:28 --> Total execution time: 0.1665
DEBUG - 2021-02-02 12:11:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:11:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:11:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 12:11:31 --> Total execution time: 0.1501
DEBUG - 2021-02-02 12:11:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:11:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:11:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:11:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:11:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:11:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 12:11:54 --> Total execution time: 0.1437
DEBUG - 2021-02-02 12:11:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:11:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:11:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 12:11:58 --> Total execution time: 0.1889
DEBUG - 2021-02-02 12:12:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:12:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:12:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:12:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:12:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:12:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 12:12:07 --> Total execution time: 0.1339
DEBUG - 2021-02-02 12:12:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:12:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:12:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 12:12:11 --> Total execution time: 0.1418
DEBUG - 2021-02-02 12:12:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:12:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:12:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:36:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 12:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 12:36:45 --> Total execution time: 0.1751
DEBUG - 2021-02-02 12:36:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:36:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:36:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 12:36:48 --> Total execution time: 0.1871
DEBUG - 2021-02-02 12:36:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:36:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:36:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:36:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:36:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:36:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 12:36:57 --> Total execution time: 0.1704
DEBUG - 2021-02-02 12:37:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:37:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:37:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 12:37:00 --> Total execution time: 0.1713
DEBUG - 2021-02-02 12:37:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:37:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:37:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:37:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:37:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:37:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:37:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:37:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:37:12 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 12:37:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:37:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 12:37:14 --> Total execution time: 0.1299
DEBUG - 2021-02-02 12:37:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:37:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:37:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 12:37:17 --> Total execution time: 0.1515
DEBUG - 2021-02-02 12:37:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:37:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:37:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:37:24 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 12:37:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:37:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 12:37:30 --> Total execution time: 0.1262
DEBUG - 2021-02-02 12:37:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:37:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:37:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 12:37:33 --> Total execution time: 0.1565
DEBUG - 2021-02-02 12:37:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:37:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:37:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:37:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:37:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:37:42 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 12:37:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:37:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:37:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 12:37:46 --> Total execution time: 0.1450
DEBUG - 2021-02-02 12:37:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:37:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:37:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 12:37:51 --> Total execution time: 0.1452
DEBUG - 2021-02-02 12:37:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:37:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:37:54 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:37:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:37:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:37:58 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 12:41:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:41:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:41:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 12:41:00 --> Total execution time: 0.1749
DEBUG - 2021-02-02 12:41:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:41:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:41:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:41:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:41:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 12:41:11 --> Total execution time: 0.1594
DEBUG - 2021-02-02 12:41:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:41:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:41:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:41:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:41:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 12:41:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:41:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:41:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 12:41:33 --> Total execution time: 0.1551
DEBUG - 2021-02-02 12:41:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:41:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:41:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:41:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:41:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 12:41:44 --> Total execution time: 0.1695
DEBUG - 2021-02-02 12:41:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:41:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:41:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:48:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:48:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 12:49:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:49:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:49:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-02-02 12:49:15 --> Total execution time: 0.1554
DEBUG - 2021-02-02 12:49:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 12:50:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:50:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 12:50:40 --> Total execution time: 0.1360
DEBUG - 2021-02-02 12:50:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:50:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:50:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:50:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:50:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 12:50:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:50:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:50:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 12:50:59 --> Total execution time: 0.1376
DEBUG - 2021-02-02 12:51:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:51:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:51:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:51:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:51:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:51:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 12:51:10 --> Total execution time: 0.1316
DEBUG - 2021-02-02 12:51:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:51:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:51:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 12:51:13 --> Total execution time: 0.1349
DEBUG - 2021-02-02 12:51:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:51:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:51:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:54:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:54:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 12:54:15 --> Total execution time: 0.1912
DEBUG - 2021-02-02 12:54:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:54:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:54:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 12:54:18 --> Total execution time: 0.1702
DEBUG - 2021-02-02 12:54:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:54:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:55:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:55:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:55:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 12:55:09 --> Total execution time: 0.1364
DEBUG - 2021-02-02 12:55:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:55:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:55:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 12:55:11 --> Total execution time: 0.1678
DEBUG - 2021-02-02 12:55:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:55:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:55:15 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:55:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:55:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 12:55:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:55:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 12:55:27 --> Total execution time: 0.1523
DEBUG - 2021-02-02 12:55:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:55:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:55:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 12:55:30 --> Total execution time: 0.1576
DEBUG - 2021-02-02 12:55:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:55:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:55:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:55:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:55:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:55:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 12:55:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:55:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:55:39 --> Query error: Undeclared variable: undefined - Invalid query: select g.*,c.category_name from tbl_culture_master g  LEFT JOIN tbl_exercise_mode_categories c ON c.exercise_mode_category_id=g.category_id where g.is_active='1' AND g.is_delete='0' AND g.category_id='6' AND g.target_language_id='37' limit undefined,10 
ERROR - 2021-02-02 12:55:39 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 639
DEBUG - 2021-02-02 12:55:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:55:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:55:53 --> Query error: Undeclared variable: undefined - Invalid query: select g.*,c.category_name from tbl_culture_master g  LEFT JOIN tbl_exercise_mode_categories c ON c.exercise_mode_category_id=g.category_id where g.is_active='1' AND g.is_delete='0' AND g.category_id='6' AND g.target_language_id='37' limit undefined,10 
ERROR - 2021-02-02 12:55:53 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 639
DEBUG - 2021-02-02 12:56:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:56:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:56:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:56:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:56:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:56:02 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 12:56:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:56:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:56:06 --> Query error: Undeclared variable: undefined - Invalid query: select g.*,c.category_name from tbl_culture_master g  LEFT JOIN tbl_exercise_mode_categories c ON c.exercise_mode_category_id=g.category_id where g.is_active='1' AND g.is_delete='0' AND g.category_id='6' AND g.target_language_id='37' limit undefined,10 
ERROR - 2021-02-02 12:56:06 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 639
DEBUG - 2021-02-02 12:56:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:56:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 12:56:28 --> Total execution time: 0.1086
DEBUG - 2021-02-02 12:56:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:56:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:56:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 12:56:31 --> Total execution time: 0.1420
DEBUG - 2021-02-02 12:56:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:56:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:56:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:56:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:56:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:56:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 12:56:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:56:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:56:39 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 12:56:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:56:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:56:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 12:56:46 --> Total execution time: 0.1523
DEBUG - 2021-02-02 12:56:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:56:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:56:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 12:56:49 --> Total execution time: 0.1439
DEBUG - 2021-02-02 12:56:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:56:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:56:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:56:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:56:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:56:55 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 12:57:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:57:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 12:57:00 --> Total execution time: 0.1618
DEBUG - 2021-02-02 12:57:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:57:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:57:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 12:57:03 --> Total execution time: 0.1208
DEBUG - 2021-02-02 12:57:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:57:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 12:57:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:57:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:57:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 12:57:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:57:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 12:57:10 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 12:57:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 12:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 12:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 12:57:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 12:57:46 --> Query error: Undeclared variable: undefined - Invalid query: select g.*,c.category_name from tbl_culture_master g  LEFT JOIN tbl_exercise_mode_categories c ON c.exercise_mode_category_id=g.category_id where g.is_active='1' AND g.is_delete='0' AND g.category_id='6' AND g.target_language_id='37' limit undefined,10 
ERROR - 2021-02-02 12:57:46 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 639
DEBUG - 2021-02-02 13:10:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:10:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:10:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:10:13 --> Total execution time: 0.1488
DEBUG - 2021-02-02 13:10:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:10:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:10:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 13:10:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:10:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:10:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 13:10:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:10:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:10:23 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 13:10:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:10:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:10:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:10:35 --> Total execution time: 0.1507
DEBUG - 2021-02-02 13:10:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:10:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:10:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:10:38 --> Total execution time: 0.1410
DEBUG - 2021-02-02 13:10:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:10:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:10:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 13:10:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:10:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:10:43 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 13:10:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:10:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:10:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:10:50 --> Total execution time: 0.1515
DEBUG - 2021-02-02 13:10:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:10:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:10:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:10:52 --> Total execution time: 0.1461
DEBUG - 2021-02-02 13:10:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:10:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:10:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 13:10:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:10:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:10:58 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 13:11:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:11:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:11:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:11:04 --> Total execution time: 0.1382
DEBUG - 2021-02-02 13:11:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:11:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:11:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:11:08 --> Total execution time: 0.1377
DEBUG - 2021-02-02 13:11:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:11:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:11:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 13:11:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:11:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:11:14 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 13:11:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:11:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:11:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:11:20 --> Total execution time: 0.1624
DEBUG - 2021-02-02 13:11:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:11:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:11:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:11:24 --> Total execution time: 0.1575
DEBUG - 2021-02-02 13:11:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:11:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:11:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 13:11:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:11:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:11:31 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 13:13:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:13:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:13:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:13:55 --> Total execution time: 0.1623
DEBUG - 2021-02-02 13:13:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:13:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:13:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 13:14:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:14:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:14:02 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 13:14:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:14:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:14:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:14:12 --> Total execution time: 0.1566
DEBUG - 2021-02-02 13:14:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:14:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:14:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:14:16 --> Total execution time: 0.2046
DEBUG - 2021-02-02 13:14:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:14:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:14:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 13:14:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:14:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:14:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 13:14:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:14:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:14:22 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 13:17:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:17:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 13:17:29 --> Total execution time: 0.1402
DEBUG - 2021-02-02 13:17:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:17:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:17:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 13:17:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:17:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:17:35 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 13:17:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:17:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 13:17:41 --> Total execution time: 0.1549
DEBUG - 2021-02-02 13:18:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:18:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 13:18:27 --> Total execution time: 0.1471
DEBUG - 2021-02-02 13:18:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:18:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:18:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 13:18:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:18:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:18:33 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 13:18:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:18:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 13:18:50 --> Total execution time: 0.1404
DEBUG - 2021-02-02 13:18:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:18:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 13:18:55 --> Total execution time: 0.1325
DEBUG - 2021-02-02 13:19:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:19:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 13:19:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:19:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:19:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:19:30 --> Total execution time: 0.1383
DEBUG - 2021-02-02 13:19:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:19:34 --> UTF-8 Support Enabled
ERROR - 2021-02-02 13:19:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 13:19:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:19:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 13:19:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:19:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:19:38 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 13:19:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:19:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:19:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:19:47 --> Total execution time: 0.1342
DEBUG - 2021-02-02 13:19:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:19:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:19:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:19:51 --> Total execution time: 0.1328
DEBUG - 2021-02-02 13:19:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:19:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:19:54 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 13:19:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:19:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:19:54 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 13:19:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:19:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:19:58 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 13:20:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:20:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 13:20:23 --> Total execution time: 0.1348
DEBUG - 2021-02-02 13:20:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:20:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:20:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 13:20:26 --> Total execution time: 0.1343
DEBUG - 2021-02-02 13:20:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:20:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:20:29 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 13:20:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:20:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:20:33 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 13:20:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:20:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 13:20:36 --> Total execution time: 0.1544
DEBUG - 2021-02-02 13:20:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:20:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:20:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:20:38 --> Total execution time: 0.1732
DEBUG - 2021-02-02 13:20:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:20:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:20:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 13:20:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:20:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:20:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 13:20:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:20:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:20:45 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 13:20:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:20:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:20:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:20:51 --> Total execution time: 0.1448
DEBUG - 2021-02-02 13:20:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:20:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:20:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:20:53 --> Total execution time: 0.1346
DEBUG - 2021-02-02 13:20:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:20:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:20:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 13:20:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:20:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:20:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 13:21:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:21:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:21:01 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 13:22:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:22:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:22:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:22:11 --> Total execution time: 0.1460
DEBUG - 2021-02-02 13:22:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:22:15 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 13:22:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:22:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 13:22:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:22:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:22:18 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 13:22:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:22:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:22:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:22:22 --> Total execution time: 0.1764
DEBUG - 2021-02-02 13:22:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:22:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:22:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:22:25 --> Total execution time: 0.1626
DEBUG - 2021-02-02 13:22:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:22:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:22:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 13:22:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:22:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:22:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 13:22:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:22:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:22:32 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 13:22:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:22:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 13:22:44 --> Total execution time: 0.1630
DEBUG - 2021-02-02 13:22:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:22:47 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 13:22:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:22:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 13:22:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:22:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:22:50 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 13:23:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:23:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 13:23:37 --> Total execution time: 0.1561
DEBUG - 2021-02-02 13:23:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:23:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:23:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 13:23:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:23:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:23:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 13:23:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:23:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:23:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:23:51 --> Total execution time: 0.1280
DEBUG - 2021-02-02 13:23:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:23:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:23:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 13:23:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:23:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:23:53 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 13:24:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:24:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 13:24:03 --> Total execution time: 0.1337
DEBUG - 2021-02-02 13:24:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:24:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:24:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:24:06 --> Total execution time: 0.1370
DEBUG - 2021-02-02 13:24:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:24:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 13:24:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:24:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 13:24:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:24:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:24:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:24:14 --> Total execution time: 0.1340
DEBUG - 2021-02-02 13:24:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:24:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:24:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:24:20 --> Total execution time: 0.1635
DEBUG - 2021-02-02 13:24:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:24:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:24:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 13:24:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:24:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:24:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 13:24:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:24:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 13:24:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 13:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 13:24:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 13:24:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 13:24:43 --> Total execution time: 0.1240
DEBUG - 2021-02-02 13:24:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:24:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:24:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 13:24:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:24:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:24:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 13:34:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:34:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:34:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 13:34:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 13:34:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 13:34:22 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:37:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:37:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:37:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 14:37:41 --> Total execution time: 0.1549
DEBUG - 2021-02-02 14:37:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:37:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:37:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 14:37:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:37:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:37:45 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 14:37:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:37:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:37:48 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:37:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:37:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 14:38:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:38:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:38:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 14:38:02 --> Total execution time: 0.1198
DEBUG - 2021-02-02 14:38:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:38:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:38:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 14:38:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:38:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:38:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 14:38:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:38:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:38:08 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:40:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:40:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:40:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 14:40:32 --> Total execution time: 0.2095
DEBUG - 2021-02-02 14:40:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:40:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:40:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 14:40:35 --> Total execution time: 0.5590
DEBUG - 2021-02-02 14:40:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:40:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:40:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 14:40:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:40:44 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:43:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:43:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:43:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 14:43:00 --> Total execution time: 0.1421
DEBUG - 2021-02-02 14:43:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:43:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:43:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 14:43:03 --> Total execution time: 0.1590
DEBUG - 2021-02-02 14:43:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:43:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:43:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 14:43:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:43:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:43:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 14:43:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:43:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:43:08 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:43:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:43:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:43:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 14:43:15 --> Total execution time: 0.1543
DEBUG - 2021-02-02 14:43:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:43:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:43:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 14:43:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:43:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:43:24 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:43:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:43:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:43:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 14:43:32 --> Total execution time: 0.2252
DEBUG - 2021-02-02 14:43:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:43:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:43:36 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:43:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:43:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:43:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 14:43:43 --> Total execution time: 0.1681
DEBUG - 2021-02-02 14:43:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:43:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:43:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 14:43:46 --> Total execution time: 0.1912
DEBUG - 2021-02-02 14:43:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:43:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:43:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 14:43:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:43:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:43:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 14:43:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:43:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:43:53 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:44:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:44:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:44:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 14:44:01 --> Total execution time: 0.1490
DEBUG - 2021-02-02 14:44:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:44:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:44:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 14:44:04 --> Total execution time: 0.1556
DEBUG - 2021-02-02 14:44:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:44:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:44:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 14:44:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:44:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:44:10 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:44:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:44:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:44:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 14:44:15 --> Total execution time: 0.1401
DEBUG - 2021-02-02 14:44:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:44:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:44:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 14:44:18 --> Total execution time: 0.1291
DEBUG - 2021-02-02 14:44:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:44:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:44:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 14:44:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:44:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:44:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 14:44:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:44:23 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:48:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:48:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:48:52 --> 404 Page Not Found: Admin_master/edit_culture
DEBUG - 2021-02-02 14:49:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:49:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:49:10 --> Severity: error --> Exception: syntax error, unexpected ''cate' (T_ENCAPSED_AND_WHITESPACE) /home/langoalphademo/public_html/indylan/application/controllers/Admin_master.php 2366
DEBUG - 2021-02-02 14:49:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:49:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:49:14 --> Severity: error --> Exception: syntax error, unexpected end of file /home/langoalphademo/public_html/indylan/application/controllers/Admin_master.php 3534
DEBUG - 2021-02-02 14:49:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:49:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:49:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 14:49:30 --> Total execution time: 0.1492
DEBUG - 2021-02-02 14:49:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:49:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:49:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 14:49:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:49:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:49:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 14:49:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:49:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 14:49:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:49:36 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:49:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:49:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 14:49:40 --> Total execution time: 0.1507
DEBUG - 2021-02-02 14:49:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:49:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:49:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 14:49:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:49:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:49:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 14:49:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:49:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:49:47 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:54:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:54:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 14:54:53 --> Total execution time: 0.1462
DEBUG - 2021-02-02 14:54:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:54:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:54:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 14:54:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:54:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:54:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 14:55:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:55:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:55:01 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:55:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:55:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 14:55:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:55:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:55:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 14:55:12 --> Total execution time: 0.1307
DEBUG - 2021-02-02 14:55:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:55:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:55:15 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 14:55:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:55:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:55:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 14:55:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:55:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:55:18 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:56:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:56:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:56:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 14:56:02 --> Total execution time: 0.1275
DEBUG - 2021-02-02 14:56:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:56:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:56:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 14:56:07 --> Total execution time: 0.1464
DEBUG - 2021-02-02 14:56:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:56:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:56:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 14:56:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:56:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:56:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 14:56:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:56:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:56:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 14:56:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:56:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:56:13 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:56:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:56:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:56:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 14:56:16 --> Total execution time: 0.1784
DEBUG - 2021-02-02 14:56:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:56:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:56:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 14:56:18 --> Total execution time: 0.1855
DEBUG - 2021-02-02 14:56:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:56:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:56:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 14:56:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:56:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:56:24 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:56:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:56:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 14:56:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:56:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:56:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 14:56:35 --> Total execution time: 0.1691
DEBUG - 2021-02-02 14:56:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:56:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:56:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 14:56:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:56:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:56:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 14:56:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:56:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:56:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 14:56:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:56:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:56:43 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:57:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:57:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 14:57:00 --> Total execution time: 0.1551
DEBUG - 2021-02-02 14:57:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:57:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:57:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 14:57:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:57:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:57:06 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:57:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:57:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 14:57:13 --> Total execution time: 0.1553
DEBUG - 2021-02-02 14:57:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:57:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 14:57:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:57:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:57:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 14:57:53 --> Total execution time: 0.1375
DEBUG - 2021-02-02 14:57:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:57:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:57:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 14:57:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:57:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:57:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 14:58:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:58:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:58:00 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:58:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:58:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:58:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 14:58:05 --> Total execution time: 0.1323
DEBUG - 2021-02-02 14:58:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:58:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:58:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 14:58:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:58:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:58:12 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:58:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:58:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 14:58:20 --> Total execution time: 0.1565
DEBUG - 2021-02-02 14:58:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:58:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:58:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 14:58:23 --> Total execution time: 0.1385
DEBUG - 2021-02-02 14:58:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:58:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:58:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 14:58:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:58:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:58:30 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:58:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:58:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:58:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 14:58:33 --> Total execution time: 0.1860
DEBUG - 2021-02-02 14:58:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:58:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:58:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 14:58:36 --> Total execution time: 0.1924
DEBUG - 2021-02-02 14:58:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:58:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:58:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 14:58:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:58:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:58:43 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:58:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:58:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:58:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 14:58:55 --> Total execution time: 0.1413
DEBUG - 2021-02-02 14:58:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:58:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:58:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 14:58:58 --> Total execution time: 0.1408
DEBUG - 2021-02-02 14:59:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:59:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:59:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 14:59:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:59:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:59:04 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:59:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:59:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:59:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 14:59:13 --> Total execution time: 0.1505
DEBUG - 2021-02-02 14:59:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:59:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:59:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 14:59:15 --> Total execution time: 0.1416
DEBUG - 2021-02-02 14:59:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:59:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:59:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 14:59:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:59:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:59:22 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 14:59:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:59:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 14:59:24 --> Total execution time: 0.1669
DEBUG - 2021-02-02 14:59:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 14:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 14:59:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 14:59:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 14:59:27 --> Total execution time: 0.1520
DEBUG - 2021-02-02 14:59:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:59:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:59:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 14:59:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:59:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:59:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 14:59:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 14:59:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 14:59:32 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 15:01:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:01:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 15:01:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 15:01:00 --> Total execution time: 0.1353
DEBUG - 2021-02-02 15:01:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:01:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:01:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 15:01:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:01:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:01:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 15:01:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:01:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:01:06 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 15:01:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:01:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 15:01:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 15:01:09 --> Total execution time: 0.1100
DEBUG - 2021-02-02 15:01:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:01:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:01:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 15:01:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:01:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:01:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 15:01:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:01:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:01:17 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 15:01:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:01:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 15:01:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 15:01:24 --> Total execution time: 0.1811
DEBUG - 2021-02-02 15:01:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:01:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 15:01:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:01:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 15:01:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:01:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:01:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 15:01:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:01:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:01:31 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 15:01:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:01:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 15:01:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 15:01:58 --> Total execution time: 0.1503
DEBUG - 2021-02-02 15:02:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:02:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 15:02:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:02:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:02:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 15:02:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:02:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:02:04 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 15:02:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:02:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 15:02:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 15:02:29 --> Total execution time: 0.1397
DEBUG - 2021-02-02 15:02:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:02:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 15:02:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-02 15:02:33 --> Total execution time: 0.1357
DEBUG - 2021-02-02 15:02:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:02:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:02:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 15:02:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:02:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:02:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-02 15:02:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:02:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:02:38 --> 404 Page Not Found: Assets/js
DEBUG - 2021-02-02 15:02:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:02:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 15:02:48 --> Total execution time: 0.1905
DEBUG - 2021-02-02 15:02:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:02:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 15:02:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 15:02:51 --> Total execution time: 0.1384
DEBUG - 2021-02-02 15:02:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:02:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 15:04:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:04:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 15:04:12 --> Total execution time: 0.1200
DEBUG - 2021-02-02 15:04:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:04:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 15:04:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 15:04:15 --> Total execution time: 0.1526
DEBUG - 2021-02-02 15:04:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:04:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:04:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 15:04:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:04:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 15:04:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 15:04:25 --> Total execution time: 0.1551
DEBUG - 2021-02-02 15:04:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:04:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 15:04:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 15:04:29 --> Total execution time: 0.1410
DEBUG - 2021-02-02 15:04:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:04:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:04:31 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 15:04:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:04:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 15:04:41 --> Total execution time: 0.1877
DEBUG - 2021-02-02 15:04:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:04:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:04:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 15:04:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:04:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 15:04:53 --> Total execution time: 0.1367
DEBUG - 2021-02-02 15:05:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:05:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-02 15:05:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:05:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 15:05:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 15:05:20 --> Total execution time: 0.1691
DEBUG - 2021-02-02 15:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:05:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 15:05:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:05:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 15:05:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 15:05:35 --> Total execution time: 0.1425
DEBUG - 2021-02-02 15:05:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:05:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 15:05:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 15:05:38 --> Total execution time: 0.1443
DEBUG - 2021-02-02 15:05:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:05:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:05:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 15:05:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:05:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 15:05:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 15:05:49 --> Total execution time: 0.1472
DEBUG - 2021-02-02 15:05:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:05:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 15:05:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 15:05:53 --> Total execution time: 0.1375
DEBUG - 2021-02-02 15:05:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:05:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:05:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 15:06:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:06:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 15:06:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 15:06:13 --> Total execution time: 0.1450
DEBUG - 2021-02-02 15:06:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:06:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 15:06:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 15:06:16 --> Total execution time: 0.1670
DEBUG - 2021-02-02 15:06:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:06:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:06:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 15:06:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:06:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 15:06:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 15:06:26 --> Total execution time: 0.1283
DEBUG - 2021-02-02 15:06:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:06:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 15:06:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 15:06:28 --> Total execution time: 0.1243
DEBUG - 2021-02-02 15:06:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:06:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:06:31 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-02 15:06:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:06:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 15:06:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 15:06:37 --> Total execution time: 0.1656
DEBUG - 2021-02-02 15:06:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-02 15:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-02 15:06:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-02 15:06:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-02 15:06:40 --> Total execution time: 0.1590
DEBUG - 2021-02-02 15:06:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-02 15:06:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-02 15:06:43 --> 404 Page Not Found: Assets/chosen
