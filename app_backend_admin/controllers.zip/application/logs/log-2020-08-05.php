<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-08-05 05:00:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-05 05:00:08 --> No URI present. Default controller set.
DEBUG - 2020-08-05 05:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-05 05:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-05 05:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-05 05:00:09 --> Total execution time: 1.2958
DEBUG - 2020-08-05 05:00:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-05 05:00:09 --> No URI present. Default controller set.
DEBUG - 2020-08-05 05:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-05 05:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-05 05:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-05 05:00:09 --> Total execution time: 0.1662
DEBUG - 2020-08-05 05:08:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-05 05:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-05 05:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-05 05:08:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-05 05:08:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-05 05:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-05 05:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-05 05:08:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-05 05:08:48 --> Total execution time: 0.2255
DEBUG - 2020-08-05 05:08:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-05 05:08:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-05 05:08:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-05 05:08:59 --> UTF-8 Support Enabled
DEBUG - 2020-08-05 05:08:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-05 05:08:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-05 05:08:59 --> UTF-8 Support Enabled
DEBUG - 2020-08-05 05:08:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-05 05:08:59 --> 404 Page Not Found: Assets/js
DEBUG - 2020-08-05 05:27:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-05 05:27:21 --> No URI present. Default controller set.
DEBUG - 2020-08-05 05:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-05 05:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-05 05:27:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-05 05:27:21 --> Total execution time: 0.1167
