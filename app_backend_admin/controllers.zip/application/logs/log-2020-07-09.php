<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-07-09 09:34:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:34:53 --> No URI present. Default controller set.
DEBUG - 2020-07-09 09:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-09 09:35:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:35:39 --> No URI present. Default controller set.
DEBUG - 2020-07-09 09:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-09 09:38:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:38:48 --> No URI present. Default controller set.
DEBUG - 2020-07-09 09:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-09 09:38:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-09 09:38:48 --> Total execution time: 0.2216
DEBUG - 2020-07-09 09:47:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-09 09:47:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-09 09:47:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-09 09:47:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-09 09:47:40 --> Total execution time: 0.1964
DEBUG - 2020-07-09 09:47:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-09 09:47:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-09 09:47:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-09 09:47:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-09 09:47:47 --> Total execution time: 0.1769
DEBUG - 2020-07-09 09:48:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-09 09:48:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-09 09:48:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-09 09:48:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-09 09:48:09 --> Total execution time: 0.1922
DEBUG - 2020-07-09 09:48:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-09 09:48:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-09 09:48:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-09 09:48:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-09 09:48:22 --> Total execution time: 0.2695
DEBUG - 2020-07-09 09:48:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-09 09:48:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:23 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-09 09:48:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:23 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-09 09:48:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:23 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-09 09:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:48:23 --> UTF-8 Support Enabled
ERROR - 2020-07-09 09:48:23 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-09 09:48:23 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-09 09:48:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:24 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-09 09:48:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:24 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-09 09:48:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:48:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:24 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-09 09:48:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:24 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-09 09:48:24 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-09 09:48:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:48:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:24 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-09 09:48:24 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-09 09:48:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:24 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-09 09:48:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:24 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-09 09:48:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:48:24 --> UTF-8 Support Enabled
ERROR - 2020-07-09 09:48:24 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-09 09:48:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:24 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-09 09:48:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:24 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-09 09:48:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:48:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:24 --> 404 Page Not Found: Uploads/opposites.jpg
ERROR - 2020-07-09 09:48:24 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-09 09:48:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:48:24 --> UTF-8 Support Enabled
ERROR - 2020-07-09 09:48:24 --> 404 Page Not Found: Uploads/music.jpg
ERROR - 2020-07-09 09:48:24 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-09 09:48:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:24 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-09 09:48:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:24 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-09 09:48:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:48:24 --> UTF-8 Support Enabled
ERROR - 2020-07-09 09:48:24 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-09 09:48:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:24 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-09 09:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:48:24 --> UTF-8 Support Enabled
ERROR - 2020-07-09 09:48:24 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-09 09:48:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:24 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-09 09:48:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:25 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-09 09:48:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:25 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-09 09:48:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:25 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-09 09:48:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:25 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-09 09:48:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:25 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-09 09:48:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:48:26 --> UTF-8 Support Enabled
ERROR - 2020-07-09 09:48:26 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-09 09:48:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:26 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-09 09:48:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:26 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-09 09:48:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:26 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-09 09:48:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:26 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-09 09:48:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:27 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-09 09:48:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:27 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-09 09:48:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:48:27 --> UTF-8 Support Enabled
ERROR - 2020-07-09 09:48:27 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-09 09:48:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:27 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-09 09:48:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:27 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-09 09:48:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:27 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-09 09:48:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:27 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-09 09:48:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:48:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:27 --> UTF-8 Support Enabled
ERROR - 2020-07-09 09:48:27 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-09 09:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:48:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:27 --> 404 Page Not Found: Uploads/legal_terminology.jpg
ERROR - 2020-07-09 09:48:27 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-09 09:48:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:27 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-09 09:48:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:27 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-09 09:48:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:27 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-09 09:48:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:48:28 --> UTF-8 Support Enabled
ERROR - 2020-07-09 09:48:28 --> 404 Page Not Found: Uploads/numbers.png
ERROR - 2020-07-09 09:48:28 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-09 09:48:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:28 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-09 09:48:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:48:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:28 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-09 09:48:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:28 --> 404 Page Not Found: Uploads/professions.jpg
ERROR - 2020-07-09 09:48:28 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-09 09:48:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:28 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-09 09:48:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:48:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:28 --> 404 Page Not Found: Uploads/supermarket.jpg
ERROR - 2020-07-09 09:48:28 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-09 09:48:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:28 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-09 09:48:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 09:48:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:28 --> 404 Page Not Found: Uploads/travel.jpg
ERROR - 2020-07-09 09:48:28 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-09 09:48:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 09:48:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 09:48:28 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-09 10:38:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-09 10:38:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-09 10:38:18 --> Total execution time: 0.1359
DEBUG - 2020-07-09 10:38:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-09 10:38:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-09 10:38:18 --> Total execution time: 0.1909
DEBUG - 2020-07-09 10:38:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-09 10:38:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:19 --> UTF-8 Support Enabled
ERROR - 2020-07-09 10:38:19 --> 404 Page Not Found: Uploads/adverbs.jpg
DEBUG - 2020-07-09 10:38:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:19 --> 404 Page Not Found: Uploads/accessories.jpg
DEBUG - 2020-07-09 10:38:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:19 --> 404 Page Not Found: Uploads/animals_in_europe.jpg
DEBUG - 2020-07-09 10:38:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:19 --> 404 Page Not Found: Uploads/animals_with_hooves.jpg
ERROR - 2020-07-09 10:38:19 --> 404 Page Not Found: Uploads/appearance.jpg
DEBUG - 2020-07-09 10:38:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:19 --> 404 Page Not Found: Uploads/animals_in_the_world.jpg
DEBUG - 2020-07-09 10:38:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:19 --> 404 Page Not Found: Uploads/at_home.jpg
DEBUG - 2020-07-09 10:38:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:19 --> UTF-8 Support Enabled
ERROR - 2020-07-09 10:38:19 --> 404 Page Not Found: Uploads/baby_toiletries.jpg
DEBUG - 2020-07-09 10:38:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:19 --> 404 Page Not Found: Uploads/baby_clothes.jpg
DEBUG - 2020-07-09 10:38:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:19 --> 404 Page Not Found: Uploads/At__the_dentists.JPG
DEBUG - 2020-07-09 10:38:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:19 --> 404 Page Not Found: Uploads/bakery_and_pasta.jpg
DEBUG - 2020-07-09 10:38:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:19 --> 404 Page Not Found: Uploads/bathroom.jpg
DEBUG - 2020-07-09 10:38:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:19 --> UTF-8 Support Enabled
ERROR - 2020-07-09 10:38:19 --> 404 Page Not Found: Uploads/berries.jpg
DEBUG - 2020-07-09 10:38:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:19 --> 404 Page Not Found: Uploads/birds.jpg
DEBUG - 2020-07-09 10:38:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:20 --> 404 Page Not Found: Uploads/bedroom.jpg
DEBUG - 2020-07-09 10:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:20 --> 404 Page Not Found: Uploads/body_parts.jpg
DEBUG - 2020-07-09 10:38:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:20 --> 404 Page Not Found: Uploads/childrens_clothes.jpg
DEBUG - 2020-07-09 10:38:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:20 --> 404 Page Not Found: Uploads/containers_and_portions.jpg
DEBUG - 2020-07-09 10:38:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:20 --> 404 Page Not Found: Uploads/clothes.jpg
ERROR - 2020-07-09 10:38:20 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-09 10:38:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:20 --> 404 Page Not Found: Uploads/cooking_verbs.jpg
DEBUG - 2020-07-09 10:38:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:20 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-09 10:38:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:20 --> 404 Page Not Found: Uploads/dairy.jpg
DEBUG - 2020-07-09 10:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:20 --> 404 Page Not Found: Uploads/opposites_doubles.jpg
DEBUG - 2020-07-09 10:38:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:20 --> 404 Page Not Found: Uploads/drinks.jpg
DEBUG - 2020-07-09 10:38:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:20 --> 404 Page Not Found: Uploads/electronic_appliances.jpg
DEBUG - 2020-07-09 10:38:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:20 --> 404 Page Not Found: Uploads/employment.jpg
ERROR - 2020-07-09 10:38:20 --> 404 Page Not Found: Uploads/everyday_life.jpg
DEBUG - 2020-07-09 10:38:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:20 --> UTF-8 Support Enabled
ERROR - 2020-07-09 10:38:20 --> 404 Page Not Found: Uploads/equipment.jpg
DEBUG - 2020-07-09 10:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:20 --> 404 Page Not Found: Uploads/face_and_head.jpg
ERROR - 2020-07-09 10:38:20 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-09 10:38:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:20 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-09 10:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:21 --> 404 Page Not Found: Uploads/generic.jpg
DEBUG - 2020-07-09 10:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:21 --> UTF-8 Support Enabled
ERROR - 2020-07-09 10:38:21 --> 404 Page Not Found: Uploads/furniture.jpg
DEBUG - 2020-07-09 10:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:21 --> UTF-8 Support Enabled
ERROR - 2020-07-09 10:38:21 --> 404 Page Not Found: Uploads/fruits.jpg
DEBUG - 2020-07-09 10:38:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:21 --> 404 Page Not Found: Uploads/fixtures.jpg
DEBUG - 2020-07-09 10:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:21 --> 404 Page Not Found: Uploads/fish_and_seafood.jpg
DEBUG - 2020-07-09 10:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:21 --> UTF-8 Support Enabled
ERROR - 2020-07-09 10:38:21 --> 404 Page Not Found: Uploads/in_the_kitchen.jpg
ERROR - 2020-07-09 10:38:21 --> 404 Page Not Found: Uploads/ground_and_air.jpg
DEBUG - 2020-07-09 10:38:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:21 --> 404 Page Not Found: Uploads/grains_and_cereals.jpg
DEBUG - 2020-07-09 10:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:21 --> 404 Page Not Found: Uploads/illnesses.jpg
DEBUG - 2020-07-09 10:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:21 --> 404 Page Not Found: Uploads/herbs_and_spices.jpg
ERROR - 2020-07-09 10:38:21 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-09 10:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:21 --> 404 Page Not Found: Uploads/items_at_home.jpg
DEBUG - 2020-07-09 10:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:21 --> UTF-8 Support Enabled
ERROR - 2020-07-09 10:38:21 --> 404 Page Not Found: Uploads/insects.jpg
DEBUG - 2020-07-09 10:38:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:21 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-09 10:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:21 --> 404 Page Not Found: Uploads/laundry_and_cleaning.jpg
DEBUG - 2020-07-09 10:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:21 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-09 10:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:21 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-09 10:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:21 --> 404 Page Not Found: Uploads/materials_and_patterns.jpg
DEBUG - 2020-07-09 10:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:21 --> 404 Page Not Found: Uploads/medical_symptoms.jpg
ERROR - 2020-07-09 10:38:21 --> 404 Page Not Found: Uploads/meat.jpg
DEBUG - 2020-07-09 10:38:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:21 --> 404 Page Not Found: Uploads/medical_equipment.jpg
DEBUG - 2020-07-09 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:22 --> 404 Page Not Found: Uploads/medical_terms.jpg
ERROR - 2020-07-09 10:38:22 --> 404 Page Not Found: Uploads/medication.jpg
DEBUG - 2020-07-09 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:22 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-09 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:22 --> UTF-8 Support Enabled
ERROR - 2020-07-09 10:38:22 --> 404 Page Not Found: Uploads/nationalities.jpg
DEBUG - 2020-07-09 10:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:22 --> 404 Page Not Found: Uploads/Mushrooms.jpg
DEBUG - 2020-07-09 10:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:22 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-09 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:22 --> 404 Page Not Found: Uploads/nuts_and_dried_fruit.jpg
DEBUG - 2020-07-09 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:22 --> 404 Page Not Found: Uploads/numbers_cardinals.png
DEBUG - 2020-07-09 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:22 --> 404 Page Not Found: Uploads/numbers_ordinals.png
DEBUG - 2020-07-09 10:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:22 --> 404 Page Not Found: Uploads/Ready_meals.JPG
ERROR - 2020-07-09 10:38:22 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-09 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:22 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-09 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:22 --> 404 Page Not Found: Uploads/rooms.jpg
ERROR - 2020-07-09 10:38:22 --> 404 Page Not Found: Uploads/reptiles_and_amphibians.jpg
DEBUG - 2020-07-09 10:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:22 --> 404 Page Not Found: Uploads/Sauces_and_condiments.jpg
DEBUG - 2020-07-09 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:22 --> 404 Page Not Found: Uploads/scotland.jpg
ERROR - 2020-07-09 10:38:22 --> 404 Page Not Found: Uploads/sea_animals_and_fish.jpg
DEBUG - 2020-07-09 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:22 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-09 10:38:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:23 --> 404 Page Not Found: Uploads/sport_terms.png
DEBUG - 2020-07-09 10:38:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:23 --> UTF-8 Support Enabled
ERROR - 2020-07-09 10:38:23 --> 404 Page Not Found: Uploads/Snacks_and_sweets.JPG
DEBUG - 2020-07-09 10:38:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:23 --> 404 Page Not Found: Uploads/shoes_and_trousers.jpg
ERROR - 2020-07-09 10:38:23 --> 404 Page Not Found: Uploads/tools_and_diy.jpg
ERROR - 2020-07-09 10:38:23 --> 404 Page Not Found: Uploads/Toiletries.jpg
DEBUG - 2020-07-09 10:38:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:23 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-09 10:38:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:23 --> 404 Page Not Found: Uploads/types_of_sports.jpg
ERROR - 2020-07-09 10:38:23 --> 404 Page Not Found: Uploads/Vegetables.JPG
DEBUG - 2020-07-09 10:38:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:23 --> 404 Page Not Found: Uploads/toys_and_games.jpg
ERROR - 2020-07-09 10:38:23 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-09 10:38:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:23 --> 404 Page Not Found: Uploads/1_verbs.png
DEBUG - 2020-07-09 10:38:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:23 --> 404 Page Not Found: Uploads/water.jpg
ERROR - 2020-07-09 10:38:23 --> 404 Page Not Found: Uploads/2_verbs.png
ERROR - 2020-07-09 10:38:23 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-09 10:38:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:23 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-09 10:38:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-09 10:38:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-09 10:38:29 --> Total execution time: 0.1623
DEBUG - 2020-07-09 10:38:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-09 10:38:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-09 10:38:29 --> Total execution time: 0.6056
DEBUG - 2020-07-09 10:38:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-09 10:38:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:30 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-09 10:38:30 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-09 10:38:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:30 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-09 10:38:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:30 --> UTF-8 Support Enabled
ERROR - 2020-07-09 10:38:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:31 --> UTF-8 Support Enabled
ERROR - 2020-07-09 10:38:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:31 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-09 10:38:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:31 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-09 10:38:31 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-09 10:38:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:32 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-09 10:38:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:32 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-09 10:38:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:32 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-09 10:38:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:32 --> UTF-8 Support Enabled
ERROR - 2020-07-09 10:38:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:32 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-09 10:38:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:32 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-09 10:38:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:33 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-09 10:38:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:33 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-09 10:38:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:33 --> UTF-8 Support Enabled
ERROR - 2020-07-09 10:38:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-09 10:38:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:33 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-09 10:38:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-09 10:38:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-09 10:38:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-09 10:38:33 --> 404 Page Not Found: Uploads/words
