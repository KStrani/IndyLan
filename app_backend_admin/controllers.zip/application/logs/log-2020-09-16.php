<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-09-16 09:38:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:38:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:38:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:38:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:38:40 --> Total execution time: 0.1552
DEBUG - 2020-09-16 09:39:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:39:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:39:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:39:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:39:04 --> Total execution time: 0.1215
DEBUG - 2020-09-16 09:39:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:39:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:39:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 09:39:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:39:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:39:08 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 09:39:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:39:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:39:10 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-09-16 09:39:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:39:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:39:13 --> Total execution time: 0.1638
DEBUG - 2020-09-16 09:39:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:39:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 09:39:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 09:39:16 --> Total execution time: 0.2026
DEBUG - 2020-09-16 09:39:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:39:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:39:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 09:39:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:39:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:39:24 --> Total execution time: 0.1744
DEBUG - 2020-09-16 09:39:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:39:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:39:28 --> Total execution time: 0.1026
DEBUG - 2020-09-16 09:39:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:39:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:39:37 --> Total execution time: 0.1596
DEBUG - 2020-09-16 09:39:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:39:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:39:46 --> Total execution time: 0.1097
DEBUG - 2020-09-16 09:39:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:39:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:39:47 --> Total execution time: 0.1165
DEBUG - 2020-09-16 09:40:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:40:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:40:47 --> Total execution time: 0.1646
DEBUG - 2020-09-16 09:40:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:40:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 09:40:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-16 09:40:50 --> Total execution time: 0.2242
DEBUG - 2020-09-16 09:40:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:40:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:40:54 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 09:40:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:40:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:40:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:40:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:40:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:40:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:40:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:40:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:40:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:40:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:40:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:40:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:40:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:40:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:40:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:40:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:40:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:40:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:40:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:40:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:40:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:40:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:40:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:40:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:40:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:40:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:40:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:40:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:40:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:40:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:40:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:40:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:40:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:41:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:02 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 09:41:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:41:05 --> UTF-8 Support Enabled
ERROR - 2020-09-16 09:41:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:41:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:41:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:41:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:43:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:43:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:43:25 --> Total execution time: 0.1656
DEBUG - 2020-09-16 09:43:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:43:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:43:29 --> Total execution time: 0.1553
DEBUG - 2020-09-16 09:43:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:43:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:43:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 09:45:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:45:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:45:34 --> Total execution time: 0.0983
DEBUG - 2020-09-16 09:45:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:45:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:45:45 --> Total execution time: 0.1450
DEBUG - 2020-09-16 09:45:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:45:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:45:51 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2020-09-16 09:45:51 --> Total execution time: 0.1019
DEBUG - 2020-09-16 09:45:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:45:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:45:55 --> get_subcategory_list->{"lang":"37","category_id":"67","user_id":"1","support_lang_id":"1"}
DEBUG - 2020-09-16 09:45:55 --> Total execution time: 0.1133
DEBUG - 2020-09-16 09:45:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:45:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:45:59 --> get_exercise_type_list->{"lang":"37","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2020-09-16 09:45:59 --> Total execution time: 0.1422
DEBUG - 2020-09-16 09:46:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:46:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:46:04 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"1","exercise_mode_id":"1","category_id":"67","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2020-09-16 09:46:04 --> Total execution time: 0.2002
DEBUG - 2020-09-16 09:46:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:46:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:46:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:46:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:46:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:46:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:46:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:46:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:46:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:46:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:46:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:46:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:46:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:46:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:46:12 --> get_exercise_type_list->{"lang":"37","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2020-09-16 09:46:12 --> Total execution time: 0.1101
DEBUG - 2020-09-16 09:50:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:50:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:50:37 --> Total execution time: 0.1384
DEBUG - 2020-09-16 09:50:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:50:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:50:42 --> Total execution time: 0.1179
DEBUG - 2020-09-16 09:50:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:50:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:50:55 --> Total execution time: 0.1277
DEBUG - 2020-09-16 09:51:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:51:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:51:01 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-09-16 09:51:01 --> Total execution time: 0.1515
DEBUG - 2020-09-16 09:51:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:51:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:51:05 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 09:51:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:51:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:51:06 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 09:51:06 --> Total execution time: 0.1225
DEBUG - 2020-09-16 09:51:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:51:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:51:09 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 09:51:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:51:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:51:10 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-09-16 09:51:10 --> Total execution time: 0.1211
DEBUG - 2020-09-16 09:51:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:51:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:51:16 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
ERROR - 2020-09-16 09:51:16 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 09:51:16 --> Total execution time: 0.1209
DEBUG - 2020-09-16 09:51:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:51:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:51:22 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 09:51:22 --> Total execution time: 0.1091
DEBUG - 2020-09-16 09:51:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:51:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:51:24 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 09:51:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:51:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:51:28 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 09:51:28 --> Total execution time: 0.1662
DEBUG - 2020-09-16 09:51:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:51:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:51:32 --> get_subcategory_list->{"lang":"37","category_id":"89","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 09:51:32 --> Total execution time: 0.1584
DEBUG - 2020-09-16 09:51:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:51:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:51:35 --> get_exercise_type_list->{"lang":"37","subcategory_id":"97","support_lang_id":"3"}
DEBUG - 2020-09-16 09:51:35 --> Total execution time: 0.1425
DEBUG - 2020-09-16 09:51:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:51:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:51:39 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"89","subcategory_id":"97","support_lang_id":"3"}
ERROR - 2020-09-16 09:51:39 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 09:51:39 --> Total execution time: 0.1277
DEBUG - 2020-09-16 09:56:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:56:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:56:18 --> Total execution time: 0.1238
DEBUG - 2020-09-16 09:56:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:56:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 09:56:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-16 09:56:26 --> Total execution time: 0.2706
DEBUG - 2020-09-16 09:56:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:56:30 --> UTF-8 Support Enabled
ERROR - 2020-09-16 09:56:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 09:56:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:56:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:36 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 09:56:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:56:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:36 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 09:56:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:56:39 --> UTF-8 Support Enabled
ERROR - 2020-09-16 09:56:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:56:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:56:39 --> UTF-8 Support Enabled
ERROR - 2020-09-16 09:56:39 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 09:56:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:56:41 --> UTF-8 Support Enabled
ERROR - 2020-09-16 09:56:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:56:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:41 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 09:56:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:44 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:44 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:56:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:45 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 09:56:45 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:45 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:45 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:56:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:56:47 --> Total execution time: 0.2686
DEBUG - 2020-09-16 09:56:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:56:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 09:56:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-16 09:56:50 --> Total execution time: 0.2216
DEBUG - 2020-09-16 09:56:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:53 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 09:56:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:56:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:56:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:56:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:57:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:57:03 --> Total execution time: 0.2614
DEBUG - 2020-09-16 09:57:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:57:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 09:57:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-16 09:57:06 --> Total execution time: 0.2480
DEBUG - 2020-09-16 09:57:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:57:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:57:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:09 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 09:57:09 --> 404 Page Not Found: Assets/chosen
ERROR - 2020-09-16 09:57:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:57:09 --> UTF-8 Support Enabled
ERROR - 2020-09-16 09:57:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:57:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:57:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:12 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 09:57:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:12 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 09:57:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:57:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:17 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 09:57:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:57:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:57:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:22 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 09:57:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-16 09:57:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:22 --> Total execution time: 0.2384
DEBUG - 2020-09-16 09:57:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:57:25 --> UTF-8 Support Enabled
ERROR - 2020-09-16 09:57:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:25 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 09:57:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:57:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 09:57:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-16 09:57:26 --> Total execution time: 0.3781
DEBUG - 2020-09-16 09:57:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:57:29 --> UTF-8 Support Enabled
ERROR - 2020-09-16 09:57:29 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 09:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:29 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 09:57:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:57:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:34 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 09:57:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:57:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:40 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 09:57:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:57:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:57:43 --> Total execution time: 0.9259
DEBUG - 2020-09-16 09:57:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:57:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 09:57:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-16 09:57:46 --> Total execution time: 0.4062
DEBUG - 2020-09-16 09:57:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 09:57:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:57:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:49 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 09:57:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:53 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:53 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:57:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:57:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:57:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:58:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:00 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 09:58:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:58:03 --> UTF-8 Support Enabled
ERROR - 2020-09-16 09:58:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:58:03 --> UTF-8 Support Enabled
ERROR - 2020-09-16 09:58:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:58:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:58:06 --> Total execution time: 1.1469
DEBUG - 2020-09-16 09:58:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:58:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 09:58:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-16 09:58:09 --> Total execution time: 0.3300
DEBUG - 2020-09-16 09:58:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:58:14 --> UTF-8 Support Enabled
ERROR - 2020-09-16 09:58:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 09:58:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:58:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:21 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 09:58:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:23 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:58:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:23 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 09:58:23 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:23 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:58:26 --> UTF-8 Support Enabled
ERROR - 2020-09-16 09:58:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:58:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:58:40 --> Total execution time: 1.2257
DEBUG - 2020-09-16 09:58:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:58:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 09:58:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-16 09:58:43 --> Total execution time: 0.2171
DEBUG - 2020-09-16 09:58:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:47 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 09:58:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:58:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:49 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 09:58:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:53 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:58:53 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:58:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:58:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:58:55 --> Total execution time: 0.1486
DEBUG - 2020-09-16 09:58:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:58:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 09:58:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-16 09:58:58 --> Total execution time: 0.2832
DEBUG - 2020-09-16 09:59:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:59:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 09:59:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-16 09:59:02 --> Total execution time: 0.2499
DEBUG - 2020-09-16 09:59:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:59:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:59:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 09:59:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:59:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:59:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:59:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:59:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:59:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:59:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:59:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:59:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:59:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:59:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:59:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:59:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:59:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:59:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:59:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:59:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:59:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:59:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:59:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:59:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:59:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:59:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:59:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:59:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:59:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:59:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:59:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:59:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:59:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:59:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:59:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:59:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:59:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:59:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:59:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:59:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:59:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:59:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:59:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:59:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:59:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:59:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:59:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:59:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:59:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:59:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:59:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:59:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:59:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:59:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 09:59:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:59:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:59:19 --> Total execution time: 0.7189
DEBUG - 2020-09-16 09:59:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 09:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 09:59:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 09:59:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-16 09:59:22 --> Total execution time: 0.1829
DEBUG - 2020-09-16 09:59:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 09:59:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 09:59:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:00:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:00:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:00:08 --> Total execution time: 0.1418
DEBUG - 2020-09-16 10:00:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:00:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:00:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-16 10:00:10 --> Total execution time: 0.1854
DEBUG - 2020-09-16 10:00:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:00:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:00:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-16 10:00:11 --> Total execution time: 0.1339
DEBUG - 2020-09-16 10:00:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:00:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:00:15 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:00:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:00:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:00:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-16 10:00:26 --> Total execution time: 0.2045
DEBUG - 2020-09-16 10:00:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:00:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:00:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:00:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-16 10:00:29 --> Total execution time: 0.1943
DEBUG - 2020-09-16 10:00:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:00:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:00:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:00:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:00:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:00:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:00:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:00:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-16 10:00:52 --> Total execution time: 0.1527
DEBUG - 2020-09-16 10:00:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:00:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:00:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:00:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:00:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:00:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:00:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:00:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:00:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:00:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:00:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:00:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:00:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:00:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:00:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:00:55 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 10:00:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:00:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:00:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:00:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:00:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:00:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:00:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:00:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:00:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:00:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:00:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:00:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:00:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:00:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:00:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:00:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:00:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:00:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:00:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:01:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:01:02 --> get_subcategory_list->{"lang":"37","category_id":"89","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:01:02 --> Total execution time: 0.1294
DEBUG - 2020-09-16 10:01:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:01:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:02 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 10:01:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:01:21 --> UTF-8 Support Enabled
ERROR - 2020-09-16 10:01:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:01:25 --> UTF-8 Support Enabled
ERROR - 2020-09-16 10:01:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:01:28 --> UTF-8 Support Enabled
ERROR - 2020-09-16 10:01:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:01:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:01:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:01:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:01:40 --> Total execution time: 0.1304
DEBUG - 2020-09-16 10:01:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:01:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:01:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:01:44 --> Total execution time: 0.1256
DEBUG - 2020-09-16 10:02:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:02:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:02:29 --> Total execution time: 0.1103
DEBUG - 2020-09-16 10:02:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:02:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:02:38 --> Total execution time: 0.1448
DEBUG - 2020-09-16 10:02:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:02:45 --> Total execution time: 0.1608
DEBUG - 2020-09-16 10:02:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:02:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:02:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:02:50 --> Total execution time: 0.1451
DEBUG - 2020-09-16 10:02:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:02:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:03:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:03:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:03:02 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-09-16 10:03:02 --> Total execution time: 0.1181
DEBUG - 2020-09-16 10:03:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:03:04 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 10:03:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:03:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:03:08 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:03:08 --> Total execution time: 0.1395
DEBUG - 2020-09-16 10:03:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:03:11 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 10:03:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:03:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:03:15 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-09-16 10:03:15 --> Total execution time: 0.0989
DEBUG - 2020-09-16 10:03:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:03:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:03:20 --> Total execution time: 0.1516
DEBUG - 2020-09-16 10:03:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:03:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:03:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:03:22 --> Total execution time: 0.1651
DEBUG - 2020-09-16 10:03:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:03:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:03:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:03:24 --> Total execution time: 0.1688
DEBUG - 2020-09-16 10:03:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:03:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:03:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:03:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:03:32 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:03:32 --> Total execution time: 0.1176
DEBUG - 2020-09-16 10:03:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:03:35 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 10:03:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:03:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:03:35 --> Total execution time: 0.1571
DEBUG - 2020-09-16 10:03:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:03:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:03:37 --> get_subcategory_list->{"lang":"37","category_id":"82","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:03:37 --> Total execution time: 0.1300
DEBUG - 2020-09-16 10:03:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:03:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:03:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 10:03:39 --> Total execution time: 0.1786
DEBUG - 2020-09-16 10:03:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:03:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:03:41 --> get_exercise_type_list->{"lang":"37","subcategory_id":"82","support_lang_id":"3"}
DEBUG - 2020-09-16 10:03:41 --> Total execution time: 0.1029
DEBUG - 2020-09-16 10:03:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:03:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:03:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:03:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:03:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:03:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:03:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:03:42 --> UTF-8 Support Enabled
ERROR - 2020-09-16 10:03:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:03:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:03:42 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 10:03:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:03:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:03:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:03:45 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"82","subcategory_id":"82","support_lang_id":"3"}
ERROR - 2020-09-16 10:03:45 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 10:03:45 --> Total execution time: 0.1270
DEBUG - 2020-09-16 10:03:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:03:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:03:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:03:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:03:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:03:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:03:49 --> get_subcategory_list->{"lang":"37","category_id":"82","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:03:49 --> Total execution time: 0.1442
DEBUG - 2020-09-16 10:03:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:03:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:03:56 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:03:56 --> Total execution time: 0.1219
DEBUG - 2020-09-16 10:04:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:04:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:04:01 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 10:04:01 --> Total execution time: 0.1212
DEBUG - 2020-09-16 10:04:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:04:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:04:05 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
ERROR - 2020-09-16 10:04:05 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 10:04:05 --> Total execution time: 0.1346
DEBUG - 2020-09-16 10:04:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:04:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:04:08 --> Total execution time: 0.1459
DEBUG - 2020-09-16 10:04:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:04:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:04:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2020-09-16 10:04:11 --> Total execution time: 0.1875
DEBUG - 2020-09-16 10:04:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:04:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:04:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:04:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:04:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:04:37 --> Total execution time: 0.1822
DEBUG - 2020-09-16 10:04:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:04:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:04:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2020-09-16 10:04:38 --> Total execution time: 0.1784
DEBUG - 2020-09-16 10:04:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:04:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:04:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2020-09-16 10:04:40 --> Total execution time: 0.2024
DEBUG - 2020-09-16 10:04:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:04:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:04:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:04:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:04:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:04:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2020-09-16 10:04:50 --> Total execution time: 0.1433
DEBUG - 2020-09-16 10:05:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:05:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:05:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:05:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:05:04 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
ERROR - 2020-09-16 10:05:04 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 10:05:04 --> Total execution time: 0.1281
DEBUG - 2020-09-16 10:05:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:05:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:05:04 --> Total execution time: 0.1597
DEBUG - 2020-09-16 10:05:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:05:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:05:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:05:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:05:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:05:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:05:08 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 10:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:05:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:05:08 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:05:08 --> Total execution time: 0.1288
DEBUG - 2020-09-16 10:05:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:05:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:05:12 --> 404 Page Not Found: Uploads/At__the_dentists.JPG
DEBUG - 2020-09-16 10:05:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:05:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:05:15 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 10:05:15 --> Total execution time: 0.1202
DEBUG - 2020-09-16 10:05:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:05:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:05:20 --> get_subcategory_list->{"lang":"37","category_id":"89","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:05:20 --> Total execution time: 0.1589
DEBUG - 2020-09-16 10:05:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:05:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:05:28 --> get_exercise_type_list->{"lang":"37","subcategory_id":"97","support_lang_id":"3"}
DEBUG - 2020-09-16 10:05:28 --> Total execution time: 0.1623
DEBUG - 2020-09-16 10:05:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:05:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:05:30 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-09-16 10:05:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:05:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:05:34 --> Total execution time: 0.1778
DEBUG - 2020-09-16 10:05:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:05:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:05:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2020-09-16 10:05:42 --> Total execution time: 0.1396
DEBUG - 2020-09-16 10:05:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:05:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:05:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:06:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:06:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:06:10 --> Total execution time: 0.1439
DEBUG - 2020-09-16 10:06:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:06:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:06:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 10:06:13 --> Total execution time: 0.1656
DEBUG - 2020-09-16 10:06:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:06:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:06:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:06:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:06:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:06:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:06:17 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 10:06:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:06:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:06:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:06:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:06:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:06:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:06:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:06:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:06:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:06:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:06:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:06:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:06:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:06:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:06:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:06:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:06:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:06:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:06:25 --> Total execution time: 0.1463
DEBUG - 2020-09-16 10:06:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:06:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:06:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 10:06:28 --> Total execution time: 0.1453
DEBUG - 2020-09-16 10:06:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:06:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:06:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:06:32 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 10:06:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:06:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:06:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:06:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 10:06:38 --> Total execution time: 0.1625
DEBUG - 2020-09-16 10:06:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:06:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:06:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 10:06:41 --> Total execution time: 0.1611
DEBUG - 2020-09-16 10:06:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:06:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:06:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:06:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:06:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:06:44 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:07:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:07:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:07:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 10:07:22 --> Total execution time: 0.1996
DEBUG - 2020-09-16 10:07:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:07:25 --> UTF-8 Support Enabled
ERROR - 2020-09-16 10:07:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:07:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:07:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:07:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:07:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:07:51 --> Total execution time: 0.2025
DEBUG - 2020-09-16 10:07:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:07:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:07:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 10:07:53 --> Total execution time: 0.1225
DEBUG - 2020-09-16 10:07:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:07:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:07:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:07:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:07:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:07:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:07:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:07:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:07:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:08:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:08:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:08:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 10:08:04 --> Total execution time: 0.1595
DEBUG - 2020-09-16 10:08:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:08:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:08:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 10:08:07 --> Total execution time: 0.2045
DEBUG - 2020-09-16 10:08:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:08:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:08:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:08:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:08:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:09:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:09:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:09:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 10:09:33 --> Total execution time: 0.1607
DEBUG - 2020-09-16 10:09:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:09:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:09:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:09:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:09:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:09:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:10:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:10:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:10:26 --> Total execution time: 0.1543
DEBUG - 2020-09-16 10:10:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:10:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:10:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 10:10:29 --> Total execution time: 0.2042
DEBUG - 2020-09-16 10:10:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:10:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:10:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:10:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:10:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:10:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:10:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:10:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:10:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 10:10:40 --> Total execution time: 0.1813
DEBUG - 2020-09-16 10:10:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:10:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:10:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 10:10:42 --> Total execution time: 0.1569
DEBUG - 2020-09-16 10:10:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:10:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:10:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:10:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:10:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:10:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:11:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:11:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:11:10 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"89","subcategory_id":"97","support_lang_id":"3"}
ERROR - 2020-09-16 10:11:10 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 10:11:10 --> Total execution time: 0.1126
DEBUG - 2020-09-16 10:11:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:11:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:11:16 --> get_subcategory_list->{"lang":"37","category_id":"89","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:11:16 --> Total execution time: 0.1358
DEBUG - 2020-09-16 10:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:11:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:11:21 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-09-16 10:11:21 --> Total execution time: 0.1350
DEBUG - 2020-09-16 10:11:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:11:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:11:24 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 10:11:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:11:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:11:26 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:11:26 --> Total execution time: 0.1631
DEBUG - 2020-09-16 10:11:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:11:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:11:26 --> Total execution time: 0.1236
DEBUG - 2020-09-16 10:11:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:11:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:11:27 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 10:11:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:11:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:11:29 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-09-16 10:11:29 --> Total execution time: 0.1312
DEBUG - 2020-09-16 10:11:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:11:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:11:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2020-09-16 10:11:30 --> Total execution time: 0.2398
DEBUG - 2020-09-16 10:11:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:11:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:11:32 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
ERROR - 2020-09-16 10:11:32 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 10:11:32 --> Total execution time: 0.1205
DEBUG - 2020-09-16 10:11:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:11:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:11:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:11:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:11:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:11:36 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:11:36 --> Total execution time: 0.1347
DEBUG - 2020-09-16 10:11:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:11:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:11:40 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 10:12:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:12:14 --> get_subcategory_list->{"lang":"37","category_id":"82","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:12:14 --> Total execution time: 0.1262
DEBUG - 2020-09-16 10:12:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:12:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:12:18 --> get_exercise_type_list->{"lang":"37","subcategory_id":"82","support_lang_id":"3"}
DEBUG - 2020-09-16 10:12:18 --> Total execution time: 0.1072
DEBUG - 2020-09-16 10:12:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:12:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:12:22 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"82","subcategory_id":"82","support_lang_id":"3"}
ERROR - 2020-09-16 10:12:22 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 10:12:22 --> Total execution time: 0.1335
DEBUG - 2020-09-16 10:12:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:12:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:12:28 --> get_subcategory_list->{"lang":"37","category_id":"82","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:12:28 --> Total execution time: 0.1366
DEBUG - 2020-09-16 10:12:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:12:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:12:32 --> Total execution time: 0.1394
DEBUG - 2020-09-16 10:12:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:12:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:12:33 --> get_subcategory_list->{"lang":"37","category_id":"83","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:12:33 --> Total execution time: 0.1316
DEBUG - 2020-09-16 10:12:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:12:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:12:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 10:12:35 --> Total execution time: 0.1568
DEBUG - 2020-09-16 10:12:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:12:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:12:37 --> get_exercise_type_list->{"lang":"37","subcategory_id":"84","support_lang_id":"3"}
DEBUG - 2020-09-16 10:12:37 --> Total execution time: 0.1124
DEBUG - 2020-09-16 10:12:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:12:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:12:38 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:12:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:12:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:12:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:12:38 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 10:12:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:12:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:12:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:12:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:12:38 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:12:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:12:38 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:12:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:12:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:12:38 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:12:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:12:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:12:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:12:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:12:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:12:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:12:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:12:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:12:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:12:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:12:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:12:41 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"83","subcategory_id":"84","support_lang_id":"3"}
ERROR - 2020-09-16 10:12:41 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 10:12:41 --> Total execution time: 0.1262
DEBUG - 2020-09-16 10:12:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:12:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:12:46 --> get_subcategory_list->{"lang":"37","category_id":"83","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:12:46 --> Total execution time: 0.1459
DEBUG - 2020-09-16 10:12:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:12:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:12:54 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:12:54 --> Total execution time: 0.1198
DEBUG - 2020-09-16 10:13:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:13:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:13:04 --> Total execution time: 0.1816
DEBUG - 2020-09-16 10:13:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:13:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:13:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:13:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:13:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:13:16 --> Total execution time: 0.1292
DEBUG - 2020-09-16 10:13:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:13:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:13:44 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-09-16 10:13:44 --> Total execution time: 0.1151
DEBUG - 2020-09-16 10:13:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:13:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:13:47 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 10:13:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:13:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:13:47 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:13:47 --> Total execution time: 0.1124
DEBUG - 2020-09-16 10:13:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:13:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:13:50 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 10:13:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:13:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:13:51 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-09-16 10:13:51 --> Total execution time: 0.1510
DEBUG - 2020-09-16 10:13:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:13:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:13:54 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
ERROR - 2020-09-16 10:13:54 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 10:13:54 --> Total execution time: 0.1361
DEBUG - 2020-09-16 10:13:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:13:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:13:59 --> Total execution time: 0.1502
DEBUG - 2020-09-16 10:14:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:14:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:14:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2020-09-16 10:14:02 --> Total execution time: 0.1694
DEBUG - 2020-09-16 10:14:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:14:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:14:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:14:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:14:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:14:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/langoalphademo/public_html/indylan/application/views/admin/add_phrases.php 41
DEBUG - 2020-09-16 10:14:12 --> Total execution time: 0.1218
DEBUG - 2020-09-16 10:14:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:14:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:14:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:14:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:14:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:14:23 --> Total execution time: 0.1739
DEBUG - 2020-09-16 10:14:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:14:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:14:30 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:14:30 --> Total execution time: 0.1562
DEBUG - 2020-09-16 10:14:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:14:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:14:33 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 10:14:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:14:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:14:36 --> get_subcategory_list->{"lang":"37","category_id":"84","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:14:36 --> Total execution time: 0.1448
DEBUG - 2020-09-16 10:14:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:14:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:14:46 --> get_exercise_type_list->{"lang":"37","subcategory_id":"85","support_lang_id":"3"}
DEBUG - 2020-09-16 10:14:46 --> Total execution time: 0.1450
DEBUG - 2020-09-16 10:14:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:14:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:14:50 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"84","subcategory_id":"85","support_lang_id":"3"}
ERROR - 2020-09-16 10:14:50 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 10:14:50 --> Total execution time: 0.1648
DEBUG - 2020-09-16 10:15:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:15:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:15:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:15:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:15:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2020-09-16 10:15:07 --> Total execution time: 0.1609
DEBUG - 2020-09-16 10:15:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:15:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:15:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:15:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:15:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:15:45 --> Total execution time: 0.1467
DEBUG - 2020-09-16 10:15:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:15:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:15:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:15:48 --> Total execution time: 0.1309
DEBUG - 2020-09-16 10:15:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:15:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:15:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:16:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:16:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:16:08 --> Total execution time: 0.1403
DEBUG - 2020-09-16 10:16:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:16:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:16:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:16:10 --> Total execution time: 0.1428
DEBUG - 2020-09-16 10:16:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:16:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:16:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:16:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:16:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:16:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:16:19 --> Total execution time: 0.1415
DEBUG - 2020-09-16 10:16:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:16:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:16:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:16:22 --> Total execution time: 0.1207
DEBUG - 2020-09-16 10:16:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:16:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:16:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:16:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:16:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:16:55 --> Total execution time: 0.1396
DEBUG - 2020-09-16 10:16:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:16:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:16:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:17:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:17:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:17:09 --> Total execution time: 0.1268
DEBUG - 2020-09-16 10:17:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:17:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:17:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:17:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:17:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:17:20 --> Total execution time: 0.1762
DEBUG - 2020-09-16 10:17:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:17:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:17:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:17:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:17:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:17:41 --> Total execution time: 0.1238
DEBUG - 2020-09-16 10:17:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:17:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:17:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:18:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:18:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:18:15 --> Total execution time: 0.1665
DEBUG - 2020-09-16 10:18:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:18:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:18:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:18:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:18:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:18:29 --> Total execution time: 0.1703
DEBUG - 2020-09-16 10:18:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:18:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:18:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:18:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:18:47 --> Total execution time: 0.1428
DEBUG - 2020-09-16 10:18:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:18:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:18:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 10:18:50 --> Total execution time: 0.1578
DEBUG - 2020-09-16 10:18:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:18:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:18:53 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:18:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:18:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:18:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:18:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:18:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:18:53 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:18:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:18:53 --> 404 Page Not Found: Assets/chosen
ERROR - 2020-09-16 10:18:53 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:18:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:18:53 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:18:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:18:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:18:54 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:18:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:18:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:18:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:18:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:18:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:18:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:18:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:18:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:18:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:18:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:18:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:18:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:18:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:18:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:18:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:19:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:19:14 --> No URI present. Default controller set.
DEBUG - 2020-09-16 10:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:19:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:19:14 --> Total execution time: 0.1704
DEBUG - 2020-09-16 10:19:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:19:17 --> No URI present. Default controller set.
DEBUG - 2020-09-16 10:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:19:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:19:17 --> Total execution time: 0.1705
DEBUG - 2020-09-16 10:19:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:19:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:19:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:19:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:19:50 --> Total execution time: 0.1302
DEBUG - 2020-09-16 10:19:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:19:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:19:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:19:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:19:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:19:55 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 10:19:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:19:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:19:56 --> Total execution time: 0.1634
DEBUG - 2020-09-16 10:19:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:19:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:19:57 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-09-16 10:19:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:19:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:19:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 10:19:59 --> Total execution time: 0.2098
DEBUG - 2020-09-16 10:20:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:20:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:20:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:20:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:20:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:20:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:20:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:20:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:20:08 --> Total execution time: 0.1231
DEBUG - 2020-09-16 10:20:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:20:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:20:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:20:11 --> Total execution time: 0.1348
DEBUG - 2020-09-16 10:20:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:20:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:20:11 --> Total execution time: 0.1381
DEBUG - 2020-09-16 10:20:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:20:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:20:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:20:14 --> Total execution time: 0.1694
DEBUG - 2020-09-16 10:20:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:20:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:20:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:20:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:20:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:20:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:20:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:20:24 --> Total execution time: 0.1097
DEBUG - 2020-09-16 10:20:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:20:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:20:29 --> Total execution time: 0.1523
DEBUG - 2020-09-16 10:20:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:20:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:20:31 --> Total execution time: 0.1459
DEBUG - 2020-09-16 10:20:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:20:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:20:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:20:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:20:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:20:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 10:20:33 --> Total execution time: 0.1468
DEBUG - 2020-09-16 10:20:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:20:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:20:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2020-09-16 10:20:34 --> Total execution time: 0.1617
DEBUG - 2020-09-16 10:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:20:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:20:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 10:20:37 --> Total execution time: 0.1715
DEBUG - 2020-09-16 10:20:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:20:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:20:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:20:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:20:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:20:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:20:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:20:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:20:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:20:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:20:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:20:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:20:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:20:52 --> Total execution time: 0.1776
DEBUG - 2020-09-16 10:20:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:20:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:20:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:20:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:20:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:20:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/langoalphademo/public_html/indylan/application/views/admin/add_phrases.php 41
DEBUG - 2020-09-16 10:20:58 --> Total execution time: 0.1851
DEBUG - 2020-09-16 10:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:00 --> Total execution time: 0.1085
DEBUG - 2020-09-16 10:21:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:21:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:21:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:02 --> Total execution time: 0.1284
DEBUG - 2020-09-16 10:21:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:21:04 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 10:21:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:21:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:21:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:21:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:06 --> Total execution time: 0.1179
DEBUG - 2020-09-16 10:21:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:21:08 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-09-16 10:21:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:09 --> Total execution time: 0.1166
DEBUG - 2020-09-16 10:21:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:11 --> Total execution time: 0.1200
DEBUG - 2020-09-16 10:21:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:12 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 10:21:12 --> Total execution time: 0.1487
DEBUG - 2020-09-16 10:21:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:13 --> Total execution time: 0.1476
DEBUG - 2020-09-16 10:21:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:21:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:21:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:15 --> Total execution time: 0.1447
DEBUG - 2020-09-16 10:21:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:21:15 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 10:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:15 --> Total execution time: 0.1517
DEBUG - 2020-09-16 10:21:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:17 --> Total execution time: 0.1324
DEBUG - 2020-09-16 10:21:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:20 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:21:20 --> Total execution time: 0.1104
DEBUG - 2020-09-16 10:21:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:21:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:21:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:24 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 10:21:24 --> Total execution time: 0.1432
DEBUG - 2020-09-16 10:21:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:28 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
ERROR - 2020-09-16 10:21:28 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 10:21:28 --> Total execution time: 0.1254
DEBUG - 2020-09-16 10:21:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:33 --> Total execution time: 0.1579
DEBUG - 2020-09-16 10:21:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:36 --> Total execution time: 0.1576
DEBUG - 2020-09-16 10:21:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:37 --> Total execution time: 0.1603
DEBUG - 2020-09-16 10:21:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:37 --> Total execution time: 0.1634
DEBUG - 2020-09-16 10:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:37 --> Total execution time: 0.1557
DEBUG - 2020-09-16 10:21:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:38 --> Total execution time: 0.1729
DEBUG - 2020-09-16 10:21:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:21:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:21:38 --> Total execution time: 0.1407
DEBUG - 2020-09-16 10:21:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:40 --> Total execution time: 0.1230
DEBUG - 2020-09-16 10:21:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:21:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:21:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:40 --> Total execution time: 0.1209
DEBUG - 2020-09-16 10:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:21:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:21:40 --> Total execution time: 0.1344
DEBUG - 2020-09-16 10:21:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:40 --> Total execution time: 0.1209
DEBUG - 2020-09-16 10:21:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:21:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:21:40 --> Total execution time: 0.1329
DEBUG - 2020-09-16 10:21:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:21:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:21:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:21:43 --> Total execution time: 0.1429
DEBUG - 2020-09-16 10:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:21:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:21:43 --> Total execution time: 0.1258
DEBUG - 2020-09-16 10:21:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:21:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:21:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:21:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:22:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:22:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:22:29 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-09-16 10:22:29 --> Total execution time: 0.1062
DEBUG - 2020-09-16 10:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:22:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:22:34 --> Total execution time: 0.1463
DEBUG - 2020-09-16 10:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:22:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:22:35 --> Total execution time: 0.1301
DEBUG - 2020-09-16 10:22:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:22:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:22:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 10:22:37 --> Total execution time: 0.1219
DEBUG - 2020-09-16 10:22:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:22:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:22:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 10:22:39 --> Total execution time: 0.1754
DEBUG - 2020-09-16 10:22:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:22:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:22:40 --> Total execution time: 0.1557
DEBUG - 2020-09-16 10:22:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:22:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:22:41 --> Total execution time: 0.1583
DEBUG - 2020-09-16 10:22:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:22:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:22:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:22:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:22:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:22:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:22:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:22:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:22:44 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
ERROR - 2020-09-16 10:22:44 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 10:22:44 --> Total execution time: 0.1655
DEBUG - 2020-09-16 10:22:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:22:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:22:44 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:22:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:22:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:22:44 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:22:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:22:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:22:44 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:22:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:22:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:22:45 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:22:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:22:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:22:45 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:22:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:22:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:22:45 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:22:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:22:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:23:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:23:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:23:38 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-09-16 10:23:38 --> Total execution time: 0.0949
DEBUG - 2020-09-16 10:23:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:23:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:23:45 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:23:45 --> Total execution time: 0.1076
DEBUG - 2020-09-16 10:23:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:23:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:23:47 --> Total execution time: 0.1242
DEBUG - 2020-09-16 10:23:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:23:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:23:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:23:50 --> Total execution time: 0.1386
DEBUG - 2020-09-16 10:23:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:23:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:23:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:23:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:23:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:23:52 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-09-16 10:23:52 --> Total execution time: 0.1230
DEBUG - 2020-09-16 10:23:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:23:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:23:55 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 10:24:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:24:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:24:02 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:24:02 --> Total execution time: 0.1303
DEBUG - 2020-09-16 10:24:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:24:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:24:05 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 10:24:05 --> Total execution time: 0.1137
DEBUG - 2020-09-16 10:24:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:24:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:24:10 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
ERROR - 2020-09-16 10:24:10 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 10:24:10 --> Total execution time: 0.1178
DEBUG - 2020-09-16 10:24:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:24:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:24:35 --> Total execution time: 0.1822
DEBUG - 2020-09-16 10:24:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:24:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:24:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:24:37 --> Total execution time: 0.1635
DEBUG - 2020-09-16 10:24:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:24:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:24:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:24:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:24:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:24:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:24:45 --> Total execution time: 0.1528
DEBUG - 2020-09-16 10:24:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:24:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:24:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:24:47 --> Total execution time: 0.1381
DEBUG - 2020-09-16 10:24:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:24:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:24:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:25:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:25:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:25:12 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-09-16 10:25:12 --> Total execution time: 0.1072
DEBUG - 2020-09-16 10:26:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:26:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:26:06 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:26:06 --> Total execution time: 0.1188
DEBUG - 2020-09-16 10:26:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:26:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:26:14 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 10:26:14 --> Total execution time: 0.0901
DEBUG - 2020-09-16 10:26:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:26:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:26:21 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 10:26:21 --> Total execution time: 0.1351
DEBUG - 2020-09-16 10:26:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:26:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:26:24 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 10:26:24 --> Total execution time: 0.1452
DEBUG - 2020-09-16 10:26:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:26:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:26:30 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
ERROR - 2020-09-16 10:26:30 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 10:26:30 --> Total execution time: 0.1335
DEBUG - 2020-09-16 10:27:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:27:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:27:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:27:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:27:59 --> Total execution time: 0.1370
DEBUG - 2020-09-16 10:28:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:28:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:28:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2020-09-16 10:28:01 --> Total execution time: 0.1864
DEBUG - 2020-09-16 10:28:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:28:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:28:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:28:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:28:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:29:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:29:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:29:44 --> Total execution time: 0.1351
DEBUG - 2020-09-16 10:29:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:29:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:29:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:29:47 --> Total execution time: 0.1690
DEBUG - 2020-09-16 10:29:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:29:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:29:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:31:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:31:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:31:12 --> Total execution time: 0.1774
DEBUG - 2020-09-16 10:31:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:31:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:31:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 10:31:16 --> Total execution time: 0.1673
DEBUG - 2020-09-16 10:31:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:31:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:31:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:31:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:31:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:31:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:31:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:31:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:31:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:31:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:31:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:31:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:31:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:31:19 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 10:31:19 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 10:31:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:31:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:31:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:31:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:31:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:31:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:31:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:31:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:31:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:33:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:33:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:33:22 --> get_culture_type_1->{"slang":"","tlang":"","exercise_mode_id":"","category_id":"","subcategory_id":"","support_lang_id":""}
ERROR - 2020-09-16 10:33:22 --> {"status":0,"message":"Parameters not passed","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-09-16 10:33:22 --> Total execution time: 0.1089
DEBUG - 2020-09-16 10:34:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:34:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:34:01 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
ERROR - 2020-09-16 10:34:01 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 10:34:01 --> Total execution time: 0.1191
DEBUG - 2020-09-16 10:35:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:35:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:35:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:35:36 --> Total execution time: 0.1635
DEBUG - 2020-09-16 10:35:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:35:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:35:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:35:39 --> Total execution time: 0.1709
DEBUG - 2020-09-16 10:35:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:35:41 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:35:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:35:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:35:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:35:48 --> Total execution time: 0.1570
DEBUG - 2020-09-16 10:35:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:35:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:35:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:35:50 --> Total execution time: 0.1351
DEBUG - 2020-09-16 10:35:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:35:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:35:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:35:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:35:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:35:58 --> Total execution time: 0.1743
DEBUG - 2020-09-16 10:36:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:36:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:36:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:36:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:36:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:36:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:36:28 --> Total execution time: 0.1632
DEBUG - 2020-09-16 10:36:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:36:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:36:31 --> Total execution time: 0.1720
DEBUG - 2020-09-16 10:36:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:36:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:36:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:37:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:37:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:37:41 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 10:37:41 --> Total execution time: 0.1176
DEBUG - 2020-09-16 10:49:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:49:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:49:26 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
ERROR - 2020-09-16 10:49:26 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 10:49:26 --> Total execution time: 0.1489
DEBUG - 2020-09-16 10:51:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:51:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:51:32 --> Total execution time: 0.1972
DEBUG - 2020-09-16 10:52:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:52:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:52:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:52:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:52:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:52:15 --> Total execution time: 0.1577
DEBUG - 2020-09-16 10:52:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:52:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:52:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:52:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:52:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:52:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:52:36 --> Total execution time: 0.1623
DEBUG - 2020-09-16 10:52:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:52:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:52:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 10:52:39 --> Total execution time: 0.2138
DEBUG - 2020-09-16 10:52:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:52:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:52:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:54:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:54:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:54:26 --> get_grammer_type_1->{"slang":"37","tlang":"1","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
ERROR - 2020-09-16 10:54:26 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 10:54:26 --> Total execution time: 0.1583
DEBUG - 2020-09-16 10:55:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:55:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:55:33 --> get_grammer_type_1->{"slang":"37","tlang":"1","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 10:55:33 --> Total execution time: 0.1176
DEBUG - 2020-09-16 10:56:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:56:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:56:18 --> Total execution time: 0.1324
DEBUG - 2020-09-16 10:56:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:56:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 10:56:21 --> Total execution time: 0.1618
DEBUG - 2020-09-16 10:56:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:56:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:56:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:56:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:56:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:56:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:56:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:56:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:56:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:56:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:56:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:56:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:56:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:56:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:56:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:56:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:56:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:56:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:56:45 --> Total execution time: 0.1628
DEBUG - 2020-09-16 10:56:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:56:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:56:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:56:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:56:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:56:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:56:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:56:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:56:57 --> 404 Page Not Found: Assets/js
DEBUG - 2020-09-16 10:57:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:57:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:57:15 --> 404 Page Not Found: Assets/js
DEBUG - 2020-09-16 10:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:57:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:57:24 --> Total execution time: 0.1265
DEBUG - 2020-09-16 10:58:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:58:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:58:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 10:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 10:58:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:58:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 10:58:18 --> Total execution time: 0.1868
DEBUG - 2020-09-16 10:58:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:58:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:58:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:58:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:58:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:58:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 10:58:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:58:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:58:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:58:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:58:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:58:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:58:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:58:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:58:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:58:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:58:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:58:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:58:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:58:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:58:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:58:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:58:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:58:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 10:58:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 10:58:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 10:58:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:04:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:04:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:04:51 --> Total execution time: 0.2003
DEBUG - 2020-09-16 11:04:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:04:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:04:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 11:08:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:08:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:08:36 --> Total execution time: 0.1575
DEBUG - 2020-09-16 11:10:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:10:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:10:14 --> Total execution time: 0.1297
DEBUG - 2020-09-16 11:10:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:10:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:10:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 11:19:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:19:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:19:23 --> Total execution time: 0.1632
DEBUG - 2020-09-16 11:19:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:19:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:19:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 11:19:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:19:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:19:39 --> Total execution time: 0.1624
DEBUG - 2020-09-16 11:20:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:20:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:20:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:20:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 11:20:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 11:20:08 --> Total execution time: 0.1167
DEBUG - 2020-09-16 11:20:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:20:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:20:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 11:20:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:20:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:20:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:20:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:20:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:20:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:20:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:20:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:20:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:20:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:20:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:20:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:20:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:20:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:20:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:20:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:20:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:20:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:20:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:20:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:20:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:20:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:20:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:20:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:20:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:20:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:20:38 --> Total execution time: 0.1654
DEBUG - 2020-09-16 11:20:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:20:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:20:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:20:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:20:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:20:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 11:20:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:20:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:20:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:20:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 11:20:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 11:20:54 --> Total execution time: 0.2029
DEBUG - 2020-09-16 11:20:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:20:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:20:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 11:20:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:20:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:20:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:21:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:21:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:21:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:21:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:21:00 --> UTF-8 Support Enabled
ERROR - 2020-09-16 11:21:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:21:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:21:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:21:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:21:00 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 11:21:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:21:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:21:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:21:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:46:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:46:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:46:42 --> Total execution time: 0.1722
DEBUG - 2020-09-16 11:52:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:52:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:52:26 --> Total execution time: 0.1450
DEBUG - 2020-09-16 11:52:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:52:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:52:35 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-09-16 11:52:35 --> Total execution time: 0.1348
DEBUG - 2020-09-16 11:52:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:52:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:52:37 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 11:52:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:52:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:52:38 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 11:52:38 --> Total execution time: 0.1133
DEBUG - 2020-09-16 11:52:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:52:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:52:41 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 11:52:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:52:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:52:41 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-09-16 11:52:41 --> Total execution time: 0.0972
DEBUG - 2020-09-16 11:52:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:52:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:52:45 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
ERROR - 2020-09-16 11:52:45 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 11:52:45 --> Total execution time: 0.1360
DEBUG - 2020-09-16 11:52:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:52:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:52:51 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 11:52:51 --> Total execution time: 0.1425
DEBUG - 2020-09-16 11:52:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:52:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:52:53 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 11:53:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:53:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:53:26 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-09-16 11:53:26 --> Total execution time: 0.1351
DEBUG - 2020-09-16 11:53:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:53:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:53:29 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 11:53:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:53:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:53:35 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 11:53:35 --> Total execution time: 0.1483
DEBUG - 2020-09-16 11:53:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:53:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:53:38 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 11:53:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:53:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:53:39 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-09-16 11:53:39 --> Total execution time: 0.1256
DEBUG - 2020-09-16 11:54:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:54:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 11:54:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-16 11:54:21 --> Total execution time: 0.1680
DEBUG - 2020-09-16 11:54:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:54:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:54:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 11:54:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:54:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:54:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:54:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:54:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:54:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:54:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:54:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:54:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:54:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:54:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:54:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:54:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:54:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:54:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:54:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:54:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:54:28 --> UTF-8 Support Enabled
ERROR - 2020-09-16 11:54:28 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 11:54:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:54:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:54:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 11:54:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:54:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:54:33 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
ERROR - 2020-09-16 11:54:33 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 11:54:33 --> Total execution time: 0.1169
DEBUG - 2020-09-16 11:54:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:54:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:54:34 --> Total execution time: 0.1633
DEBUG - 2020-09-16 11:54:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:54:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 11:54:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 11:54:36 --> Total execution time: 0.1671
DEBUG - 2020-09-16 11:54:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:54:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:54:38 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 11:54:38 --> Total execution time: 0.1516
DEBUG - 2020-09-16 11:54:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:54:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:54:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 11:54:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:54:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:54:41 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 11:54:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:54:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:54:57 --> Total execution time: 0.1597
DEBUG - 2020-09-16 11:55:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:55:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 11:55:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:55:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:55:24 --> Total execution time: 0.1347
DEBUG - 2020-09-16 11:55:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:55:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:55:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:55:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 11:55:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 11:55:38 --> Total execution time: 0.1626
DEBUG - 2020-09-16 11:55:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:55:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:55:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 11:55:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:55:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:55:57 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-09-16 11:55:57 --> Total execution time: 0.1114
DEBUG - 2020-09-16 11:56:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:56:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:56:05 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
ERROR - 2020-09-16 11:56:05 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 11:56:05 --> Total execution time: 0.1128
DEBUG - 2020-09-16 11:57:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:57:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:57:07 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 11:57:07 --> Total execution time: 0.1814
DEBUG - 2020-09-16 11:57:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:57:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:57:10 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 11:57:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:57:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:57:18 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-09-16 11:57:18 --> Total execution time: 0.1173
DEBUG - 2020-09-16 11:57:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:57:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 11:57:21 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 11:57:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:57:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:57:28 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 11:57:28 --> Total execution time: 0.1568
DEBUG - 2020-09-16 11:57:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:57:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:57:42 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 11:57:42 --> Total execution time: 0.1166
DEBUG - 2020-09-16 11:57:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:57:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:57:50 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
ERROR - 2020-09-16 11:57:50 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 11:57:50 --> Total execution time: 0.1297
DEBUG - 2020-09-16 11:58:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:58:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:58:55 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 11:58:55 --> Total execution time: 0.1567
DEBUG - 2020-09-16 11:59:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 11:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 11:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 11:59:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 11:59:06 --> Total execution time: 0.1803
DEBUG - 2020-09-16 12:00:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:00:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:00:32 --> Total execution time: 0.1144
DEBUG - 2020-09-16 12:00:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:00:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:00:39 --> Total execution time: 0.1584
DEBUG - 2020-09-16 12:00:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:00:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:00:47 --> get_category_list->{"lang":"1","exercise_mode_id":"4","support_lang_id":"3"}
ERROR - 2020-09-16 12:00:47 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-09-16 12:00:47 --> Total execution time: 0.1397
DEBUG - 2020-09-16 12:01:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:01:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:01:42 --> Total execution time: 0.1400
DEBUG - 2020-09-16 12:01:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:01:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:01:53 --> Total execution time: 0.1221
DEBUG - 2020-09-16 12:01:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:01:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:01:59 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 12:01:59 --> Total execution time: 0.1280
DEBUG - 2020-09-16 12:02:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:02:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:02:05 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 12:02:05 --> Total execution time: 0.1367
DEBUG - 2020-09-16 12:02:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:02:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:02:10 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:02:10 --> Total execution time: 0.1477
DEBUG - 2020-09-16 12:02:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:02:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:02:16 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:02:16 --> Total execution time: 0.1272
DEBUG - 2020-09-16 12:04:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:04:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:04:14 --> Total execution time: 0.1185
DEBUG - 2020-09-16 12:04:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:04:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:04:20 --> Total execution time: 0.1169
DEBUG - 2020-09-16 12:04:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:04:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:04:45 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 12:04:45 --> Total execution time: 0.1495
DEBUG - 2020-09-16 12:04:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:04:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:04:50 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 12:04:50 --> Total execution time: 0.1408
DEBUG - 2020-09-16 12:04:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:04:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:04:54 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:04:54 --> Total execution time: 0.1371
DEBUG - 2020-09-16 12:05:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:05:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:05:03 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:05:03 --> Total execution time: 0.0998
DEBUG - 2020-09-16 12:05:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:05:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 12:05:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 12:05:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:05:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 12:05:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 12:07:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:07:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:07:28 --> Total execution time: 0.1062
DEBUG - 2020-09-16 12:07:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:07:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:07:34 --> Total execution time: 0.1491
DEBUG - 2020-09-16 12:07:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:07:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:07:44 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-09-16 12:07:44 --> Total execution time: 0.1482
DEBUG - 2020-09-16 12:07:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:07:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 12:07:47 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 12:07:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:07:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:07:49 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 12:07:49 --> Total execution time: 0.1546
DEBUG - 2020-09-16 12:07:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:07:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:07:53 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 12:07:53 --> Total execution time: 0.1522
DEBUG - 2020-09-16 12:07:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:07:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:07:59 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
ERROR - 2020-09-16 12:07:59 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 12:07:59 --> Total execution time: 0.1459
DEBUG - 2020-09-16 12:09:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:09:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:09:41 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 12:09:41 --> Total execution time: 0.1083
DEBUG - 2020-09-16 12:09:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:09:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:09:47 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 12:09:47 --> Total execution time: 0.1139
DEBUG - 2020-09-16 12:09:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:09:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:09:58 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 12:09:58 --> Total execution time: 0.1311
DEBUG - 2020-09-16 12:10:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:10:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:10:02 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:10:02 --> Total execution time: 0.1009
DEBUG - 2020-09-16 12:10:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:10:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:10:08 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:10:08 --> Total execution time: 0.1288
DEBUG - 2020-09-16 12:10:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:10:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 12:10:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 12:11:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:11:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 12:11:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 12:14:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:14:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:14:52 --> Total execution time: 0.1432
DEBUG - 2020-09-16 12:15:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:15:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:15:57 --> Total execution time: 0.1183
DEBUG - 2020-09-16 12:18:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:18:14 --> Total execution time: 0.1574
DEBUG - 2020-09-16 12:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:22:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:22:34 --> Total execution time: 0.1640
DEBUG - 2020-09-16 12:22:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:22:46 --> Total execution time: 0.1412
DEBUG - 2020-09-16 12:22:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:22:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:22:56 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 12:22:56 --> Total execution time: 0.1120
DEBUG - 2020-09-16 12:23:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:23:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:23:03 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 12:23:03 --> Total execution time: 0.1058
DEBUG - 2020-09-16 12:23:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:23:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:23:07 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:23:07 --> Total execution time: 0.1979
DEBUG - 2020-09-16 12:23:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:23:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:23:11 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:23:11 --> Total execution time: 0.1378
DEBUG - 2020-09-16 12:23:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:23:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 12:23:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 12:24:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:24:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 12:24:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 12:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:33:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:33:27 --> Total execution time: 0.1119
DEBUG - 2020-09-16 12:33:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:33:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:33:32 --> Total execution time: 0.1149
DEBUG - 2020-09-16 12:33:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:33:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:33:47 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 12:33:47 --> Total execution time: 0.1425
DEBUG - 2020-09-16 12:33:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:33:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:33:52 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 12:33:52 --> Total execution time: 0.1592
DEBUG - 2020-09-16 12:33:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:33:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:33:57 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:33:57 --> Total execution time: 0.1319
DEBUG - 2020-09-16 12:34:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:34:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:34:03 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:34:03 --> Total execution time: 0.1082
DEBUG - 2020-09-16 12:34:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:34:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 12:34:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 12:35:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:35:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:35:01 --> Total execution time: 0.1279
DEBUG - 2020-09-16 12:35:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:35:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:35:22 --> Total execution time: 0.1577
DEBUG - 2020-09-16 12:35:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:35:27 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-09-16 12:35:27 --> Total execution time: 0.1459
DEBUG - 2020-09-16 12:35:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:35:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 12:35:30 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 12:35:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:35:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:35:32 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 12:35:32 --> Total execution time: 0.0995
DEBUG - 2020-09-16 12:35:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:35:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:35:50 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 12:35:50 --> Total execution time: 0.1557
DEBUG - 2020-09-16 12:35:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:35:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:35:55 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:35:55 --> Total execution time: 0.1340
DEBUG - 2020-09-16 12:36:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:36:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:36:06 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:36:06 --> Total execution time: 0.1122
DEBUG - 2020-09-16 12:36:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:36:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 12:36:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 12:43:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:43:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:43:36 --> Total execution time: 0.1338
DEBUG - 2020-09-16 12:43:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:43:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:43:42 --> Total execution time: 0.1108
DEBUG - 2020-09-16 12:43:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:43:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:43:50 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 12:43:50 --> Total execution time: 0.1449
DEBUG - 2020-09-16 12:43:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:43:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:43:54 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 12:43:54 --> Total execution time: 0.1470
DEBUG - 2020-09-16 12:43:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:43:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:43:57 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:43:57 --> Total execution time: 0.1360
DEBUG - 2020-09-16 12:44:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:44:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:44:01 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:44:01 --> Total execution time: 0.1285
DEBUG - 2020-09-16 12:44:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:44:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 12:44:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 12:44:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:44:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:44:16 --> Total execution time: 0.1127
DEBUG - 2020-09-16 12:45:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:45:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:45:29 --> Total execution time: 0.1404
DEBUG - 2020-09-16 12:45:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:45:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:45:40 --> Total execution time: 0.1165
DEBUG - 2020-09-16 12:45:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:45:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:45:46 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 12:45:46 --> Total execution time: 0.1186
DEBUG - 2020-09-16 12:45:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:45:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:45:50 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 12:45:50 --> Total execution time: 0.1364
DEBUG - 2020-09-16 12:45:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:45:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:45:54 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:45:54 --> Total execution time: 0.1356
DEBUG - 2020-09-16 12:45:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:45:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:45:57 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:45:57 --> Total execution time: 0.1541
DEBUG - 2020-09-16 12:46:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:46:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 12:46:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 12:48:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:48:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:48:45 --> Total execution time: 0.1444
DEBUG - 2020-09-16 12:49:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:49:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:49:19 --> Total execution time: 0.1565
DEBUG - 2020-09-16 12:49:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:49:29 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 12:49:29 --> Total execution time: 0.1685
DEBUG - 2020-09-16 12:49:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:49:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:49:33 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 12:49:33 --> Total execution time: 0.1429
DEBUG - 2020-09-16 12:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:49:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:49:36 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:49:36 --> Total execution time: 0.0981
DEBUG - 2020-09-16 12:49:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:49:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:49:39 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:49:39 --> Total execution time: 0.1260
DEBUG - 2020-09-16 12:49:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:49:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 12:49:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 12:50:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:50:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:50:00 --> Total execution time: 0.1449
DEBUG - 2020-09-16 12:50:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:50:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:50:03 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:50:03 --> Total execution time: 0.0980
DEBUG - 2020-09-16 12:50:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:50:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 12:50:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 12:50:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:50:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:50:13 --> Total execution time: 0.0986
DEBUG - 2020-09-16 12:50:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:50:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:50:16 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:50:16 --> Total execution time: 0.1744
DEBUG - 2020-09-16 12:50:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:50:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 12:50:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 12:50:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:50:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:50:24 --> Total execution time: 0.1088
DEBUG - 2020-09-16 12:50:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:50:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:50:34 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:50:34 --> Total execution time: 0.1654
DEBUG - 2020-09-16 12:50:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:50:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 12:50:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 12:54:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:54:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:54:15 --> Total execution time: 0.1682
DEBUG - 2020-09-16 12:55:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:55:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:55:34 --> Total execution time: 0.1493
DEBUG - 2020-09-16 12:56:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:56:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:56:07 --> Total execution time: 0.1053
DEBUG - 2020-09-16 12:56:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:56:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:56:13 --> Total execution time: 0.1724
DEBUG - 2020-09-16 12:56:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:56:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:56:19 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 12:56:19 --> Total execution time: 0.1469
DEBUG - 2020-09-16 12:56:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:56:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:56:23 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 12:56:23 --> Total execution time: 0.1712
DEBUG - 2020-09-16 12:56:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:56:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:56:26 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:56:26 --> Total execution time: 0.1620
DEBUG - 2020-09-16 12:56:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:56:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:56:29 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:56:29 --> Total execution time: 0.1385
DEBUG - 2020-09-16 12:56:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:56:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 12:56:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 12:58:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:58:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:58:15 --> Total execution time: 0.1099
DEBUG - 2020-09-16 12:58:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:58:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:58:25 --> Total execution time: 0.1198
DEBUG - 2020-09-16 12:58:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:58:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:58:29 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 12:58:29 --> Total execution time: 0.1371
DEBUG - 2020-09-16 12:58:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:58:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:58:34 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 12:58:34 --> Total execution time: 0.1451
DEBUG - 2020-09-16 12:58:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:58:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:58:37 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:58:37 --> Total execution time: 0.1160
DEBUG - 2020-09-16 12:58:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 12:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 12:58:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 12:58:41 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 12:58:41 --> Total execution time: 0.1543
DEBUG - 2020-09-16 12:58:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 12:58:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 12:58:44 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:03:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:03:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:03:00 --> Total execution time: 0.1365
DEBUG - 2020-09-16 13:03:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:03:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 13:03:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 13:03:02 --> Total execution time: 0.1390
DEBUG - 2020-09-16 13:03:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:03:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:03:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:03:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:03:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:03:41 --> Total execution time: 0.1371
DEBUG - 2020-09-16 13:03:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:03:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:08:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:08:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:08:56 --> Total execution time: 0.1769
DEBUG - 2020-09-16 13:08:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:08:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:08:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:09:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:09:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:09:10 --> Total execution time: 0.1427
DEBUG - 2020-09-16 13:09:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:09:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:09:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:09:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:09:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:09:13 --> Total execution time: 0.1383
DEBUG - 2020-09-16 13:09:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:09:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:09:15 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:09:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:09:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:09:26 --> Total execution time: 0.1825
DEBUG - 2020-09-16 13:09:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:09:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 13:09:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-09-16 13:09:30 --> Total execution time: 0.1330
DEBUG - 2020-09-16 13:09:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:09:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:09:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:09:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:09:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:09:37 --> Total execution time: 0.1267
DEBUG - 2020-09-16 13:09:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:09:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:09:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:12:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:12:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:12:13 --> Total execution time: 0.1223
DEBUG - 2020-09-16 13:12:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:12:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:12:21 --> Total execution time: 0.1731
DEBUG - 2020-09-16 13:12:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:12:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:12:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:13:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:13:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:13:09 --> Total execution time: 0.1654
DEBUG - 2020-09-16 13:13:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:13:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:13:18 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 13:13:18 --> Total execution time: 0.1136
DEBUG - 2020-09-16 13:13:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:13:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:13:23 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 13:13:23 --> Total execution time: 0.1242
DEBUG - 2020-09-16 13:13:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:13:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:13:27 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 13:13:27 --> Total execution time: 0.1300
DEBUG - 2020-09-16 13:13:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:13:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:13:30 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 13:13:30 --> Total execution time: 0.1443
DEBUG - 2020-09-16 13:13:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:13:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:13:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:18:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:18:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:18:06 --> Total execution time: 0.1283
DEBUG - 2020-09-16 13:18:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:18:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:18:11 --> Total execution time: 0.1648
DEBUG - 2020-09-16 13:18:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:18:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:18:20 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 13:18:20 --> Total execution time: 0.1441
DEBUG - 2020-09-16 13:18:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:18:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:18:25 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 13:18:25 --> Total execution time: 0.1840
DEBUG - 2020-09-16 13:18:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:18:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:18:29 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 13:18:29 --> Total execution time: 0.1258
DEBUG - 2020-09-16 13:18:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:18:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:18:34 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 13:18:34 --> Total execution time: 0.1413
DEBUG - 2020-09-16 13:18:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:18:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:18:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:19:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:19:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:19:05 --> Total execution time: 0.1698
DEBUG - 2020-09-16 13:19:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:19:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:19:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:19:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:19:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:19:42 --> Total execution time: 0.1338
DEBUG - 2020-09-16 13:19:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:19:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:19:47 --> Total execution time: 0.1233
DEBUG - 2020-09-16 13:19:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:19:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:19:51 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 13:19:51 --> Total execution time: 0.0958
DEBUG - 2020-09-16 13:19:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:19:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:19:55 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 13:19:55 --> Total execution time: 0.1443
DEBUG - 2020-09-16 13:20:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:20:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:20:00 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 13:20:00 --> Total execution time: 0.1436
DEBUG - 2020-09-16 13:21:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:21:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:21:47 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 13:21:47 --> Total execution time: 0.1340
DEBUG - 2020-09-16 13:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:21:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:25:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:25:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:25:07 --> Total execution time: 0.1429
DEBUG - 2020-09-16 13:25:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:25:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:25:24 --> Total execution time: 0.1077
DEBUG - 2020-09-16 13:25:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:25:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:25:37 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 13:25:37 --> Total execution time: 0.1128
DEBUG - 2020-09-16 13:25:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:25:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:25:43 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 13:25:43 --> Total execution time: 0.1476
DEBUG - 2020-09-16 13:25:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:25:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:25:54 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 13:25:54 --> Total execution time: 0.1421
DEBUG - 2020-09-16 13:26:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:26:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:26:13 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 13:26:13 --> Total execution time: 0.1064
DEBUG - 2020-09-16 13:26:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:26:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:26:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:27:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:27:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:27:08 --> Total execution time: 0.0983
DEBUG - 2020-09-16 13:27:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:27:57 --> Total execution time: 0.1491
DEBUG - 2020-09-16 13:28:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:28:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:28:19 --> Total execution time: 0.1243
DEBUG - 2020-09-16 13:28:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:28:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:28:23 --> Total execution time: 0.1694
DEBUG - 2020-09-16 13:28:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:28:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:28:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:28:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:28:28 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-16 13:28:28 --> Total execution time: 0.1137
DEBUG - 2020-09-16 13:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:28:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 13:28:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 13:28:30 --> Total execution time: 0.1423
DEBUG - 2020-09-16 13:28:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:28:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:28:33 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-16 13:28:33 --> Total execution time: 0.1887
DEBUG - 2020-09-16 13:28:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:28:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:28:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:28:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:28:36 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-16 13:28:37 --> Total execution time: 0.1761
DEBUG - 2020-09-16 13:28:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:28:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:28:40 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"3","exercise_mode_id":"1","category_id":"62","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-16 13:28:40 --> Total execution time: 0.1836
DEBUG - 2020-09-16 13:28:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:28:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:28:45 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-16 13:28:45 --> Total execution time: 0.1404
DEBUG - 2020-09-16 13:28:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:28:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:28:49 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"3","exercise_mode_id":"1","category_id":"62","subcategory_id":"101","support_lang_id":"3"}
ERROR - 2020-09-16 13:28:49 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 13:28:49 --> Total execution time: 0.1304
DEBUG - 2020-09-16 13:28:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:28:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:28:55 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-16 13:28:55 --> Total execution time: 0.0996
DEBUG - 2020-09-16 13:28:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:28:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:28:56 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-16 13:28:56 --> Total execution time: 0.1049
DEBUG - 2020-09-16 13:28:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:28:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:28:57 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-16 13:28:57 --> Total execution time: 0.1056
DEBUG - 2020-09-16 13:28:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:28:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:28:58 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 13:28:58 --> Total execution time: 0.1404
DEBUG - 2020-09-16 13:29:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:29:03 --> get_subcategory_list->{"lang":"37","category_id":"90","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-16 13:29:03 --> Total execution time: 0.1033
DEBUG - 2020-09-16 13:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:29:05 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-16 13:29:05 --> Total execution time: 0.1089
DEBUG - 2020-09-16 13:29:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 13:29:10 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-09-16 13:29:10 --> Total execution time: 0.1527
DEBUG - 2020-09-16 13:29:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:29:12 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-16 13:29:12 --> Total execution time: 0.1614
DEBUG - 2020-09-16 13:29:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:29:14 --> get_subcategory_list->{"lang":"37","category_id":"90","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-16 13:29:14 --> Total execution time: 0.1645
DEBUG - 2020-09-16 13:29:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:29:16 --> get_exercise_type_list->{"lang":"37","subcategory_id":"99","support_lang_id":"3"}
DEBUG - 2020-09-16 13:29:16 --> Total execution time: 0.1682
DEBUG - 2020-09-16 13:29:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 13:29:19 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-09-16 13:29:19 --> Total execution time: 0.1358
DEBUG - 2020-09-16 13:29:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:29:22 --> get_exercise_type_list->{"lang":"37","subcategory_id":"99","support_lang_id":"3"}
DEBUG - 2020-09-16 13:29:22 --> Total execution time: 0.1447
DEBUG - 2020-09-16 13:29:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:29:24 --> get_culture_type_1->{"slang":"37","tlang":"3","exercise_mode_id":"5","category_id":"90","subcategory_id":"99","support_lang_id":"3"}
ERROR - 2020-09-16 13:29:24 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 13:29:24 --> Total execution time: 0.1127
DEBUG - 2020-09-16 13:29:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:29:27 --> get_exercise_type_list->{"lang":"37","subcategory_id":"99","support_lang_id":"3"}
DEBUG - 2020-09-16 13:29:27 --> Total execution time: 0.1177
DEBUG - 2020-09-16 13:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:29:27 --> get_subcategory_list->{"lang":"37","category_id":"90","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-16 13:29:27 --> Total execution time: 0.1242
DEBUG - 2020-09-16 13:29:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:29:29 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 13:29:29 --> Total execution time: 0.1576
DEBUG - 2020-09-16 13:29:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:29:30 --> get_subcategory_list->{"lang":"37","category_id":"72","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-16 13:29:30 --> Total execution time: 0.1539
DEBUG - 2020-09-16 13:29:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:29:34 --> Total execution time: 0.1527
DEBUG - 2020-09-16 13:29:34 --> get_exercise_type_list->{"lang":"37","subcategory_id":"131","support_lang_id":"3"}
DEBUG - 2020-09-16 13:29:34 --> Total execution time: 0.0973
DEBUG - 2020-09-16 13:29:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:29:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:29:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:29:40 --> get_exercise_type_list->{"lang":"37","subcategory_id":"131","support_lang_id":"3"}
DEBUG - 2020-09-16 13:29:40 --> Total execution time: 0.1600
DEBUG - 2020-09-16 13:29:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:29:41 --> get_subcategory_list->{"lang":"37","category_id":"72","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-16 13:29:41 --> Total execution time: 0.1805
DEBUG - 2020-09-16 13:29:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:29:41 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 13:29:41 --> Total execution time: 0.1108
DEBUG - 2020-09-16 13:29:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:29:41 --> get_culture_type_1->{"slang":"37","tlang":"3","exercise_mode_id":"5","category_id":"72","subcategory_id":"131","support_lang_id":"3"}
ERROR - 2020-09-16 13:29:41 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 13:29:41 --> Total execution time: 0.1276
DEBUG - 2020-09-16 13:29:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:29:47 --> Total execution time: 0.1399
DEBUG - 2020-09-16 13:29:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:29:54 --> get_category_list->{"lang":"41","exercise_mode_id":"2","support_lang_id":"3"}
ERROR - 2020-09-16 13:29:54 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-09-16 13:29:54 --> Total execution time: 0.1392
DEBUG - 2020-09-16 13:29:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:29:56 --> get_subcategory_list->{"lang":"41","category_id":"90","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-16 13:29:56 --> Total execution time: 0.1584
DEBUG - 2020-09-16 13:29:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:29:57 --> get_exercise_type_list->{"lang":"41","subcategory_id":"131","support_lang_id":"3"}
DEBUG - 2020-09-16 13:29:57 --> Total execution time: 0.1299
DEBUG - 2020-09-16 13:29:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:29:59 --> get_subcategory_list->{"lang":"41","category_id":"90","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-16 13:29:59 --> Total execution time: 0.1380
DEBUG - 2020-09-16 13:29:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:29:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:29:59 --> get_category_list->{"lang":"41","exercise_mode_id":"2","support_lang_id":"3"}
ERROR - 2020-09-16 13:29:59 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-09-16 13:29:59 --> Total execution time: 0.1174
DEBUG - 2020-09-16 13:30:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:30:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:30:00 --> get_category_list->{"lang":"41","exercise_mode_id":"4","support_lang_id":"3"}
ERROR - 2020-09-16 13:30:00 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-09-16 13:30:00 --> Total execution time: 0.1286
DEBUG - 2020-09-16 13:30:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:30:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:30:03 --> Total execution time: 0.1592
DEBUG - 2020-09-16 13:30:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:30:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:30:04 --> get_category_list->{"lang":"41","exercise_mode_id":"5","support_lang_id":"3"}
ERROR - 2020-09-16 13:30:04 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-09-16 13:30:04 --> Total execution time: 0.1090
DEBUG - 2020-09-16 13:30:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:30:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:30:05 --> Total execution time: 0.1425
DEBUG - 2020-09-16 13:30:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:30:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:30:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:30:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:30:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:30:15 --> get_category_list->{"lang":"39","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-16 13:30:15 --> Total execution time: 0.1383
DEBUG - 2020-09-16 13:30:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:30:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:30:20 --> get_subcategory_list->{"lang":"39","category_id":"112","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-16 13:30:20 --> Total execution time: 0.1713
DEBUG - 2020-09-16 13:30:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:30:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:30:21 --> get_exercise_type_list->{"lang":"39","subcategory_id":"98","support_lang_id":"3"}
DEBUG - 2020-09-16 13:30:21 --> Total execution time: 0.1318
DEBUG - 2020-09-16 13:30:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:30:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:30:23 --> get_sorce_lan_word_type_3->{"slang":"39","tlang":"3","exercise_mode_id":"1","category_id":"112","subcategory_id":"98","support_lang_id":"3"}
ERROR - 2020-09-16 13:30:23 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 13:30:23 --> Total execution time: 0.1421
DEBUG - 2020-09-16 13:31:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:31:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:31:45 --> Total execution time: 0.1215
DEBUG - 2020-09-16 13:32:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:32:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:32:13 --> Total execution time: 0.1288
DEBUG - 2020-09-16 13:32:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:32:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:32:19 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 13:32:19 --> Total execution time: 0.1131
DEBUG - 2020-09-16 13:32:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:32:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:32:22 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 13:32:22 --> Total execution time: 0.1007
DEBUG - 2020-09-16 13:32:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:32:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:32:28 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 13:32:28 --> Total execution time: 0.1316
DEBUG - 2020-09-16 13:32:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:32:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:32:54 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 13:32:54 --> Total execution time: 0.1723
DEBUG - 2020-09-16 13:32:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:32:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:32:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:35:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:35:27 --> Total execution time: 0.1614
DEBUG - 2020-09-16 13:35:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:35:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:35:29 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:36:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:36:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:36:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:36:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 13:36:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 13:36:07 --> Total execution time: 0.1499
DEBUG - 2020-09-16 13:36:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:36:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:36:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:36:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:36:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:36:33 --> Total execution time: 0.1617
DEBUG - 2020-09-16 13:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:36:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:36:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:38:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:38:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:38:18 --> Total execution time: 0.1307
DEBUG - 2020-09-16 13:38:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:38:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:38:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:38:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:39:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:39:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 13:39:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 13:39:00 --> Total execution time: 0.1547
DEBUG - 2020-09-16 13:39:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:39:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:39:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:39:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:39:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:39:17 --> Total execution time: 0.1484
DEBUG - 2020-09-16 13:39:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:39:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:39:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:39:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:39:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:39:27 --> Total execution time: 0.1415
DEBUG - 2020-09-16 13:39:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:39:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 13:39:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 13:39:29 --> Total execution time: 0.1646
DEBUG - 2020-09-16 13:39:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:39:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:39:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:39:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:39:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:39:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:39:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:39:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:39:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:39:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:39:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:39:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:39:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:39:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:39:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:39:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:39:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:39:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:39:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:39:36 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 13:39:36 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 13:39:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:39:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:39:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:39:38 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:39:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:39:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:39:51 --> Total execution time: 0.1537
DEBUG - 2020-09-16 13:39:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:39:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:39:54 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:39:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:39:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:39:54 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:40:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:40:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:40:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:40:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 13:40:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 13:40:22 --> Total execution time: 0.1230
DEBUG - 2020-09-16 13:40:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:40:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:40:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:40:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:40:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:40:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:40:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:40:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:40:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:40:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:40:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:40:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:40:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:40:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:40:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:40:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:40:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:40:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:40:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:40:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:40:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:40:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:40:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:40:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:40:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:40:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:40:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:40:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:40:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:40:34 --> Total execution time: 0.1531
DEBUG - 2020-09-16 13:40:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:40:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:40:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:40:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:40:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:40:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:41:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:41:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:41:31 --> Total execution time: 0.1245
DEBUG - 2020-09-16 13:41:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:41:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 13:41:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 13:41:34 --> Total execution time: 0.1551
DEBUG - 2020-09-16 13:41:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:41:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:41:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:41:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:41:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:41:36 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 13:41:36 --> Total execution time: 0.1225
DEBUG - 2020-09-16 13:42:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:42:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:42:10 --> get_culture_type_1->{"slang":"37","tlang":"1","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 13:42:10 --> Total execution time: 0.1369
DEBUG - 2020-09-16 13:42:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:42:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:42:33 --> get_grammer_type_1->{"slang":"37","tlang":"1","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 13:42:33 --> Total execution time: 0.1483
DEBUG - 2020-09-16 13:47:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:47:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:47:06 --> get_grammer_type_1->{"slang":"37","tlang":"1","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 13:47:06 --> Total execution time: 0.1422
DEBUG - 2020-09-16 13:53:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:53:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:53:06 --> Total execution time: 0.1237
DEBUG - 2020-09-16 13:53:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:53:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:53:12 --> Total execution time: 0.1405
DEBUG - 2020-09-16 13:53:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:53:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:53:18 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 13:53:18 --> Total execution time: 0.1137
DEBUG - 2020-09-16 13:53:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:53:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:53:21 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 13:53:21 --> Total execution time: 0.1526
DEBUG - 2020-09-16 13:53:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:53:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:53:27 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 13:53:27 --> Total execution time: 0.1123
DEBUG - 2020-09-16 13:53:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:53:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:53:31 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 13:53:31 --> Total execution time: 0.1571
DEBUG - 2020-09-16 13:53:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:53:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:53:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:56:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:56:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:56:57 --> Total execution time: 0.1473
DEBUG - 2020-09-16 13:56:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:56:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:56:59 --> Total execution time: 0.1669
DEBUG - 2020-09-16 13:57:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:57:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 13:57:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 13:57:00 --> Total execution time: 0.2113
DEBUG - 2020-09-16 13:57:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:57:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:57:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:57:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:57:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:57:17 --> Total execution time: 0.1777
DEBUG - 2020-09-16 13:57:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:57:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 13:57:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 13:57:19 --> Total execution time: 0.1325
DEBUG - 2020-09-16 13:57:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:57:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:57:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:57:21 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 13:57:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:57:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:57:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:57:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:57:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:57:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:57:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:57:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:57:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:57:26 --> Total execution time: 0.1661
DEBUG - 2020-09-16 13:57:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:57:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:57:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 13:57:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:57:29 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:57:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:57:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:57:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 13:57:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:57:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:57:40 --> 404 Page Not Found: Assets/js
DEBUG - 2020-09-16 13:58:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:58:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:58:54 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 13:58:54 --> Total execution time: 0.1371
DEBUG - 2020-09-16 13:59:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:59:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:59:04 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-09-16 13:59:04 --> Total execution time: 0.1262
DEBUG - 2020-09-16 13:59:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:59:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:59:07 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 13:59:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:59:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:59:09 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 13:59:09 --> Total execution time: 0.1440
DEBUG - 2020-09-16 13:59:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:59:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 13:59:11 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 13:59:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:59:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:59:14 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 13:59:14 --> Total execution time: 0.1229
DEBUG - 2020-09-16 13:59:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:59:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:59:17 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 13:59:17 --> Total execution time: 0.1368
DEBUG - 2020-09-16 13:59:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 13:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 13:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 13:59:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 13:59:21 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
ERROR - 2020-09-16 13:59:21 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 13:59:21 --> Total execution time: 0.1637
DEBUG - 2020-09-16 14:00:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:00:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:00:20 --> get_culture_type_1->{"slang":"37","tlang":"1","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 14:00:20 --> Total execution time: 0.1127
DEBUG - 2020-09-16 14:04:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:04:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:04:07 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 14:04:07 --> Total execution time: 0.1546
DEBUG - 2020-09-16 14:04:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:04:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:04:13 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 14:04:13 --> Total execution time: 0.1331
DEBUG - 2020-09-16 14:04:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:04:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:04:17 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 14:04:17 --> Total execution time: 0.1354
DEBUG - 2020-09-16 14:04:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:04:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:04:20 --> get_culture_type_1->{"slang":"37","tlang":"1","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 14:04:20 --> Total execution time: 0.1431
DEBUG - 2020-09-16 14:04:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:04:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:04:25 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 14:04:25 --> Total execution time: 0.1209
DEBUG - 2020-09-16 14:04:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:04:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:04:32 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 14:04:32 --> Total execution time: 0.1664
DEBUG - 2020-09-16 14:04:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:04:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:04:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 14:05:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:05:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:05:39 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 14:05:39 --> Total execution time: 0.1335
DEBUG - 2020-09-16 14:05:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:05:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:05:45 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 14:05:45 --> Total execution time: 0.1710
DEBUG - 2020-09-16 14:06:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:06:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:06:43 --> Total execution time: 0.1568
DEBUG - 2020-09-16 14:07:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:07:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:07:08 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"1"}
DEBUG - 2020-09-16 14:07:08 --> Total execution time: 0.1068
DEBUG - 2020-09-16 14:07:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:07:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:07:13 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"1"}
DEBUG - 2020-09-16 14:07:13 --> Total execution time: 0.1062
DEBUG - 2020-09-16 14:07:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:07:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:07:17 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"1"}
DEBUG - 2020-09-16 14:07:17 --> Total execution time: 0.1189
DEBUG - 2020-09-16 14:07:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:07:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:07:20 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"1"}
DEBUG - 2020-09-16 14:07:20 --> Total execution time: 0.1006
DEBUG - 2020-09-16 14:07:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:07:23 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 14:07:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:07:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:07:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 14:07:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:07:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:07:45 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 14:07:45 --> Total execution time: 0.1216
DEBUG - 2020-09-16 14:08:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:08:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:08:17 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"1"}
DEBUG - 2020-09-16 14:08:17 --> Total execution time: 0.1415
DEBUG - 2020-09-16 14:08:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:08:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:08:38 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"1"}
DEBUG - 2020-09-16 14:08:38 --> Total execution time: 0.1440
DEBUG - 2020-09-16 14:08:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:08:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:08:44 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"1"}
DEBUG - 2020-09-16 14:08:44 --> Total execution time: 0.1359
DEBUG - 2020-09-16 14:09:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:09:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:09:02 --> Total execution time: 0.1078
DEBUG - 2020-09-16 14:09:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:09:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:09:13 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-16 14:09:13 --> Total execution time: 0.0990
DEBUG - 2020-09-16 14:09:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:09:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:09:17 --> get_subcategory_list->{"lang":"37","category_id":"90","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 14:09:17 --> Total execution time: 0.1133
DEBUG - 2020-09-16 14:09:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:09:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:09:21 --> get_subcategory_list->{"lang":"37","category_id":"89","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 14:09:21 --> Total execution time: 0.1039
DEBUG - 2020-09-16 14:09:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:09:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:09:27 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 14:09:27 --> Total execution time: 0.1064
DEBUG - 2020-09-16 14:09:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:09:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:09:31 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 14:09:31 --> Total execution time: 0.1137
DEBUG - 2020-09-16 14:09:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:09:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:09:36 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 14:09:36 --> Total execution time: 0.1153
DEBUG - 2020-09-16 14:09:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:09:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:09:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 14:09:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:09:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:09:52 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 14:09:52 --> Total execution time: 0.1203
DEBUG - 2020-09-16 14:09:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:09:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:09:56 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 14:09:56 --> Total execution time: 0.1257
DEBUG - 2020-09-16 14:10:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:10:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:10:02 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 14:10:02 --> Total execution time: 0.0998
DEBUG - 2020-09-16 14:10:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:10:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:10:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 14:11:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:11:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:11:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 14:12:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:12:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:12:13 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-09-16 14:12:13 --> Total execution time: 0.1136
DEBUG - 2020-09-16 14:12:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:12:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:12:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 14:12:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:12:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:12:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 14:13:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:13:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:13:06 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 14:13:06 --> Total execution time: 0.1520
DEBUG - 2020-09-16 14:13:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:13:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:13:15 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-09-16 14:13:15 --> Total execution time: 0.1401
DEBUG - 2020-09-16 14:13:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:13:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:13:18 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 14:15:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:15:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:15:59 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:15:59 --> Total execution time: 0.1038
DEBUG - 2020-09-16 14:22:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:22:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:22:56 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:22:56 --> Total execution time: 0.1224
DEBUG - 2020-09-16 14:27:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:27:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:27:41 --> Total execution time: 0.1816
DEBUG - 2020-09-16 14:27:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:27:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:27:51 --> Total execution time: 0.1377
DEBUG - 2020-09-16 14:28:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:28:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:28:00 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-09-16 14:28:00 --> Total execution time: 0.1199
DEBUG - 2020-09-16 14:28:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:28:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:28:03 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 14:28:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:28:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:28:07 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 14:28:07 --> Total execution time: 0.1300
DEBUG - 2020-09-16 14:28:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:28:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:28:10 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 14:28:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:28:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:28:17 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 14:28:17 --> Total execution time: 0.1171
DEBUG - 2020-09-16 14:28:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:28:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:28:23 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:28:23 --> Total execution time: 0.1181
DEBUG - 2020-09-16 14:28:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:28:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:28:29 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:28:29 --> Total execution time: 0.1507
DEBUG - 2020-09-16 14:29:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:29:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:29:01 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:29:01 --> Total execution time: 0.1329
DEBUG - 2020-09-16 14:29:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:29:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:29:13 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:29:13 --> Total execution time: 0.1512
DEBUG - 2020-09-16 14:30:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:30:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:30:00 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:30:00 --> Total execution time: 0.1423
DEBUG - 2020-09-16 14:30:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:30:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:30:05 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:30:05 --> Total execution time: 0.0968
DEBUG - 2020-09-16 14:31:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:31:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:31:17 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:31:17 --> Total execution time: 0.1482
DEBUG - 2020-09-16 14:32:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:32:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:32:06 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:32:06 --> Total execution time: 0.1509
DEBUG - 2020-09-16 14:32:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:32:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:32:19 --> Total execution time: 0.1359
DEBUG - 2020-09-16 14:34:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:34:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:34:54 --> Total execution time: 0.1566
DEBUG - 2020-09-16 14:34:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:34:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:34:59 --> Total execution time: 0.1041
DEBUG - 2020-09-16 14:35:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:35:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:35:07 --> Total execution time: 0.1304
DEBUG - 2020-09-16 14:35:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:35:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:35:13 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-09-16 14:35:13 --> Total execution time: 0.0934
DEBUG - 2020-09-16 14:35:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:35:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:35:16 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 14:35:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:35:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:35:18 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 14:35:18 --> Total execution time: 0.1330
DEBUG - 2020-09-16 14:35:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:35:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:35:22 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:35:22 --> Total execution time: 0.1536
DEBUG - 2020-09-16 14:35:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:35:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:35:26 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:35:26 --> Total execution time: 0.1441
DEBUG - 2020-09-16 14:36:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:36:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:36:05 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 14:36:05 --> Total execution time: 0.1235
DEBUG - 2020-09-16 14:36:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:36:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:36:15 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-09-16 14:36:15 --> Total execution time: 0.1222
DEBUG - 2020-09-16 14:36:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:36:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:36:18 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 14:36:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:36:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:36:19 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 14:36:19 --> Total execution time: 0.1132
DEBUG - 2020-09-16 14:36:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:36:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:36:21 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 14:36:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:36:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:36:23 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-09-16 14:36:23 --> Total execution time: 0.1595
DEBUG - 2020-09-16 14:36:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:36:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:36:27 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
ERROR - 2020-09-16 14:36:27 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-16 14:36:27 --> Total execution time: 0.1383
DEBUG - 2020-09-16 14:38:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:38:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:38:51 --> Total execution time: 0.1539
DEBUG - 2020-09-16 14:38:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:38:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 14:38:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 14:38:54 --> Total execution time: 0.1796
DEBUG - 2020-09-16 14:38:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:38:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:38:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 14:39:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:39:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:39:01 --> Total execution time: 0.1348
DEBUG - 2020-09-16 14:39:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:39:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:39:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 14:39:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:39:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:39:13 --> Total execution time: 0.1666
DEBUG - 2020-09-16 14:39:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:39:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:39:45 --> Total execution time: 0.1335
DEBUG - 2020-09-16 14:40:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:40:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:40:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:40:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 14:40:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 14:40:04 --> Total execution time: 0.1807
DEBUG - 2020-09-16 14:40:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:40:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:40:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 14:40:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:40:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:40:27 --> Total execution time: 0.1304
DEBUG - 2020-09-16 14:40:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:40:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:40:33 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-09-16 14:40:33 --> Total execution time: 0.1100
DEBUG - 2020-09-16 14:40:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:40:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:40:37 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 14:40:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:40:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:40:38 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 14:40:38 --> Total execution time: 0.0985
DEBUG - 2020-09-16 14:40:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:40:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:40:43 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:40:43 --> Total execution time: 0.1383
DEBUG - 2020-09-16 14:40:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:40:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:40:46 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:40:46 --> Total execution time: 0.1294
DEBUG - 2020-09-16 14:41:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:41:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:41:34 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:41:34 --> Total execution time: 0.1450
DEBUG - 2020-09-16 14:43:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:43:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:43:15 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 14:43:15 --> Total execution time: 0.1456
DEBUG - 2020-09-16 14:43:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:43:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:43:42 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-09-16 14:43:42 --> Total execution time: 0.1394
DEBUG - 2020-09-16 14:43:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:43:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:43:45 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 14:43:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:43:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:43:59 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 14:43:59 --> Total execution time: 0.1481
DEBUG - 2020-09-16 14:44:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:44:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:44:02 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 14:44:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:44:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:44:11 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 14:44:11 --> Total execution time: 0.1426
DEBUG - 2020-09-16 14:44:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:44:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:44:16 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:44:16 --> Total execution time: 0.1361
DEBUG - 2020-09-16 14:44:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:44:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:44:33 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:44:33 --> Total execution time: 0.1509
DEBUG - 2020-09-16 14:45:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:45:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:45:15 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 14:45:15 --> Total execution time: 0.1185
DEBUG - 2020-09-16 14:45:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:45:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:45:20 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:45:20 --> Total execution time: 0.1305
DEBUG - 2020-09-16 14:47:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:47:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:47:59 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:47:59 --> Total execution time: 0.1267
DEBUG - 2020-09-16 14:50:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:50:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:50:18 --> Total execution time: 0.1323
DEBUG - 2020-09-16 14:50:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:50:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:50:21 --> Total execution time: 0.1587
DEBUG - 2020-09-16 14:50:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:50:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:50:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 14:50:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:50:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:50:27 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 14:50:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:50:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:50:28 --> 404 Page Not Found: Uploads/At__the_dentists.JPG
DEBUG - 2020-09-16 14:50:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:50:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:50:31 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-09-16 14:50:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:50:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:50:37 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-09-16 14:50:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:50:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:50:59 --> Total execution time: 0.1654
DEBUG - 2020-09-16 14:51:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:51:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:51:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 14:51:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:51:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:51:14 --> Total execution time: 0.1322
DEBUG - 2020-09-16 14:51:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:51:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:51:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 14:51:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:51:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:51:28 --> Total execution time: 0.1415
DEBUG - 2020-09-16 14:51:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:51:31 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 14:53:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:53:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:53:37 --> Total execution time: 0.1364
DEBUG - 2020-09-16 14:54:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:54:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:54:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 14:54:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:54:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:54:30 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 14:54:30 --> Total execution time: 0.1614
DEBUG - 2020-09-16 14:54:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:54:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:54:35 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:54:35 --> Total execution time: 0.1578
DEBUG - 2020-09-16 14:54:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:54:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:54:43 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:54:43 --> Total execution time: 0.1191
DEBUG - 2020-09-16 14:56:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:56:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:56:28 --> Total execution time: 0.1494
DEBUG - 2020-09-16 14:56:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:56:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:56:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 14:56:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:56:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:56:58 --> Total execution time: 0.1361
DEBUG - 2020-09-16 14:57:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:57:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:57:53 --> Total execution time: 0.1679
DEBUG - 2020-09-16 14:57:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:57:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:57:58 --> Total execution time: 0.1410
DEBUG - 2020-09-16 14:58:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:58:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:58:04 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-09-16 14:58:04 --> Total execution time: 0.1519
DEBUG - 2020-09-16 14:58:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:58:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:58:08 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 14:58:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:58:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:58:10 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-16 14:58:10 --> Total execution time: 0.1389
DEBUG - 2020-09-16 14:58:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:58:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:58:14 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:58:14 --> Total execution time: 0.1198
DEBUG - 2020-09-16 14:58:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:58:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:58:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:58:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 14:58:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 14:58:17 --> Total execution time: 0.1657
DEBUG - 2020-09-16 14:58:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:58:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:58:19 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:58:19 --> Total execution time: 0.1630
DEBUG - 2020-09-16 14:58:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:58:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:58:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 14:58:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:58:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:58:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 14:58:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:58:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:58:23 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 14:58:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:58:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:58:23 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 14:58:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:58:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:58:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 14:58:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:58:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:58:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 14:58:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:58:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:58:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 14:58:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:58:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:58:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 14:58:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:58:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:58:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 14:58:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:58:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:58:45 --> Total execution time: 0.1967
DEBUG - 2020-09-16 14:58:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:58:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:58:59 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-09-16 14:58:59 --> Total execution time: 0.1049
DEBUG - 2020-09-16 14:59:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:59:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:59:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:59:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:59:11 --> Total execution time: 0.1444
DEBUG - 2020-09-16 14:59:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:59:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:59:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:59:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:59:20 --> Total execution time: 0.1334
DEBUG - 2020-09-16 14:59:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:59:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:59:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:59:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 14:59:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:59:22 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-16 14:59:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:59:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:59:23 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-09-16 14:59:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:59:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:59:30 --> Total execution time: 0.1816
DEBUG - 2020-09-16 14:59:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:59:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:59:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 14:59:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:59:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:59:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 14:59:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:59:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 14:59:48 --> Total execution time: 0.1562
DEBUG - 2020-09-16 14:59:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 14:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 14:59:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 14:59:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 14:59:50 --> Total execution time: 0.1631
DEBUG - 2020-09-16 14:59:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 14:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 14:59:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:00:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:00:09 --> Total execution time: 0.1090
DEBUG - 2020-09-16 15:00:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:00:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:00:19 --> Total execution time: 0.1585
DEBUG - 2020-09-16 15:00:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:00:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:00:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:00:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:00:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:00:45 --> Total execution time: 0.1441
DEBUG - 2020-09-16 15:00:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:00:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 15:00:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 15:00:48 --> Total execution time: 0.1538
DEBUG - 2020-09-16 15:00:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:00:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:00:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:00:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:00:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:00:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:00:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:00:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:00:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:00:51 --> UTF-8 Support Enabled
ERROR - 2020-09-16 15:00:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:00:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:00:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:00:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:00:53 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:00:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:00:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:00:54 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:00:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:00:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:00:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:00:54 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:00:54 --> UTF-8 Support Enabled
ERROR - 2020-09-16 15:00:54 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:00:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:00:54 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:00:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:00:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:00:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:00:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:00:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:00:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:00:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:00:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:00:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:01:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:01:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:01:37 --> Total execution time: 0.2081
DEBUG - 2020-09-16 15:01:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:01:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:01:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:01:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:01:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:01:50 --> Total execution time: 0.1361
DEBUG - 2020-09-16 15:01:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:01:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:01:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:01:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:01:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:01:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:02:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:02:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:02:12 --> Total execution time: 0.1496
DEBUG - 2020-09-16 15:02:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:02:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 15:02:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2020-09-16 15:02:16 --> Total execution time: 0.1847
DEBUG - 2020-09-16 15:02:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:02:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:02:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:02:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:02:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 15:02:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/langoalphademo/public_html/indylan/application/views/admin/add_phrases.php 41
DEBUG - 2020-09-16 15:02:26 --> Total execution time: 0.1662
DEBUG - 2020-09-16 15:02:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:02:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:02:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:02:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:02:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:02:37 --> Total execution time: 0.1265
DEBUG - 2020-09-16 15:02:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:02:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 15:02:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 15:02:42 --> Total execution time: 0.1790
DEBUG - 2020-09-16 15:02:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:02:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:02:44 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:02:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:02:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:02:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:02:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:02:45 --> UTF-8 Support Enabled
ERROR - 2020-09-16 15:02:45 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:02:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:02:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:02:45 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:02:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:02:45 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:02:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:02:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:02:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:02:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:02:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:02:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:02:47 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 15:02:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:02:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:02:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:02:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:02:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:02:50 --> Total execution time: 0.1233
DEBUG - 2020-09-16 15:02:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:02:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:02:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:03:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:03:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:03:03 --> Total execution time: 0.1373
DEBUG - 2020-09-16 15:03:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:03:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 15:03:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 15:03:06 --> Total execution time: 0.1285
DEBUG - 2020-09-16 15:03:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:03:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:03:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:03:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:03:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:03:15 --> Total execution time: 0.1524
DEBUG - 2020-09-16 15:03:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:03:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:03:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:03:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:03:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 15:03:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 15:03:41 --> Total execution time: 0.1504
DEBUG - 2020-09-16 15:03:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:03:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:03:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:05:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:05:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:05:05 --> Total execution time: 0.1434
DEBUG - 2020-09-16 15:05:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:05:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:05:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:05:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:05:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:05:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:06:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:06:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:06:32 --> Total execution time: 0.1210
DEBUG - 2020-09-16 15:06:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:06:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:06:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:06:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:06:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:06:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:06:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:06:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:06:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:06:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 15:06:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 15:06:58 --> Total execution time: 0.1940
DEBUG - 2020-09-16 15:07:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:07:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:07:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:07:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:07:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:07:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:07:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:07:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:07:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:07:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:07:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:07:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:07:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:07:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:07:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:07:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:07:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:07:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:07:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:07:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:07:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:07:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:07:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:07:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:07:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:07:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:07:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:07:17 --> Total execution time: 0.1359
DEBUG - 2020-09-16 15:07:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:07:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:07:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:07:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:07:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:07:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:07:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:07:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:07:35 --> Total execution time: 0.1246
DEBUG - 2020-09-16 15:07:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:07:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 15:07:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 15:07:37 --> Total execution time: 0.1740
DEBUG - 2020-09-16 15:07:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:07:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:07:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:07:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:07:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:07:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:07:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:07:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:07:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:07:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:07:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:07:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:07:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:07:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:07:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:07:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:07:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:07:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:07:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:07:43 --> 404 Page Not Found: Uploads/words
ERROR - 2020-09-16 15:07:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:07:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:07:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:07:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:07:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:07:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:10:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:10:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 15:10:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 15:10:10 --> Total execution time: 0.1346
DEBUG - 2020-09-16 15:10:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:10:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:10:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:10:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:10:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:10:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:10:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:10:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:10:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:10:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:10:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:10:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:10:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:10:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:10:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:10:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:10:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:10:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:10:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:10:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:10:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:10:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:10:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:10:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:10:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:10:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:10:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:10:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:10:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:10:33 --> Total execution time: 0.2299
DEBUG - 2020-09-16 15:11:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:11:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:17:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:17:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 15:17:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 15:17:37 --> Total execution time: 0.1794
DEBUG - 2020-09-16 15:17:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:17:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:17:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:17:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:17:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:17:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:17:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:17:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:17:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:17:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:17:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:17:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:17:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:17:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:17:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:18:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:18:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:18:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:18:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:18:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:18:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:18:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:18:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:18:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:18:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:18:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:18:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:18:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:18:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:23:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:23:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 15:23:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 15:23:40 --> Total execution time: 0.1785
DEBUG - 2020-09-16 15:23:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:23:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:23:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:23:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:23:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:23:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:23:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:23:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:23:45 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:23:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:23:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:23:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:23:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:23:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:23:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:23:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:23:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:23:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:23:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:23:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:23:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:23:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:23:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:23:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:23:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:23:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:23:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:24:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:24:21 --> Total execution time: 0.1342
DEBUG - 2020-09-16 15:24:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:24:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 15:24:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 15:24:24 --> Total execution time: 0.1572
DEBUG - 2020-09-16 15:24:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:24:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 15:24:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 15:24:26 --> Total execution time: 0.1638
DEBUG - 2020-09-16 15:24:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:24:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:24:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:24:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:24:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:24:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:24:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:24:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:24:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 15:24:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 15:24:34 --> Total execution time: 0.1538
DEBUG - 2020-09-16 15:24:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:24:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 15:24:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-09-16 15:24:37 --> Total execution time: 0.1598
DEBUG - 2020-09-16 15:24:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:24:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:24:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:24:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:24:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:24:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:24:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:24:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:24:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-16 15:25:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:25:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:25:45 --> Total execution time: 0.1322
DEBUG - 2020-09-16 15:25:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:25:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 15:25:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 15:25:48 --> Total execution time: 0.1623
DEBUG - 2020-09-16 15:25:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:25:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:25:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:26:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:26:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:26:15 --> Total execution time: 0.1632
DEBUG - 2020-09-16 15:26:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:26:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:26:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:26:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:26:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:26:44 --> Total execution time: 0.1519
DEBUG - 2020-09-16 15:26:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:26:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:27:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:27:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 15:27:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 15:27:02 --> Total execution time: 0.1251
DEBUG - 2020-09-16 15:27:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:27:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:27:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:27:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:27:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:27:14 --> Total execution time: 0.1627
DEBUG - 2020-09-16 15:27:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:27:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:27:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-16 15:27:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:27:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 15:27:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-16 15:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-16 15:27:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 15:27:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-16 15:27:32 --> Total execution time: 0.1676
DEBUG - 2020-09-16 15:27:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-16 15:27:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-16 15:27:34 --> 404 Page Not Found: Assets/chosen
