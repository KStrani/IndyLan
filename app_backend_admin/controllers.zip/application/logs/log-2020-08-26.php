<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-08-26 06:10:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 06:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 06:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 06:10:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 06:10:28 --> Total execution time: 0.1378
DEBUG - 2020-08-26 06:10:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 06:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 06:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 06:10:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 06:10:45 --> Total execution time: 0.1355
DEBUG - 2020-08-26 06:11:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 06:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 06:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 06:11:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 06:11:54 --> Total execution time: 0.1542
DEBUG - 2020-08-26 06:28:59 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 06:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 06:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 06:29:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 06:29:00 --> Total execution time: 0.1258
DEBUG - 2020-08-26 06:30:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 06:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 06:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 06:30:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 06:30:32 --> Total execution time: 0.1459
DEBUG - 2020-08-26 06:30:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 06:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 06:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 06:30:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 06:30:37 --> Total execution time: 0.1697
DEBUG - 2020-08-26 06:30:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 06:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 06:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 06:30:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 06:30:44 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-08-26 06:30:44 --> Total execution time: 0.1180
DEBUG - 2020-08-26 06:31:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 06:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 06:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 06:31:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 06:31:01 --> get_subcategory_list->{"lang":"37","category_id":"50","user_id":"767","support_lang_id":"3"}
DEBUG - 2020-08-26 06:31:01 --> Total execution time: 0.1309
DEBUG - 2020-08-26 06:31:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 06:31:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 06:31:04 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-08-26 06:31:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 06:31:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 06:31:07 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-08-26 06:31:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 06:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 06:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 06:31:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 06:31:16 --> get_exercise_type_list->{"lang":"37","subcategory_id":"269","support_lang_id":"3"}
ERROR - 2020-08-26 06:31:16 --> Query error: Unknown column 'type.type_seh' in 'field list' - Invalid query: select type.id, type.type_seh as type_name,type.image  from tbl_exercise_type type LEFT JOIN tbl_exercise_mode_categories_exercise ex ON type.id=ex.exercise_type_id where ex.category_id='269' AND ex.is_active='1' order by type.sequence asc
ERROR - 2020-08-26 06:31:16 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 280
DEBUG - 2020-08-26 06:31:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 06:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 06:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 06:31:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 06:31:20 --> get_subcategory_list->{"lang":"37","category_id":"50","user_id":"767","support_lang_id":"3"}
DEBUG - 2020-08-26 06:31:20 --> Total execution time: 0.1599
DEBUG - 2020-08-26 06:31:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 06:31:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 06:31:23 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-08-26 06:31:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 06:31:34 --> No URI present. Default controller set.
DEBUG - 2020-08-26 06:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 06:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 06:31:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 06:31:34 --> Total execution time: 0.1723
DEBUG - 2020-08-26 06:31:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 06:31:54 --> No URI present. Default controller set.
DEBUG - 2020-08-26 06:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 06:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 06:31:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 06:31:54 --> Total execution time: 0.1502
DEBUG - 2020-08-26 07:57:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 07:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 07:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 07:57:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 07:57:36 --> Total execution time: 0.1447
DEBUG - 2020-08-26 07:57:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 07:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 07:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 07:57:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 07:57:49 --> Total execution time: 0.1466
DEBUG - 2020-08-26 07:58:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 07:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 07:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 07:58:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 07:58:01 --> Total execution time: 0.1145
DEBUG - 2020-08-26 07:58:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 07:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 07:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 07:58:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 07:58:06 --> get_category_list->{"lang":"12","exercise_mode_id":"1","support_lang_id":"1"}
ERROR - 2020-08-26 07:58:06 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-26 07:58:06 --> Total execution time: 0.1410
DEBUG - 2020-08-26 07:58:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 07:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 07:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 07:58:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 07:58:11 --> Total execution time: 0.1351
DEBUG - 2020-08-26 07:58:13 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 07:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 07:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 07:58:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 07:58:13 --> Total execution time: 0.1318
DEBUG - 2020-08-26 07:58:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 07:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 07:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 07:58:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 07:58:20 --> Total execution time: 0.1396
DEBUG - 2020-08-26 08:00:50 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:00:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:00:50 --> Total execution time: 0.1484
DEBUG - 2020-08-26 08:00:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:00:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:00:53 --> Total execution time: 0.1481
DEBUG - 2020-08-26 08:01:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:01:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:01:01 --> Total execution time: 0.1276
DEBUG - 2020-08-26 08:14:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:14:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:14:06 --> Total execution time: 0.1421
DEBUG - 2020-08-26 08:14:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:14:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:14:11 --> Total execution time: 0.1183
DEBUG - 2020-08-26 08:14:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:14:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 08:14:15 --> 404 Page Not Found: Assets/languge
DEBUG - 2020-08-26 08:14:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:14:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 08:14:15 --> 404 Page Not Found: Assets/languge
DEBUG - 2020-08-26 08:14:17 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:14:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 08:14:17 --> 404 Page Not Found: Assets/languge
DEBUG - 2020-08-26 08:14:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:14:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 08:14:18 --> 404 Page Not Found: Assets/languge
DEBUG - 2020-08-26 08:14:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:14:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:14:31 --> Total execution time: 0.1259
DEBUG - 2020-08-26 08:14:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:14:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:14:41 --> Total execution time: 0.1720
DEBUG - 2020-08-26 08:14:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 08:14:44 --> 404 Page Not Found: Assets/languge
DEBUG - 2020-08-26 08:14:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 08:14:45 --> 404 Page Not Found: Assets/languge
DEBUG - 2020-08-26 08:14:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:14:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 08:14:47 --> 404 Page Not Found: Assets/languge
DEBUG - 2020-08-26 08:14:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 08:14:48 --> 404 Page Not Found: Assets/languge
DEBUG - 2020-08-26 08:20:26 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:20:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 08:20:26 --> 404 Page Not Found: Api/get_source_lang
DEBUG - 2020-08-26 08:20:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:20:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 08:20:32 --> 404 Page Not Found: Api/get_source_lang
DEBUG - 2020-08-26 08:20:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:20:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:20:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 08:20:40 --> 404 Page Not Found: Assets/languge
DEBUG - 2020-08-26 08:20:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 08:20:40 --> 404 Page Not Found: Assets/languge
DEBUG - 2020-08-26 08:20:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:20:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:20:41 --> Total execution time: 0.1703
DEBUG - 2020-08-26 08:20:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:20:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 08:20:42 --> 404 Page Not Found: Assets/languge
DEBUG - 2020-08-26 08:20:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:20:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 08:20:42 --> 404 Page Not Found: Assets/languge
DEBUG - 2020-08-26 08:21:17 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:21:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:21:17 --> Total execution time: 0.1329
DEBUG - 2020-08-26 08:26:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:26:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:26:46 --> Total execution time: 0.1430
DEBUG - 2020-08-26 08:27:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:27:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 08:27:06 --> 404 Page Not Found: Assets/languge
DEBUG - 2020-08-26 08:31:00 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:31:00 --> No URI present. Default controller set.
DEBUG - 2020-08-26 08:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:31:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:31:01 --> Total execution time: 0.1521
DEBUG - 2020-08-26 08:31:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:31:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:31:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:31:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:31:49 --> Total execution time: 0.1324
DEBUG - 2020-08-26 08:31:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:31:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 08:31:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-26 08:32:00 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:32:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:32:00 --> Total execution time: 0.1396
DEBUG - 2020-08-26 08:32:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:32:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 08:32:33 --> 404 Page Not Found: Assets/languge
DEBUG - 2020-08-26 08:32:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:32:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:32:43 --> Total execution time: 0.1732
DEBUG - 2020-08-26 08:32:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:32:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 08:32:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-26 08:33:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:33:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:33:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:33:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:33:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:33:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:33:11 --> Total execution time: 0.1335
DEBUG - 2020-08-26 08:33:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:33:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:33:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:33:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:33:24 --> Total execution time: 0.1417
DEBUG - 2020-08-26 08:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 08:33:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-26 08:33:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:33:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:33:39 --> Total execution time: 0.1568
DEBUG - 2020-08-26 08:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:33:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:33:41 --> Total execution time: 0.1404
DEBUG - 2020-08-26 08:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:33:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-26 08:33:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-08-26 08:33:42 --> Total execution time: 0.1742
DEBUG - 2020-08-26 08:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:33:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-26 08:33:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-08-26 08:33:43 --> Total execution time: 0.1884
DEBUG - 2020-08-26 08:33:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:33:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 08:33:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-26 08:33:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:33:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:33:52 --> Total execution time: 0.1331
DEBUG - 2020-08-26 08:33:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:33:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-26 08:33:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-08-26 08:33:54 --> Total execution time: 0.1539
DEBUG - 2020-08-26 08:33:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:33:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 08:33:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-26 08:35:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:35:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:35:07 --> Total execution time: 0.1474
DEBUG - 2020-08-26 08:35:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:35:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:35:08 --> Total execution time: 0.1495
DEBUG - 2020-08-26 08:35:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:35:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:35:10 --> Total execution time: 0.1321
DEBUG - 2020-08-26 08:35:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:35:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-26 08:35:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-08-26 08:35:11 --> Total execution time: 0.1610
DEBUG - 2020-08-26 08:35:14 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:35:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 08:35:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-26 08:35:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:35:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:35:20 --> Total execution time: 0.1540
DEBUG - 2020-08-26 08:35:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:35:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:35:23 --> Total execution time: 0.1287
DEBUG - 2020-08-26 08:35:26 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:35:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 08:35:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-26 08:50:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:50:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:50:05 --> Total execution time: 0.1123
DEBUG - 2020-08-26 08:50:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:50:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:50:11 --> Total execution time: 0.1607
DEBUG - 2020-08-26 08:58:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:58:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:58:55 --> Total execution time: 0.1270
DEBUG - 2020-08-26 08:59:00 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:59:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:59:00 --> Total execution time: 0.1270
DEBUG - 2020-08-26 08:59:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:59:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:59:09 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
ERROR - 2020-08-26 08:59:09 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-26 08:59:09 --> Total execution time: 0.1707
DEBUG - 2020-08-26 08:59:19 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 08:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 08:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 08:59:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 08:59:19 --> Total execution time: 0.1618
DEBUG - 2020-08-26 09:01:17 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:01:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:01:17 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
ERROR - 2020-08-26 09:01:17 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-26 09:01:17 --> Total execution time: 0.1123
DEBUG - 2020-08-26 09:01:26 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:01:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:01:26 --> Total execution time: 0.1131
DEBUG - 2020-08-26 09:01:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:01:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:01:27 --> Total execution time: 0.1190
DEBUG - 2020-08-26 09:01:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:01:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:01:36 --> Total execution time: 0.1429
DEBUG - 2020-08-26 09:01:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:01:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:01:40 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-08-26 09:01:40 --> Total execution time: 0.1304
DEBUG - 2020-08-26 09:02:02 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:02:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 09:02:02 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-08-26 09:02:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:02:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 09:02:06 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-08-26 09:02:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:02:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 09:02:16 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-08-26 09:02:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:02:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:02:21 --> get_subcategory_list->{"lang":"37","category_id":"50","user_id":"745","support_lang_id":"3"}
DEBUG - 2020-08-26 09:02:21 --> Total execution time: 0.1270
DEBUG - 2020-08-26 09:02:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:02:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:02:24 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-08-26 09:02:24 --> Total execution time: 0.1357
DEBUG - 2020-08-26 09:02:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:02:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 09:02:30 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-08-26 09:02:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:02:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 09:02:31 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-08-26 09:02:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:02:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:02:31 --> get_subcategory_list->{"lang":"37","category_id":"120","user_id":"745","support_lang_id":"3"}
DEBUG - 2020-08-26 09:02:31 --> Total execution time: 0.1243
DEBUG - 2020-08-26 09:02:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:02:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 09:02:32 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-08-26 09:02:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:02:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 09:02:34 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-08-26 09:02:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:02:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:02:35 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-08-26 09:02:35 --> Total execution time: 0.1332
DEBUG - 2020-08-26 09:02:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:02:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:02:40 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-08-26 09:02:40 --> Total execution time: 0.1368
DEBUG - 2020-08-26 09:02:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:02:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 09:02:41 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-08-26 09:02:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:02:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 09:02:44 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-08-26 09:02:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:02:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 09:02:48 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-08-26 09:02:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:02:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 09:02:52 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-08-26 09:03:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:03:23 --> Total execution time: 0.1001
DEBUG - 2020-08-26 09:03:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:03:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:03:28 --> Total execution time: 0.1158
DEBUG - 2020-08-26 09:03:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:03:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:03:30 --> Total execution time: 0.1254
DEBUG - 2020-08-26 09:08:19 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:08:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:08:19 --> Total execution time: 0.1133
DEBUG - 2020-08-26 09:10:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:10:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:10:42 --> Total execution time: 0.1502
DEBUG - 2020-08-26 09:10:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:10:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:10:48 --> Total execution time: 0.1101
DEBUG - 2020-08-26 09:11:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:11:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:11:15 --> Total execution time: 0.1212
DEBUG - 2020-08-26 09:37:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:37:24 --> No URI present. Default controller set.
DEBUG - 2020-08-26 09:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:37:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:37:24 --> Total execution time: 0.1277
DEBUG - 2020-08-26 09:38:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:38:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:38:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:38:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:38:32 --> Total execution time: 0.1609
DEBUG - 2020-08-26 09:38:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 09:38:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-26 09:54:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:54:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:54:31 --> user_login->{"email":"admin@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2020-08-26 09:54:31 --> Total execution time: 0.1659
DEBUG - 2020-08-26 09:54:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:54:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:54:33 --> Total execution time: 0.1283
DEBUG - 2020-08-26 09:54:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:54:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:54:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:54:54 --> Total execution time: 0.2009
DEBUG - 2020-08-26 09:54:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:54:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:54:57 --> Total execution time: 0.1507
DEBUG - 2020-08-26 09:55:00 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 09:55:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-26 09:55:17 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:55:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:55:18 --> Total execution time: 0.1834
DEBUG - 2020-08-26 09:55:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:55:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 09:55:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-26 09:57:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:57:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:57:34 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:57:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:57:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:57:37 --> Total execution time: 0.1623
DEBUG - 2020-08-26 09:57:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:57:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 09:57:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-26 09:57:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:57:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:57:54 --> Total execution time: 0.1263
DEBUG - 2020-08-26 09:58:02 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:58:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:58:02 --> Total execution time: 0.1415
DEBUG - 2020-08-26 09:58:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 09:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 09:58:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:58:05 --> Total execution time: 0.1640
DEBUG - 2020-08-26 09:58:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 09:58:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 09:58:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-26 10:01:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 10:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 10:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 10:01:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 10:01:29 --> Total execution time: 0.1512
DEBUG - 2020-08-26 10:06:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 10:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 10:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 10:06:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 10:06:02 --> Total execution time: 0.1336
DEBUG - 2020-08-26 10:06:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 10:06:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 10:06:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-26 10:06:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 10:06:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 10:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 10:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 10:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 10:06:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 10:06:11 --> Total execution time: 0.1505
DEBUG - 2020-08-26 10:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 10:06:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-26 10:06:11 --> Query error: Unknown column 'mode_name' in 'order clause' - Invalid query: SELECT *
FROM `tbl_exercise_type`
WHERE `exercise_mode_id` = '1'
ORDER BY `mode_name` ASC
ERROR - 2020-08-26 10:06:11 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 896
DEBUG - 2020-08-26 10:07:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 10:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 10:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 10:07:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 10:07:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 10:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 10:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 10:07:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 10:07:49 --> Total execution time: 0.1666
DEBUG - 2020-08-26 10:07:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 10:07:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 10:07:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-26 10:08:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 10:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 10:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 10:08:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 10:08:11 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-26 10:08:11 --> Total execution time: 0.1511
DEBUG - 2020-08-26 10:08:17 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 10:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 10:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 10:08:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 10:08:17 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-26 10:08:17 --> Total execution time: 0.1190
DEBUG - 2020-08-26 10:08:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 10:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 10:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 10:08:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 10:08:23 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
ERROR - 2020-08-26 10:08:23 --> Query error: Unknown column 'type.type_seh' in 'field list' - Invalid query: select type.id, type.type_seh as type_name,type.image  from tbl_exercise_type type LEFT JOIN tbl_exercise_mode_categories_exercise ex ON type.id=ex.exercise_type_id where ex.category_id='273' AND ex.is_active='1' order by type.sequence asc
ERROR - 2020-08-26 10:08:23 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 280
DEBUG - 2020-08-26 10:08:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 10:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 10:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 10:08:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 10:08:36 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-26 10:08:36 --> Total execution time: 0.1416
DEBUG - 2020-08-26 10:10:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 10:10:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 10:10:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-26 10:10:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 10:10:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 10:10:06 --> 404 Page Not Found: Assets/js
DEBUG - 2020-08-26 10:12:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 10:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 10:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 10:12:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 10:12:07 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-26 10:12:07 --> Total execution time: 0.1158
DEBUG - 2020-08-26 10:12:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 10:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 10:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 10:12:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 10:12:12 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-26 10:12:12 --> Total execution time: 0.1415
DEBUG - 2020-08-26 10:12:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 10:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 10:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 10:12:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 10:12:16 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
ERROR - 2020-08-26 10:12:16 --> Query error: Unknown column 'type.type_seh' in 'field list' - Invalid query: select type.id, type.type_seh as type_name,type.image  from tbl_exercise_type type LEFT JOIN tbl_exercise_mode_categories_exercise ex ON type.id=ex.exercise_type_id where ex.category_id='273' AND ex.is_active='1' order by type.sequence asc
ERROR - 2020-08-26 10:12:16 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 280
DEBUG - 2020-08-26 10:16:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 10:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 10:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 10:16:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 10:16:11 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-26 10:16:11 --> Total execution time: 0.1617
DEBUG - 2020-08-26 10:16:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 10:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 10:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 10:16:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 10:16:16 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-26 10:16:16 --> Total execution time: 0.1452
DEBUG - 2020-08-26 10:17:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 10:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 10:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 10:17:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 10:17:12 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-26 10:17:12 --> Total execution time: 0.1445
DEBUG - 2020-08-26 10:17:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 10:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 10:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 10:17:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 10:17:16 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-26 10:17:16 --> Total execution time: 0.1463
DEBUG - 2020-08-26 10:17:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 10:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 10:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 10:17:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 10:17:21 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"2","exercise_mode_id":"1","category_id":"123","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-26 10:17:21 --> Total execution time: 0.1535
DEBUG - 2020-08-26 11:36:26 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 11:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 11:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 11:36:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 11:36:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 11:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 11:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 11:36:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 11:36:30 --> Total execution time: 0.1749
DEBUG - 2020-08-26 12:59:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 12:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 12:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 12:59:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 12:59:38 --> Total execution time: 0.1233
DEBUG - 2020-08-26 12:59:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 12:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 12:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 12:59:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 12:59:42 --> Total execution time: 0.0884
DEBUG - 2020-08-26 12:59:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 12:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 12:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 12:59:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 12:59:52 --> Total execution time: 0.1371
DEBUG - 2020-08-26 12:59:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 12:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 12:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 12:59:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 12:59:54 --> Total execution time: 0.1174
DEBUG - 2020-08-26 12:59:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 12:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 12:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 12:59:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 12:59:58 --> Total execution time: 0.1310
DEBUG - 2020-08-26 13:00:03 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 13:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 13:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 13:00:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 13:00:03 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-08-26 13:00:03 --> Total execution time: 0.1037
DEBUG - 2020-08-26 13:00:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 13:00:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 13:00:10 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-08-26 13:00:13 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 13:00:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 13:00:13 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-08-26 13:00:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 13:00:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 13:00:18 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-08-26 13:00:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 13:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 13:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 13:00:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 13:00:19 --> get_subcategory_list->{"lang":"37","category_id":"120","user_id":"767","support_lang_id":"3"}
DEBUG - 2020-08-26 13:00:19 --> Total execution time: 0.1436
DEBUG - 2020-08-26 13:00:19 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 13:00:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 13:00:19 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-08-26 13:00:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 13:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 13:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 13:00:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 13:00:23 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-08-26 13:00:23 --> Total execution time: 0.1545
DEBUG - 2020-08-26 13:00:26 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 13:00:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 13:00:26 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-08-26 13:00:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 13:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 13:00:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 13:00:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 13:00:29 --> get_subcategory_list->{"lang":"37","category_id":"50","user_id":"767","support_lang_id":"3"}
DEBUG - 2020-08-26 13:00:29 --> Total execution time: 0.1656
DEBUG - 2020-08-26 13:00:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 13:00:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 13:00:32 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-08-26 13:00:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 13:00:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 13:00:35 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-08-26 13:00:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 13:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 13:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 13:00:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 13:00:49 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-08-26 13:00:49 --> Total execution time: 0.1380
DEBUG - 2020-08-26 13:03:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 13:03:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 13:03:15 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-08-26 13:03:19 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 13:03:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-26 13:03:19 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-08-26 13:03:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 13:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 13:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 13:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 13:03:23 --> Total execution time: 0.1378
DEBUG - 2020-08-26 13:03:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 13:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 13:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 13:03:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 13:03:36 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-08-26 13:03:36 --> Total execution time: 0.1468
DEBUG - 2020-08-26 13:03:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 13:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 13:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 13:03:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 13:03:39 --> Total execution time: 0.1730
DEBUG - 2020-08-26 18:31:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-26 18:31:08 --> No URI present. Default controller set.
DEBUG - 2020-08-26 18:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-26 18:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-26 18:31:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 18:31:08 --> Total execution time: 0.1381
