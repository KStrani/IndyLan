<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-10-13 04:58:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 04:58:47 --> No URI present. Default controller set.
DEBUG - 2020-10-13 04:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 04:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 04:58:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 04:58:47 --> Total execution time: 0.1453
DEBUG - 2020-10-13 05:01:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 05:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 05:01:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 05:02:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 05:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 05:02:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 05:02:05 --> Total execution time: 0.1213
DEBUG - 2020-10-13 05:02:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:02:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 05:02:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 05:02:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:02:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 05:02:11 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-13 05:02:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:02:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 05:02:14 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-10-13 05:02:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 05:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 05:02:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 05:02:22 --> Total execution time: 0.1349
DEBUG - 2020-10-13 05:02:25 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 05:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 05:02:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 05:02:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 05:02:25 --> Total execution time: 0.1244
DEBUG - 2020-10-13 05:02:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:02:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 05:02:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 05:02:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 05:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 05:02:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 05:02:49 --> Total execution time: 0.1396
DEBUG - 2020-10-13 05:02:53 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 05:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 05:02:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 05:02:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-10-13 05:02:53 --> Total execution time: 0.1962
DEBUG - 2020-10-13 05:02:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 05:02:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 05:02:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:02:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 05:02:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 05:02:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:02:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 05:02:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 05:02:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:02:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 05:02:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 05:02:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:02:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:02:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:02:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 05:02:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 05:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 05:02:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 05:02:59 --> 404 Page Not Found: Uploads/words
ERROR - 2020-10-13 05:02:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 05:02:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:02:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 05:02:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 05:03:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:03:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 05:03:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 05:03:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 05:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 05:03:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 05:03:04 --> Total execution time: 0.1144
DEBUG - 2020-10-13 05:03:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 05:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 05:03:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 05:03:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-10-13 05:03:07 --> Total execution time: 0.1438
DEBUG - 2020-10-13 05:03:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:03:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 05:03:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 05:35:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:35:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 05:35:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 05:35:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:35:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 05:35:48 --> 404 Page Not Found: Assets/js
DEBUG - 2020-10-13 05:54:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 05:54:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 05:54:44 --> 404 Page Not Found: Assets/js
DEBUG - 2020-10-13 06:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:01:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:01:08 --> Total execution time: 0.1569
DEBUG - 2020-10-13 06:01:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:01:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:01:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:01:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:01:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:01:24 --> Total execution time: 0.1859
DEBUG - 2020-10-13 06:01:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:01:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:01:28 --> Total execution time: 0.1550
DEBUG - 2020-10-13 06:01:31 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:01:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:01:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 06:01:31 --> Total execution time: 0.1362
DEBUG - 2020-10-13 06:01:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:01:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:01:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:02:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:02:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:02:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 06:02:22 --> Total execution time: 0.1445
DEBUG - 2020-10-13 06:02:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:02:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:02:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:02:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:02:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:02:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 06:02:34 --> Total execution time: 0.1360
DEBUG - 2020-10-13 06:02:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:02:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:02:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 06:02:37 --> Total execution time: 0.1676
DEBUG - 2020-10-13 06:02:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:02:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:03:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:03:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:03:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 06:03:18 --> Total execution time: 0.1682
DEBUG - 2020-10-13 06:03:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:03:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:03:19 --> Total execution time: 0.1463
DEBUG - 2020-10-13 06:03:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:03:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:03:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 06:03:21 --> Total execution time: 0.1415
DEBUG - 2020-10-13 06:03:25 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:03:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:03:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:03:31 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:03:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:03:31 --> Total execution time: 0.1583
DEBUG - 2020-10-13 06:03:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:03:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:03:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:03:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:03:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:03:42 --> Total execution time: 0.1087
DEBUG - 2020-10-13 06:04:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:04:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:04:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:04:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:04:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 06:04:08 --> Total execution time: 0.1425
DEBUG - 2020-10-13 06:04:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:04:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:04:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:04:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:04:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:04:49 --> Total execution time: 0.1316
DEBUG - 2020-10-13 06:04:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:04:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:04:54 --> Total execution time: 0.1295
DEBUG - 2020-10-13 06:05:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:05:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:05:02 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"1"}
DEBUG - 2020-10-13 06:05:02 --> Total execution time: 0.1033
DEBUG - 2020-10-13 06:05:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:05:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:05:05 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-13 06:05:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:05:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:05:07 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-13 06:05:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:05:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:05:09 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"1","support_lang_id":"1"}
DEBUG - 2020-10-13 06:05:09 --> Total execution time: 0.1509
DEBUG - 2020-10-13 06:05:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:05:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:05:13 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"1"}
DEBUG - 2020-10-13 06:05:13 --> Total execution time: 0.1522
DEBUG - 2020-10-13 06:05:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:05:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:05:18 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"1"}
DEBUG - 2020-10-13 06:05:18 --> Total execution time: 0.1227
DEBUG - 2020-10-13 06:05:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:05:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:05:29 --> Total execution time: 0.1224
DEBUG - 2020-10-13 06:05:31 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:05:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:05:31 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"1"}
DEBUG - 2020-10-13 06:05:31 --> Total execution time: 0.1186
DEBUG - 2020-10-13 06:05:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:05:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:05:42 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"1","support_lang_id":"1"}
DEBUG - 2020-10-13 06:05:42 --> Total execution time: 0.1383
DEBUG - 2020-10-13 06:05:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:05:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:05:43 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"1"}
DEBUG - 2020-10-13 06:05:43 --> Total execution time: 0.1651
DEBUG - 2020-10-13 06:05:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:05:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:05:46 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-13 06:05:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:05:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:05:48 --> Total execution time: 0.1156
DEBUG - 2020-10-13 06:05:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:05:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:05:48 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-13 06:05:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:05:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:05:48 --> Total execution time: 0.1096
DEBUG - 2020-10-13 06:05:53 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:05:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:05:53 --> Total execution time: 0.1131
DEBUG - 2020-10-13 06:05:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:05:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:05:56 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-13 06:05:56 --> Total execution time: 0.1236
DEBUG - 2020-10-13 06:06:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:06:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:06:00 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-13 06:06:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:06:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:06:03 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-13 06:06:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:06:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:06:04 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-13 06:06:04 --> Total execution time: 0.1139
DEBUG - 2020-10-13 06:06:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:06:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:06:06 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-13 06:06:06 --> Total execution time: 0.1770
DEBUG - 2020-10-13 06:06:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:06:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:06:09 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-13 06:06:09 --> Total execution time: 0.1618
DEBUG - 2020-10-13 06:06:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:06:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:06:10 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-13 06:06:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:06:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:06:11 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-13 06:06:11 --> Total execution time: 0.1255
DEBUG - 2020-10-13 06:06:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:06:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:06:12 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-13 06:06:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:06:18 --> UTF-8 Support Enabled
ERROR - 2020-10-13 06:06:18 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-13 06:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:06:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:06:19 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-13 06:06:19 --> Total execution time: 0.1423
DEBUG - 2020-10-13 06:06:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:06:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:06:21 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-13 06:06:25 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:06:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:06:25 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-13 06:06:25 --> Total execution time: 0.1198
DEBUG - 2020-10-13 06:06:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:06:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:06:29 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-13 06:06:29 --> Total execution time: 0.1301
DEBUG - 2020-10-13 06:07:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:07:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:07:01 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-13 06:07:01 --> Total execution time: 0.1338
DEBUG - 2020-10-13 06:07:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:07:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:07:01 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-13 06:07:01 --> Total execution time: 0.1544
DEBUG - 2020-10-13 06:07:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:07:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:07:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:07:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:07:02 --> Total execution time: 0.1242
DEBUG - 2020-10-13 06:07:02 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-13 06:07:02 --> Total execution time: 0.1039
DEBUG - 2020-10-13 06:07:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:07:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:07:02 --> Total execution time: 0.1000
DEBUG - 2020-10-13 06:07:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:07:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:07:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 06:07:21 --> Total execution time: 0.1401
DEBUG - 2020-10-13 06:07:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:07:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:07:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:07:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:07:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:07:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 06:07:29 --> Total execution time: 0.1976
DEBUG - 2020-10-13 06:07:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:07:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:07:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:12:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:12:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:12:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:12:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:14:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:14:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:14:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 06:14:42 --> Total execution time: 0.1721
DEBUG - 2020-10-13 06:14:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:14:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:14:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:15:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:15:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:15:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:15:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:15:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:15:01 --> 404 Page Not Found: Assets/js
DEBUG - 2020-10-13 06:15:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:15:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:15:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 06:15:05 --> Total execution time: 0.1635
DEBUG - 2020-10-13 06:15:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:15:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:15:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 06:15:09 --> Total execution time: 0.1380
DEBUG - 2020-10-13 06:15:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:15:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:15:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:15:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:15:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:15:14 --> 404 Page Not Found: Assets/js
DEBUG - 2020-10-13 06:16:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:16:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:16:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 06:16:10 --> Total execution time: 0.1391
DEBUG - 2020-10-13 06:16:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:16:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:16:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:16:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:16:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:16:33 --> Total execution time: 0.1768
DEBUG - 2020-10-13 06:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:16:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:16:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 06:16:34 --> Total execution time: 0.1354
DEBUG - 2020-10-13 06:16:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:16:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:16:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:16:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:16:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:16:43 --> Total execution time: 0.1326
DEBUG - 2020-10-13 06:16:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:16:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:16:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 06:16:46 --> Total execution time: 0.1697
DEBUG - 2020-10-13 06:16:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:16:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:16:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:16:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:16:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:16:54 --> Total execution time: 0.1568
DEBUG - 2020-10-13 06:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:16:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:16:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 06:16:57 --> Total execution time: 0.1286
DEBUG - 2020-10-13 06:16:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:16:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:16:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:17:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:17:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:17:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 06:17:05 --> Total execution time: 0.1776
DEBUG - 2020-10-13 06:17:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:17:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:17:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 06:17:08 --> Total execution time: 0.1158
DEBUG - 2020-10-13 06:17:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:17:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:17:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:17:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:17:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:17:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 06:17:16 --> Total execution time: 0.1630
DEBUG - 2020-10-13 06:17:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:17:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:17:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 06:17:19 --> Total execution time: 0.1715
DEBUG - 2020-10-13 06:17:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:17:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:17:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:17:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:17:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:17:41 --> Total execution time: 0.1241
DEBUG - 2020-10-13 06:17:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:17:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:17:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-10-13 06:17:44 --> Total execution time: 0.1631
DEBUG - 2020-10-13 06:17:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:17:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:17:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:18:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:18:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:18:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-10-13 06:18:03 --> Total execution time: 0.1354
DEBUG - 2020-10-13 06:18:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:18:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:18:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:18:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:18:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:18:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:18:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:18:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:18:15 --> 404 Page Not Found: Assets/js
DEBUG - 2020-10-13 06:23:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:23:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:23:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-10-13 06:23:08 --> Total execution time: 0.1400
DEBUG - 2020-10-13 06:23:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:23:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:23:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:29:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:29:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:29:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-10-13 06:29:18 --> Total execution time: 0.1752
DEBUG - 2020-10-13 06:29:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:29:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:29:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:29:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:29:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:29:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 06:29:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:29:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:29:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 06:29:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:29:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:29:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:29:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 06:29:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:29:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 06:29:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:29:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:29:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:29:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:29:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 06:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:29:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:29:25 --> 404 Page Not Found: Uploads/words
ERROR - 2020-10-13 06:29:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 06:29:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:29:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:29:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 06:34:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:34:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:34:11 --> Total execution time: 0.1121
DEBUG - 2020-10-13 06:34:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:34:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:34:16 --> Total execution time: 0.1126
DEBUG - 2020-10-13 06:34:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:34:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:34:22 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-10-13 06:34:22 --> Total execution time: 0.1271
DEBUG - 2020-10-13 06:34:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:34:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:34:28 --> get_subcategory_list->{"lang":"37","category_id":"89","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-13 06:34:28 --> Total execution time: 0.1090
DEBUG - 2020-10-13 06:34:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:34:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:34:33 --> get_exercise_type_list->{"lang":"37","subcategory_id":"97","support_lang_id":"3"}
DEBUG - 2020-10-13 06:34:33 --> Total execution time: 0.1410
DEBUG - 2020-10-13 06:34:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:34:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:34:38 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"89","subcategory_id":"97","support_lang_id":"3"}
DEBUG - 2020-10-13 06:34:38 --> Total execution time: 0.1478
DEBUG - 2020-10-13 06:34:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:34:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:34:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 06:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:34:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 06:34:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:34:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:34:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:34:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 06:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:34:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:34:47 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"89","subcategory_id":"97","support_lang_id":"3"}
DEBUG - 2020-10-13 06:34:47 --> Total execution time: 0.1439
DEBUG - 2020-10-13 06:34:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:34:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:34:49 --> get_exercise_type_list->{"lang":"37","subcategory_id":"97","support_lang_id":"3"}
DEBUG - 2020-10-13 06:34:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:34:49 --> Total execution time: 0.1135
DEBUG - 2020-10-13 06:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:34:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:34:49 --> get_subcategory_list->{"lang":"37","category_id":"89","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-13 06:34:49 --> Total execution time: 0.1127
DEBUG - 2020-10-13 06:34:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:34:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:34:50 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-10-13 06:34:50 --> Total execution time: 0.1065
DEBUG - 2020-10-13 06:34:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:34:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:34:51 --> Total execution time: 0.1299
DEBUG - 2020-10-13 06:34:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:34:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:34:51 --> Total execution time: 0.1554
DEBUG - 2020-10-13 06:34:57 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:34:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:34:57 --> Total execution time: 0.1408
DEBUG - 2020-10-13 06:35:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:35:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:35:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:35:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:35:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:35:08 --> Total execution time: 0.1727
DEBUG - 2020-10-13 06:35:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:35:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:35:45 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:35:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:35:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-10-13 06:35:45 --> Total execution time: 0.1456
DEBUG - 2020-10-13 06:35:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:35:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:35:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:35:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:35:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:35:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 06:35:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:35:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:35:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 06:35:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:35:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:35:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:35:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:35:51 --> 404 Page Not Found: Uploads/words
ERROR - 2020-10-13 06:35:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 06:35:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:35:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:35:51 --> 404 Page Not Found: Uploads/words
ERROR - 2020-10-13 06:35:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 06:35:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:35:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:35:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 06:35:53 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:35:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:35:53 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 06:37:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:37:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:37:48 --> Total execution time: 0.0967
DEBUG - 2020-10-13 06:37:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:37:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:37:54 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"1"}
DEBUG - 2020-10-13 06:37:54 --> Total execution time: 0.1469
DEBUG - 2020-10-13 06:37:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:37:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:37:58 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"1","support_lang_id":"1"}
DEBUG - 2020-10-13 06:37:58 --> Total execution time: 0.1258
DEBUG - 2020-10-13 06:38:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:38:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:38:02 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"1"}
DEBUG - 2020-10-13 06:38:02 --> Total execution time: 0.1035
DEBUG - 2020-10-13 06:38:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:38:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:38:06 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"1"}
DEBUG - 2020-10-13 06:38:06 --> Total execution time: 0.1765
DEBUG - 2020-10-13 06:38:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:38:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:38:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 06:38:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:38:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:38:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:38:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 06:38:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:38:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 06:38:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:38:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:38:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 06:38:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:38:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:38:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 06:38:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:38:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:38:15 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"1"}
DEBUG - 2020-10-13 06:38:15 --> Total execution time: 0.1265
DEBUG - 2020-10-13 06:38:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:38:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:38:17 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"1"}
DEBUG - 2020-10-13 06:38:17 --> Total execution time: 0.1401
DEBUG - 2020-10-13 06:38:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:38:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:38:17 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"1","support_lang_id":"1"}
DEBUG - 2020-10-13 06:38:17 --> Total execution time: 0.1358
DEBUG - 2020-10-13 06:38:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:38:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:38:18 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"1"}
DEBUG - 2020-10-13 06:38:18 --> Total execution time: 0.1538
DEBUG - 2020-10-13 06:39:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:39:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 06:39:15 --> Total execution time: 0.1269
DEBUG - 2020-10-13 06:39:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:39:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:39:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-10-13 06:39:18 --> Total execution time: 0.1482
DEBUG - 2020-10-13 06:39:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:39:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:39:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 06:58:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 06:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 06:58:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 06:58:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-10-13 06:58:15 --> Total execution time: 0.1576
DEBUG - 2020-10-13 06:58:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 06:58:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 06:58:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 07:00:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:00:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 07:00:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-10-13 07:00:15 --> Total execution time: 0.1264
DEBUG - 2020-10-13 07:00:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:00:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 07:00:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 07:00:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:00:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 07:00:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 07:00:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:00:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 07:00:48 --> 404 Page Not Found: Assets/js
DEBUG - 2020-10-13 07:01:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:01:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:01:11 --> Total execution time: 0.1214
DEBUG - 2020-10-13 07:01:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:01:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 07:01:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 07:01:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:01:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:01:27 --> Total execution time: 0.1278
DEBUG - 2020-10-13 07:01:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:01:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:01:29 --> Total execution time: 0.1228
DEBUG - 2020-10-13 07:04:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:04:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 07:04:36 --> Query error: Unknown column 'target_language_id' in 'field list' - Invalid query: INSERT INTO `tbl_dialogue_list` (`dialogue_master_id`, `phrase`, `audio_name`, `speaker`, `sequence_no`, `target_language_id`) VALUES (212, 'Hello I am tester ?', 'test', '1', 1, '37')
ERROR - 2020-10-13 07:04:36 --> Query error: Unknown column 'target_language_id' in 'field list' - Invalid query: INSERT INTO `tbl_dialogue_list` (`dialogue_master_id`, `phrase`, `audio_name`, `speaker`, `sequence_no`, `target_language_id`) VALUES (212, 'Hello I am tester ?', 'test', '2', 2, '37')
DEBUG - 2020-10-13 07:04:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:04:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 07:04:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-10-13 07:04:39 --> Total execution time: 0.1727
DEBUG - 2020-10-13 07:04:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:04:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 07:04:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 07:10:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:10:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 07:10:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-10-13 07:10:05 --> Total execution time: 0.1274
DEBUG - 2020-10-13 07:10:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:10:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 07:10:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 07:11:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:11:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 07:11:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 07:11:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:11:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 07:11:12 --> 404 Page Not Found: Assets/js
DEBUG - 2020-10-13 07:19:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:19:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:19:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:19:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 07:19:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-10-13 07:19:30 --> Total execution time: 0.2082
DEBUG - 2020-10-13 07:19:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:19:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 07:19:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-10-13 07:19:30 --> Total execution time: 0.1799
DEBUG - 2020-10-13 07:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:19:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 07:19:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-10-13 07:19:30 --> Total execution time: 0.2017
DEBUG - 2020-10-13 07:19:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:19:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 07:19:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-10-13 07:19:30 --> Total execution time: 0.1412
DEBUG - 2020-10-13 07:19:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:19:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 07:19:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 07:19:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:19:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 07:19:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-10-13 07:19:43 --> Total execution time: 0.1506
DEBUG - 2020-10-13 07:19:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:19:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 07:19:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 07:19:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:19:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 07:19:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-10-13 07:19:55 --> Total execution time: 0.1967
DEBUG - 2020-10-13 07:19:57 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:19:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 07:19:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-10-13 07:19:57 --> Total execution time: 0.1706
DEBUG - 2020-10-13 07:20:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:20:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 07:20:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 07:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:20:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:20:36 --> Total execution time: 0.1043
DEBUG - 2020-10-13 07:20:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:20:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:20:41 --> Total execution time: 0.1240
DEBUG - 2020-10-13 07:20:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:20:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:20:51 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"1"}
DEBUG - 2020-10-13 07:20:51 --> Total execution time: 0.1225
DEBUG - 2020-10-13 07:20:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:20:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:20:57 --> get_subcategory_list->{"lang":"37","category_id":"98","user_id":"1","support_lang_id":"1"}
DEBUG - 2020-10-13 07:20:57 --> Total execution time: 0.1095
DEBUG - 2020-10-13 07:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:21:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:21:00 --> get_exercise_type_list->{"lang":"37","subcategory_id":"235","support_lang_id":"1"}
DEBUG - 2020-10-13 07:21:00 --> Total execution time: 0.1253
DEBUG - 2020-10-13 07:21:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:21:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:21:06 --> get_dialogue_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"2","category_id":"98","subcategory_id":"235","support_lang_id":"1"}
ERROR - 2020-10-13 07:21:06 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-13 07:21:06 --> Total execution time: 0.1249
DEBUG - 2020-10-13 07:21:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:21:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:21:11 --> get_exercise_type_list->{"lang":"37","subcategory_id":"235","support_lang_id":"1"}
DEBUG - 2020-10-13 07:21:11 --> Total execution time: 0.1376
DEBUG - 2020-10-13 07:21:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:21:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:21:15 --> get_dialogue_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"2","category_id":"98","subcategory_id":"235","support_lang_id":"1"}
ERROR - 2020-10-13 07:21:15 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-13 07:21:15 --> Total execution time: 0.0983
DEBUG - 2020-10-13 07:21:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:21:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:21:20 --> get_exercise_type_list->{"lang":"37","subcategory_id":"235","support_lang_id":"1"}
DEBUG - 2020-10-13 07:21:20 --> Total execution time: 0.1551
DEBUG - 2020-10-13 07:21:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:21:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:21:22 --> get_subcategory_list->{"lang":"37","category_id":"98","user_id":"1","support_lang_id":"1"}
DEBUG - 2020-10-13 07:21:22 --> Total execution time: 0.1164
DEBUG - 2020-10-13 07:21:23 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:21:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:21:23 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"1"}
DEBUG - 2020-10-13 07:21:23 --> Total execution time: 0.1326
DEBUG - 2020-10-13 07:21:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:21:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:21:27 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"1"}
DEBUG - 2020-10-13 07:21:27 --> Total execution time: 0.1287
DEBUG - 2020-10-13 07:21:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:21:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:21:34 --> Total execution time: 0.1769
DEBUG - 2020-10-13 07:21:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:21:36 --> Total execution time: 0.1133
DEBUG - 2020-10-13 07:21:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:21:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:21:40 --> Total execution time: 0.1565
DEBUG - 2020-10-13 07:21:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:21:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:21:44 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2020-10-13 07:21:44 --> Total execution time: 0.1114
DEBUG - 2020-10-13 07:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:21:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:21:50 --> get_subcategory_list->{"lang":"37","category_id":"95","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-13 07:21:50 --> Total execution time: 0.1339
DEBUG - 2020-10-13 07:21:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:21:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:21:59 --> get_exercise_type_list->{"lang":"37","subcategory_id":"234","support_lang_id":"3"}
DEBUG - 2020-10-13 07:21:59 --> Total execution time: 0.1353
DEBUG - 2020-10-13 07:22:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:22:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:22:03 --> get_dialogue_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"2","category_id":"95","subcategory_id":"234","support_lang_id":"3"}
DEBUG - 2020-10-13 07:22:03 --> Total execution time: 0.1008
DEBUG - 2020-10-13 07:22:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:22:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:22:08 --> get_exercise_type_list->{"lang":"37","subcategory_id":"234","support_lang_id":"3"}
DEBUG - 2020-10-13 07:22:08 --> Total execution time: 0.1383
DEBUG - 2020-10-13 07:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:22:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:22:10 --> get_subcategory_list->{"lang":"37","category_id":"95","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-13 07:22:10 --> Total execution time: 0.1248
DEBUG - 2020-10-13 07:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:22:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:22:10 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2020-10-13 07:22:10 --> Total execution time: 0.1109
DEBUG - 2020-10-13 07:22:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:22:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:22:13 --> Total execution time: 0.1371
DEBUG - 2020-10-13 07:22:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:22:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:22:13 --> Total execution time: 0.1116
DEBUG - 2020-10-13 07:22:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:22:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:22:17 --> Total execution time: 0.1651
DEBUG - 2020-10-13 07:22:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:22:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:22:22 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"1"}
DEBUG - 2020-10-13 07:22:22 --> Total execution time: 0.1431
DEBUG - 2020-10-13 07:22:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:22:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:22:28 --> get_subcategory_list->{"lang":"37","category_id":"94","user_id":"1","support_lang_id":"1"}
DEBUG - 2020-10-13 07:22:28 --> Total execution time: 0.1349
DEBUG - 2020-10-13 07:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:22:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:22:34 --> get_exercise_type_list->{"lang":"37","subcategory_id":"232","support_lang_id":"1"}
DEBUG - 2020-10-13 07:22:34 --> Total execution time: 0.1347
DEBUG - 2020-10-13 07:22:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:22:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:22:37 --> get_dialogue_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"2","category_id":"94","subcategory_id":"232","support_lang_id":"1"}
ERROR - 2020-10-13 07:22:37 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-13 07:22:37 --> Total execution time: 0.1393
DEBUG - 2020-10-13 07:22:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:22:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:22:41 --> get_exercise_type_list->{"lang":"37","subcategory_id":"232","support_lang_id":"1"}
DEBUG - 2020-10-13 07:22:41 --> Total execution time: 0.1093
DEBUG - 2020-10-13 07:22:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:22:46 --> get_dialogue_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"2","category_id":"94","subcategory_id":"232","support_lang_id":"1"}
ERROR - 2020-10-13 07:22:46 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-13 07:22:46 --> Total execution time: 0.1403
DEBUG - 2020-10-13 07:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:22:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:22:47 --> get_exercise_type_list->{"lang":"37","subcategory_id":"232","support_lang_id":"1"}
DEBUG - 2020-10-13 07:22:47 --> Total execution time: 0.1119
DEBUG - 2020-10-13 07:22:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:22:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:22:49 --> get_subcategory_list->{"lang":"37","category_id":"94","user_id":"1","support_lang_id":"1"}
DEBUG - 2020-10-13 07:22:49 --> Total execution time: 0.1002
DEBUG - 2020-10-13 07:22:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:22:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:22:52 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"1"}
DEBUG - 2020-10-13 07:22:52 --> Total execution time: 0.1160
DEBUG - 2020-10-13 07:22:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:22:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:22:56 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"1"}
DEBUG - 2020-10-13 07:22:56 --> Total execution time: 0.1142
DEBUG - 2020-10-13 07:23:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:23:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:23:07 --> get_subcategory_list->{"lang":"37","category_id":"98","user_id":"1","support_lang_id":"1"}
DEBUG - 2020-10-13 07:23:07 --> Total execution time: 0.1079
DEBUG - 2020-10-13 07:23:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 07:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 07:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 07:23:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 07:23:09 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"1"}
DEBUG - 2020-10-13 07:23:09 --> Total execution time: 0.1134
DEBUG - 2020-10-13 11:51:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 11:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 11:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 11:51:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 11:51:20 --> Total execution time: 0.1076
DEBUG - 2020-10-13 12:40:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:40:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:40:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:40:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:40:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:40:15 --> Total execution time: 0.1354
DEBUG - 2020-10-13 12:40:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:40:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:40:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:40:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:40:51 --> Total execution time: 0.1360
DEBUG - 2020-10-13 12:40:53 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:40:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:40:53 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-13 12:40:53 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:40:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:40:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 12:40:53 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:40:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:40:53 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-10-13 12:40:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:40:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:40:55 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-13 12:41:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:41:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:41:00 --> Total execution time: 0.1865
DEBUG - 2020-10-13 12:41:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:41:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 12:41:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 12:41:03 --> Total execution time: 0.1252
DEBUG - 2020-10-13 12:41:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:41:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:41:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 12:42:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:42:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:42:21 --> Total execution time: 0.1363
DEBUG - 2020-10-13 12:42:25 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:42:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 12:42:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 12:42:25 --> Total execution time: 0.1849
DEBUG - 2020-10-13 12:42:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:42:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:42:26 --> Total execution time: 0.1088
DEBUG - 2020-10-13 12:42:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:42:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 12:42:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 12:42:28 --> Total execution time: 0.1488
DEBUG - 2020-10-13 12:42:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:42:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:42:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 12:45:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:45:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:45:33 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-13 12:45:33 --> Total execution time: 0.4486
DEBUG - 2020-10-13 12:45:35 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:45:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:45:35 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-13 12:45:35 --> Total execution time: 0.2053
DEBUG - 2020-10-13 12:45:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:45:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:45:39 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-13 12:45:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:45:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:45:42 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-13 12:46:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:46:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:46:17 --> Total execution time: 0.1269
DEBUG - 2020-10-13 12:46:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:46:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:46:18 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"765","support_lang_id":"3"}
DEBUG - 2020-10-13 12:46:18 --> Total execution time: 0.1022
DEBUG - 2020-10-13 12:46:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:46:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 12:46:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 12:46:20 --> Total execution time: 0.1267
DEBUG - 2020-10-13 12:46:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:46:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:46:21 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-13 12:46:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:46:22 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-13 12:46:22 --> Total execution time: 0.1399
DEBUG - 2020-10-13 12:46:23 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:46:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:46:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 12:46:23 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:46:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:46:23 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-13 12:46:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:46:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 12:46:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 12:46:28 --> Total execution time: 0.1342
DEBUG - 2020-10-13 12:46:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:46:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 12:46:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-13 12:46:30 --> Total execution time: 0.1318
DEBUG - 2020-10-13 12:46:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:46:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:46:32 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-13 12:46:32 --> Total execution time: 0.1042
DEBUG - 2020-10-13 12:46:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:46:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:46:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 12:47:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:47:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:47:24 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-13 12:47:24 --> Total execution time: 0.1176
DEBUG - 2020-10-13 12:47:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:47:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:47:26 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"765","support_lang_id":"3"}
DEBUG - 2020-10-13 12:47:26 --> Total execution time: 0.1393
DEBUG - 2020-10-13 12:47:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:47:29 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-13 12:47:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:47:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:47:31 --> Total execution time: 0.1553
DEBUG - 2020-10-13 12:47:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:47:32 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-13 12:47:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:47:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 12:47:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-10-13 12:47:34 --> Total execution time: 0.1540
DEBUG - 2020-10-13 12:47:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:47:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:47:34 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-13 12:47:34 --> Total execution time: 0.1126
DEBUG - 2020-10-13 12:47:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:47:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 12:47:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:47:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 12:47:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:47:37 --> UTF-8 Support Enabled
ERROR - 2020-10-13 12:47:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 12:47:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:47:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:47:37 --> 404 Page Not Found: Uploads/words
ERROR - 2020-10-13 12:47:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 12:47:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:47:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 12:47:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:47:38 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-13 12:47:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:47:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 12:47:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:47:39 --> UTF-8 Support Enabled
ERROR - 2020-10-13 12:47:39 --> 404 Page Not Found: Uploads/words
ERROR - 2020-10-13 12:47:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 12:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:47:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:47:39 --> 404 Page Not Found: Uploads/words
ERROR - 2020-10-13 12:47:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 12:47:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:47:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 12:47:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:47:40 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-13 12:47:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:47:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:47:41 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-10-13 12:47:41 --> Total execution time: 0.1167
DEBUG - 2020-10-13 12:47:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:47:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 12:47:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:47:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 12:47:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:47:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:47:48 --> get_subcategory_list->{"lang":"37","category_id":"89","user_id":"765","support_lang_id":"3"}
DEBUG - 2020-10-13 12:47:48 --> Total execution time: 0.1333
DEBUG - 2020-10-13 12:47:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:47:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:47:52 --> get_exercise_type_list->{"lang":"37","subcategory_id":"97","support_lang_id":"3"}
DEBUG - 2020-10-13 12:47:52 --> Total execution time: 0.1130
DEBUG - 2020-10-13 12:47:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:47:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:47:56 --> Total execution time: 0.1703
DEBUG - 2020-10-13 12:47:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:47:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 12:47:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-10-13 12:47:59 --> Total execution time: 0.1666
DEBUG - 2020-10-13 12:48:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:48:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:48:00 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"89","subcategory_id":"97","support_lang_id":"3"}
DEBUG - 2020-10-13 12:48:00 --> Total execution time: 0.1123
DEBUG - 2020-10-13 12:48:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:48:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:48:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 12:48:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:48:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:48:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 12:48:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:48:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:48:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:48:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 12:48:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:48:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 12:48:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:48:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:48:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 12:48:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:48:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:48:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 12:48:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:48:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:48:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 12:50:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:50:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:50:10 --> Total execution time: 0.1255
DEBUG - 2020-10-13 12:50:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:50:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:50:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 12:50:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:50:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:50:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 12:50:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:50:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:50:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:50:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 12:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:50:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:50:43 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"89","subcategory_id":"97","support_lang_id":"3"}
DEBUG - 2020-10-13 12:50:43 --> Total execution time: 0.1163
DEBUG - 2020-10-13 12:50:45 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:50:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:50:45 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-13 12:50:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:50:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:50:48 --> get_exercise_type_list->{"lang":"37","subcategory_id":"97","support_lang_id":"3"}
DEBUG - 2020-10-13 12:50:48 --> Total execution time: 0.1299
DEBUG - 2020-10-13 12:50:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:50:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:50:52 --> get_subcategory_list->{"lang":"37","category_id":"89","user_id":"765","support_lang_id":"3"}
DEBUG - 2020-10-13 12:50:52 --> Total execution time: 0.1258
DEBUG - 2020-10-13 12:50:57 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:50:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:50:57 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-10-13 12:50:57 --> Total execution time: 0.1130
DEBUG - 2020-10-13 12:53:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:53:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:53:29 --> Total execution time: 0.1410
DEBUG - 2020-10-13 12:53:31 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:53:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 12:53:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2020-10-13 12:53:31 --> Total execution time: 0.1981
DEBUG - 2020-10-13 12:53:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:53:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:53:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 12:53:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:53:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:53:34 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"3"}
DEBUG - 2020-10-13 12:53:34 --> Total execution time: 0.1135
DEBUG - 2020-10-13 12:53:45 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:53:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:53:45 --> get_subcategory_list->{"lang":"37","category_id":"102","user_id":"765","support_lang_id":"3"}
DEBUG - 2020-10-13 12:53:45 --> Total execution time: 0.1115
DEBUG - 2020-10-13 12:53:45 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:53:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:53:46 --> Total execution time: 0.1642
DEBUG - 2020-10-13 12:53:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:53:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 12:53:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2020-10-13 12:53:48 --> Total execution time: 0.1927
DEBUG - 2020-10-13 12:53:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:53:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:53:50 --> get_exercise_type_list->{"lang":"37","subcategory_id":"249","support_lang_id":"3"}
DEBUG - 2020-10-13 12:53:50 --> Total execution time: 0.1021
DEBUG - 2020-10-13 12:53:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:53:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:53:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 12:53:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:53:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 12:53:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2020-10-13 12:53:57 --> Total execution time: 0.1769
DEBUG - 2020-10-13 12:53:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:53:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 12:53:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2020-10-13 12:53:59 --> Total execution time: 0.1504
DEBUG - 2020-10-13 12:54:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:54:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:54:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 12:54:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:54:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-13 12:54:03 --> get_phrases_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"3","category_id":"102","subcategory_id":"249","support_lang_id":"3"}
DEBUG - 2020-10-13 12:54:03 --> Total execution time: 0.1150
DEBUG - 2020-10-13 12:54:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:54:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 12:54:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/langoalphademo/public_html/indylan/application/views/admin/edit_phrases.php 40
DEBUG - 2020-10-13 12:54:15 --> Total execution time: 0.1288
DEBUG - 2020-10-13 12:54:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:54:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:54:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-13 12:55:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-13 12:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-13 12:55:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-13 12:55:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/langoalphademo/public_html/indylan/application/views/admin/edit_phrases.php 40
DEBUG - 2020-10-13 12:55:01 --> Total execution time: 0.1334
DEBUG - 2020-10-13 12:55:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-13 12:55:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-13 12:55:03 --> 404 Page Not Found: Assets/chosen
