<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-09-02 06:11:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-02 06:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-02 06:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-02 06:11:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-02 06:11:37 --> Total execution time: 0.1936
DEBUG - 2020-09-02 06:11:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-02 06:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-02 06:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-02 06:11:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-02 06:11:58 --> Total execution time: 0.1404
DEBUG - 2020-09-02 10:57:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-02 10:57:54 --> No URI present. Default controller set.
DEBUG - 2020-09-02 10:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-02 10:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-02 10:57:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-02 10:57:54 --> Total execution time: 0.1210
DEBUG - 2020-09-02 14:30:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-02 14:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-02 14:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-02 14:30:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-02 14:30:15 --> Total execution time: 0.1639
DEBUG - 2020-09-02 14:30:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-02 14:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-02 14:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-02 14:30:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-02 14:30:21 --> Total execution time: 0.0967
DEBUG - 2020-09-02 14:30:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-02 14:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-02 14:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-02 14:30:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-02 14:30:41 --> get_category_list->{"lang":"38","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-02 14:30:41 --> Total execution time: 0.1309
DEBUG - 2020-09-02 14:30:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-02 14:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-02 14:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-02 14:30:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-02 14:30:51 --> get_subcategory_list->{"lang":"38","category_id":"62","user_id":"767","support_lang_id":"3"}
DEBUG - 2020-09-02 14:30:51 --> Total execution time: 0.1523
DEBUG - 2020-09-02 14:30:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-02 14:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-02 14:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-02 14:30:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-02 14:30:52 --> get_category_list->{"lang":"38","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-02 14:30:52 --> Total execution time: 0.1639
DEBUG - 2020-09-02 14:31:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-02 14:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-02 14:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-02 14:31:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-02 14:31:30 --> get_subcategory_list->{"lang":"38","category_id":"53","user_id":"767","support_lang_id":"3"}
DEBUG - 2020-09-02 14:31:30 --> Total execution time: 0.1542
DEBUG - 2020-09-02 14:31:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-02 14:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-02 14:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-02 14:31:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-02 14:31:31 --> get_exercise_type_list->{"lang":"38","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-02 14:31:31 --> Total execution time: 0.1035
DEBUG - 2020-09-02 14:31:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-02 14:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-02 14:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-02 14:31:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-02 14:31:40 --> get_sorce_lan_word_type_8->{"slang":"38","tlang":"3","exercise_mode_id":"1","category_id":"53","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-02 14:31:40 --> Total execution time: 0.1467
