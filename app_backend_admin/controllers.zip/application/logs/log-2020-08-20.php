<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-08-20 10:15:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-20 10:15:34 --> No URI present. Default controller set.
DEBUG - 2020-08-20 10:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-20 10:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-20 10:15:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-20 10:15:34 --> Total execution time: 0.8142
DEBUG - 2020-08-20 10:18:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-20 10:18:33 --> No URI present. Default controller set.
DEBUG - 2020-08-20 10:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-20 10:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-20 10:18:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-20 10:18:33 --> Total execution time: 0.1812
DEBUG - 2020-08-20 11:02:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-20 11:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-20 11:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-20 11:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-20 11:02:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-20 11:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-20 11:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-20 11:02:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-20 11:02:46 --> Total execution time: 0.2794
DEBUG - 2020-08-20 11:02:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-20 11:02:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-20 11:02:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-20 11:02:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-20 11:02:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-20 11:02:46 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-08-20 11:03:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-20 11:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-20 11:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-20 11:03:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-20 11:03:01 --> Total execution time: 0.2291
DEBUG - 2020-08-20 11:26:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-20 11:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-20 11:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-20 11:26:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-20 11:26:40 --> Severity: Warning --> Use of undefined constant COUNTRY_IMAGE - assumed 'COUNTRY_IMAGE' (this will throw an Error in a future version of PHP) E:\xampp\htdocs\voolsy\indylan\application\models\Api_model.php 51
ERROR - 2020-08-20 11:26:40 --> Severity: Warning --> Use of undefined constant COUNTRY_IMAGE - assumed 'COUNTRY_IMAGE' (this will throw an Error in a future version of PHP) E:\xampp\htdocs\voolsy\indylan\application\models\Api_model.php 51
ERROR - 2020-08-20 11:26:40 --> Severity: Warning --> Use of undefined constant COUNTRY_IMAGE - assumed 'COUNTRY_IMAGE' (this will throw an Error in a future version of PHP) E:\xampp\htdocs\voolsy\indylan\application\models\Api_model.php 53
ERROR - 2020-08-20 11:26:40 --> Severity: Warning --> Use of undefined constant COUNTRY_IMAGE - assumed 'COUNTRY_IMAGE' (this will throw an Error in a future version of PHP) E:\xampp\htdocs\voolsy\indylan\application\models\Api_model.php 53
ERROR - 2020-08-20 11:26:40 --> Severity: Warning --> Use of undefined constant COUNTRY_IMAGE - assumed 'COUNTRY_IMAGE' (this will throw an Error in a future version of PHP) E:\xampp\htdocs\voolsy\indylan\application\models\Api_model.php 51
DEBUG - 2020-08-20 11:26:40 --> Total execution time: 0.6531
