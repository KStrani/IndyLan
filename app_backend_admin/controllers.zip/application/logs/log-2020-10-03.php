<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-10-03 09:03:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:03:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:03:56 --> user_login->{"email":"ronak.doshi@voolsy.com","password":"b51dedb33ef8d983d741d5e035760a08"}
DEBUG - 2020-10-03 09:03:56 --> Total execution time: 0.1769
DEBUG - 2020-10-03 09:03:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:03:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:03:59 --> Total execution time: 0.1331
DEBUG - 2020-10-03 09:03:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:03:59 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:03:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:03:59 --> Total execution time: 0.1098
DEBUG - 2020-10-03 09:04:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:04:02 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:04:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:04:02 --> Total execution time: 0.1224
DEBUG - 2020-10-03 09:04:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:04:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:04:19 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:04:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:04:19 --> Total execution time: 0.1169
DEBUG - 2020-10-03 09:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:04:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:04:19 --> Total execution time: 0.1355
DEBUG - 2020-10-03 09:04:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:04:22 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:04:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:04:22 --> Total execution time: 0.1545
DEBUG - 2020-10-03 09:04:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:04:26 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:04:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:04:26 --> Total execution time: 0.1537
DEBUG - 2020-10-03 09:04:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:04:29 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:04:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:04:29 --> Total execution time: 0.1465
DEBUG - 2020-10-03 09:05:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:05:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:05:11 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:05:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:05:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:05:11 --> Total execution time: 0.1279
DEBUG - 2020-10-03 09:05:11 --> Total execution time: 0.1348
DEBUG - 2020-10-03 09:05:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:05:19 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:05:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:05:19 --> Total execution time: 0.1443
DEBUG - 2020-10-03 09:05:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:05:21 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:05:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:05:21 --> Total execution time: 0.1258
DEBUG - 2020-10-03 09:05:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:05:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:05:24 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2020-10-03 09:05:24 --> Total execution time: 0.1402
DEBUG - 2020-10-03 09:32:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:03 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:03 --> Total execution time: 0.1490
DEBUG - 2020-10-03 09:32:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:05 --> Total execution time: 0.0933
DEBUG - 2020-10-03 09:32:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:05 --> Total execution time: 0.1485
DEBUG - 2020-10-03 09:32:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:06 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:06 --> Total execution time: 0.1331
DEBUG - 2020-10-03 09:32:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:09 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:09 --> Total execution time: 0.1540
DEBUG - 2020-10-03 09:32:09 --> Total execution time: 0.1270
DEBUG - 2020-10-03 09:32:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:12 --> Total execution time: 0.1116
DEBUG - 2020-10-03 09:32:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:12 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:12 --> Total execution time: 0.1342
DEBUG - 2020-10-03 09:32:23 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:23 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:23 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:23 --> Total execution time: 0.1204
DEBUG - 2020-10-03 09:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:23 --> Total execution time: 0.1249
DEBUG - 2020-10-03 09:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:24 --> Total execution time: 0.0959
DEBUG - 2020-10-03 09:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:24 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:24 --> Total execution time: 0.1268
DEBUG - 2020-10-03 09:32:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:27 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:27 --> Total execution time: 0.1113
DEBUG - 2020-10-03 09:32:28 --> Total execution time: 0.1478
DEBUG - 2020-10-03 09:32:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:29 --> Total execution time: 0.1154
DEBUG - 2020-10-03 09:32:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:35 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:35 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:35 --> Total execution time: 0.1481
DEBUG - 2020-10-03 09:32:35 --> Total execution time: 0.1310
DEBUG - 2020-10-03 09:32:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:36 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:36 --> Total execution time: 0.1345
DEBUG - 2020-10-03 09:32:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:41 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:41 --> Total execution time: 0.1250
DEBUG - 2020-10-03 09:32:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:42 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-10-03 09:32:42 --> Total execution time: 0.0995
DEBUG - 2020-10-03 09:32:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:46 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:46 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"746","support_lang_id":"3"}
DEBUG - 2020-10-03 09:32:46 --> Total execution time: 0.1213
DEBUG - 2020-10-03 09:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:46 --> Total execution time: 0.1229
DEBUG - 2020-10-03 09:32:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:49 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:49 --> Total execution time: 0.1177
DEBUG - 2020-10-03 09:32:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:32:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:32:50 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-10-03 09:32:50 --> Total execution time: 0.1514
DEBUG - 2020-10-03 09:33:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:33:44 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:33:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:33:45 --> Total execution time: 0.1187
DEBUG - 2020-10-03 09:33:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:33:49 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:33:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:33:49 --> Total execution time: 0.1134
DEBUG - 2020-10-03 09:33:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:33:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:33:49 --> get_culture_type_1->{"slang":"37","tlang":"3","exercise_mode_id":"5","category_id":"91","subcategory_id":"100","support_lang_id":"3"}
ERROR - 2020-10-03 09:33:49 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-03 09:33:49 --> Total execution time: 0.1026
DEBUG - 2020-10-03 09:34:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:04 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:34:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:04 --> get_exercise_type_list->{"lang":"37","subcategory_id":"100","support_lang_id":"3"}
DEBUG - 2020-10-03 09:34:04 --> Total execution time: 0.1022
DEBUG - 2020-10-03 09:34:04 --> Total execution time: 0.1161
DEBUG - 2020-10-03 09:34:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:07 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:07 --> get_subcategory_list->{"lang":"37","category_id":"91","user_id":"746","support_lang_id":"3"}
DEBUG - 2020-10-03 09:34:07 --> Total execution time: 0.1156
DEBUG - 2020-10-03 09:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:07 --> Total execution time: 0.1155
DEBUG - 2020-10-03 09:34:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:11 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:11 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-10-03 09:34:11 --> Total execution time: 0.1308
DEBUG - 2020-10-03 09:34:11 --> Total execution time: 0.1332
DEBUG - 2020-10-03 09:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:18 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:18 --> Total execution time: 0.1278
DEBUG - 2020-10-03 09:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:20 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:20 --> Total execution time: 0.1375
DEBUG - 2020-10-03 09:34:23 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:23 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-03 09:34:23 --> Total execution time: 0.1215
DEBUG - 2020-10-03 09:34:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 09:34:26 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 09:34:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 09:34:29 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 09:34:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:30 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:31 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"746","support_lang_id":"3"}
DEBUG - 2020-10-03 09:34:31 --> Total execution time: 0.1207
DEBUG - 2020-10-03 09:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:31 --> Total execution time: 0.1456
DEBUG - 2020-10-03 09:34:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 09:34:33 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 09:34:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:34 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-03 09:34:34 --> Total execution time: 0.1124
DEBUG - 2020-10-03 09:34:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:34 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:35 --> Total execution time: 0.1208
DEBUG - 2020-10-03 09:34:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 09:34:36 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 09:34:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:37 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:37 --> Total execution time: 0.1205
DEBUG - 2020-10-03 09:34:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:39 --> get_grammer_type_2->{"slang":"37","tlang":"3","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
ERROR - 2020-10-03 09:34:39 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-03 09:34:39 --> Total execution time: 0.1102
DEBUG - 2020-10-03 09:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:43 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-03 09:34:43 --> Total execution time: 0.1027
DEBUG - 2020-10-03 09:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:43 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:43 --> Total execution time: 0.1548
DEBUG - 2020-10-03 09:34:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:44 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"746","support_lang_id":"3"}
DEBUG - 2020-10-03 09:34:44 --> Total execution time: 0.1000
DEBUG - 2020-10-03 09:34:45 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:45 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-03 09:34:45 --> Total execution time: 0.1505
DEBUG - 2020-10-03 09:34:45 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:46 --> Total execution time: 0.1551
DEBUG - 2020-10-03 09:34:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:46 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:46 --> Total execution time: 0.1151
DEBUG - 2020-10-03 09:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:46 --> Total execution time: 0.1347
DEBUG - 2020-10-03 09:34:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:51 --> Total execution time: 0.1122
DEBUG - 2020-10-03 09:34:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:52 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:52 --> Total execution time: 0.1144
DEBUG - 2020-10-03 09:34:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:54 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:54 --> Total execution time: 0.1247
DEBUG - 2020-10-03 09:34:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:55 --> Total execution time: 0.1201
DEBUG - 2020-10-03 09:34:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:34:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:34:56 --> Total execution time: 0.1181
DEBUG - 2020-10-03 09:35:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:35:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:35:42 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:35:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:35:42 --> Total execution time: 0.1100
DEBUG - 2020-10-03 09:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:35:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:35:42 --> Total execution time: 0.1612
DEBUG - 2020-10-03 09:35:45 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:35:45 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:35:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:35:46 --> Total execution time: 0.1459
DEBUG - 2020-10-03 09:35:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:35:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:35:47 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-03 09:35:47 --> Total execution time: 0.1028
DEBUG - 2020-10-03 09:35:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:35:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 09:35:47 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 09:35:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:35:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 09:35:50 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 09:35:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:35:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:35:54 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"746","support_lang_id":"3"}
DEBUG - 2020-10-03 09:35:54 --> Total execution time: 0.1051
DEBUG - 2020-10-03 09:35:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:35:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:35:54 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:35:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 09:35:54 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 09:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:35:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:35:54 --> Total execution time: 0.1185
DEBUG - 2020-10-03 09:35:57 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:35:57 --> UTF-8 Support Enabled
ERROR - 2020-10-03 09:35:57 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 09:35:57 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:35:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:35:58 --> Total execution time: 0.1344
DEBUG - 2020-10-03 09:35:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:35:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:35:59 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-10-03 09:35:59 --> Total execution time: 0.1443
DEBUG - 2020-10-03 09:36:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:36:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:36:09 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:36:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:36:09 --> get_grammer_type_1->{"slang":"37","tlang":"3","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
ERROR - 2020-10-03 09:36:09 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-03 09:36:09 --> Total execution time: 0.1040
DEBUG - 2020-10-03 09:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:36:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:36:09 --> Total execution time: 0.1317
DEBUG - 2020-10-03 09:36:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:36:11 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:36:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:36:11 --> Total execution time: 0.1278
DEBUG - 2020-10-03 09:37:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:37:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:37:06 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-10-03 09:37:06 --> Total execution time: 0.1271
DEBUG - 2020-10-03 09:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:37:07 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:37:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:37:07 --> Total execution time: 0.1430
DEBUG - 2020-10-03 09:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:37:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:37:07 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"746","support_lang_id":"3"}
DEBUG - 2020-10-03 09:37:07 --> Total execution time: 0.1410
DEBUG - 2020-10-03 09:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:37:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:37:08 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-03 09:37:08 --> Total execution time: 0.1291
DEBUG - 2020-10-03 09:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:37:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:37:08 --> Total execution time: 0.1271
DEBUG - 2020-10-03 09:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:37:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:37:08 --> Total execution time: 0.1318
DEBUG - 2020-10-03 09:37:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:37:09 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:37:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:37:10 --> Total execution time: 0.1179
DEBUG - 2020-10-03 09:37:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:37:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:37:24 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:37:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:37:24 --> Total execution time: 0.1217
DEBUG - 2020-10-03 09:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:37:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:37:24 --> Total execution time: 0.1579
DEBUG - 2020-10-03 09:38:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:38:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:38:12 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:38:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:38:12 --> Total execution time: 0.1113
DEBUG - 2020-10-03 09:38:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:38:12 --> Total execution time: 0.1147
DEBUG - 2020-10-03 09:38:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:38:15 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:38:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:38:15 --> Total execution time: 0.1411
DEBUG - 2020-10-03 09:38:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:38:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:38:17 --> Total execution time: 0.0994
DEBUG - 2020-10-03 09:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:38:21 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:38:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:38:21 --> Total execution time: 0.1301
DEBUG - 2020-10-03 09:38:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:38:27 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:38:28 --> Total execution time: 0.1323
DEBUG - 2020-10-03 09:38:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:38:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 09:38:28 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 09:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:38:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:38:28 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"1"}
DEBUG - 2020-10-03 09:38:28 --> Total execution time: 0.1147
DEBUG - 2020-10-03 09:38:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:38:29 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:38:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:38:29 --> Total execution time: 0.1377
DEBUG - 2020-10-03 09:38:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:38:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 09:38:29 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 09:38:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:38:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:38:30 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"746","support_lang_id":"1"}
DEBUG - 2020-10-03 09:38:30 --> Total execution time: 0.1129
DEBUG - 2020-10-03 09:38:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:38:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:38:36 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:38:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:38:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:38:36 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"1"}
DEBUG - 2020-10-03 09:38:36 --> Total execution time: 0.1454
DEBUG - 2020-10-03 09:38:36 --> Total execution time: 0.1364
DEBUG - 2020-10-03 09:38:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:38:38 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:38:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:38:38 --> Total execution time: 0.1381
DEBUG - 2020-10-03 09:38:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:38:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:38:42 --> get_grammer_type_1->{"slang":"37","tlang":"1","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"1"}
DEBUG - 2020-10-03 09:38:42 --> Total execution time: 0.1395
DEBUG - 2020-10-03 09:38:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 09:38:42 --> No URI present. Default controller set.
DEBUG - 2020-10-03 09:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 09:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 09:38:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 09:38:42 --> Total execution time: 0.1186
DEBUG - 2020-10-03 10:06:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:06:49 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:06:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:06:49 --> Total execution time: 0.1155
DEBUG - 2020-10-03 10:06:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:06:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:06:51 --> Total execution time: 0.0999
DEBUG - 2020-10-03 10:08:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:08:04 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:08:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:08:04 --> Total execution time: 0.1350
DEBUG - 2020-10-03 10:08:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:08:06 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:08:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:08:06 --> Total execution time: 0.1155
DEBUG - 2020-10-03 10:08:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:08:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:08:16 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:08:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:08:16 --> Total execution time: 0.0991
DEBUG - 2020-10-03 10:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:08:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:08:16 --> Total execution time: 0.1145
DEBUG - 2020-10-03 10:08:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:08:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:08:16 --> Total execution time: 0.1026
DEBUG - 2020-10-03 10:08:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:08:18 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:08:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:08:18 --> Total execution time: 0.1199
DEBUG - 2020-10-03 10:08:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:08:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:08:28 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:08:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:08:28 --> Total execution time: 0.0976
DEBUG - 2020-10-03 10:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:08:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:08:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:08:28 --> Total execution time: 0.1132
DEBUG - 2020-10-03 10:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:08:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:08:28 --> Total execution time: 0.1064
DEBUG - 2020-10-03 10:08:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:08:30 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:08:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:08:31 --> Total execution time: 0.1327
DEBUG - 2020-10-03 10:08:31 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:08:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:08:32 --> Total execution time: 0.1305
DEBUG - 2020-10-03 10:08:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:08:39 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:08:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:08:39 --> Total execution time: 0.1298
DEBUG - 2020-10-03 10:08:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:08:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:08:41 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"1"}
DEBUG - 2020-10-03 10:08:41 --> Total execution time: 0.1559
DEBUG - 2020-10-03 10:08:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:08:42 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:08:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:08:42 --> Total execution time: 0.1284
DEBUG - 2020-10-03 10:08:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:08:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 10:08:44 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 10:08:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:08:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 10:08:46 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 10:09:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:09:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:09:05 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:09:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:09:05 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"746","support_lang_id":"1"}
DEBUG - 2020-10-03 10:09:05 --> Total execution time: 0.1261
DEBUG - 2020-10-03 10:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:09:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:09:05 --> Total execution time: 0.1515
DEBUG - 2020-10-03 10:09:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:09:07 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:09:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:09:08 --> Total execution time: 0.1328
DEBUG - 2020-10-03 10:09:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:09:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:09:08 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"1"}
DEBUG - 2020-10-03 10:09:08 --> Total execution time: 0.1032
DEBUG - 2020-10-03 10:09:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:09:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:09:13 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:09:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:09:13 --> get_grammer_type_1->{"slang":"37","tlang":"1","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"1"}
DEBUG - 2020-10-03 10:09:13 --> Total execution time: 0.1033
DEBUG - 2020-10-03 10:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:09:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:09:13 --> Total execution time: 0.1310
DEBUG - 2020-10-03 10:09:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:09:15 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:09:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:09:15 --> Total execution time: 0.1244
DEBUG - 2020-10-03 10:10:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:10:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:10:12 --> Total execution time: 0.1304
DEBUG - 2020-10-03 10:10:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:10:12 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:10:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:10:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:10:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:10:12 --> Total execution time: 0.1100
DEBUG - 2020-10-03 10:10:12 --> Total execution time: 0.1571
DEBUG - 2020-10-03 10:10:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:10:15 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:10:15 --> Total execution time: 0.1510
DEBUG - 2020-10-03 10:11:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:11:11 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:11:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:11:11 --> Total execution time: 0.1154
DEBUG - 2020-10-03 10:11:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:11:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:11:17 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:11:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:11:17 --> Total execution time: 0.1303
DEBUG - 2020-10-03 10:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:11:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:11:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:11:17 --> Total execution time: 0.1357
DEBUG - 2020-10-03 10:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:11:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:11:17 --> Total execution time: 0.1090
DEBUG - 2020-10-03 10:11:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:11:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:11:24 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:11:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:11:24 --> Total execution time: 0.1328
DEBUG - 2020-10-03 10:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:11:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:11:24 --> Total execution time: 0.1190
DEBUG - 2020-10-03 10:11:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:11:27 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:11:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:11:28 --> Total execution time: 0.1307
DEBUG - 2020-10-03 10:11:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:11:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:11:30 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"1"}
DEBUG - 2020-10-03 10:11:30 --> Total execution time: 0.1133
DEBUG - 2020-10-03 10:11:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:11:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 10:11:32 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 10:11:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:11:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:11:34 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"746","support_lang_id":"1"}
DEBUG - 2020-10-03 10:11:34 --> Total execution time: 0.1145
DEBUG - 2020-10-03 10:11:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:11:34 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:11:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:11:35 --> Total execution time: 0.1362
DEBUG - 2020-10-03 10:11:35 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:11:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 10:11:35 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 10:11:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:11:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:11:37 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:11:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:11:37 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"1"}
DEBUG - 2020-10-03 10:11:37 --> Total execution time: 0.1025
DEBUG - 2020-10-03 10:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:11:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:11:37 --> Total execution time: 0.1320
DEBUG - 2020-10-03 10:11:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:11:40 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:11:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:11:40 --> Total execution time: 0.1180
DEBUG - 2020-10-03 10:11:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:11:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:11:41 --> get_grammer_type_1->{"slang":"37","tlang":"1","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"1"}
DEBUG - 2020-10-03 10:11:41 --> Total execution time: 0.0986
DEBUG - 2020-10-03 10:11:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:11:55 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:11:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:11:55 --> Total execution time: 0.1252
DEBUG - 2020-10-03 10:11:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:11:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:11:56 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"1"}
DEBUG - 2020-10-03 10:11:56 --> Total execution time: 0.1042
DEBUG - 2020-10-03 10:12:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:02 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:02 --> get_grammer_type_2->{"slang":"37","tlang":"1","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"1"}
ERROR - 2020-10-03 10:12:02 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-03 10:12:02 --> Total execution time: 0.1032
DEBUG - 2020-10-03 10:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:02 --> Total execution time: 0.1483
DEBUG - 2020-10-03 10:12:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:06 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:06 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"1"}
DEBUG - 2020-10-03 10:12:06 --> Total execution time: 0.1069
DEBUG - 2020-10-03 10:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:06 --> Total execution time: 0.1237
DEBUG - 2020-10-03 10:12:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:06 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"746","support_lang_id":"1"}
DEBUG - 2020-10-03 10:12:06 --> Total execution time: 0.1236
DEBUG - 2020-10-03 10:12:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:09 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:09 --> Total execution time: 0.1112
DEBUG - 2020-10-03 10:12:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:10 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"1"}
DEBUG - 2020-10-03 10:12:10 --> Total execution time: 0.1135
DEBUG - 2020-10-03 10:12:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 10:12:13 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 10:12:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:14 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"746","support_lang_id":"1"}
DEBUG - 2020-10-03 10:12:14 --> Total execution time: 0.1302
DEBUG - 2020-10-03 10:12:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:14 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:14 --> Total execution time: 0.1809
DEBUG - 2020-10-03 10:12:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 10:12:16 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 10:12:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:18 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:18 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"1"}
DEBUG - 2020-10-03 10:12:18 --> Total execution time: 0.1446
DEBUG - 2020-10-03 10:12:18 --> Total execution time: 0.1172
DEBUG - 2020-10-03 10:12:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:20 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:20 --> get_grammer_type_1->{"slang":"37","tlang":"1","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"1"}
ERROR - 2020-10-03 10:12:20 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-03 10:12:20 --> Total execution time: 0.1133
DEBUG - 2020-10-03 10:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:20 --> Total execution time: 0.1326
DEBUG - 2020-10-03 10:12:23 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:23 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"1"}
DEBUG - 2020-10-03 10:12:23 --> Total execution time: 0.1431
DEBUG - 2020-10-03 10:12:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:24 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:24 --> Total execution time: 0.1550
DEBUG - 2020-10-03 10:12:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:27 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:27 --> get_grammer_type_2->{"slang":"37","tlang":"1","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"1"}
DEBUG - 2020-10-03 10:12:27 --> Total execution time: 0.0993
DEBUG - 2020-10-03 10:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:27 --> Total execution time: 0.1142
DEBUG - 2020-10-03 10:12:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:29 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:29 --> Total execution time: 0.1424
DEBUG - 2020-10-03 10:12:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:39 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:39 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"1"}
DEBUG - 2020-10-03 10:12:39 --> Total execution time: 0.1229
DEBUG - 2020-10-03 10:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:39 --> Total execution time: 0.1129
DEBUG - 2020-10-03 10:12:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:40 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"746","support_lang_id":"1"}
DEBUG - 2020-10-03 10:12:40 --> Total execution time: 0.1054
DEBUG - 2020-10-03 10:12:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:41 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"1"}
DEBUG - 2020-10-03 10:12:41 --> Total execution time: 0.1101
DEBUG - 2020-10-03 10:12:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:41 --> Total execution time: 0.1179
DEBUG - 2020-10-03 10:12:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:41 --> Total execution time: 0.1143
DEBUG - 2020-10-03 10:12:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:12:42 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:12:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:12:42 --> Total execution time: 0.1266
DEBUG - 2020-10-03 10:13:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:13:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:13:02 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:13:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:13:02 --> Total execution time: 0.1142
DEBUG - 2020-10-03 10:13:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:13:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:13:03 --> Total execution time: 0.1245
DEBUG - 2020-10-03 10:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:13:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:13:03 --> Total execution time: 0.0992
DEBUG - 2020-10-03 10:13:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:13:05 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:13:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:13:05 --> Total execution time: 0.1129
DEBUG - 2020-10-03 10:14:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:14:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:14:20 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:14:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:14:20 --> Total execution time: 0.0989
DEBUG - 2020-10-03 10:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:14:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:14:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:14:20 --> Total execution time: 0.1372
DEBUG - 2020-10-03 10:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:14:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:14:20 --> Total execution time: 0.0958
DEBUG - 2020-10-03 10:14:23 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 10:14:23 --> No URI present. Default controller set.
DEBUG - 2020-10-03 10:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 10:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 10:14:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 10:14:23 --> Total execution time: 0.1157
DEBUG - 2020-10-03 13:54:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:54:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:54:09 --> user_register->{"first_name":"a","last_name":"","email":"a@a.a","password":"123456","confirm_password":"123456","social_id":null,"social_type":"0","user_image":null}
DEBUG - 2020-10-03 13:54:09 --> Total execution time: 0.1097
DEBUG - 2020-10-03 13:54:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:54:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:54:12 --> Total execution time: 0.1229
DEBUG - 2020-10-03 13:54:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:54:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:54:16 --> Total execution time: 0.1182
DEBUG - 2020-10-03 13:54:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:54:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:54:21 --> Total execution time: 0.1163
DEBUG - 2020-10-03 13:54:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:54:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:54:26 --> Total execution time: 0.1138
DEBUG - 2020-10-03 13:54:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:54:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:54:32 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-03 13:54:32 --> Total execution time: 0.1288
DEBUG - 2020-10-03 13:54:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:54:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:54:36 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"769","support_lang_id":"3"}
DEBUG - 2020-10-03 13:54:36 --> Total execution time: 0.1157
DEBUG - 2020-10-03 13:54:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:54:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:54:40 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-10-03 13:54:40 --> Total execution time: 0.1071
DEBUG - 2020-10-03 13:54:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:54:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:54:43 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"3","exercise_mode_id":"1","category_id":"62","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-10-03 13:54:43 --> Total execution time: 0.1361
DEBUG - 2020-10-03 13:54:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:54:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:54:49 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-10-03 13:54:49 --> Total execution time: 0.1251
DEBUG - 2020-10-03 13:54:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:54:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:54:52 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"3","exercise_mode_id":"1","category_id":"62","subcategory_id":"101","support_lang_id":"3"}
ERROR - 2020-10-03 13:54:52 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-03 13:54:52 --> Total execution time: 0.1275
DEBUG - 2020-10-03 13:54:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:54:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:54:56 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-10-03 13:54:56 --> Total execution time: 0.1085
DEBUG - 2020-10-03 13:55:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:55:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:55:14 --> get_sorce_lan_word_type_3->{"slang":"37","tlang":"3","exercise_mode_id":"1","category_id":"62","subcategory_id":"101","support_lang_id":"3"}
ERROR - 2020-10-03 13:55:14 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-03 13:55:14 --> Total execution time: 0.1453
DEBUG - 2020-10-03 13:55:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:55:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:55:17 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-10-03 13:55:17 --> Total execution time: 0.1198
DEBUG - 2020-10-03 13:55:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:55:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:55:22 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"769","support_lang_id":"3"}
DEBUG - 2020-10-03 13:55:22 --> Total execution time: 0.1668
DEBUG - 2020-10-03 13:55:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:55:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:55:26 --> get_exercise_type_list->{"lang":"37","subcategory_id":"102","support_lang_id":"3"}
DEBUG - 2020-10-03 13:55:26 --> Total execution time: 0.1111
DEBUG - 2020-10-03 13:55:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:55:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:55:29 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"3","exercise_mode_id":"1","category_id":"62","subcategory_id":"102","support_lang_id":"3"}
DEBUG - 2020-10-03 13:55:29 --> Total execution time: 0.1287
DEBUG - 2020-10-03 13:55:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:55:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:55:33 --> get_exercise_type_list->{"lang":"37","subcategory_id":"102","support_lang_id":"3"}
DEBUG - 2020-10-03 13:55:33 --> Total execution time: 0.1190
DEBUG - 2020-10-03 13:55:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:55:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:55:34 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"769","support_lang_id":"3"}
DEBUG - 2020-10-03 13:55:34 --> Total execution time: 0.1432
DEBUG - 2020-10-03 13:55:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:55:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:55:36 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-03 13:55:36 --> Total execution time: 0.1115
DEBUG - 2020-10-03 13:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 13:56:27 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 13:56:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:56:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 13:56:30 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 13:56:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:56:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 13:56:51 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 13:56:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 13:56:54 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 13:57:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:57:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 13:57:44 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 13:57:45 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:57:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:57:46 --> Total execution time: 0.1124
DEBUG - 2020-10-03 13:57:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:57:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:57:46 --> Total execution time: 0.1110
DEBUG - 2020-10-03 13:57:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:57:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 13:57:47 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 13:57:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:57:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:57:50 --> Total execution time: 0.1048
DEBUG - 2020-10-03 13:57:53 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:57:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:57:53 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-03 13:57:53 --> Total execution time: 0.1149
DEBUG - 2020-10-03 13:57:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:57:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 13:57:58 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 13:58:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:58:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 13:58:01 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 13:58:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:58:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:58:02 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"769","support_lang_id":"3"}
DEBUG - 2020-10-03 13:58:02 --> Total execution time: 0.1124
DEBUG - 2020-10-03 13:58:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:58:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:58:06 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-10-03 13:58:06 --> Total execution time: 0.1187
DEBUG - 2020-10-03 13:58:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:58:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-03 13:58:08 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-10-03 13:58:08 --> Total execution time: 0.1150
DEBUG - 2020-10-03 13:58:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:58:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:58:12 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-10-03 13:58:12 --> Total execution time: 0.1101
DEBUG - 2020-10-03 13:58:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:58:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:58:16 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"769","support_lang_id":"3"}
DEBUG - 2020-10-03 13:58:16 --> Total execution time: 0.1344
DEBUG - 2020-10-03 13:58:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:58:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:58:19 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-10-03 13:58:19 --> Total execution time: 0.1320
DEBUG - 2020-10-03 13:58:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:58:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:58:24 --> get_grammer_type_2->{"slang":"37","tlang":"3","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
ERROR - 2020-10-03 13:58:24 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-03 13:58:24 --> Total execution time: 0.1120
DEBUG - 2020-10-03 13:58:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:58:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:58:28 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-10-03 13:58:28 --> Total execution time: 0.0970
DEBUG - 2020-10-03 13:58:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:58:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:58:33 --> get_grammer_type_1->{"slang":"37","tlang":"3","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
ERROR - 2020-10-03 13:58:33 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-03 13:58:33 --> Total execution time: 0.1021
DEBUG - 2020-10-03 13:58:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:58:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:58:37 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-10-03 13:58:37 --> Total execution time: 0.1074
DEBUG - 2020-10-03 13:58:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:58:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 13:58:41 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 13:58:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:58:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:58:42 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"769","support_lang_id":"3"}
DEBUG - 2020-10-03 13:58:42 --> Total execution time: 0.1257
DEBUG - 2020-10-03 13:58:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:58:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:58:44 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-03 13:58:44 --> Total execution time: 0.1031
DEBUG - 2020-10-03 13:58:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:58:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 13:58:44 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 13:58:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:58:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:58:49 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-03 13:58:49 --> Total execution time: 0.1102
DEBUG - 2020-10-03 13:58:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:58:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:58:49 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"769","support_lang_id":"3"}
DEBUG - 2020-10-03 13:58:49 --> Total execution time: 0.1130
DEBUG - 2020-10-03 13:58:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:58:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 13:58:50 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 13:58:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:58:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 13:58:51 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 13:58:53 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:58:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:58:53 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-03 13:58:53 --> Total execution time: 0.1402
DEBUG - 2020-10-03 13:58:57 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:58:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:58:57 --> get_grammer_type_2->{"slang":"37","tlang":"3","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
ERROR - 2020-10-03 13:58:57 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-03 13:58:57 --> Total execution time: 0.1419
DEBUG - 2020-10-03 13:59:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:59:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:59:08 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-03 13:59:08 --> Total execution time: 0.1296
DEBUG - 2020-10-03 13:59:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:59:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 13:59:47 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 13:59:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:59:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 13:59:49 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 13:59:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:59:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 13:59:55 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 13:59:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:59:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:59:55 --> get_grammer_type_2->{"slang":"37","tlang":"3","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
ERROR - 2020-10-03 13:59:55 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-03 13:59:55 --> Total execution time: 0.1217
DEBUG - 2020-10-03 13:59:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:59:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 13:59:56 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 13:59:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 13:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 13:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 13:59:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 13:59:59 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-03 13:59:59 --> Total execution time: 0.1315
DEBUG - 2020-10-03 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:00:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:00:02 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-03 14:00:02 --> Total execution time: 0.1067
DEBUG - 2020-10-03 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:00:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:00:02 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"769","support_lang_id":"3"}
DEBUG - 2020-10-03 14:00:02 --> Total execution time: 0.1063
DEBUG - 2020-10-03 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:00:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:00:02 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:00:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:00:02 --> Total execution time: 0.0988
DEBUG - 2020-10-03 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:00:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:00:02 --> Total execution time: 0.1042
DEBUG - 2020-10-03 14:00:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:00:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:00:05 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 14:00:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:00:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:00:10 --> Total execution time: 0.1298
DEBUG - 2020-10-03 14:00:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:00:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:00:17 --> Total execution time: 0.1041
DEBUG - 2020-10-03 14:00:23 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:00:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:00:24 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-03 14:00:24 --> Total execution time: 0.1446
DEBUG - 2020-10-03 14:00:31 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:00:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:00:31 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 14:00:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:00:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:00:32 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"769","support_lang_id":"3"}
DEBUG - 2020-10-03 14:00:32 --> Total execution time: 0.1258
DEBUG - 2020-10-03 14:00:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:00:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:00:34 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 14:00:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:00:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:00:40 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 14:00:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:00:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:00:41 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-03 14:00:41 --> Total execution time: 0.1069
DEBUG - 2020-10-03 14:00:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:00:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:00:43 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 14:00:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:00:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:00:48 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 14:00:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:00:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:00:48 --> get_grammer_type_2->{"slang":"37","tlang":"3","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
ERROR - 2020-10-03 14:00:48 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-03 14:00:48 --> Total execution time: 0.1408
DEBUG - 2020-10-03 14:00:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:00:51 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 14:02:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:02:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:02:01 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 14:04:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:04:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:04:00 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 14:04:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:04:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:04:06 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 14:04:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:04:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:04:10 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 14:04:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:04:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:04:55 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 14:04:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:04:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:04:58 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 14:05:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:05:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:05:28 --> Total execution time: 0.1623
DEBUG - 2020-10-03 14:05:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:05:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:05:32 --> Total execution time: 0.1140
DEBUG - 2020-10-03 14:05:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:05:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:05:38 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-03 14:05:38 --> Total execution time: 0.1544
DEBUG - 2020-10-03 14:05:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:05:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:05:41 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 14:05:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:05:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:05:41 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-10-03 14:05:41 --> Total execution time: 0.1131
DEBUG - 2020-10-03 14:05:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:05:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:05:44 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 14:05:45 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:05:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:05:45 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-03 14:05:45 --> Total execution time: 0.1012
DEBUG - 2020-10-03 14:05:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:05:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:05:49 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
ERROR - 2020-10-03 14:05:49 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-03 14:05:49 --> Total execution time: 0.1146
DEBUG - 2020-10-03 14:07:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:07:06 --> No URI present. Default controller set.
DEBUG - 2020-10-03 14:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:07:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:07:06 --> Total execution time: 0.1342
DEBUG - 2020-10-03 14:07:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:07:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:07:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:07:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:07:22 --> Total execution time: 0.1478
DEBUG - 2020-10-03 14:07:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:07:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:07:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-03 14:07:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:07:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:07:28 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 14:07:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:07:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:07:30 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-10-03 14:07:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:07:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:07:36 --> Total execution time: 0.1212
DEBUG - 2020-10-03 14:07:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:07:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:07:54 --> Total execution time: 0.1103
DEBUG - 2020-10-03 14:08:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:08:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:08:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:08:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:08:03 --> Total execution time: 0.1158
DEBUG - 2020-10-03 14:08:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:08:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:08:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-03 14:08:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:08:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:08:09 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 14:08:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:08:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:08:09 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-10-03 14:08:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:08:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:08:20 --> Total execution time: 0.1441
DEBUG - 2020-10-03 14:08:23 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:08:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-03 14:08:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-03 14:08:23 --> Total execution time: 0.1678
DEBUG - 2020-10-03 14:08:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:08:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:08:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-03 14:08:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:08:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-03 14:08:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-03 14:08:47 --> Total execution time: 0.1766
DEBUG - 2020-10-03 14:08:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:08:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-03 14:08:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-03 14:08:50 --> Total execution time: 0.1363
DEBUG - 2020-10-03 14:08:53 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:08:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:08:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-03 14:09:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:09:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:09:04 --> Total execution time: 0.1212
DEBUG - 2020-10-03 14:09:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:09:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-03 14:09:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-03 14:09:06 --> Total execution time: 0.1375
DEBUG - 2020-10-03 14:09:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:09:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:09:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-03 14:09:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:09:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-03 14:09:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-03 14:09:15 --> Total execution time: 0.1253
DEBUG - 2020-10-03 14:09:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:09:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-03 14:09:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-03 14:09:18 --> Total execution time: 0.1185
DEBUG - 2020-10-03 14:09:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:09:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:09:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-03 14:09:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:09:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:09:36 --> Total execution time: 0.1407
DEBUG - 2020-10-03 14:09:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:09:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:09:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-03 14:11:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:11:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:11:43 --> Total execution time: 0.1233
DEBUG - 2020-10-03 14:16:25 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:16:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:16:25 --> Total execution time: 0.1322
DEBUG - 2020-10-03 14:16:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:16:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:16:30 --> Total execution time: 0.1187
DEBUG - 2020-10-03 14:16:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:16:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:16:46 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-03 14:16:46 --> Total execution time: 0.1253
DEBUG - 2020-10-03 14:16:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:16:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:16:49 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 14:16:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:16:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:16:51 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-10-03 14:16:51 --> Total execution time: 0.1247
DEBUG - 2020-10-03 14:16:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:16:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-03 14:16:54 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-03 14:16:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:16:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:16:54 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-03 14:16:54 --> Total execution time: 0.0968
DEBUG - 2020-10-03 14:16:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:16:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-03 14:16:59 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
ERROR - 2020-10-03 14:16:59 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-03 14:16:59 --> Total execution time: 0.1097
DEBUG - 2020-10-03 14:17:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-03 14:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-03 14:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-03 14:17:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-03 14:17:12 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-10-03 14:17:12 --> Total execution time: 0.1223
