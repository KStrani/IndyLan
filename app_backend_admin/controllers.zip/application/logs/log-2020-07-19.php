<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-07-19 11:00:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:00:48 --> No URI present. Default controller set.
DEBUG - 2020-07-19 11:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-19 11:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-19 11:00:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-19 11:00:49 --> Total execution time: 1.0947
DEBUG - 2020-07-19 11:00:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:00:50 --> No URI present. Default controller set.
DEBUG - 2020-07-19 11:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-19 11:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-19 11:00:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-19 11:00:50 --> Total execution time: 0.2525
DEBUG - 2020-07-19 11:01:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-19 11:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-19 11:01:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-19 11:01:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-19 11:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-19 11:01:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-19 11:01:06 --> Total execution time: 0.2475
DEBUG - 2020-07-19 11:01:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-19 11:01:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-19 11:01:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:07 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-19 11:01:07 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-19 11:01:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-19 11:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-19 11:01:07 --> UTF-8 Support Enabled
ERROR - 2020-07-19 11:01:07 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-19 11:01:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:07 --> 404 Page Not Found: Uploads/clothes.jpg
ERROR - 2020-07-19 11:01:07 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-19 11:01:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:07 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:08 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-19 11:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:08 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-19 11:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:08 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-19 11:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-19 11:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:08 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
ERROR - 2020-07-19 11:01:08 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-19 11:01:08 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:08 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-19 11:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-19 11:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:08 --> 404 Page Not Found: Uploads/home.jpg
ERROR - 2020-07-19 11:01:08 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:08 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-19 11:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:08 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:08 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:08 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-19 11:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:08 --> 404 Page Not Found: Uploads/opposites.jpg
ERROR - 2020-07-19 11:01:08 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:08 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
ERROR - 2020-07-19 11:01:08 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-19 11:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:08 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:08 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-19 11:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:08 --> 404 Page Not Found: Uploads/supermarket.jpg
ERROR - 2020-07-19 11:01:08 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:08 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-19 11:01:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:09 --> 404 Page Not Found: Uploads/weather.jpg
ERROR - 2020-07-19 11:01:09 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-19 11:01:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:09 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-19 11:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-19 11:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-19 11:01:10 --> UTF-8 Support Enabled
ERROR - 2020-07-19 11:01:10 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-19 11:01:10 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-19 11:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:10 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-19 11:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-19 11:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:10 --> 404 Page Not Found: Uploads/clothes.jpg
ERROR - 2020-07-19 11:01:10 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-19 11:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:10 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-19 11:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:10 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-19 11:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:10 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-19 11:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:10 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-19 11:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-19 11:01:10 --> UTF-8 Support Enabled
ERROR - 2020-07-19 11:01:10 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-19 11:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:10 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-19 11:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:10 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-19 11:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:10 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-19 11:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:10 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-19 11:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-19 11:01:10 --> UTF-8 Support Enabled
ERROR - 2020-07-19 11:01:10 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-19 11:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:10 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-19 11:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:10 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-19 11:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:10 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-19 11:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:10 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-19 11:01:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:11 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-19 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:11 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-19 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:11 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-19 11:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-19 11:01:11 --> UTF-8 Support Enabled
ERROR - 2020-07-19 11:01:11 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-19 11:01:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:11 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-19 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:11 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-19 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:11 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-19 11:01:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:11 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-19 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-19 11:01:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:11 --> 404 Page Not Found: Uploads/travel.jpg
ERROR - 2020-07-19 11:01:11 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-19 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:11 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-19 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-19 11:01:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-19 11:01:11 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
