<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-07-24 10:09:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-24 10:09:33 --> No URI present. Default controller set.
DEBUG - 2020-07-24 10:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-24 10:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-24 10:09:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-24 10:09:35 --> Total execution time: 1.5243
DEBUG - 2020-07-24 10:09:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-24 10:09:36 --> No URI present. Default controller set.
DEBUG - 2020-07-24 10:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-24 10:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-24 10:09:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-24 10:09:36 --> Total execution time: 0.1703
DEBUG - 2020-07-24 10:12:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-24 10:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-24 10:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-24 10:12:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-24 10:12:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-24 10:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-24 10:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-24 10:12:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-24 10:12:44 --> Total execution time: 0.3879
DEBUG - 2020-07-24 10:12:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-24 10:12:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-24 10:12:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-24 10:12:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-24 10:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-24 10:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-24 10:12:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-24 10:12:48 --> Total execution time: 0.1900
DEBUG - 2020-07-24 10:12:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-24 10:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-24 10:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-24 10:12:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-24 10:12:49 --> Total execution time: 0.4485
DEBUG - 2020-07-24 10:12:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-24 10:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-24 10:12:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-24 10:13:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-24 10:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-24 10:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-24 10:13:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-24 10:14:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-24 10:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-24 10:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-24 10:14:05 --> Session class already loaded. Second attempt ignored.
