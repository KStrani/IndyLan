<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-03-14 12:44:52 --> UTF-8 Support Enabled
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-03-14 12:44:52 --> UTF-8 Support Enabled
DEBUG - 2021-03-14 12:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-14 12:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-14 12:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-03-14 12:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-03-14 12:44:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-03-14 12:44:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-03-14 12:44:53 --> Total execution time: 0.1800
DEBUG - 2021-03-14 12:44:53 --> Total execution time: 0.1819
