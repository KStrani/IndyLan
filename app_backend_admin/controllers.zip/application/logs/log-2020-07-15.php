<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-07-15 04:57:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-15 04:57:26 --> No URI present. Default controller set.
DEBUG - 2020-07-15 04:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-15 04:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-15 04:57:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-15 04:57:27 --> Total execution time: 0.7260
DEBUG - 2020-07-15 05:12:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-15 05:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-15 05:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-15 05:12:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-15 05:12:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-15 05:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-15 05:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-15 05:12:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-15 05:12:57 --> Total execution time: 0.1180
DEBUG - 2020-07-15 11:30:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-15 11:30:39 --> No URI present. Default controller set.
DEBUG - 2020-07-15 11:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-15 11:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-15 11:30:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-15 11:30:40 --> Total execution time: 2.2260
