<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-07-10 04:56:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:06 --> No URI present. Default controller set.
DEBUG - 2020-07-10 04:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 04:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 04:56:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 04:56:07 --> Total execution time: 1.0037
DEBUG - 2020-07-10 04:56:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 04:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 04:56:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 04:56:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 04:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 04:56:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 04:56:25 --> Total execution time: 0.4319
DEBUG - 2020-07-10 04:56:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 04:56:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:26 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 04:56:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 04:56:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:26 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-10 04:56:26 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-10 04:56:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 04:56:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:26 --> 404 Page Not Found: Uploads/colours.jpg
ERROR - 2020-07-10 04:56:26 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-10 04:56:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:26 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-10 04:56:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 04:56:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:26 --> 404 Page Not Found: Uploads/employment.jpg
ERROR - 2020-07-10 04:56:26 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-10 04:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 04:56:27 --> UTF-8 Support Enabled
ERROR - 2020-07-10 04:56:27 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-10 04:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:27 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-10 04:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:27 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-10 04:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 04:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:27 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
ERROR - 2020-07-10 04:56:27 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-10 04:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:27 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-10 04:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 04:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:27 --> 404 Page Not Found: Uploads/materials.jpg
ERROR - 2020-07-10 04:56:27 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-10 04:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 04:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:27 --> 404 Page Not Found: Uploads/months_and_days.jpg
ERROR - 2020-07-10 04:56:27 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-10 04:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:27 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-10 04:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:27 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-10 04:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:27 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-10 04:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:27 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-10 04:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 04:56:27 --> UTF-8 Support Enabled
ERROR - 2020-07-10 04:56:27 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-10 04:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:27 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-10 04:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:27 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-10 04:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:27 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-10 04:56:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 04:56:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:28 --> 404 Page Not Found: Uploads/travel.jpg
ERROR - 2020-07-10 04:56:28 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-10 04:56:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:28 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-10 04:56:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:28 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-10 04:56:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:28 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-10 04:56:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 04:56:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:28 --> 404 Page Not Found: Uploads/clothes.jpg
ERROR - 2020-07-10 04:56:28 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 04:56:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:28 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-10 04:56:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:28 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-10 04:56:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:28 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-10 04:56:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:29 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-10 04:56:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:29 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-10 04:56:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 04:56:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:29 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-10 04:56:29 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-10 04:56:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:29 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-10 04:56:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:29 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-10 04:56:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:29 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-10 04:56:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:29 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-10 04:56:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:29 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-10 04:56:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:29 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-10 04:56:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 04:56:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 04:56:29 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-10 05:15:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:15:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-10 05:15:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '='1'' at line 1 - Invalid query: select * from tbl_master_language status='1'
ERROR - 2020-07-10 05:15:52 --> Severity: error --> Exception: Call to a member function result_array() on boolean E:\xampp\htdocs\voolsy\langoadmin\application\models\Admin_model.php 27
DEBUG - 2020-07-10 05:15:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:15:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-10 05:15:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '='1'' at line 1 - Invalid query: select * from tbl_master_language status='1'
ERROR - 2020-07-10 05:15:56 --> Severity: error --> Exception: Call to a member function result_array() on boolean E:\xampp\htdocs\voolsy\langoadmin\application\models\Admin_model.php 27
DEBUG - 2020-07-10 05:15:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:15:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-10 05:15:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '='1'' at line 1 - Invalid query: select * from tbl_master_language status='1'
ERROR - 2020-07-10 05:15:58 --> Severity: error --> Exception: Call to a member function result_array() on boolean E:\xampp\htdocs\voolsy\langoadmin\application\models\Admin_model.php 27
DEBUG - 2020-07-10 05:15:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:15:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-10 05:15:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '='1'' at line 1 - Invalid query: select * from tbl_master_language status='1'
ERROR - 2020-07-10 05:15:58 --> Severity: error --> Exception: Call to a member function result_array() on boolean E:\xampp\htdocs\voolsy\langoadmin\application\models\Admin_model.php 27
DEBUG - 2020-07-10 05:16:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:16:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-10 05:16:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '='1'' at line 1 - Invalid query: select * from tbl_master_language status='1'
ERROR - 2020-07-10 05:16:10 --> Severity: error --> Exception: Call to a member function result_array() on boolean E:\xampp\htdocs\voolsy\langoadmin\application\models\Admin_model.php 27
DEBUG - 2020-07-10 05:16:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:16:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 05:16:33 --> Total execution time: 0.1515
DEBUG - 2020-07-10 05:16:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 05:16:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:33 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-10 05:16:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:33 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-10 05:16:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:33 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 05:16:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:33 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-10 05:16:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:33 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-10 05:16:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:16:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:33 --> 404 Page Not Found: Uploads/employment.jpg
ERROR - 2020-07-10 05:16:33 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-10 05:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:34 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-10 05:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:34 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-10 05:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:34 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-10 05:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:16:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:34 --> 404 Page Not Found: Uploads/health_care.jpg
ERROR - 2020-07-10 05:16:34 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-10 05:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:34 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-10 05:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:34 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-10 05:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:16:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:34 --> 404 Page Not Found: Uploads/materials.jpg
ERROR - 2020-07-10 05:16:34 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-10 05:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:34 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-10 05:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:16:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:34 --> 404 Page Not Found: Uploads/numbers.png
ERROR - 2020-07-10 05:16:34 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-10 05:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:16:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:34 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
ERROR - 2020-07-10 05:16:34 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-10 05:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:34 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-10 05:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:16:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:34 --> 404 Page Not Found: Uploads/professions.jpg
ERROR - 2020-07-10 05:16:34 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-10 05:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:34 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-10 05:16:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:35 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-10 05:16:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:35 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-10 05:16:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:35 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-10 05:16:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:35 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-10 05:16:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:35 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-10 05:16:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:35 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-10 05:16:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:16:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:35 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-10 05:16:35 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-10 05:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:16:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:35 --> 404 Page Not Found: Uploads/clothes.jpg
ERROR - 2020-07-10 05:16:35 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 05:16:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:36 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-10 05:16:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:36 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-10 05:16:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:36 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-10 05:16:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:16:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 05:16:55 --> Total execution time: 0.1571
DEBUG - 2020-07-10 05:16:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 05:16:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:56 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 05:16:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:56 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-10 05:16:56 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-10 05:16:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:56 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-10 05:16:56 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-10 05:16:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:56 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-10 05:16:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:56 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-10 05:16:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:56 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-10 05:16:56 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:16:56 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-10 05:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:56 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-10 05:16:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:56 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-10 05:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:57 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-10 05:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:16:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:57 --> 404 Page Not Found: Uploads/in_the_office.jpg
ERROR - 2020-07-10 05:16:57 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-10 05:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:57 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-10 05:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:16:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:57 --> 404 Page Not Found: Uploads/materials.jpg
ERROR - 2020-07-10 05:16:57 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-10 05:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:57 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-10 05:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:16:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:57 --> 404 Page Not Found: Uploads/places.jpg
ERROR - 2020-07-10 05:16:57 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-10 05:16:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:57 --> 404 Page Not Found: Uploads/professions.jpg
ERROR - 2020-07-10 05:16:57 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-10 05:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:57 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-10 05:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:57 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-10 05:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:16:57 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:16:57 --> 404 Page Not Found: Uploads/supermarket.jpg
ERROR - 2020-07-10 05:16:57 --> 404 Page Not Found: Uploads/shapes.png
ERROR - 2020-07-10 05:16:57 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-10 05:16:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:57 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-10 05:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:57 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-10 05:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:57 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-10 05:16:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:57 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-10 05:16:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:16:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:58 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-10 05:16:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:16:58 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 05:17:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:17:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 05:17:06 --> Total execution time: 0.1441
DEBUG - 2020-07-10 05:17:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 05:17:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:06 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 05:17:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:07 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-10 05:17:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:07 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-10 05:17:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:07 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-10 05:17:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:07 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-10 05:17:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:07 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-10 05:17:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:07 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-10 05:17:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:17:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:07 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-10 05:17:07 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-10 05:17:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:07 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-10 05:17:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:07 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-10 05:17:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:07 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-10 05:17:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:07 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-10 05:17:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:17:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:07 --> 404 Page Not Found: Uploads/legal_terminology.jpg
ERROR - 2020-07-10 05:17:07 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-10 05:17:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:17:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:07 --> 404 Page Not Found: Uploads/months_and_days.jpg
ERROR - 2020-07-10 05:17:07 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-10 05:17:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:08 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-10 05:17:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:08 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-10 05:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:17:08 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:17:08 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-10 05:17:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:08 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-10 05:17:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:17:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:08 --> 404 Page Not Found: Uploads/professions.jpg
ERROR - 2020-07-10 05:17:08 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-10 05:17:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:08 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-10 05:17:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:08 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-10 05:17:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:08 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-10 05:17:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:08 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-10 05:17:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:17:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:08 --> 404 Page Not Found: Uploads/travel.jpg
ERROR - 2020-07-10 05:17:08 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-10 05:17:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:17:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:08 --> 404 Page Not Found: Uploads/weather.jpg
ERROR - 2020-07-10 05:17:08 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-10 05:17:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:17:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:17:08 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 05:20:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:20:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 05:20:20 --> Total execution time: 0.1825
DEBUG - 2020-07-10 05:20:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 05:20:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:21 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 05:20:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:21 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-10 05:20:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:21 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-10 05:20:21 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-10 05:20:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:21 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-10 05:20:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:21 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-10 05:20:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:21 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-10 05:20:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:21 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-10 05:20:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:21 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-10 05:20:21 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-10 05:20:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:21 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-10 05:20:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:20:22 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:20:22 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-10 05:20:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:22 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-10 05:20:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:20:22 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:20:22 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-10 05:20:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:22 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-10 05:20:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:20:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:22 --> 404 Page Not Found: Uploads/legal_terminology.jpg
ERROR - 2020-07-10 05:20:22 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-10 05:20:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:20:22 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:20:22 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-10 05:20:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:22 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-10 05:20:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:22 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-10 05:20:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:22 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-10 05:20:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:22 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-10 05:20:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:22 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-10 05:20:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:22 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-10 05:20:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:20:22 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:20:22 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-10 05:20:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:20:22 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:20:22 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-10 05:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:20:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:22 --> 404 Page Not Found: Uploads/transport.jpg
ERROR - 2020-07-10 05:20:22 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-10 05:20:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:22 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-10 05:20:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:22 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-10 05:20:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:23 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-10 05:20:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:20:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:20:23 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-10 05:20:23 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 05:21:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:21:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 05:21:49 --> Total execution time: 0.2169
DEBUG - 2020-07-10 05:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:21:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 05:21:50 --> Total execution time: 0.2351
DEBUG - 2020-07-10 05:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 05:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:50 --> 404 Page Not Found: Uploads/accessories.jpg
DEBUG - 2020-07-10 05:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:50 --> 404 Page Not Found: Uploads/adverbs.jpg
DEBUG - 2020-07-10 05:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:50 --> 404 Page Not Found: Uploads/appearance.jpg
ERROR - 2020-07-10 05:21:50 --> 404 Page Not Found: Uploads/animals_in_the_world.jpg
DEBUG - 2020-07-10 05:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:50 --> 404 Page Not Found: Uploads/animals_with_hooves.jpg
ERROR - 2020-07-10 05:21:50 --> 404 Page Not Found: Uploads/animals_in_europe.jpg
DEBUG - 2020-07-10 05:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:51 --> 404 Page Not Found: Uploads/At__the_dentists.JPG
DEBUG - 2020-07-10 05:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:51 --> 404 Page Not Found: Uploads/at_home.jpg
DEBUG - 2020-07-10 05:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:51 --> 404 Page Not Found: Uploads/baby_clothes.jpg
ERROR - 2020-07-10 05:21:51 --> 404 Page Not Found: Uploads/baby_toiletries.jpg
DEBUG - 2020-07-10 05:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:51 --> 404 Page Not Found: Uploads/bathroom.jpg
DEBUG - 2020-07-10 05:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:51 --> 404 Page Not Found: Uploads/bakery_and_pasta.jpg
DEBUG - 2020-07-10 05:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:51 --> 404 Page Not Found: Uploads/birds.jpg
DEBUG - 2020-07-10 05:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:51 --> 404 Page Not Found: Uploads/berries.jpg
DEBUG - 2020-07-10 05:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:51 --> 404 Page Not Found: Uploads/bedroom.jpg
DEBUG - 2020-07-10 05:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:51 --> 404 Page Not Found: Uploads/body_parts.jpg
DEBUG - 2020-07-10 05:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:51 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-10 05:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:51 --> 404 Page Not Found: Uploads/childrens_clothes.jpg
DEBUG - 2020-07-10 05:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:51 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-10 05:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:51 --> 404 Page Not Found: Uploads/cooking_verbs.jpg
DEBUG - 2020-07-10 05:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:51 --> 404 Page Not Found: Uploads/containers_and_portions.jpg
DEBUG - 2020-07-10 05:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:51 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-10 05:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:51 --> 404 Page Not Found: Uploads/opposites_doubles.jpg
DEBUG - 2020-07-10 05:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:51 --> 404 Page Not Found: Uploads/dairy.jpg
DEBUG - 2020-07-10 05:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:52 --> 404 Page Not Found: Uploads/drinks.jpg
DEBUG - 2020-07-10 05:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:52 --> 404 Page Not Found: Uploads/electronic_appliances.jpg
DEBUG - 2020-07-10 05:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:52 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-10 05:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:52 --> 404 Page Not Found: Uploads/equipment.jpg
DEBUG - 2020-07-10 05:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:52 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-10 05:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:52 --> 404 Page Not Found: Uploads/face_and_head.jpg
DEBUG - 2020-07-10 05:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:52 --> 404 Page Not Found: Uploads/everyday_life.jpg
DEBUG - 2020-07-10 05:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:52 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-10 05:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:52 --> 404 Page Not Found: Uploads/fish_and_seafood.jpg
DEBUG - 2020-07-10 05:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:52 --> 404 Page Not Found: Uploads/fixtures.jpg
DEBUG - 2020-07-10 05:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:52 --> 404 Page Not Found: Uploads/fruits.jpg
DEBUG - 2020-07-10 05:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:52 --> 404 Page Not Found: Uploads/furniture.jpg
ERROR - 2020-07-10 05:21:52 --> 404 Page Not Found: Uploads/generic.jpg
DEBUG - 2020-07-10 05:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:52 --> 404 Page Not Found: Uploads/grains_and_cereals.jpg
DEBUG - 2020-07-10 05:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:52 --> 404 Page Not Found: Uploads/herbs_and_spices.jpg
DEBUG - 2020-07-10 05:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:52 --> 404 Page Not Found: Uploads/ground_and_air.jpg
DEBUG - 2020-07-10 05:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:52 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-10 05:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:52 --> 404 Page Not Found: Uploads/in_the_kitchen.jpg
DEBUG - 2020-07-10 05:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:52 --> 404 Page Not Found: Uploads/illnesses.jpg
DEBUG - 2020-07-10 05:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:53 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-10 05:21:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:53 --> 404 Page Not Found: Uploads/items_at_home.jpg
DEBUG - 2020-07-10 05:21:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:53 --> 404 Page Not Found: Uploads/insects.jpg
DEBUG - 2020-07-10 05:21:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:53 --> 404 Page Not Found: Uploads/laundry_and_cleaning.jpg
DEBUG - 2020-07-10 05:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:53 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-10 05:21:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:53 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-10 05:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:53 --> 404 Page Not Found: Uploads/materials_and_patterns.jpg
DEBUG - 2020-07-10 05:21:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:53 --> 404 Page Not Found: Uploads/medical_equipment.jpg
DEBUG - 2020-07-10 05:21:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:53 --> 404 Page Not Found: Uploads/medical_symptoms.jpg
ERROR - 2020-07-10 05:21:53 --> 404 Page Not Found: Uploads/medical_terms.jpg
DEBUG - 2020-07-10 05:21:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:53 --> 404 Page Not Found: Uploads/meat.jpg
DEBUG - 2020-07-10 05:21:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:53 --> 404 Page Not Found: Uploads/medication.jpg
ERROR - 2020-07-10 05:21:53 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-10 05:21:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:53 --> 404 Page Not Found: Uploads/Mushrooms.jpg
DEBUG - 2020-07-10 05:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:53 --> 404 Page Not Found: Uploads/numbers_cardinals.png
ERROR - 2020-07-10 05:21:53 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-10 05:21:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:53 --> 404 Page Not Found: Uploads/nationalities.jpg
DEBUG - 2020-07-10 05:21:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:53 --> 404 Page Not Found: Uploads/numbers_ordinals.png
ERROR - 2020-07-10 05:21:53 --> 404 Page Not Found: Uploads/nuts_and_dried_fruit.jpg
DEBUG - 2020-07-10 05:21:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/Ready_meals.JPG
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/professions.jpg
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-10 05:21:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/reptiles_and_amphibians.jpg
DEBUG - 2020-07-10 05:21:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/rooms.jpg
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/Sauces_and_condiments.jpg
DEBUG - 2020-07-10 05:21:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/sea_animals_and_fish.jpg
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-10 05:21:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:54 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/shoes_and_trousers.jpg
DEBUG - 2020-07-10 05:21:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/Snacks_and_sweets.JPG
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/sport_terms.png
DEBUG - 2020-07-10 05:21:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/Toiletries.jpg
DEBUG - 2020-07-10 05:21:54 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/tools_and_diy.jpg
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/toys_and_games.jpg
DEBUG - 2020-07-10 05:21:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:54 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/types_of_sports.jpg
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-10 05:21:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/2_verbs.png
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/Vegetables.JPG
DEBUG - 2020-07-10 05:21:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/1_verbs.png
DEBUG - 2020-07-10 05:21:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-10 05:21:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:54 --> 404 Page Not Found: Uploads/water.jpg
DEBUG - 2020-07-10 05:21:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:21:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 05:21:56 --> Total execution time: 0.1442
DEBUG - 2020-07-10 05:21:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:21:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 05:21:57 --> Total execution time: 0.5517
DEBUG - 2020-07-10 05:21:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 05:21:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:21:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:21:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:21:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:58 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:21:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:21:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:21:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:21:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:21:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:58 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:21:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:21:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:21:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:21:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:21:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:21:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:59 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:21:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:21:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:21:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:59 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:21:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:21:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:21:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:21:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:59 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:21:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:21:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:21:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:21:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:21:59 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:21:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:21:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:21:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:00 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:22:00 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:00 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:22:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:00 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:00 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:00 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:01 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:22:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:01 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:01 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:01 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:01 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:22:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 05:22:07 --> Total execution time: 0.3962
DEBUG - 2020-07-10 05:22:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 05:22:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:08 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:22:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:08 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:22:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:08 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:08 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:09 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:09 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:09 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:09 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:10 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:10 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:10 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:10 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:22:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:10 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:10 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:11 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:11 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:22:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:11 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:22:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:11 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:22:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 05:22:32 --> Total execution time: 0.3831
DEBUG - 2020-07-10 05:22:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 05:22:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:33 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:34 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:34 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:34 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:34 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:34 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:35 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:35 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:35 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:35 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:22:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:35 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:36 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:36 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:36 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:22:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:22:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:22:36 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:36 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:22:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:23:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 05:23:23 --> Total execution time: 0.3680
DEBUG - 2020-07-10 05:23:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 05:23:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:24 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:23:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:24 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:23:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:24 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:23:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:25 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:23:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:25 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:23:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:25 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:23:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:25 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:23:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:25 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:23:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:25 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:23:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:25 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:23:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:26 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:23:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:26 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:23:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:26 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:23:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:26 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:23:26 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:23:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:26 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:23:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:26 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:23:26 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:23:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:26 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:23:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:27 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:23:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:27 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:23:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:27 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:23:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:27 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:23:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:23:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:23:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:29:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 05:29:39 --> Total execution time: 0.4023
DEBUG - 2020-07-10 05:29:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 05:29:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:29:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:40 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:29:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:29:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:40 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:29:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:29:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:40 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:29:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:29:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:41 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:29:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:29:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:41 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:29:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:29:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:41 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:29:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:29:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:41 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:29:41 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:29:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:29:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:42 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:29:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:29:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:42 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:29:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:29:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:42 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:29:42 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:29:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:29:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:42 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:29:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:29:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:42 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:29:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:29:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:43 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:29:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:29:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:43 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:29:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:29:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:43 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:29:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:29:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:43 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:29:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:29:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:43 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:29:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:29:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:43 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:29:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:29:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:29:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:40:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-10 05:40:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\header.php 86
DEBUG - 2020-07-10 05:40:11 --> Total execution time: 0.3761
DEBUG - 2020-07-10 05:40:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 05:40:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:40:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:12 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:40:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:40:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:12 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:40:12 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:40:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:40:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:12 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:40:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:40:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:12 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:40:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:40:12 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:40:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:13 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:40:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:13 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:40:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:13 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:40:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:13 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:40:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:13 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:40:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:13 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:40:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:13 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:40:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:14 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:40:14 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:40:14 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:40:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:14 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:40:14 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:40:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:14 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:40:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:15 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:40:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:40:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:15 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:40:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:40:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:15 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:40:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:40:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:40:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:44:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 05:44:45 --> Total execution time: 0.3820
DEBUG - 2020-07-10 05:44:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 05:44:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:44:46 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:44:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:46 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:44:46 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:44:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:44:46 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:44:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:46 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:44:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:44:47 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:44:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:47 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:44:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:47 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:44:47 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:44:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:47 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:44:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:48 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:44:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:44:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:48 --> UTF-8 Support Enabled
ERROR - 2020-07-10 05:44:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:48 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:44:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:44:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:49 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:44:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:44:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:49 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:44:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:44:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:49 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-10 05:44:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 05:44:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-10 05:44:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:44:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 05:44:51 --> Total execution time: 0.1795
DEBUG - 2020-07-10 05:44:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:44:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-10 05:44:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '='1'' at line 1 - Invalid query: select * from tbl_master_language status='1'
ERROR - 2020-07-10 05:44:52 --> Severity: error --> Exception: Call to a member function result_array() on boolean E:\xampp\htdocs\voolsy\langoadmin\application\models\Admin_model.php 27
DEBUG - 2020-07-10 05:44:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:44:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-10 05:44:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '='1'' at line 1 - Invalid query: select * from tbl_master_language status='1'
ERROR - 2020-07-10 05:44:55 --> Severity: error --> Exception: Call to a member function result_array() on boolean E:\xampp\htdocs\voolsy\langoadmin\application\models\Admin_model.php 27
DEBUG - 2020-07-10 05:44:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:44:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-10 05:44:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '='1'' at line 1 - Invalid query: select * from tbl_master_language status='1'
ERROR - 2020-07-10 05:44:56 --> Severity: error --> Exception: Call to a member function result_array() on boolean E:\xampp\htdocs\voolsy\langoadmin\application\models\Admin_model.php 27
DEBUG - 2020-07-10 05:44:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:44:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-10 05:44:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '='1'' at line 1 - Invalid query: select * from tbl_master_language status='1'
ERROR - 2020-07-10 05:44:57 --> Severity: error --> Exception: Call to a member function result_array() on boolean E:\xampp\htdocs\voolsy\langoadmin\application\models\Admin_model.php 27
DEBUG - 2020-07-10 05:45:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:45:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 05:45:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:45:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-10 05:45:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '='1'' at line 1 - Invalid query: select * from tbl_master_language status='1'
ERROR - 2020-07-10 05:45:38 --> Severity: error --> Exception: Call to a member function result_array() on boolean E:\xampp\htdocs\voolsy\langoadmin\application\models\Admin_model.php 28
DEBUG - 2020-07-10 05:45:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:45:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-10 05:45:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '=1' at line 1 - Invalid query: select * from tbl_master_language status=1
ERROR - 2020-07-10 05:45:46 --> Severity: error --> Exception: Call to a member function result_array() on boolean E:\xampp\htdocs\voolsy\langoadmin\application\models\Admin_model.php 28
DEBUG - 2020-07-10 05:45:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:45:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 05:46:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:46:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 05:46:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:46:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 05:48:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:48:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 05:48:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:48:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 05:48:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 05:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 05:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 05:48:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 06:09:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 06:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 06:09:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 06:09:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 06:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 06:09:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 06:09:20 --> Total execution time: 0.1266
DEBUG - 2020-07-10 06:09:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 06:09:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 06:09:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:21 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-10 06:09:21 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-10 06:09:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:21 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 06:09:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 06:09:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:21 --> UTF-8 Support Enabled
ERROR - 2020-07-10 06:09:21 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-10 06:09:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:21 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-10 06:09:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:21 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-10 06:09:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:21 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-10 06:09:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:21 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-10 06:09:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:21 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-10 06:09:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:21 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-10 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:22 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-10 06:09:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:22 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-10 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 06:09:22 --> UTF-8 Support Enabled
ERROR - 2020-07-10 06:09:22 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-10 06:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 06:09:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:22 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-10 06:09:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:22 --> 404 Page Not Found: Uploads/in_the_office.jpg
ERROR - 2020-07-10 06:09:22 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-10 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:22 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-10 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:22 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-10 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:22 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-10 06:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 06:09:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:22 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-10 06:09:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:22 --> 404 Page Not Found: Uploads/numbers.png
ERROR - 2020-07-10 06:09:22 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-10 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:22 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-10 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:22 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-10 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 06:09:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:22 --> 404 Page Not Found: Uploads/shapes.png
ERROR - 2020-07-10 06:09:22 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-10 06:09:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:22 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-10 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:22 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-10 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:22 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-10 06:09:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:23 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-10 06:09:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:23 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-10 06:09:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 06:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 06:09:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:23 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-10 06:09:23 --> 404 Page Not Found: Uploads/clothes.jpg
ERROR - 2020-07-10 06:09:23 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-10 06:09:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:23 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 06:09:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:23 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-10 06:09:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:09:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:09:23 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-10 06:56:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 06:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 06:56:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-10 06:56:49 --> Severity: error --> Exception: syntax error, unexpected '?>' E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\header.php 87
DEBUG - 2020-07-10 06:57:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 06:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 06:57:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 06:57:22 --> Total execution time: 0.1799
DEBUG - 2020-07-10 06:57:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 06:57:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:23 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 06:57:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:23 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-10 06:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 06:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 06:57:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:23 --> UTF-8 Support Enabled
ERROR - 2020-07-10 06:57:23 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-10 06:57:23 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-10 06:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:23 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-10 06:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:23 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-10 06:57:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 06:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:23 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-10 06:57:23 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-10 06:57:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 06:57:23 --> UTF-8 Support Enabled
ERROR - 2020-07-10 06:57:23 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-10 06:57:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:23 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-10 06:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:23 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-10 06:57:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:23 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-10 06:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:24 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-10 06:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:24 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-10 06:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:24 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-10 06:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:24 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-10 06:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:24 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-10 06:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:24 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-10 06:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:24 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-10 06:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:24 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-10 06:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:24 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-10 06:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:24 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-10 06:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:24 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-10 06:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:24 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-10 06:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:24 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-10 06:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:24 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-10 06:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:24 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-10 06:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 06:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:24 --> 404 Page Not Found: Uploads/supermarket.jpg
ERROR - 2020-07-10 06:57:24 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-10 06:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 06:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:24 --> 404 Page Not Found: Uploads/weather.jpg
ERROR - 2020-07-10 06:57:24 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-10 06:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 06:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 06:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:25 --> 404 Page Not Found: Uploads/animals.jpg
ERROR - 2020-07-10 06:57:25 --> 404 Page Not Found: Uploads/colours.jpg
ERROR - 2020-07-10 06:57:25 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-10 06:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 06:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:25 --> 404 Page Not Found: Uploads/clothes.jpg
ERROR - 2020-07-10 06:57:25 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-10 06:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:25 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-10 06:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:25 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-10 06:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:26 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-10 06:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 06:57:26 --> UTF-8 Support Enabled
ERROR - 2020-07-10 06:57:26 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-10 06:57:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:26 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-10 06:57:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:26 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-10 06:57:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 06:57:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 06:57:26 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-10 07:05:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:06 --> 404 Page Not Found: Change_language/4
DEBUG - 2020-07-10 07:05:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 07:05:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 07:05:09 --> Total execution time: 0.1720
DEBUG - 2020-07-10 07:05:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 07:05:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 07:05:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 07:05:12 --> Total execution time: 0.1916
DEBUG - 2020-07-10 07:05:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 07:05:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:12 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 07:05:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:12 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-10 07:05:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:05:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:13 --> 404 Page Not Found: Uploads/colours.jpg
ERROR - 2020-07-10 07:05:13 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-10 07:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:05:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:13 --> 404 Page Not Found: Uploads/clothes.jpg
ERROR - 2020-07-10 07:05:13 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-10 07:05:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:13 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-10 07:05:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:05:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:13 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-10 07:05:13 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-10 07:05:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:05:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:13 --> 404 Page Not Found: Uploads/grammar.jpg
ERROR - 2020-07-10 07:05:13 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-10 07:05:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:13 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-10 07:05:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:14 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-10 07:05:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:05:14 --> UTF-8 Support Enabled
ERROR - 2020-07-10 07:05:14 --> 404 Page Not Found: Uploads/in_the_office.jpg
ERROR - 2020-07-10 07:05:14 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-10 07:05:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:14 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-10 07:05:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:14 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-10 07:05:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:14 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-10 07:05:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:14 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-10 07:05:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:14 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-10 07:05:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:05:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:14 --> 404 Page Not Found: Uploads/opposites.jpg
ERROR - 2020-07-10 07:05:14 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-10 07:05:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:14 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-10 07:05:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:14 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-10 07:05:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:14 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-10 07:05:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:14 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-10 07:05:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:14 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-10 07:05:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:05:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:14 --> 404 Page Not Found: Uploads/travel.jpg
ERROR - 2020-07-10 07:05:14 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-10 07:05:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:14 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-10 07:05:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:14 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-10 07:05:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:05:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:15 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-10 07:05:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:15 --> 404 Page Not Found: Uploads/animals.jpg
ERROR - 2020-07-10 07:05:15 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-10 07:05:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:05:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:15 --> UTF-8 Support Enabled
ERROR - 2020-07-10 07:05:15 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-10 07:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:05:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:15 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
ERROR - 2020-07-10 07:05:15 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-10 07:05:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:05:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:15 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-10 07:05:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:15 --> 404 Page Not Found: Uploads/home.jpg
ERROR - 2020-07-10 07:05:15 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-10 07:05:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:05:16 --> UTF-8 Support Enabled
ERROR - 2020-07-10 07:05:16 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-10 07:05:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:16 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-10 07:05:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:16 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-10 07:05:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:05:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:16 --> 404 Page Not Found: Uploads/numbers.png
ERROR - 2020-07-10 07:05:16 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-10 07:05:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:16 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-10 07:05:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:16 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-10 07:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:05:16 --> UTF-8 Support Enabled
ERROR - 2020-07-10 07:05:16 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-10 07:05:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:16 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-10 07:05:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:05:16 --> UTF-8 Support Enabled
ERROR - 2020-07-10 07:05:16 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-10 07:05:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:16 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-10 07:05:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:16 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-10 07:05:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:05:16 --> UTF-8 Support Enabled
ERROR - 2020-07-10 07:05:16 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-10 07:05:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:05:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:16 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-10 07:05:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:05:16 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-10 07:07:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 07:07:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 07:07:01 --> Total execution time: 0.1332
DEBUG - 2020-07-10 07:07:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:07:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 07:07:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:07:02 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 07:07:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:07:02 --> UTF-8 Support Enabled
ERROR - 2020-07-10 07:07:02 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-10 07:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:07:02 --> UTF-8 Support Enabled
ERROR - 2020-07-10 07:07:02 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-10 07:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:07:02 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-10 07:07:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:07:02 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-10 07:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:07:02 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-10 07:07:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:07:02 --> UTF-8 Support Enabled
ERROR - 2020-07-10 07:07:02 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-10 07:07:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:07:02 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-10 07:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:07:02 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-10 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:07:03 --> UTF-8 Support Enabled
ERROR - 2020-07-10 07:07:03 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-10 07:07:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:07:03 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-10 07:07:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:07:03 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-10 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:07:03 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-10 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:07:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:07:03 --> 404 Page Not Found: Uploads/in_the_office.jpg
ERROR - 2020-07-10 07:07:03 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-10 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:07:03 --> UTF-8 Support Enabled
ERROR - 2020-07-10 07:07:03 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-10 07:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:07:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:07:03 --> 404 Page Not Found: Uploads/months_and_days.jpg
ERROR - 2020-07-10 07:07:03 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-10 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:07:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:07:03 --> 404 Page Not Found: Uploads/numbers.png
ERROR - 2020-07-10 07:07:03 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-10 07:07:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:07:03 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-10 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:07:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:07:03 --> 404 Page Not Found: Uploads/places.jpg
ERROR - 2020-07-10 07:07:03 --> 404 Page Not Found: Uploads/scotland.jpg
ERROR - 2020-07-10 07:07:03 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-10 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:07:03 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-10 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:07:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:07:03 --> 404 Page Not Found: Uploads/sports.jpg
ERROR - 2020-07-10 07:07:03 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-10 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:07:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:07:03 --> 404 Page Not Found: Uploads/travel.jpg
ERROR - 2020-07-10 07:07:03 --> 404 Page Not Found: Uploads/weather.jpg
ERROR - 2020-07-10 07:07:03 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-10 07:07:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:07:04 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-10 07:07:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:07:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:07:04 --> 404 Page Not Found: Uploads/animals.jpg
ERROR - 2020-07-10 07:07:04 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-10 07:10:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 07:10:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 07:10:35 --> Total execution time: 0.1768
DEBUG - 2020-07-10 07:10:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 07:10:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:35 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 07:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:36 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-10 07:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:10:36 --> UTF-8 Support Enabled
ERROR - 2020-07-10 07:10:36 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-10 07:10:36 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-10 07:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:36 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-10 07:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:36 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-10 07:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:36 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-10 07:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:36 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-10 07:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:36 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-10 07:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:36 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-10 07:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:36 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-10 07:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:36 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-10 07:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:36 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-10 07:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:36 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-10 07:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:10:36 --> UTF-8 Support Enabled
ERROR - 2020-07-10 07:10:36 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-10 07:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:36 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-10 07:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:36 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-10 07:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:37 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-10 07:10:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:37 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-10 07:10:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:37 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-10 07:10:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:37 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-10 07:10:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:37 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-10 07:10:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:37 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-10 07:10:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:37 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-10 07:10:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:37 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-10 07:10:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:37 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-10 07:10:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:10:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:37 --> 404 Page Not Found: Uploads/supermarket.jpg
ERROR - 2020-07-10 07:10:37 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-10 07:10:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:10:37 --> UTF-8 Support Enabled
ERROR - 2020-07-10 07:10:37 --> 404 Page Not Found: Uploads/weather.jpg
ERROR - 2020-07-10 07:10:37 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-10 07:10:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:37 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-10 07:10:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:10:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:38 --> 404 Page Not Found: Uploads/home.jpg
ERROR - 2020-07-10 07:10:38 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-10 07:10:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:38 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-10 07:10:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 07:10:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:10:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:10:46 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-10 07:11:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 07:11:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 07:11:18 --> Total execution time: 0.1336
DEBUG - 2020-07-10 07:11:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 07:11:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:18 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 07:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:19 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-10 07:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:19 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-10 07:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:19 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-10 07:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:19 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-10 07:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:19 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-10 07:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:19 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-10 07:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:19 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-10 07:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:19 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-10 07:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:19 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-10 07:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:19 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-10 07:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:19 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-10 07:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:19 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-10 07:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:20 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-10 07:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:20 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-10 07:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:20 --> 404 Page Not Found: Uploads/materials.jpg
ERROR - 2020-07-10 07:11:20 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-10 07:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:20 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-10 07:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:20 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-10 07:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:20 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-10 07:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:20 --> 404 Page Not Found: Uploads/professions.jpg
ERROR - 2020-07-10 07:11:20 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-10 07:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:20 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-10 07:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:20 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-10 07:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:20 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-10 07:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:20 --> 404 Page Not Found: Uploads/travel.jpg
ERROR - 2020-07-10 07:11:20 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-10 07:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:11:20 --> UTF-8 Support Enabled
ERROR - 2020-07-10 07:11:20 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-10 07:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:20 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-10 07:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:20 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-10 07:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:21 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-10 07:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:21 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-10 07:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:11:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:21 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-10 07:11:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:11:21 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 07:44:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 07:44:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 07:44:08 --> Total execution time: 0.1380
DEBUG - 2020-07-10 07:44:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 07:44:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:09 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 07:44:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:09 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-10 07:44:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:09 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-10 07:44:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:09 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-10 07:44:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:09 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-10 07:44:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:09 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-10 07:44:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:10 --> 404 Page Not Found: Uploads/grammar.jpg
ERROR - 2020-07-10 07:44:10 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-10 07:44:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:10 --> UTF-8 Support Enabled
ERROR - 2020-07-10 07:44:10 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-10 07:44:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:10 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-10 07:44:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:10 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-10 07:44:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:10 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-10 07:44:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:10 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-10 07:44:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:10 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-10 07:44:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:10 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-10 07:44:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:10 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-10 07:44:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:10 --> 404 Page Not Found: Uploads/music.jpg
ERROR - 2020-07-10 07:44:10 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-10 07:44:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:11 --> 404 Page Not Found: Uploads/numbers.png
ERROR - 2020-07-10 07:44:11 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-10 07:44:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:11 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-10 07:44:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:11 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-10 07:44:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:11 --> 404 Page Not Found: Uploads/scotland.jpg
ERROR - 2020-07-10 07:44:11 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-10 07:44:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:11 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-10 07:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:11 --> 404 Page Not Found: Uploads/sports.jpg
ERROR - 2020-07-10 07:44:11 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-10 07:44:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:11 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-10 07:44:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:11 --> UTF-8 Support Enabled
ERROR - 2020-07-10 07:44:11 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-10 07:44:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:11 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-10 07:44:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:11 --> 404 Page Not Found: Uploads/weather.jpg
ERROR - 2020-07-10 07:44:11 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-10 07:44:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:12 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-10 07:44:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:12 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-10 07:44:12 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-10 07:44:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:12 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-10 07:44:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:12 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-10 07:44:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:12 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 07:44:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:13 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-10 07:44:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:13 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-10 07:44:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:13 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-10 07:44:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:13 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-10 07:44:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:13 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-10 07:44:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:13 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-10 07:44:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:13 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-10 07:44:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:13 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-10 07:44:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:13 --> UTF-8 Support Enabled
ERROR - 2020-07-10 07:44:13 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-10 07:44:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:13 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-10 07:44:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:13 --> UTF-8 Support Enabled
ERROR - 2020-07-10 07:44:13 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-10 07:44:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:13 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-10 07:44:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 07:44:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 07:44:38 --> Total execution time: 0.1536
DEBUG - 2020-07-10 07:44:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:39 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:39 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-10 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:39 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-10 07:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:39 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-10 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:39 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-10 07:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:39 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-10 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:39 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-10 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:39 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-10 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:39 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-10 07:44:39 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-10 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:39 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-10 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:39 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-10 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:39 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-10 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:39 --> 404 Page Not Found: Uploads/materials.jpg
ERROR - 2020-07-10 07:44:39 --> 404 Page Not Found: Uploads/legal_terminology.jpg
ERROR - 2020-07-10 07:44:39 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-10 07:44:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:40 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-10 07:44:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:40 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-10 07:44:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:40 --> UTF-8 Support Enabled
ERROR - 2020-07-10 07:44:40 --> 404 Page Not Found: Uploads/numbers.png
ERROR - 2020-07-10 07:44:40 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-10 07:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:40 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-10 07:44:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:40 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-10 07:44:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:40 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-10 07:44:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:40 --> 404 Page Not Found: Uploads/scotland.jpg
ERROR - 2020-07-10 07:44:40 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-10 07:44:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:40 --> 404 Page Not Found: Uploads/sports.jpg
ERROR - 2020-07-10 07:44:40 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-10 07:44:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:40 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-10 07:44:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:40 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-10 07:44:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:40 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-10 07:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:40 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-10 07:44:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:41 --> UTF-8 Support Enabled
ERROR - 2020-07-10 07:44:41 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 07:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:41 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-10 07:44:41 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-10 07:44:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:41 --> 404 Page Not Found: Uploads/numbers.png
ERROR - 2020-07-10 07:44:41 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-10 07:44:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:41 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-10 07:44:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:42 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-10 07:44:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:44:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:44:42 --> 404 Page Not Found: Uploads/places.jpg
ERROR - 2020-07-10 07:44:42 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-10 07:56:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 07:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-10 07:56:43 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\header.php 86
DEBUG - 2020-07-10 07:56:43 --> Total execution time: 0.1686
DEBUG - 2020-07-10 07:56:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 07:56:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:44 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-10 07:56:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 07:56:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-10 07:56:47 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\header.php 86
DEBUG - 2020-07-10 07:56:47 --> Total execution time: 0.1684
DEBUG - 2020-07-10 07:56:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 07:56:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:49 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-10 07:56:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 07:56:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 07:56:52 --> Total execution time: 0.1550
DEBUG - 2020-07-10 07:56:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 07:56:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 07:56:52 --> Total execution time: 0.1617
DEBUG - 2020-07-10 07:56:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-10 07:56:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:52 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 07:56:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:52 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-10 07:56:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:53 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-10 07:56:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:53 --> 404 Page Not Found: Uploads/countries.jpg
ERROR - 2020-07-10 07:56:53 --> 404 Page Not Found: Uploads/colours.jpg
ERROR - 2020-07-10 07:56:53 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-10 07:56:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:53 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-10 07:56:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:56:53 --> UTF-8 Support Enabled
ERROR - 2020-07-10 07:56:53 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-10 07:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:53 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-10 07:56:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:53 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-10 07:56:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:53 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-10 07:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:53 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-10 07:56:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:53 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-10 07:56:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:53 --> 404 Page Not Found: Uploads/in_the_office.jpg
ERROR - 2020-07-10 07:56:53 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-10 07:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:53 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-10 07:56:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:53 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-10 07:56:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:54 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-10 07:56:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:54 --> 404 Page Not Found: Uploads/numbers.png
ERROR - 2020-07-10 07:56:54 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-10 07:56:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:54 --> 404 Page Not Found: Uploads/opposites.jpg
ERROR - 2020-07-10 07:56:54 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-10 07:56:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:54 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-10 07:56:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:54 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-10 07:56:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:54 --> 404 Page Not Found: Uploads/transport.jpg
ERROR - 2020-07-10 07:56:54 --> 404 Page Not Found: Uploads/sports.jpg
ERROR - 2020-07-10 07:56:54 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-10 07:56:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:54 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-10 07:56:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:54 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-10 07:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:54 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-10 07:56:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:54 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-10 07:56:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:56:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:55 --> 404 Page Not Found: Uploads/places.jpg
ERROR - 2020-07-10 07:56:55 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-10 07:56:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:55 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-10 07:56:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:56:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:55 --> 404 Page Not Found: Uploads/professions.jpg
ERROR - 2020-07-10 07:56:55 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-10 07:56:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:55 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-10 07:56:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:56 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-10 07:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 07:56:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:56 --> 404 Page Not Found: Uploads/scotland.jpg
ERROR - 2020-07-10 07:56:56 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-10 07:56:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:56 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-10 07:56:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 07:56:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 07:56:56 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-10 09:34:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 09:34:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 09:34:29 --> 404 Page Not Found: Change_language/4
DEBUG - 2020-07-10 09:34:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 09:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 09:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 09:34:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 09:34:34 --> Total execution time: 0.1941
DEBUG - 2020-07-10 09:34:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 09:34:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 09:34:36 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-10 09:34:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 09:34:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 09:34:45 --> 404 Page Not Found: Change_language/3
DEBUG - 2020-07-10 09:34:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 09:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-10 09:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-10 09:34:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-10 09:34:50 --> Total execution time: 0.1481
DEBUG - 2020-07-10 09:34:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-10 09:34:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-10 09:34:52 --> 404 Page Not Found: Assets/js
