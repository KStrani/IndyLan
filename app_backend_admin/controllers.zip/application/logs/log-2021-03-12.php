<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-03-12 10:14:41 --> UTF-8 Support Enabled
DEBUG - 2021-03-12 10:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-12 10:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-03-12 10:14:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-03-12 10:14:43 --> UTF-8 Support Enabled
DEBUG - 2021-03-12 10:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-12 10:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-03-12 10:14:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-03-12 10:14:43 --> Total execution time: 0.1862
DEBUG - 2021-03-12 10:14:54 --> UTF-8 Support Enabled
DEBUG - 2021-03-12 10:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-12 10:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-03-12 10:14:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-03-12 10:14:56 --> UTF-8 Support Enabled
DEBUG - 2021-03-12 10:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-12 10:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-03-12 10:14:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-03-12 10:14:57 --> Total execution time: 0.1782
