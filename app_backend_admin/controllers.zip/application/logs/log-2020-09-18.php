<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-09-18 05:23:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 05:23:58 --> No URI present. Default controller set.
DEBUG - 2020-09-18 05:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-18 05:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-18 05:23:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 05:23:59 --> Total execution time: 0.2373
DEBUG - 2020-09-18 05:24:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 05:24:01 --> No URI present. Default controller set.
DEBUG - 2020-09-18 05:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-18 05:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-18 05:24:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 05:24:01 --> Total execution time: 0.1264
DEBUG - 2020-09-18 12:12:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 12:12:59 --> No URI present. Default controller set.
DEBUG - 2020-09-18 12:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-18 12:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-18 12:12:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 12:12:59 --> Total execution time: 0.1411
DEBUG - 2020-09-18 12:14:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 12:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-18 12:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-18 12:14:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 12:14:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 12:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-18 12:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-18 12:14:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 12:14:15 --> Total execution time: 0.1482
DEBUG - 2020-09-18 12:14:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 12:14:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-18 12:14:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-18 12:14:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 12:14:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-18 12:14:19 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-18 12:14:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 12:14:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-18 12:14:22 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-09-18 12:14:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 12:14:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-18 12:14:23 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-18 12:14:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 12:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-18 12:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-18 12:14:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 12:14:25 --> Total execution time: 0.1533
DEBUG - 2020-09-18 12:14:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 12:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-18 12:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-18 12:14:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-18 12:14:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-18 12:14:28 --> Total execution time: 0.1258
DEBUG - 2020-09-18 12:14:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 12:14:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-18 12:14:31 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-18 12:15:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 12:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-18 12:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-18 12:15:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-18 12:15:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-18 12:15:23 --> Total execution time: 0.1307
DEBUG - 2020-09-18 12:15:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 12:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-18 12:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-18 12:15:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-18 12:15:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-18 12:15:26 --> Total execution time: 0.1472
DEBUG - 2020-09-18 12:15:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 12:15:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-18 12:15:29 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-18 12:15:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 12:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-18 12:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-18 12:15:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 12:15:34 --> Total execution time: 0.1174
DEBUG - 2020-09-18 12:15:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 12:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-18 12:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-18 12:15:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-18 12:15:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-18 12:15:37 --> Total execution time: 0.1273
DEBUG - 2020-09-18 12:15:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 12:15:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-18 12:15:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-18 12:15:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 12:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-18 12:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-18 12:15:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-18 12:15:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-18 12:15:45 --> Total execution time: 0.1291
DEBUG - 2020-09-18 12:15:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 12:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-18 12:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-18 12:15:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-18 12:15:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-18 12:15:48 --> Total execution time: 0.1196
DEBUG - 2020-09-18 12:15:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 12:15:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-18 12:15:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-18 12:16:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 12:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-18 12:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-18 12:16:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 12:16:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 12:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-18 12:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-18 12:16:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-18 12:16:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-18 12:16:15 --> Total execution time: 0.1318
DEBUG - 2020-09-18 12:16:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-18 12:16:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-18 12:16:18 --> 404 Page Not Found: Assets/chosen
