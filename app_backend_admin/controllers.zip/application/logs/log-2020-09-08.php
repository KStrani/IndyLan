<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-09-08 01:05:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:05:55 --> No URI present. Default controller set.
DEBUG - 2020-09-08 01:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 01:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 01:05:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 01:05:55 --> Total execution time: 0.1537
DEBUG - 2020-09-08 01:06:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 01:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 01:06:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 01:06:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 01:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 01:06:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 01:06:25 --> Total execution time: 0.1285
DEBUG - 2020-09-08 01:06:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:06:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 01:06:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-08 01:08:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 01:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 01:08:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 01:08:01 --> Total execution time: 0.1832
DEBUG - 2020-09-08 01:08:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:08:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 01:08:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-08 01:08:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 01:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 01:08:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 01:08:10 --> Total execution time: 0.1218
DEBUG - 2020-09-08 01:08:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:08:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 01:08:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-08 01:08:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 01:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 01:08:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 01:08:19 --> Total execution time: 0.1175
DEBUG - 2020-09-08 01:08:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:08:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 01:08:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-08 01:08:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 01:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 01:08:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 01:08:30 --> Total execution time: 0.1465
DEBUG - 2020-09-08 01:08:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 01:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 01:08:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 01:08:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 01:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 01:08:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 01:08:48 --> Total execution time: 0.1297
DEBUG - 2020-09-08 01:08:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:08:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 01:08:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-08 01:13:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:13:40 --> No URI present. Default controller set.
DEBUG - 2020-09-08 01:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 01:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 01:13:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 01:13:41 --> Total execution time: 0.1855
DEBUG - 2020-09-08 01:17:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 01:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 01:17:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 01:17:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 01:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 01:17:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 01:17:06 --> Total execution time: 0.1631
DEBUG - 2020-09-08 01:17:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:17:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 01:17:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-08 01:17:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:17:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 01:17:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-08 01:17:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:17:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 01:17:25 --> 404 Page Not Found: Assets/js
DEBUG - 2020-09-08 01:19:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 01:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 01:19:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 01:19:00 --> Total execution time: 0.1252
DEBUG - 2020-09-08 01:19:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 01:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 01:19:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 01:19:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 01:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 01:19:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 01:19:19 --> Total execution time: 0.1330
DEBUG - 2020-09-08 01:19:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:19:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 01:19:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-08 01:19:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:19:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 01:19:26 --> 404 Page Not Found: Assets/js
DEBUG - 2020-09-08 01:19:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 01:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 01:19:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 01:19:31 --> Total execution time: 0.1620
DEBUG - 2020-09-08 01:19:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:19:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 01:19:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-08 01:19:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 01:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 01:19:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 01:19:41 --> Total execution time: 0.1649
DEBUG - 2020-09-08 01:20:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 01:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 01:20:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 01:20:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 01:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 01:20:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 01:20:06 --> Total execution time: 0.1424
DEBUG - 2020-09-08 01:20:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 01:20:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 01:20:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-08 04:06:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 04:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 04:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 04:06:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 04:06:07 --> Total execution time: 0.1119
DEBUG - 2020-09-08 04:08:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 04:08:08 --> No URI present. Default controller set.
DEBUG - 2020-09-08 04:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 04:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 04:08:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 04:08:08 --> Total execution time: 0.2096
DEBUG - 2020-09-08 04:08:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 04:08:11 --> No URI present. Default controller set.
DEBUG - 2020-09-08 04:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 04:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 04:08:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 04:08:11 --> Total execution time: 0.1352
DEBUG - 2020-09-08 04:08:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 04:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 04:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 04:08:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 04:08:42 --> Total execution time: 0.1442
DEBUG - 2020-09-08 04:08:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 04:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 04:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 04:08:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 04:08:46 --> Total execution time: 0.1251
DEBUG - 2020-09-08 04:08:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 04:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 04:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 04:08:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 04:08:50 --> Total execution time: 0.1407
DEBUG - 2020-09-08 04:08:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 04:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 04:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 04:08:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 04:08:54 --> Total execution time: 0.1737
DEBUG - 2020-09-08 04:11:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 04:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 04:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 04:11:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 04:11:26 --> Total execution time: 0.1227
DEBUG - 2020-09-08 04:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 04:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 04:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 04:16:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 04:16:57 --> user_login->{"email":"admin@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2020-09-08 04:16:57 --> Total execution time: 0.1561
DEBUG - 2020-09-08 04:17:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 04:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 04:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 04:17:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 04:17:01 --> Total execution time: 0.1539
DEBUG - 2020-09-08 04:17:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 04:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 04:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 04:17:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 04:17:06 --> Total execution time: 0.1226
DEBUG - 2020-09-08 04:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 04:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 04:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 04:22:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 04:22:01 --> Total execution time: 0.1060
DEBUG - 2020-09-08 05:03:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 05:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 05:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 05:03:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 05:03:45 --> Total execution time: 0.1372
DEBUG - 2020-09-08 05:05:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 05:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 05:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 05:05:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 05:05:00 --> Total execution time: 0.1204
DEBUG - 2020-09-08 05:05:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 05:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 05:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 05:05:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 05:05:04 --> Total execution time: 0.1162
DEBUG - 2020-09-08 05:11:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 05:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 05:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 05:11:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 05:11:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 05:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 05:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 05:11:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 05:11:44 --> Total execution time: 0.1340
DEBUG - 2020-09-08 05:11:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 05:11:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 05:11:47 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-08 09:53:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 09:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 09:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 09:53:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 09:53:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 09:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 09:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 09:53:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 09:53:11 --> Total execution time: 0.1427
DEBUG - 2020-09-08 10:41:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 10:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 10:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 10:41:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 10:41:46 --> Total execution time: 0.1322
DEBUG - 2020-09-08 10:42:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 10:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 10:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 10:42:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 10:42:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 10:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 10:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 10:42:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 10:42:07 --> Total execution time: 0.1527
DEBUG - 2020-09-08 10:42:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 10:42:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 10:42:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-08 10:42:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 10:42:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 10:42:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-08 10:42:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 10:42:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 10:42:27 --> 404 Page Not Found: Assets/js
DEBUG - 2020-09-08 10:46:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 10:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 10:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 10:46:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-08 10:46:31 --> Severity: Compile Error --> Cannot redeclare Admin_model::get_target_lang() /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 98
DEBUG - 2020-09-08 10:46:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 10:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 10:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 10:46:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-08 10:46:38 --> Severity: Compile Error --> Cannot redeclare Admin_model::get_target_lang() /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 98
DEBUG - 2020-09-08 10:48:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 10:48:56 --> No URI present. Default controller set.
DEBUG - 2020-09-08 10:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 10:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 10:48:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-08 10:48:56 --> Severity: Compile Error --> Cannot redeclare Admin_model::get_target_lang() /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 98
DEBUG - 2020-09-08 10:49:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 10:49:54 --> No URI present. Default controller set.
DEBUG - 2020-09-08 10:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 10:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 10:49:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-08 10:49:54 --> Severity: Compile Error --> Cannot redeclare Admin_model::get_target_lang() /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 98
DEBUG - 2020-09-08 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 10:50:00 --> No URI present. Default controller set.
DEBUG - 2020-09-08 10:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 10:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 10:50:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-08 10:50:01 --> Severity: Compile Error --> Cannot redeclare Admin_model::get_target_lang() /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 98
DEBUG - 2020-09-08 10:51:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 10:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 10:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 10:51:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 10:51:43 --> Total execution time: 0.1358
DEBUG - 2020-09-08 10:51:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 10:51:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 10:51:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-08 10:51:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 10:51:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 10:51:55 --> 404 Page Not Found: Assets/js
DEBUG - 2020-09-08 10:52:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 10:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 10:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 10:52:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 10:52:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 10:52:16 --> Total execution time: 0.1270
DEBUG - 2020-09-08 10:52:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 10:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 10:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 10:52:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 10:52:18 --> Total execution time: 0.1177
DEBUG - 2020-09-08 10:52:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 10:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 10:52:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-08 10:53:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 10:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 10:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 10:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 10:53:52 --> Total execution time: 0.1267
DEBUG - 2020-09-08 10:53:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 10:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 10:53:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-08 10:54:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 10:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 10:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 10:54:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 10:54:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 10:54:07 --> Total execution time: 0.1135
DEBUG - 2020-09-08 10:54:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 10:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 10:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 10:54:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 10:54:10 --> Total execution time: 0.1182
DEBUG - 2020-09-08 10:54:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 10:54:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 10:54:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-08 12:07:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:07:56 --> No URI present. Default controller set.
DEBUG - 2020-09-08 12:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:07:56 --> Total execution time: 0.1320
DEBUG - 2020-09-08 12:12:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:12:04 --> No URI present. Default controller set.
DEBUG - 2020-09-08 12:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:12:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:12:05 --> Total execution time: 0.1268
DEBUG - 2020-09-08 12:12:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:12:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:12:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:12:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:12:32 --> Total execution time: 0.1840
DEBUG - 2020-09-08 12:12:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:12:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 12:12:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-08 12:13:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:13:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:13:03 --> Total execution time: 0.1347
DEBUG - 2020-09-08 12:13:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:13:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 12:13:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-08 12:13:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:13:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:13:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:13:21 --> Total execution time: 0.1222
DEBUG - 2020-09-08 12:13:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:13:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:13:24 --> Total execution time: 0.2183
DEBUG - 2020-09-08 12:13:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:13:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 12:13:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-08 12:17:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:17:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:17:53 --> Total execution time: 0.1492
DEBUG - 2020-09-08 12:17:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:17:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:17:56 --> Total execution time: 0.1571
DEBUG - 2020-09-08 12:17:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:17:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:17:57 --> Total execution time: 0.1474
DEBUG - 2020-09-08 12:18:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:18:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:18:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:18:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:18:19 --> Total execution time: 0.1090
DEBUG - 2020-09-08 12:18:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:18:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 12:18:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-08 12:18:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:18:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:18:32 --> Total execution time: 0.1550
DEBUG - 2020-09-08 12:18:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:18:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:18:34 --> Total execution time: 0.1691
DEBUG - 2020-09-08 12:18:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 12:18:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-08 12:18:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:18:44 --> Total execution time: 0.1322
DEBUG - 2020-09-08 12:18:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:18:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:18:45 --> Total execution time: 0.1414
DEBUG - 2020-09-08 12:18:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:18:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:18:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:18:45 --> Total execution time: 0.1191
DEBUG - 2020-09-08 12:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:18:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:18:45 --> Total execution time: 0.1142
DEBUG - 2020-09-08 12:18:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:18:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-08 12:18:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-08 12:18:47 --> Total execution time: 0.1849
DEBUG - 2020-09-08 12:18:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:18:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:18:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:18:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:18:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 12:18:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-08 12:18:47 --> Total execution time: 0.1831
DEBUG - 2020-09-08 12:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:18:47 --> Total execution time: 0.2624
DEBUG - 2020-09-08 12:18:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:18:47 --> Total execution time: 0.1744
DEBUG - 2020-09-08 12:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:18:47 --> Total execution time: 0.3003
DEBUG - 2020-09-08 12:18:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:18:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-08 12:18:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-08 12:18:47 --> Total execution time: 0.1499
DEBUG - 2020-09-08 12:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:18:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-08 12:18:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-08 12:18:48 --> Total execution time: 0.1458
DEBUG - 2020-09-08 12:18:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:18:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:18:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-08 12:18:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-08 12:18:50 --> Total execution time: 0.1188
DEBUG - 2020-09-08 12:18:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:18:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-08 12:18:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-08 12:18:50 --> Total execution time: 0.1526
DEBUG - 2020-09-08 12:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:18:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-08 12:18:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-08 12:18:50 --> Total execution time: 0.1258
DEBUG - 2020-09-08 12:18:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:18:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 12:18:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-08 12:23:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:23:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:23:37 --> user_login->{"email":"admin@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2020-09-08 12:23:37 --> Total execution time: 0.1375
DEBUG - 2020-09-08 12:23:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:23:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:23:41 --> Total execution time: 0.1241
DEBUG - 2020-09-08 12:23:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:23:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:23:45 --> Total execution time: 0.1369
DEBUG - 2020-09-08 12:23:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:23:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:23:54 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
ERROR - 2020-09-08 12:23:54 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-09-08 12:23:54 --> Total execution time: 0.1437
DEBUG - 2020-09-08 12:24:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:24:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:24:00 --> Total execution time: 0.1443
DEBUG - 2020-09-08 12:24:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:24:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:24:03 --> Total execution time: 0.1218
DEBUG - 2020-09-08 12:24:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:24:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:24:06 --> Total execution time: 0.1040
DEBUG - 2020-09-08 12:24:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:24:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:24:09 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-08 12:24:09 --> Total execution time: 0.1538
DEBUG - 2020-09-08 12:24:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:24:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:24:15 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-08 12:24:15 --> Total execution time: 0.1223
DEBUG - 2020-09-08 12:24:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:24:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:24:20 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-08 12:24:20 --> Total execution time: 0.1417
DEBUG - 2020-09-08 12:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:24:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:24:28 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"3","exercise_mode_id":"1","category_id":"62","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-08 12:24:28 --> Total execution time: 0.1672
DEBUG - 2020-09-08 12:24:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:24:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 12:24:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-08 12:24:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:24:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:24:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 12:24:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-08 12:24:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 12:24:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-08 12:24:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:24:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 12:24:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-08 12:24:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:24:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:24:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 12:24:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-08 12:24:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:24:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 12:24:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-08 12:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:24:35 --> UTF-8 Support Enabled
ERROR - 2020-09-08 12:24:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-08 12:24:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-08 12:24:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-08 12:29:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-08 12:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-08 12:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-08 12:29:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-08 12:29:55 --> Total execution time: 0.2008
