<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-01-06 14:00:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:00:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-06 14:00:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'langoalp_ci2'@'localhost' (using password: YES) /home/langoalphademo/public_html/indylan/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2021-01-06 14:00:27 --> Unable to connect to the database
DEBUG - 2021-01-06 14:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-06 14:00:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-06 14:00:27 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-01-06 14:00:27 --> Total execution time: 0.1743
DEBUG - 2021-01-06 14:00:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:00:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-06 14:00:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'langoalp_ci2'@'localhost' (using password: YES) /home/langoalphademo/public_html/indylan/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2021-01-06 14:00:42 --> Unable to connect to the database
DEBUG - 2021-01-06 14:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-06 14:00:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-06 14:00:42 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-01-06 14:00:42 --> Total execution time: 0.1114
DEBUG - 2021-01-06 14:00:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:00:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-06 14:00:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'langoalp_ci2'@'localhost' (using password: YES) /home/langoalphademo/public_html/indylan/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2021-01-06 14:00:47 --> Unable to connect to the database
DEBUG - 2021-01-06 14:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-06 14:00:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-06 14:00:47 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-01-06 14:00:47 --> Total execution time: 0.1709
DEBUG - 2021-01-06 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-06 14:00:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'langoalp_ci2'@'localhost' (using password: YES) /home/langoalphademo/public_html/indylan/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2021-01-06 14:00:52 --> Unable to connect to the database
DEBUG - 2021-01-06 14:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-06 14:00:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-06 14:01:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:01:03 --> No URI present. Default controller set.
DEBUG - 2021-01-06 14:01:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-06 14:01:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'langoalp_ci2'@'localhost' (using password: YES) /home/langoalphademo/public_html/indylan/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2021-01-06 14:01:03 --> Unable to connect to the database
DEBUG - 2021-01-06 14:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-06 14:01:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-06 14:01:03 --> Total execution time: 0.1567
DEBUG - 2021-01-06 14:01:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:01:03 --> No URI present. Default controller set.
DEBUG - 2021-01-06 14:01:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-06 14:01:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'langoalp_ci2'@'localhost' (using password: YES) /home/langoalphademo/public_html/indylan/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2021-01-06 14:01:03 --> Unable to connect to the database
DEBUG - 2021-01-06 14:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-06 14:01:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-06 14:01:03 --> Total execution time: 0.1668
DEBUG - 2021-01-06 14:01:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-06 14:01:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'langoalp_ci2'@'localhost' (using password: YES) /home/langoalphademo/public_html/indylan/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2021-01-06 14:01:10 --> Unable to connect to the database
DEBUG - 2021-01-06 14:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-06 14:01:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-06 14:01:10 --> Severity: error --> Exception: Call to a member function real_escape_string() on boolean /home/langoalphademo/public_html/indylan/system/database/drivers/mysqli/mysqli_driver.php 391
DEBUG - 2021-01-06 14:01:17 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:01:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-06 14:01:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'langoalp_ci2'@'localhost' (using password: YES) /home/langoalphademo/public_html/indylan/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2021-01-06 14:01:17 --> Unable to connect to the database
DEBUG - 2021-01-06 14:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-06 14:01:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-06 14:01:17 --> Total execution time: 0.1803
DEBUG - 2021-01-06 14:01:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:01:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-06 14:01:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'langoalp_ci2'@'localhost' (using password: YES) /home/langoalphademo/public_html/indylan/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2021-01-06 14:01:22 --> Unable to connect to the database
DEBUG - 2021-01-06 14:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-06 14:01:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-06 14:01:22 --> Severity: error --> Exception: Call to a member function real_escape_string() on boolean /home/langoalphademo/public_html/indylan/system/database/drivers/mysqli/mysqli_driver.php 391
DEBUG - 2021-01-06 14:01:24 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:01:24 --> No URI present. Default controller set.
DEBUG - 2021-01-06 14:01:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-06 14:01:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'langoalp_ci2'@'localhost' (using password: YES) /home/langoalphademo/public_html/indylan/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2021-01-06 14:01:24 --> Unable to connect to the database
DEBUG - 2021-01-06 14:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-06 14:01:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-06 14:01:24 --> Total execution time: 0.1338
DEBUG - 2021-01-06 14:01:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:01:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-06 14:01:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'langoalp_ci2'@'localhost' (using password: YES) /home/langoalphademo/public_html/indylan/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2021-01-06 14:01:32 --> Unable to connect to the database
DEBUG - 2021-01-06 14:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-06 14:01:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-06 14:01:32 --> Total execution time: 0.1890
DEBUG - 2021-01-06 14:01:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:01:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-06 14:01:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'langoalp_ci2'@'localhost' (using password: YES) /home/langoalphademo/public_html/indylan/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2021-01-06 14:01:34 --> Unable to connect to the database
DEBUG - 2021-01-06 14:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-06 14:01:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-06 14:01:34 --> Severity: error --> Exception: Call to a member function real_escape_string() on boolean /home/langoalphademo/public_html/indylan/system/database/drivers/mysqli/mysqli_driver.php 391
DEBUG - 2021-01-06 14:07:38 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:07:38 --> No URI present. Default controller set.
DEBUG - 2021-01-06 14:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-06 14:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-06 14:07:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-06 14:07:38 --> Total execution time: 0.1254
DEBUG - 2021-01-06 14:07:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-06 14:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-06 14:07:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-06 14:07:54 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-06 14:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-06 14:07:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-06 14:07:54 --> Total execution time: 0.1741
DEBUG - 2021-01-06 14:07:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:07:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-06 14:07:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-06 14:08:00 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:08:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-06 14:08:00 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2021-01-06 14:08:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:08:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-06 14:08:02 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2021-01-06 14:08:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-06 14:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-06 14:08:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-06 14:08:05 --> Total execution time: 0.1818
DEBUG - 2021-01-06 14:28:45 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-06 14:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-06 14:28:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-06 14:28:45 --> Total execution time: 0.1868
DEBUG - 2021-01-06 14:45:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-06 14:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-06 14:45:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-06 14:45:12 --> Total execution time: 0.1589
DEBUG - 2021-01-06 14:45:25 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-06 14:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-06 14:45:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-06 14:45:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-06 14:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-06 14:45:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-06 14:45:28 --> Total execution time: 0.1481
DEBUG - 2021-01-06 14:45:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:45:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-06 14:45:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-06 14:45:38 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:45:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-06 14:45:38 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2021-01-06 14:45:44 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:45:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-06 14:45:44 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2021-01-06 14:46:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-06 14:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-06 14:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-06 14:46:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-06 14:46:34 --> Total execution time: 0.1550
