<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-10-12 05:30:35 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:30:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:30:35 --> user_login->{"email":"admin@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2020-10-12 05:30:35 --> Total execution time: 0.2378
DEBUG - 2020-10-12 05:30:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:30:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:30:38 --> Total execution time: 0.1302
DEBUG - 2020-10-12 05:31:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:31:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:31:03 --> Total execution time: 0.1124
DEBUG - 2020-10-12 05:31:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:31:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:31:12 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-12 05:31:12 --> Total execution time: 0.1404
DEBUG - 2020-10-12 05:31:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:31:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:31:36 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-12 05:31:36 --> Total execution time: 0.1388
DEBUG - 2020-10-12 05:31:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:31:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:31:41 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-12 05:31:41 --> Total execution time: 0.1520
DEBUG - 2020-10-12 05:31:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:31:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 05:31:42 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 05:31:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:31:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:31:46 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 05:31:46 --> Total execution time: 0.1536
DEBUG - 2020-10-12 05:31:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:31:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:31:50 --> get_grammer_type_2->{"slang":"37","tlang":"3","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
ERROR - 2020-10-12 05:31:50 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-12 05:31:50 --> Total execution time: 0.1578
DEBUG - 2020-10-12 05:51:23 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:51:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:51:23 --> Total execution time: 0.1227
DEBUG - 2020-10-12 05:53:23 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:53:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:53:23 --> Total execution time: 0.1265
DEBUG - 2020-10-12 05:55:23 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:55:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:55:23 --> Total execution time: 0.1327
DEBUG - 2020-10-12 05:58:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:58:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:58:17 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2020-10-12 05:58:17 --> Total execution time: 0.1207
DEBUG - 2020-10-12 05:58:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:58:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:58:37 --> get_subcategory_list->{"lang":"37","category_id":"67","user_id":"1","support_lang_id":"1"}
DEBUG - 2020-10-12 05:58:37 --> Total execution time: 0.1774
DEBUG - 2020-10-12 05:58:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:58:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:58:46 --> get_exercise_type_list->{"lang":"37","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2020-10-12 05:58:46 --> Total execution time: 0.1401
DEBUG - 2020-10-12 05:59:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:59:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:59:07 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"1","exercise_mode_id":"1","category_id":"67","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2020-10-12 05:59:07 --> Total execution time: 0.1804
DEBUG - 2020-10-12 05:59:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:59:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:59:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:59:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:59:22 --> get_exercise_type_list->{"lang":"37","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2020-10-12 05:59:22 --> Total execution time: 0.1249
DEBUG - 2020-10-12 05:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:59:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:59:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:59:22 --> get_subcategory_list->{"lang":"37","category_id":"67","user_id":"1","support_lang_id":"1"}
DEBUG - 2020-10-12 05:59:22 --> Total execution time: 0.1555
DEBUG - 2020-10-12 05:59:22 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2020-10-12 05:59:22 --> Total execution time: 0.1454
DEBUG - 2020-10-12 05:59:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:59:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:59:26 --> user_login->{"email":"admin@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2020-10-12 05:59:26 --> Total execution time: 0.1152
DEBUG - 2020-10-12 05:59:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:59:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:59:29 --> Total execution time: 0.1430
DEBUG - 2020-10-12 05:59:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:59:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:59:38 --> Total execution time: 0.1136
DEBUG - 2020-10-12 05:59:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:59:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:59:50 --> Total execution time: 0.1447
DEBUG - 2020-10-12 05:59:53 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:59:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:59:53 --> Total execution time: 0.1351
DEBUG - 2020-10-12 05:59:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 05:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 05:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 05:59:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 05:59:58 --> Total execution time: 0.1299
DEBUG - 2020-10-12 06:00:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:00:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:00:08 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-12 06:00:08 --> Total execution time: 0.1113
DEBUG - 2020-10-12 06:00:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:00:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:00:11 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:00:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:00:14 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:00:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:00:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:00:21 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-12 06:00:21 --> Total execution time: 0.1534
DEBUG - 2020-10-12 06:00:25 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:00:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:00:25 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:00:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:00:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:00:28 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:00:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:00:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:00:32 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 06:00:32 --> Total execution time: 0.1122
DEBUG - 2020-10-12 06:00:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:00:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:00:43 --> get_grammer_type_2->{"slang":"37","tlang":"3","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
ERROR - 2020-10-12 06:00:43 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-12 06:00:43 --> Total execution time: 0.1026
DEBUG - 2020-10-12 06:01:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:01:04 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:01:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:01:04 --> Total execution time: 0.1347
DEBUG - 2020-10-12 06:02:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:02:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:02:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:02:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:02:04 --> Total execution time: 0.1322
DEBUG - 2020-10-12 06:02:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:02:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:02:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 06:02:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:02:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:02:13 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:02:25 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:02:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:02:25 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-10-12 06:03:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:03:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:03:52 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 06:03:52 --> Total execution time: 0.1701
DEBUG - 2020-10-12 06:05:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:05:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:05:14 --> Total execution time: 0.1285
DEBUG - 2020-10-12 06:05:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:05:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 06:05:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-12 06:05:17 --> Total execution time: 0.1543
DEBUG - 2020-10-12 06:05:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:05:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:05:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 06:06:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:06:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 06:06:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-12 06:06:37 --> Total execution time: 0.1587
DEBUG - 2020-10-12 06:06:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:06:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 06:06:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-12 06:06:40 --> Total execution time: 0.1400
DEBUG - 2020-10-12 06:06:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:06:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:06:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 06:06:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:06:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:06:49 --> Total execution time: 0.1460
DEBUG - 2020-10-12 06:06:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:06:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 06:06:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-12 06:06:52 --> Total execution time: 0.1796
DEBUG - 2020-10-12 06:06:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:06:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:06:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 06:07:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:07:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 06:07:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-12 06:07:04 --> Total execution time: 0.1611
DEBUG - 2020-10-12 06:07:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:07:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 06:07:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-12 06:07:08 --> Total execution time: 0.1370
DEBUG - 2020-10-12 06:07:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:07:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:07:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 06:08:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:08:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:08:26 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:08:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:08:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:08:27 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 06:08:27 --> Total execution time: 0.1618
DEBUG - 2020-10-12 06:08:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:08:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:08:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:08:27 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"1","support_lang_id":"3"}
ERROR - 2020-10-12 06:08:27 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:08:27 --> Total execution time: 0.1578
DEBUG - 2020-10-12 06:08:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:08:31 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:08:31 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:08:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:08:31 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-12 06:08:31 --> Total execution time: 0.0988
DEBUG - 2020-10-12 06:08:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:08:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:08:33 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:08:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:08:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:08:37 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-12 06:08:37 --> Total execution time: 0.1448
DEBUG - 2020-10-12 06:08:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:08:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:08:40 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:08:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:08:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:08:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:08:44 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-12 06:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:08:44 --> Total execution time: 0.1372
ERROR - 2020-10-12 06:08:44 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:08:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:08:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:08:48 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-10-12 06:08:48 --> Total execution time: 0.1655
DEBUG - 2020-10-12 06:08:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:08:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:08:52 --> get_grammer_type_2->{"slang":"37","tlang":"3","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
ERROR - 2020-10-12 06:08:52 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-12 06:08:52 --> Total execution time: 0.1437
DEBUG - 2020-10-12 06:09:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:09:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:09:13 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-10-12 06:09:13 --> Total execution time: 0.1140
DEBUG - 2020-10-12 06:09:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:09:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:09:15 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-12 06:09:15 --> Total execution time: 0.1893
DEBUG - 2020-10-12 06:09:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:09:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:09:38 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-12 06:09:38 --> Total execution time: 0.1282
DEBUG - 2020-10-12 06:09:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:09:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:09:41 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:09:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:09:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:09:43 --> get_subcategory_list->{"lang":"37","category_id":"88","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-12 06:09:43 --> Total execution time: 0.1434
DEBUG - 2020-10-12 06:09:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:09:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:09:44 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:09:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:09:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:09:50 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-10-12 06:09:50 --> Total execution time: 0.1598
DEBUG - 2020-10-12 06:09:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:09:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:09:54 --> get_grammer_type_1->{"slang":"37","tlang":"3","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
ERROR - 2020-10-12 06:09:54 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-12 06:09:54 --> Total execution time: 0.1022
DEBUG - 2020-10-12 06:09:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:09:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:09:58 --> get_exercise_type_list->{"lang":"37","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-10-12 06:09:58 --> Total execution time: 0.1203
DEBUG - 2020-10-12 06:15:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:15:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:15:51 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:16:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:16:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:16:03 --> Total execution time: 0.1171
DEBUG - 2020-10-12 06:16:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:16:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:16:39 --> Total execution time: 0.1454
DEBUG - 2020-10-12 06:16:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:16:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:16:50 --> Total execution time: 0.1104
DEBUG - 2020-10-12 06:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:16:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:16:57 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-12 06:16:57 --> Total execution time: 0.1508
DEBUG - 2020-10-12 06:17:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:17:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:17:01 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-12 06:17:01 --> Total execution time: 0.1332
DEBUG - 2020-10-12 06:17:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:17:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:17:04 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-10-12 06:17:04 --> Total execution time: 0.1573
DEBUG - 2020-10-12 06:17:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:17:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:17:09 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"3","exercise_mode_id":"1","category_id":"62","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-10-12 06:17:09 --> Total execution time: 0.1374
DEBUG - 2020-10-12 06:17:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:17:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:17:14 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-10-12 06:17:14 --> Total execution time: 0.1362
DEBUG - 2020-10-12 06:17:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:17:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:17:15 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-12 06:17:15 --> Total execution time: 0.1460
DEBUG - 2020-10-12 06:17:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:17:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:17:15 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-12 06:17:15 --> Total execution time: 0.1258
DEBUG - 2020-10-12 06:18:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:18:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:18:03 --> Total execution time: 0.1617
DEBUG - 2020-10-12 06:21:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:21:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:21:43 --> Total execution time: 0.1504
DEBUG - 2020-10-12 06:21:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:21:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:21:45 --> Total execution time: 0.1543
DEBUG - 2020-10-12 06:24:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:24:38 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:24:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:24:38 --> Total execution time: 0.1981
DEBUG - 2020-10-12 06:24:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:24:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:24:39 --> Total execution time: 0.0994
DEBUG - 2020-10-12 06:24:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:24:42 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:24:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:24:42 --> Total execution time: 0.1641
DEBUG - 2020-10-12 06:25:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:25:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:25:27 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:25:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:25:27 --> Total execution time: 0.1186
DEBUG - 2020-10-12 06:25:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:25:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:25:28 --> Total execution time: 0.1577
DEBUG - 2020-10-12 06:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:25:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:25:28 --> Total execution time: 0.1133
DEBUG - 2020-10-12 06:25:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:25:30 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:25:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:25:30 --> Total execution time: 0.1584
DEBUG - 2020-10-12 06:25:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:25:48 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:25:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:25:48 --> Total execution time: 0.1645
DEBUG - 2020-10-12 06:25:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:25:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:25:49 --> Total execution time: 0.1543
DEBUG - 2020-10-12 06:26:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:26:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:26:06 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:26:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:26:06 --> Total execution time: 0.1107
DEBUG - 2020-10-12 06:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:26:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:26:06 --> Total execution time: 0.1434
DEBUG - 2020-10-12 06:26:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:26:09 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:26:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:26:09 --> Total execution time: 0.1659
DEBUG - 2020-10-12 06:26:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:26:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:26:16 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:26:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:26:16 --> Total execution time: 0.1309
DEBUG - 2020-10-12 06:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:26:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:26:16 --> Total execution time: 0.1309
DEBUG - 2020-10-12 06:26:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:26:42 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:26:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:26:42 --> Total execution time: 0.1536
DEBUG - 2020-10-12 06:26:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:26:47 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:26:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:26:47 --> Total execution time: 0.1409
DEBUG - 2020-10-12 06:26:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:26:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:26:47 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-12 06:26:47 --> Total execution time: 0.1135
DEBUG - 2020-10-12 06:26:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:26:50 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:26:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:26:50 --> Total execution time: 0.1342
DEBUG - 2020-10-12 06:26:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:26:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:26:50 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:26:53 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:26:53 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:27:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:27:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:27:59 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:28:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:28:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:28:00 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:28:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:28:00 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:28:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:28:00 --> Total execution time: 0.1603
DEBUG - 2020-10-12 06:28:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:28:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:28:03 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:28:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:28:03 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:28:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:28:03 --> Total execution time: 0.1145
DEBUG - 2020-10-12 06:28:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:28:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:28:06 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:28:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:28:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:28:06 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"746","support_lang_id":"3"}
DEBUG - 2020-10-12 06:28:06 --> Total execution time: 0.1351
DEBUG - 2020-10-12 06:28:06 --> Total execution time: 0.1353
DEBUG - 2020-10-12 06:28:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:28:09 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:28:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:28:09 --> Total execution time: 0.1676
DEBUG - 2020-10-12 06:28:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:28:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:28:13 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:28:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:28:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:28:16 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:29:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:29:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:29:07 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:29:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:29:07 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 06:29:07 --> Total execution time: 0.1003
DEBUG - 2020-10-12 06:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:29:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:29:07 --> Total execution time: 0.1302
DEBUG - 2020-10-12 06:29:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:29:09 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:29:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:29:09 --> Total execution time: 0.1872
DEBUG - 2020-10-12 06:29:31 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:29:31 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:29:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:29:31 --> Total execution time: 0.1448
DEBUG - 2020-10-12 06:29:31 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:29:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:29:31 --> get_grammer_type_2->{"slang":"37","tlang":"3","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
ERROR - 2020-10-12 06:29:31 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-12 06:29:31 --> Total execution time: 0.1303
DEBUG - 2020-10-12 06:29:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:29:33 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:29:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:29:33 --> Total execution time: 0.1457
DEBUG - 2020-10-12 06:30:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:30:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 06:30:05 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-10-12 06:30:05 --> Total execution time: 0.1014
DEBUG - 2020-10-12 06:30:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:30:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:30:46 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:30:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:30:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:30:46 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 06:30:46 --> Total execution time: 0.1446
DEBUG - 2020-10-12 06:30:46 --> Total execution time: 0.1402
DEBUG - 2020-10-12 06:31:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:31:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:31:22 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:31:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:31:22 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"746","support_lang_id":"3"}
DEBUG - 2020-10-12 06:31:22 --> Total execution time: 0.1261
DEBUG - 2020-10-12 06:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:31:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:31:22 --> Total execution time: 0.1504
DEBUG - 2020-10-12 06:31:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:31:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:31:22 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-12 06:31:22 --> Total execution time: 0.1477
DEBUG - 2020-10-12 06:31:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:31:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:31:22 --> Total execution time: 0.1430
DEBUG - 2020-10-12 06:31:23 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:31:23 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:31:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:31:23 --> Total execution time: 0.1545
DEBUG - 2020-10-12 06:31:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:31:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:31:27 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:31:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:31:27 --> Total execution time: 0.1174
DEBUG - 2020-10-12 06:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:31:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:31:27 --> Total execution time: 0.1270
DEBUG - 2020-10-12 06:31:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:31:29 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:31:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:31:29 --> Total execution time: 0.1819
DEBUG - 2020-10-12 06:31:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:31:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:31:38 --> Total execution time: 0.1295
DEBUG - 2020-10-12 06:31:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:31:39 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:31:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:31:39 --> Total execution time: 0.1683
DEBUG - 2020-10-12 06:31:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:31:41 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:31:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:31:41 --> Total execution time: 0.1315
DEBUG - 2020-10-12 06:31:45 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:31:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:31:45 --> Total execution time: 0.1496
DEBUG - 2020-10-12 06:32:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:32:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:32:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:32:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 06:32:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:32:58 --> 404 Page Not Found: Assets/js
DEBUG - 2020-10-12 06:33:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:33:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:33:10 --> Total execution time: 0.1374
DEBUG - 2020-10-12 06:33:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:33:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:33:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 06:33:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:33:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:33:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 06:33:23 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:33:23 --> 404 Page Not Found: Assets/js
DEBUG - 2020-10-12 06:35:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:35:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:35:24 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 06:35:24 --> Total execution time: 0.1138
DEBUG - 2020-10-12 06:35:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:35:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:35:55 --> Total execution time: 0.1110
DEBUG - 2020-10-12 06:36:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:36:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:36:14 --> Total execution time: 0.1361
DEBUG - 2020-10-12 06:36:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:36:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:36:29 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-12 06:36:29 --> Total execution time: 0.1202
DEBUG - 2020-10-12 06:36:31 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:36:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:36:31 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:36:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:36:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:36:34 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:36:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:36:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:36:38 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-12 06:36:38 --> Total execution time: 0.1324
DEBUG - 2020-10-12 06:36:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:36:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:36:41 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:36:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:36:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:36:43 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:36:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:36:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:36:47 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 06:36:47 --> Total execution time: 0.1386
DEBUG - 2020-10-12 06:36:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:36:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:36:54 --> get_grammer_type_2->{"slang":"37","tlang":"3","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
ERROR - 2020-10-12 06:36:54 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-12 06:36:54 --> Total execution time: 0.1216
DEBUG - 2020-10-12 06:37:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:37:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:37:52 --> get_grammer_type_2->{"slang":"37","tlang":"3","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
ERROR - 2020-10-12 06:37:52 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-12 06:37:52 --> Total execution time: 0.0957
DEBUG - 2020-10-12 06:38:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:38:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:38:01 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:38:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:38:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:38:04 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 06:38:04 --> Total execution time: 0.1087
DEBUG - 2020-10-12 06:38:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:38:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:38:06 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-12 06:38:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:38:06 --> Total execution time: 0.1319
DEBUG - 2020-10-12 06:38:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:38:06 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:38:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:38:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:38:07 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-12 06:38:07 --> Total execution time: 0.1044
DEBUG - 2020-10-12 06:38:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:38:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:38:10 --> Total execution time: 0.1616
DEBUG - 2020-10-12 06:39:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:39:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:39:13 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 06:39:13 --> Total execution time: 0.1495
DEBUG - 2020-10-12 06:41:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:41:09 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:41:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:41:09 --> Total execution time: 0.1507
DEBUG - 2020-10-12 06:41:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:41:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:41:18 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:41:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:41:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:41:18 --> Total execution time: 0.1236
DEBUG - 2020-10-12 06:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:41:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:41:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:41:18 --> Total execution time: 0.1688
DEBUG - 2020-10-12 06:41:18 --> Total execution time: 0.1142
DEBUG - 2020-10-12 06:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:41:20 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:41:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:41:21 --> Total execution time: 0.1397
DEBUG - 2020-10-12 06:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:41:24 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:41:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:41:24 --> Total execution time: 0.1638
DEBUG - 2020-10-12 06:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:41:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:41:24 --> Total execution time: 0.1141
DEBUG - 2020-10-12 06:41:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:41:27 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:41:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:41:27 --> Total execution time: 0.1328
DEBUG - 2020-10-12 06:41:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:41:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:41:32 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:41:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:41:32 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-12 06:41:32 --> Total execution time: 0.1229
DEBUG - 2020-10-12 06:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:41:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:41:32 --> Total execution time: 0.1603
DEBUG - 2020-10-12 06:41:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:41:34 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:41:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:41:34 --> Total execution time: 0.1444
DEBUG - 2020-10-12 06:41:35 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:41:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:41:35 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:41:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:41:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:41:36 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"746","support_lang_id":"3"}
DEBUG - 2020-10-12 06:41:36 --> Total execution time: 0.1177
DEBUG - 2020-10-12 06:41:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:41:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:41:38 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 06:41:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:41:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:41:41 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 06:41:41 --> Total execution time: 0.1360
DEBUG - 2020-10-12 06:41:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:41:41 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:41:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:41:41 --> Total execution time: 0.1721
DEBUG - 2020-10-12 06:41:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:41:43 --> No URI present. Default controller set.
DEBUG - 2020-10-12 06:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:41:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:41:44 --> Total execution time: 0.1776
DEBUG - 2020-10-12 06:41:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:41:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:41:44 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 06:41:44 --> Total execution time: 0.1133
DEBUG - 2020-10-12 06:43:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:43:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:43:33 --> Total execution time: 0.1188
DEBUG - 2020-10-12 06:55:25 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:55:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:55:25 --> Total execution time: 0.1489
DEBUG - 2020-10-12 06:56:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:56:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:56:21 --> Total execution time: 0.1794
DEBUG - 2020-10-12 06:58:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:58:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:58:27 --> Total execution time: 0.1121
DEBUG - 2020-10-12 06:58:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 06:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 06:58:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 06:58:44 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-12 06:58:44 --> Total execution time: 0.1252
DEBUG - 2020-10-12 06:58:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 06:58:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 06:58:48 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:00:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:00:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:00:22 --> user_login->{"email":"admin@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2020-10-12 07:00:22 --> Total execution time: 0.1366
DEBUG - 2020-10-12 07:02:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:02:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:02:11 --> user_login->{"email":"admin@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2020-10-12 07:02:11 --> Total execution time: 0.1472
DEBUG - 2020-10-12 07:02:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:02:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:02:14 --> Total execution time: 0.1563
DEBUG - 2020-10-12 07:02:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:02:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:02:22 --> Total execution time: 0.1372
DEBUG - 2020-10-12 07:02:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:02:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:02:27 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-12 07:02:27 --> Total execution time: 0.1382
DEBUG - 2020-10-12 07:02:31 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:02:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:02:31 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-12 07:02:31 --> Total execution time: 0.1586
DEBUG - 2020-10-12 07:02:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:02:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:02:34 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-10-12 07:02:34 --> Total execution time: 0.1080
DEBUG - 2020-10-12 07:02:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:02:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:02:38 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"62","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-10-12 07:02:38 --> Total execution time: 0.1271
DEBUG - 2020-10-12 07:17:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:17:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:17:06 --> user_login->{"email":"admin@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2020-10-12 07:17:06 --> Total execution time: 0.1276
DEBUG - 2020-10-12 07:17:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:17:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:17:10 --> Total execution time: 0.1083
DEBUG - 2020-10-12 07:17:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:17:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:17:15 --> Total execution time: 0.1327
DEBUG - 2020-10-12 07:17:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:17:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:17:26 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"2"}
DEBUG - 2020-10-12 07:17:26 --> Total execution time: 0.1183
DEBUG - 2020-10-12 07:17:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:17:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:17:29 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:17:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:17:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:17:32 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:17:35 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:17:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:17:35 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-10-12 07:17:35 --> Total execution time: 0.1563
DEBUG - 2020-10-12 07:17:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:17:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:17:38 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:17:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:17:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:17:41 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:17:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:17:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:17:46 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"2"}
DEBUG - 2020-10-12 07:17:46 --> Total execution time: 0.1470
DEBUG - 2020-10-12 07:17:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:17:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:17:51 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"2"}
DEBUG - 2020-10-12 07:17:51 --> Total execution time: 0.1628
DEBUG - 2020-10-12 07:18:35 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:18:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:18:35 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"2"}
DEBUG - 2020-10-12 07:18:35 --> Total execution time: 0.1251
DEBUG - 2020-10-12 07:18:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:18:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:18:36 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-10-12 07:18:36 --> Total execution time: 0.1431
DEBUG - 2020-10-12 07:18:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:18:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:18:40 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:21:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:21:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:21:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:21:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:21:50 --> Total execution time: 0.1678
DEBUG - 2020-10-12 07:23:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:23:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:23:02 --> user_register->{"first_name":"test","last_name":"","email":"test1@gmail.com","password":"123456","confirm_password":"123456","social_id":null,"social_type":"0","user_image":null}
ERROR - 2020-10-12 07:23:02 --> {"status":0,"message":"Email Already Exist","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-10-12 07:23:02 --> Total execution time: 0.1511
DEBUG - 2020-10-12 07:23:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:23:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:23:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:23:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:23:08 --> Total execution time: 0.1360
DEBUG - 2020-10-12 07:23:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:23:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:23:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:23:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:23:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:23:12 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:23:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:23:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:23:16 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-10-12 07:23:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:23:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:23:38 --> user_login->{"email":"test1@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2020-10-12 07:23:38 --> Total execution time: 0.1852
DEBUG - 2020-10-12 07:23:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:23:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:23:40 --> Total execution time: 0.1360
DEBUG - 2020-10-12 07:23:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:23:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:23:49 --> Total execution time: 0.1158
DEBUG - 2020-10-12 07:23:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:23:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:23:56 --> Total execution time: 0.1258
DEBUG - 2020-10-12 07:23:57 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:23:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:23:57 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-12 07:23:57 --> Total execution time: 0.0972
DEBUG - 2020-10-12 07:23:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:23:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:23:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:23:59 --> Total execution time: 0.1656
DEBUG - 2020-10-12 07:24:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:24:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:24:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:24:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:24:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:24:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:24:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:24:01 --> UTF-8 Support Enabled
ERROR - 2020-10-12 07:24:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:24:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:24:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:24:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:24:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:24:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:24:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:24:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:24:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:24:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:24:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:24:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:24:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:24:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:24:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:24:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:24:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:24:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:24:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:24:12 --> Total execution time: 0.1297
DEBUG - 2020-10-12 07:24:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:24:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:24:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:24:15 --> Total execution time: 0.1869
DEBUG - 2020-10-12 07:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:24:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:24:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:24:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:24:18 --> 404 Page Not Found: Uploads/words
ERROR - 2020-10-12 07:24:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:24:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:24:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:24:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:24:59 --> Total execution time: 0.1466
DEBUG - 2020-10-12 07:25:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:25:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:25:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:25:02 --> Total execution time: 0.1856
DEBUG - 2020-10-12 07:25:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:25:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:25:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:25:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:25:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:25:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:25:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:25:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:25:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:25:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:25:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:25:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:25:05 --> 404 Page Not Found: Uploads/words
ERROR - 2020-10-12 07:25:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:25:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:25:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:25:07 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:25:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:25:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:25:10 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:26:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:26:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:26:28 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:26:31 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:26:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:26:31 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:26:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:26:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:26:32 --> get_subcategory_list->{"lang":"37","category_id":"73","user_id":"765","support_lang_id":"3"}
DEBUG - 2020-10-12 07:26:32 --> Total execution time: 0.1163
DEBUG - 2020-10-12 07:27:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:27:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:27:02 --> get_exercise_type_list->{"lang":"37","subcategory_id":"166","support_lang_id":"3"}
DEBUG - 2020-10-12 07:27:02 --> Total execution time: 0.1103
DEBUG - 2020-10-12 07:27:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:27:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:27:19 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"73","subcategory_id":"166","support_lang_id":"3"}
DEBUG - 2020-10-12 07:27:19 --> Total execution time: 0.1395
DEBUG - 2020-10-12 07:27:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:27:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:27:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:27:22 --> UTF-8 Support Enabled
ERROR - 2020-10-12 07:27:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:27:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:27:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:27:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:27:22 --> 404 Page Not Found: Uploads/words
ERROR - 2020-10-12 07:27:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:27:25 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:27:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:27:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:27:25 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:27:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:27:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:27:25 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:27:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:27:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:27:25 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:27:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:27:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:27:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:27:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:27:40 --> Total execution time: 0.1306
DEBUG - 2020-10-12 07:27:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:27:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:27:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-12 07:27:43 --> Total execution time: 0.2107
DEBUG - 2020-10-12 07:27:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:27:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:27:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:27:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:27:50 --> get_exercise_type_list->{"lang":"37","subcategory_id":"166","support_lang_id":"3"}
DEBUG - 2020-10-12 07:27:50 --> Total execution time: 0.1035
DEBUG - 2020-10-12 07:27:53 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:27:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:27:53 --> Total execution time: 0.1506
DEBUG - 2020-10-12 07:27:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:27:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:27:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:27:57 --> Total execution time: 0.2094
DEBUG - 2020-10-12 07:28:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:28:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:28:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:28:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:28:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:28:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:28:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:28:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:28:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:28:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:28:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:28:08 --> Total execution time: 0.1722
DEBUG - 2020-10-12 07:28:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:28:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:28:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:28:10 --> Total execution time: 0.1795
DEBUG - 2020-10-12 07:28:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:28:13 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:28:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:28:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:28:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:28:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:28:13 --> 404 Page Not Found: Uploads/words
ERROR - 2020-10-12 07:28:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:28:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:28:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:28:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:28:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:28:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:28:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:28:14 --> get_subcategory_list->{"lang":"37","category_id":"73","user_id":"765","support_lang_id":"3"}
DEBUG - 2020-10-12 07:28:14 --> Total execution time: 0.1158
DEBUG - 2020-10-12 07:28:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:28:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:28:16 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-12 07:28:16 --> Total execution time: 0.1630
DEBUG - 2020-10-12 07:28:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:28:16 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:28:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:28:19 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:28:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:28:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:28:22 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-12 07:28:22 --> Total execution time: 0.1407
DEBUG - 2020-10-12 07:28:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:28:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:28:30 --> Total execution time: 0.1132
DEBUG - 2020-10-12 07:28:31 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:28:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:28:31 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"765","support_lang_id":"3"}
DEBUG - 2020-10-12 07:28:31 --> Total execution time: 0.1225
DEBUG - 2020-10-12 07:28:31 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:28:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:28:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:28:31 --> Total execution time: 0.1690
DEBUG - 2020-10-12 07:28:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:28:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:28:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:28:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:28:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:28:43 --> Total execution time: 0.1522
DEBUG - 2020-10-12 07:28:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:28:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:28:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:28:47 --> Total execution time: 0.1362
DEBUG - 2020-10-12 07:28:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:28:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:28:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:28:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:29:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:29:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:29:39 --> Total execution time: 0.1659
DEBUG - 2020-10-12 07:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:29:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:29:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:29:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:29:50 --> No URI present. Default controller set.
DEBUG - 2020-10-12 07:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:29:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:29:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:29:50 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:29:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:29:50 --> Total execution time: 0.1304
DEBUG - 2020-10-12 07:29:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:29:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:29:52 --> No URI present. Default controller set.
DEBUG - 2020-10-12 07:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:29:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:29:52 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:29:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:29:52 --> Total execution time: 0.1129
DEBUG - 2020-10-12 07:30:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:30:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:30:33 --> Total execution time: 0.2050
DEBUG - 2020-10-12 07:30:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:30:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:30:39 --> Total execution time: 0.1572
DEBUG - 2020-10-12 07:30:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:30:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:30:42 --> Total execution time: 0.1523
DEBUG - 2020-10-12 07:32:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:32:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:32:56 --> Total execution time: 0.1408
DEBUG - 2020-10-12 07:32:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:32:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:32:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:33:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:33:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:33:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:33:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:33:30 --> Total execution time: 0.2196
DEBUG - 2020-10-12 07:33:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:33:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:33:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:33:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:33:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:33:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:33:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:33:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:33:36 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-10-12 07:33:36 --> Total execution time: 0.1314
DEBUG - 2020-10-12 07:33:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:33:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:33:40 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"62","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-10-12 07:33:40 --> Total execution time: 0.1314
DEBUG - 2020-10-12 07:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:33:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:33:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:33:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:33:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:33:57 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:33:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:33:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:33:57 --> Total execution time: 0.1603
DEBUG - 2020-10-12 07:34:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:34:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:34:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:34:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:34:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:34:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:34:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:34:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:34:02 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-10-12 07:34:02 --> Total execution time: 0.0987
DEBUG - 2020-10-12 07:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:34:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:34:09 --> Total execution time: 0.1217
DEBUG - 2020-10-12 07:34:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:34:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:34:12 --> Total execution time: 0.1356
DEBUG - 2020-10-12 07:34:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:34:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:34:28 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"62","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-10-12 07:34:28 --> Total execution time: 0.1404
DEBUG - 2020-10-12 07:34:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:34:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:34:33 --> Total execution time: 0.1349
DEBUG - 2020-10-12 07:34:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:34:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:34:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:34:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:34:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:34:49 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-10-12 07:34:49 --> Total execution time: 0.1136
DEBUG - 2020-10-12 07:35:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:35:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:35:00 --> Total execution time: 0.1417
DEBUG - 2020-10-12 07:35:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:35:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:35:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:35:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:35:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:35:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:35:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:35:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:35:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:35:19 --> Total execution time: 0.1836
DEBUG - 2020-10-12 07:35:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:35:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:35:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:35:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:35:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:35:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:35:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:35:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:35:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:35:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:35:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:35:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:35:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:35:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:35:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:35:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:35:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:35:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:35:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:35:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:36:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:36:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:36:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:36:01 --> Total execution time: 0.1949
DEBUG - 2020-10-12 07:36:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:36:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:36:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:36:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:36:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:36:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:36:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:36:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:36:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:36:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:36:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:36:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:36:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:36:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:36:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:36:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:36:11 --> Total execution time: 0.1239
DEBUG - 2020-10-12 07:36:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:36:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:36:13 --> Total execution time: 0.1365
DEBUG - 2020-10-12 07:36:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:36:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:36:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:36:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:36:17 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"62","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-10-12 07:36:17 --> Total execution time: 0.1455
DEBUG - 2020-10-12 07:36:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:36:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:36:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:36:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:36:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:36:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:36:26 --> Total execution time: 0.1632
DEBUG - 2020-10-12 07:36:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:36:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:36:30 --> Total execution time: 0.1220
DEBUG - 2020-10-12 07:36:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:36:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:36:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-12 07:36:33 --> Total execution time: 0.1241
DEBUG - 2020-10-12 07:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:36:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:36:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:36:36 --> Total execution time: 0.1654
DEBUG - 2020-10-12 07:36:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:36:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:36:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:36:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:36:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-12 07:36:48 --> Total execution time: 0.1580
DEBUG - 2020-10-12 07:36:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:36:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:36:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-12 07:36:51 --> Total execution time: 0.1300
DEBUG - 2020-10-12 07:36:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:36:54 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:36:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:36:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:36:58 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-10-12 07:36:58 --> Total execution time: 0.1182
DEBUG - 2020-10-12 07:37:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:37:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:37:03 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"62","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-10-12 07:37:03 --> Total execution time: 0.1032
DEBUG - 2020-10-12 07:37:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:37:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:37:03 --> Total execution time: 0.1270
DEBUG - 2020-10-12 07:37:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:37:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:37:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:37:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:37:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:37:06 --> Total execution time: 0.1888
DEBUG - 2020-10-12 07:37:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:37:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:37:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:37:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:37:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:37:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:37:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:37:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:37:09 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-10-12 07:37:09 --> Total execution time: 0.1463
DEBUG - 2020-10-12 07:37:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:37:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:37:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:37:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:37:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:37:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:37:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:37:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:37:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:37:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:37:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:37:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:37:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:37:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:37:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:37:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:37:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:37:17 --> Total execution time: 0.1610
DEBUG - 2020-10-12 07:37:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:37:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:37:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:37:20 --> Total execution time: 0.1661
DEBUG - 2020-10-12 07:37:25 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:37:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:37:25 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:37:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:37:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:37:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:37:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:37:32 --> Total execution time: 0.1714
DEBUG - 2020-10-12 07:37:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:37:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:37:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:37:34 --> Total execution time: 0.1691
DEBUG - 2020-10-12 07:37:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:37:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:37:38 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:37:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:37:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:37:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:37:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:37:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:37:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:39:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:39:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:39:18 --> Total execution time: 0.2045
DEBUG - 2020-10-12 07:39:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:39:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:39:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:40:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:40:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:40:06 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:40:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:40:06 --> No URI present. Default controller set.
DEBUG - 2020-10-12 07:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:40:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:40:06 --> Total execution time: 0.1211
DEBUG - 2020-10-12 07:40:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:40:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:40:07 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 07:40:07 --> Total execution time: 0.1222
DEBUG - 2020-10-12 07:40:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:40:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:40:07 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"746","support_lang_id":"3"}
DEBUG - 2020-10-12 07:40:07 --> Total execution time: 0.1126
DEBUG - 2020-10-12 07:40:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:40:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:40:07 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-12 07:40:07 --> Total execution time: 0.1051
DEBUG - 2020-10-12 07:40:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:40:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:40:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:40:08 --> Total execution time: 0.1256
DEBUG - 2020-10-12 07:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:40:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:40:08 --> Total execution time: 0.1112
DEBUG - 2020-10-12 07:40:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:40:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:40:08 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:41:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:41:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:41:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:41:02 --> Total execution time: 0.1512
DEBUG - 2020-10-12 07:41:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:41:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:41:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:41:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:41:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:41:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:41:10 --> Total execution time: 0.2008
DEBUG - 2020-10-12 07:41:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:41:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:41:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:41:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:41:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:41:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:41:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:41:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:41:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:41:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:41:13 --> 404 Page Not Found: Uploads/words
ERROR - 2020-10-12 07:41:13 --> 404 Page Not Found: Uploads/words
ERROR - 2020-10-12 07:41:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:41:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:41:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:41:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:41:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:41:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:41:22 --> Total execution time: 0.1478
DEBUG - 2020-10-12 07:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:41:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:41:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:41:25 --> Total execution time: 0.1534
DEBUG - 2020-10-12 07:41:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:41:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:41:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:41:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:41:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:41:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:41:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:41:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:41:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:41:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:41:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:41:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:41:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:41:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:41:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:41:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:41:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:41:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:41:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:41:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:41:41 --> Total execution time: 0.1634
DEBUG - 2020-10-12 07:41:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:41:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:41:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:41:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:41:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:41:55 --> Total execution time: 0.1304
DEBUG - 2020-10-12 07:42:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:42:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:42:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:42:06 --> Total execution time: 0.1527
DEBUG - 2020-10-12 07:42:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:42:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:42:09 --> Total execution time: 0.1454
DEBUG - 2020-10-12 07:42:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:42:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:42:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:42:14 --> Total execution time: 0.1472
DEBUG - 2020-10-12 07:42:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:42:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:42:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-12 07:42:16 --> Total execution time: 0.1903
DEBUG - 2020-10-12 07:42:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:42:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:42:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:42:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:42:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:42:21 --> Total execution time: 0.1395
DEBUG - 2020-10-12 07:42:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:42:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:42:30 --> Total execution time: 0.1275
DEBUG - 2020-10-12 07:42:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:42:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:42:37 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"765","support_lang_id":"3"}
DEBUG - 2020-10-12 07:42:37 --> Total execution time: 0.1817
DEBUG - 2020-10-12 07:42:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:42:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:42:43 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-12 07:42:43 --> Total execution time: 0.1239
DEBUG - 2020-10-12 07:42:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:42:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:42:46 --> Total execution time: 0.1130
DEBUG - 2020-10-12 07:42:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:42:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:42:52 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-12 07:42:52 --> Total execution time: 0.1464
DEBUG - 2020-10-12 07:42:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:42:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:42:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:42:55 --> Total execution time: 0.1638
DEBUG - 2020-10-12 07:42:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:42:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:42:56 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:42:57 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:42:57 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:42:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:42:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:42:57 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"765","support_lang_id":"3"}
DEBUG - 2020-10-12 07:42:57 --> Total execution time: 0.1388
DEBUG - 2020-10-12 07:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:42:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:42:58 --> Total execution time: 0.1367
DEBUG - 2020-10-12 07:42:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:42:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:42:59 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:42:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:42:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:42:59 --> Total execution time: 0.1380
DEBUG - 2020-10-12 07:43:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:43:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:43:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:43:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:43:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:43:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-12 07:43:02 --> Total execution time: 0.1429
DEBUG - 2020-10-12 07:43:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:43:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:43:03 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 07:43:03 --> Total execution time: 0.0978
DEBUG - 2020-10-12 07:43:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:43:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:43:04 --> Total execution time: 0.1513
DEBUG - 2020-10-12 07:43:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:43:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:43:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:43:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:43:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:43:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:43:07 --> Total execution time: 0.1536
DEBUG - 2020-10-12 07:43:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:43:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:43:08 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 07:43:08 --> Total execution time: 0.1516
DEBUG - 2020-10-12 07:43:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:43:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:43:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:43:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:43:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:43:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:43:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:43:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:43:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:43:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:43:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:43:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:43:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:43:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:43:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:43:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:43:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:43:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:43:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:43:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:43:25 --> Total execution time: 0.1572
DEBUG - 2020-10-12 07:43:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:43:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:43:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:43:27 --> Total execution time: 0.2176
DEBUG - 2020-10-12 07:43:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:43:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:43:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:43:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:43:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:43:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:43:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:43:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:43:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-12 07:43:37 --> Total execution time: 0.1630
DEBUG - 2020-10-12 07:43:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:43:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:43:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-12 07:43:40 --> Total execution time: 0.1628
DEBUG - 2020-10-12 07:43:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:43:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:43:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:43:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:43:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:43:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:43:55 --> Total execution time: 0.1847
DEBUG - 2020-10-12 07:43:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:43:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:43:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:43:58 --> Total execution time: 0.1513
DEBUG - 2020-10-12 07:44:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:44:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:44:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:44:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:44:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:44:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:44:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:44:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:44:05 --> Total execution time: 0.1533
DEBUG - 2020-10-12 07:44:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:44:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:44:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:44:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:44:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:44:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:44:20 --> Total execution time: 0.2035
DEBUG - 2020-10-12 07:44:23 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:44:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:44:23 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:44:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:44:23 --> Total execution time: 0.1197
DEBUG - 2020-10-12 07:44:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:44:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:44:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:44:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:44:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:44:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:44:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:44:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:44:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:44:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:44:39 --> Total execution time: 0.1326
DEBUG - 2020-10-12 07:44:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:44:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:44:42 --> Total execution time: 0.1357
DEBUG - 2020-10-12 07:44:45 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:44:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:44:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:46:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:46:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:46:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:46:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:46:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:46:19 --> Total execution time: 0.1809
DEBUG - 2020-10-12 07:46:23 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:46:23 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:46:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:46:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:46:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:46:23 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:46:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:46:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:46:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:46:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:46:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:46:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:46:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:46:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:46:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:46:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:46:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:46:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:46:35 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:46:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:46:35 --> Total execution time: 0.1496
DEBUG - 2020-10-12 07:46:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:46:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:46:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:46:39 --> Total execution time: 0.1389
DEBUG - 2020-10-12 07:46:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:46:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:46:41 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:46:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:46:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:46:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:46:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:46:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:46:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:46:47 --> Total execution time: 0.1763
DEBUG - 2020-10-12 07:46:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:46:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 07:46:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 07:46:52 --> Total execution time: 0.1920
DEBUG - 2020-10-12 07:46:53 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:46:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:46:53 --> Total execution time: 0.1381
DEBUG - 2020-10-12 07:46:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:46:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:46:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:46:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:46:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:46:56 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 07:49:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:49:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:07 --> No URI present. Default controller set.
DEBUG - 2020-10-12 07:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:49:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:49:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:49:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:49:07 --> Total execution time: 0.1301
DEBUG - 2020-10-12 07:49:07 --> Total execution time: 0.1750
DEBUG - 2020-10-12 07:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:49:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:49:07 --> Total execution time: 0.1475
DEBUG - 2020-10-12 07:49:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:49:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:49:24 --> Total execution time: 0.1120
DEBUG - 2020-10-12 07:49:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:49:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:49:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:28 --> No URI present. Default controller set.
DEBUG - 2020-10-12 07:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:49:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:49:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:49:28 --> Total execution time: 0.1571
DEBUG - 2020-10-12 07:49:28 --> Total execution time: 0.1186
DEBUG - 2020-10-12 07:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:49:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:49:28 --> Total execution time: 0.1500
DEBUG - 2020-10-12 07:49:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:30 --> No URI present. Default controller set.
DEBUG - 2020-10-12 07:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:49:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:49:30 --> Total execution time: 0.1395
DEBUG - 2020-10-12 07:49:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:34 --> No URI present. Default controller set.
DEBUG - 2020-10-12 07:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:49:34 --> Total execution time: 0.1620
DEBUG - 2020-10-12 07:49:35 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:49:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:49:35 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-12 07:49:35 --> Total execution time: 0.1125
DEBUG - 2020-10-12 07:49:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:49:37 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:49:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:49:39 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:49:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:49:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:49:40 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"746","support_lang_id":"3"}
DEBUG - 2020-10-12 07:49:40 --> Total execution time: 0.1492
DEBUG - 2020-10-12 07:49:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:40 --> No URI present. Default controller set.
DEBUG - 2020-10-12 07:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:49:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:49:40 --> Total execution time: 0.1327
DEBUG - 2020-10-12 07:49:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:42 --> No URI present. Default controller set.
DEBUG - 2020-10-12 07:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:49:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:49:43 --> Total execution time: 0.1083
DEBUG - 2020-10-12 07:49:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:49:43 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:49:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:49:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:49:44 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 07:49:44 --> Total execution time: 0.0981
DEBUG - 2020-10-12 07:49:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:49:46 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:49:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:49:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:49:46 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-12 07:49:46 --> Total execution time: 0.1327
DEBUG - 2020-10-12 07:49:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:49:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:49:48 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 07:49:48 --> Total execution time: 0.1352
DEBUG - 2020-10-12 07:49:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:48 --> No URI present. Default controller set.
DEBUG - 2020-10-12 07:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:49:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:49:48 --> Total execution time: 0.1865
DEBUG - 2020-10-12 07:49:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:49:49 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:49:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:49:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:49:50 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-10-12 07:49:50 --> Total execution time: 0.1299
DEBUG - 2020-10-12 07:49:53 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:49:53 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:49:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:49:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:49:54 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 07:49:54 --> Total execution time: 0.1234
DEBUG - 2020-10-12 07:49:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:49:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:49:58 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 07:49:58 --> Total execution time: 0.1111
DEBUG - 2020-10-12 07:51:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:51:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:51:24 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:51:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:51:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:51:24 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 07:51:24 --> Total execution time: 0.0995
DEBUG - 2020-10-12 07:51:25 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:51:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:51:25 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"765","support_lang_id":"3"}
DEBUG - 2020-10-12 07:51:25 --> Total execution time: 0.1059
DEBUG - 2020-10-12 07:51:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:51:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:51:27 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-12 07:51:27 --> Total execution time: 0.1114
DEBUG - 2020-10-12 07:51:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:51:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:51:27 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:51:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:51:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:51:27 --> Total execution time: 0.1291
DEBUG - 2020-10-12 07:51:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:51:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:51:29 --> Total execution time: 0.1423
DEBUG - 2020-10-12 07:51:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:51:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:51:36 --> Total execution time: 0.1206
DEBUG - 2020-10-12 07:52:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:52:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:52:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:52:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:52:12 --> Total execution time: 0.1100
DEBUG - 2020-10-12 07:52:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:52:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:52:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 07:52:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:52:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:52:20 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:52:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:52:22 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-10-12 07:52:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:52:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:52:54 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:52:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:52:54 --> No URI present. Default controller set.
DEBUG - 2020-10-12 07:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:52:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:52:54 --> Total execution time: 0.1401
DEBUG - 2020-10-12 07:52:57 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:52:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:52:57 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:52:57 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:52:57 --> No URI present. Default controller set.
DEBUG - 2020-10-12 07:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:52:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:52:57 --> Total execution time: 0.1165
DEBUG - 2020-10-12 07:53:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:53:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:53:26 --> No URI present. Default controller set.
DEBUG - 2020-10-12 07:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:53:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:53:26 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 07:53:26 --> Total execution time: 0.1410
DEBUG - 2020-10-12 07:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:53:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:53:26 --> Total execution time: 0.1648
DEBUG - 2020-10-12 07:53:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:53:29 --> No URI present. Default controller set.
DEBUG - 2020-10-12 07:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:53:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:53:29 --> Total execution time: 0.1381
DEBUG - 2020-10-12 07:53:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:53:41 --> No URI present. Default controller set.
DEBUG - 2020-10-12 07:53:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:53:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:53:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:53:41 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 07:53:41 --> Total execution time: 0.1482
DEBUG - 2020-10-12 07:53:41 --> Total execution time: 0.1637
DEBUG - 2020-10-12 07:53:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:53:43 --> No URI present. Default controller set.
DEBUG - 2020-10-12 07:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:53:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:53:43 --> Total execution time: 0.1375
DEBUG - 2020-10-12 07:53:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:53:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:53:59 --> No URI present. Default controller set.
DEBUG - 2020-10-12 07:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:53:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:53:59 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 07:53:59 --> Total execution time: 0.1471
DEBUG - 2020-10-12 07:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:53:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:53:59 --> Total execution time: 0.1439
DEBUG - 2020-10-12 07:54:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:54:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:54:03 --> No URI present. Default controller set.
DEBUG - 2020-10-12 07:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:54:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:54:03 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 07:54:03 --> Total execution time: 0.1635
DEBUG - 2020-10-12 07:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:54:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:54:03 --> Total execution time: 0.1662
DEBUG - 2020-10-12 07:54:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:54:05 --> No URI present. Default controller set.
DEBUG - 2020-10-12 07:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:54:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:54:05 --> Total execution time: 0.1254
DEBUG - 2020-10-12 07:55:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:55:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:55:22 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 07:55:22 --> Total execution time: 0.1470
DEBUG - 2020-10-12 07:55:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:55:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:55:50 --> get_grammer_type_2->{"slang":"37","tlang":"3","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
ERROR - 2020-10-12 07:55:50 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-12 07:55:50 --> Total execution time: 0.0957
DEBUG - 2020-10-12 07:55:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:55:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:55:52 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:55:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:55:52 --> No URI present. Default controller set.
DEBUG - 2020-10-12 07:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:55:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:55:52 --> Total execution time: 0.1243
DEBUG - 2020-10-12 07:55:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:55:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 07:55:55 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 07:55:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:55:55 --> No URI present. Default controller set.
DEBUG - 2020-10-12 07:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:55:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:55:55 --> Total execution time: 0.1417
DEBUG - 2020-10-12 07:55:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:55:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:55:59 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 07:55:59 --> Total execution time: 0.1378
DEBUG - 2020-10-12 07:56:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:56:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:56:19 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 07:56:19 --> Total execution time: 0.1368
DEBUG - 2020-10-12 07:57:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:57:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:57:38 --> Total execution time: 0.1208
DEBUG - 2020-10-12 07:57:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:57:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:57:42 --> Total execution time: 0.1037
DEBUG - 2020-10-12 07:58:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:58:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:58:00 --> Total execution time: 0.1871
DEBUG - 2020-10-12 07:58:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 07:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 07:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 07:58:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 07:58:50 --> Total execution time: 0.1481
DEBUG - 2020-10-12 08:12:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 08:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 08:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 08:12:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 08:12:11 --> Total execution time: 0.2027
DEBUG - 2020-10-12 08:12:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 08:12:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 08:12:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 08:19:53 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 08:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 08:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 08:19:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 08:19:53 --> Total execution time: 0.1427
DEBUG - 2020-10-12 08:20:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 08:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 08:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 08:20:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 08:20:16 --> Total execution time: 0.1345
DEBUG - 2020-10-12 08:20:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 08:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 08:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 08:20:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 08:20:28 --> Total execution time: 0.1482
DEBUG - 2020-10-12 08:23:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 08:23:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 08:23:34 --> No URI present. Default controller set.
DEBUG - 2020-10-12 08:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 08:23:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 08:23:34 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 08:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 08:23:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 08:23:35 --> Total execution time: 0.1513
DEBUG - 2020-10-12 08:23:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 08:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 08:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 08:23:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 08:23:36 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 08:23:36 --> Total execution time: 0.1382
DEBUG - 2020-10-12 08:23:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 08:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 08:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 08:23:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 08:23:36 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"746","support_lang_id":"3"}
DEBUG - 2020-10-12 08:23:36 --> Total execution time: 0.1181
DEBUG - 2020-10-12 08:23:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 08:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 08:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 08:23:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 08:23:36 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-12 08:23:36 --> Total execution time: 0.1100
DEBUG - 2020-10-12 08:23:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 08:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 08:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 08:23:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 08:23:36 --> Total execution time: 0.1112
DEBUG - 2020-10-12 08:23:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 08:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 08:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 08:23:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 08:23:37 --> Total execution time: 0.1449
DEBUG - 2020-10-12 08:23:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 08:23:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 08:23:37 --> No URI present. Default controller set.
DEBUG - 2020-10-12 08:23:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 08:23:37 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 08:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 08:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 08:23:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 08:23:37 --> Total execution time: 0.1495
DEBUG - 2020-10-12 08:24:31 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 08:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 08:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 08:24:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 08:24:31 --> get_category_list->{"lang":"38","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-12 08:24:31 --> Total execution time: 0.1035
DEBUG - 2020-10-12 08:25:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 08:25:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 08:25:24 --> No URI present. Default controller set.
DEBUG - 2020-10-12 08:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 08:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 08:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 08:25:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 08:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 08:25:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 08:25:24 --> Total execution time: 0.1463
DEBUG - 2020-10-12 08:25:24 --> Total execution time: 0.1559
DEBUG - 2020-10-12 08:25:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 08:25:39 --> No URI present. Default controller set.
DEBUG - 2020-10-12 08:25:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 08:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 08:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 08:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 08:25:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 08:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 08:25:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 08:25:39 --> Total execution time: 0.1298
DEBUG - 2020-10-12 08:25:39 --> Total execution time: 0.1449
DEBUG - 2020-10-12 08:25:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 08:25:42 --> No URI present. Default controller set.
DEBUG - 2020-10-12 08:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 08:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 08:25:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 08:25:42 --> Total execution time: 0.1320
DEBUG - 2020-10-12 08:49:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 08:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 08:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 08:49:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 08:49:37 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 08:49:37 --> Total execution time: 0.1376
DEBUG - 2020-10-12 08:49:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 08:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 08:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 08:49:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 08:49:44 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-12 08:49:44 --> Total execution time: 0.1417
DEBUG - 2020-10-12 09:21:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 09:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 09:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 09:21:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 09:21:48 --> Total execution time: 0.1083
DEBUG - 2020-10-12 09:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 09:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 09:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 09:21:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 09:21:51 --> Total execution time: 0.1335
DEBUG - 2020-10-12 09:21:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 09:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 09:21:54 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 09:21:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 09:21:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 09:21:55 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 09:21:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 09:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 09:21:58 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-10-12 09:23:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 09:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 09:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 09:23:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 09:23:44 --> Total execution time: 0.1192
DEBUG - 2020-10-12 09:23:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 09:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 09:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 09:23:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 09:23:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 09:23:46 --> Total execution time: 0.1567
DEBUG - 2020-10-12 09:23:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 09:23:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 09:23:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 09:23:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 09:23:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 09:23:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 09:23:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 09:23:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 09:23:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 09:23:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 09:23:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 09:23:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 09:23:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 09:23:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 09:23:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 09:23:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 09:23:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 09:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 09:23:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 09:23:54 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 09:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 09:23:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 09:23:54 --> Total execution time: 0.1405
DEBUG - 2020-10-12 09:24:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 09:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 09:24:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 09:25:45 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 09:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 09:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 09:25:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 09:25:45 --> Total execution time: 0.1435
DEBUG - 2020-10-12 09:25:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 09:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 09:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 09:25:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 09:25:48 --> Total execution time: 0.1286
DEBUG - 2020-10-12 09:25:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 09:25:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 09:25:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 09:25:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 09:25:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 09:25:56 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-12 09:25:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 09:25:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 09:25:59 --> 404 Page Not Found: Uploads/At__the_dentists.JPG
DEBUG - 2020-10-12 09:26:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 09:26:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 09:26:09 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-10-12 09:26:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 09:26:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 09:26:21 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-10-12 10:39:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 10:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 10:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 10:39:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 10:39:15 --> Total execution time: 0.1395
DEBUG - 2020-10-12 10:39:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 10:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 10:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 10:39:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 10:39:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-10-12 10:39:17 --> Total execution time: 0.1677
DEBUG - 2020-10-12 10:39:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 10:39:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 10:39:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 10:39:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 10:39:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 10:39:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 10:39:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 10:39:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 10:39:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 10:39:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 10:39:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 10:39:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 10:39:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 10:39:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 10:39:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 10:39:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 10:39:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 10:39:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 11:15:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 11:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 11:15:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:15:34 --> Total execution time: 0.1447
DEBUG - 2020-10-12 11:44:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 11:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 11:44:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:44:56 --> Total execution time: 0.1414
DEBUG - 2020-10-12 11:44:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 11:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 11:44:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 11:44:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-10-12 11:44:58 --> Total execution time: 0.1545
DEBUG - 2020-10-12 11:45:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:45:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 11:45:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 11:46:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 11:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 11:46:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 11:46:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-10-12 11:46:07 --> Total execution time: 0.1459
DEBUG - 2020-10-12 11:46:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:46:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 11:46:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 11:47:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 11:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 11:47:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 11:47:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-10-12 11:47:11 --> Total execution time: 0.1412
DEBUG - 2020-10-12 11:47:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:47:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 11:47:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 11:54:57 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 11:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 11:54:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 11:54:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-10-12 11:54:57 --> Total execution time: 0.1461
DEBUG - 2020-10-12 11:54:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 11:54:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 11:56:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 11:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 11:56:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:56:42 --> Total execution time: 0.1308
DEBUG - 2020-10-12 11:56:45 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:56:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 11:56:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 11:57:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 11:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 11:57:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:57:01 --> Total execution time: 0.1131
DEBUG - 2020-10-12 11:57:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 11:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 11:57:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 11:57:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2020-10-12 11:57:03 --> Total execution time: 0.1786
DEBUG - 2020-10-12 11:57:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 11:57:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 11:57:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 11:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 11:57:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:57:54 --> Total execution time: 0.1538
DEBUG - 2020-10-12 11:57:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 11:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-12 11:57:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 11:57:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-10-12 11:57:56 --> Total execution time: 0.1837
DEBUG - 2020-10-12 11:57:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:57:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 11:57:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-12 11:57:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:57:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 11:57:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 11:58:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:58:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 11:58:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 11:58:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:58:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 11:58:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 11:58:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:58:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 11:58:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 11:58:01 --> 404 Page Not Found: Uploads/words
ERROR - 2020-10-12 11:58:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-12 11:58:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:58:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-12 11:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-12 11:58:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-12 11:58:02 --> 404 Page Not Found: Uploads/words
ERROR - 2020-10-12 11:58:02 --> 404 Page Not Found: Uploads/words
