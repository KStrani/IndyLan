<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-01-28 13:03:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 13:03:48 --> No URI present. Default controller set.
DEBUG - 2021-01-28 13:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 13:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 13:03:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 13:03:49 --> Total execution time: 0.1899
DEBUG - 2021-01-28 13:03:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 13:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 13:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 13:03:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 13:04:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 13:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 13:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 13:04:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 13:04:02 --> Total execution time: 0.1346
DEBUG - 2021-01-28 13:04:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 13:04:02 --> No URI present. Default controller set.
DEBUG - 2021-01-28 13:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 13:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 13:04:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 13:04:02 --> Total execution time: 0.1149
DEBUG - 2021-01-28 13:04:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 13:04:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 13:04:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 13:04:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 13:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 13:04:08 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2021-01-28 13:04:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 13:04:22 --> No URI present. Default controller set.
DEBUG - 2021-01-28 13:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 13:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 13:04:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 13:04:22 --> Total execution time: 0.1479
DEBUG - 2021-01-28 13:18:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 13:18:39 --> No URI present. Default controller set.
DEBUG - 2021-01-28 13:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 13:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 13:18:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 13:18:39 --> Total execution time: 0.1340
DEBUG - 2021-01-28 13:18:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 13:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 13:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 13:18:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 13:18:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 13:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 13:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 13:18:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 13:18:51 --> Total execution time: 0.1176
DEBUG - 2021-01-28 14:11:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:11:52 --> No URI present. Default controller set.
DEBUG - 2021-01-28 14:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:11:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:11:52 --> Total execution time: 0.1293
DEBUG - 2021-01-28 14:12:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:12:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:12:24 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:12:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:12:25 --> Total execution time: 0.1564
DEBUG - 2021-01-28 14:12:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:12:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:12:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 14:12:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:12:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:12:33 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2021-01-28 14:12:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:12:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:12:37 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2021-01-28 14:23:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:23:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:23:37 --> user_register->{"first_name":"Dimpy","last_name":"","email":"dimpy.sojitra@voolsy.com","password":"123456","confirm_password":"123456","social_id":null,"social_type":"0","user_image":null}
ERROR - 2021-01-28 14:23:37 --> {"status":0,"message":"Email Already Exist","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2021-01-28 14:23:37 --> Total execution time: 0.1481
DEBUG - 2021-01-28 14:23:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:23:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:23:52 --> user_register->{"first_name":"Dimpy","last_name":"","email":"dimpy.sojitraa@gmail.com","password":"123456","confirm_password":"123456","social_id":null,"social_type":"0","user_image":null}
ERROR - 2021-01-28 14:23:52 --> {"status":0,"message":"Email Already Exist","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2021-01-28 14:23:52 --> Total execution time: 0.1562
DEBUG - 2021-01-28 14:24:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:24:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:24:01 --> user_register->{"first_name":"Dimpy","last_name":"","email":"dimpy.sojitra@gmail.com","password":"123456","confirm_password":"123456","social_id":null,"social_type":"0","user_image":null}
ERROR - 2021-01-28 14:24:01 --> {"status":0,"message":"Email Already Exist","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2021-01-28 14:24:01 --> Total execution time: 0.1245
DEBUG - 2021-01-28 14:24:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:24:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:24:22 --> user_register->{"first_name":"Dimpy","last_name":"","email":"dimpii.sojitra@origzo.com","password":"123456","confirm_password":"123456","social_id":null,"social_type":"0","user_image":null}
DEBUG - 2021-01-28 14:24:22 --> Total execution time: 0.1169
DEBUG - 2021-01-28 14:24:25 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:24:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:24:25 --> Total execution time: 0.0987
DEBUG - 2021-01-28 14:24:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:24:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:24:33 --> Total execution time: 0.1350
DEBUG - 2021-01-28 14:24:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:24:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:24:39 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-28 14:24:39 --> Total execution time: 0.1189
DEBUG - 2021-01-28 14:24:43 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:24:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:24:43 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"770","support_lang_id":"3"}
DEBUG - 2021-01-28 14:24:43 --> Total execution time: 0.1352
DEBUG - 2021-01-28 14:24:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:24:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:24:48 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2021-01-28 14:24:48 --> Total execution time: 0.1380
DEBUG - 2021-01-28 14:24:54 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:24:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:24:54 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"62","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2021-01-28 14:24:54 --> Total execution time: 0.1552
DEBUG - 2021-01-28 14:24:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:24:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:24:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-28 14:25:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:25:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:25:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-28 14:25:05 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:25:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:25:05 --> Total execution time: 0.1229
DEBUG - 2021-01-28 14:26:05 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:26:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:26:05 --> Total execution time: 0.1687
DEBUG - 2021-01-28 14:26:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:26:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:26:07 --> Total execution time: 0.1286
DEBUG - 2021-01-28 14:26:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:26:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:26:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 14:26:25 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:26:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:26:26 --> Total execution time: 0.1591
DEBUG - 2021-01-28 14:26:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:26:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:26:28 --> Total execution time: 0.1351
DEBUG - 2021-01-28 14:26:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:26:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:26:31 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 14:26:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:26:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:26:31 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2021-01-28 14:26:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:26:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:26:33 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2021-01-28 14:27:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:27:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:27:32 --> Total execution time: 0.1219
DEBUG - 2021-01-28 14:27:38 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:27:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:27:38 --> Total execution time: 0.1034
DEBUG - 2021-01-28 14:27:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:27:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:27:47 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-28 14:27:47 --> Total execution time: 0.1396
DEBUG - 2021-01-28 14:27:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:27:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:27:52 --> get_subcategory_list->{"lang":"37","category_id":"51","user_id":"770","support_lang_id":"3"}
DEBUG - 2021-01-28 14:27:52 --> Total execution time: 0.1316
DEBUG - 2021-01-28 14:27:56 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:27:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:27:56 --> get_exercise_type_list->{"lang":"37","subcategory_id":"106","support_lang_id":"3"}
DEBUG - 2021-01-28 14:27:56 --> Total execution time: 0.1538
DEBUG - 2021-01-28 14:28:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:28:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:28:02 --> get_sorce_lan_word_type_3->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"51","subcategory_id":"106","support_lang_id":"3"}
ERROR - 2021-01-28 14:28:02 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-01-28 14:28:02 --> Total execution time: 0.1104
DEBUG - 2021-01-28 14:28:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:28:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:28:08 --> get_exercise_type_list->{"lang":"37","subcategory_id":"106","support_lang_id":"3"}
DEBUG - 2021-01-28 14:28:08 --> Total execution time: 0.1066
DEBUG - 2021-01-28 14:28:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:28:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:28:13 --> get_subcategory_list->{"lang":"37","category_id":"51","user_id":"770","support_lang_id":"3"}
DEBUG - 2021-01-28 14:28:13 --> Total execution time: 0.1256
DEBUG - 2021-01-28 14:28:18 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:28:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:28:18 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-28 14:28:18 --> Total execution time: 0.1247
DEBUG - 2021-01-28 14:28:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:28:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:28:28 --> Total execution time: 0.1414
DEBUG - 2021-01-28 14:28:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:28:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:28:30 --> Total execution time: 0.1543
DEBUG - 2021-01-28 14:28:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:28:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:28:32 --> Total execution time: 0.1346
DEBUG - 2021-01-28 14:28:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:28:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:28:32 --> Total execution time: 0.1338
DEBUG - 2021-01-28 14:28:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:28:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:28:34 --> Total execution time: 0.1707
DEBUG - 2021-01-28 14:28:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:28:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 14:28:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 14:28:37 --> Total execution time: 0.2078
DEBUG - 2021-01-28 14:28:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:28:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 14:28:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 14:28:39 --> Total execution time: 0.1787
DEBUG - 2021-01-28 14:28:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:28:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 14:28:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 14:28:40 --> Total execution time: 0.1605
DEBUG - 2021-01-28 14:28:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:28:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:28:42 --> Total execution time: 0.1696
DEBUG - 2021-01-28 14:28:44 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:28:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:28:44 --> Total execution time: 0.1309
DEBUG - 2021-01-28 14:28:45 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:28:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:28:45 --> Total execution time: 0.1831
DEBUG - 2021-01-28 14:28:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:28:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:28:53 --> Total execution time: 0.1361
DEBUG - 2021-01-28 14:28:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:28:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 14:28:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 14:28:58 --> Total execution time: 0.1443
DEBUG - 2021-01-28 14:29:00 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:29:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 14:29:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 14:29:01 --> Total execution time: 0.2075
DEBUG - 2021-01-28 14:29:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:29:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 14:29:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 14:29:08 --> Total execution time: 0.1388
DEBUG - 2021-01-28 14:29:14 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:29:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:29:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-28 14:29:19 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:29:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-28 14:55:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:55:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:55:58 --> Total execution time: 0.1272
DEBUG - 2021-01-28 14:56:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:56:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:56:02 --> Total execution time: 0.1064
DEBUG - 2021-01-28 14:56:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:56:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:56:08 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-28 14:56:08 --> Total execution time: 0.1232
DEBUG - 2021-01-28 14:56:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:56:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:56:15 --> get_subcategory_list->{"lang":"37","category_id":"67","user_id":"770","support_lang_id":"1"}
DEBUG - 2021-01-28 14:56:15 --> Total execution time: 0.1393
DEBUG - 2021-01-28 14:56:18 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:56:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:56:18 --> get_exercise_type_list->{"lang":"37","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2021-01-28 14:56:18 --> Total execution time: 0.1130
DEBUG - 2021-01-28 14:56:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:56:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:56:22 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"67","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2021-01-28 14:56:22 --> Total execution time: 0.1201
DEBUG - 2021-01-28 14:56:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:56:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:56:30 --> get_exercise_type_list->{"lang":"37","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2021-01-28 14:56:30 --> Total execution time: 0.1144
DEBUG - 2021-01-28 14:56:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:56:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:56:33 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"67","subcategory_id":"156","support_lang_id":"1"}
ERROR - 2021-01-28 14:56:33 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-01-28 14:56:33 --> Total execution time: 0.1167
DEBUG - 2021-01-28 14:56:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:56:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:56:37 --> get_exercise_type_list->{"lang":"37","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2021-01-28 14:56:37 --> Total execution time: 0.1200
DEBUG - 2021-01-28 14:56:41 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:56:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:56:41 --> get_sorce_lan_word_type_3->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"67","subcategory_id":"156","support_lang_id":"1"}
ERROR - 2021-01-28 14:56:41 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-01-28 14:56:41 --> Total execution time: 0.1274
DEBUG - 2021-01-28 14:56:45 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:56:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:56:45 --> get_exercise_type_list->{"lang":"37","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2021-01-28 14:56:45 --> Total execution time: 0.1146
DEBUG - 2021-01-28 14:56:45 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:56:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:56:45 --> get_subcategory_list->{"lang":"37","category_id":"67","user_id":"770","support_lang_id":"1"}
DEBUG - 2021-01-28 14:56:45 --> Total execution time: 0.1046
DEBUG - 2021-01-28 14:56:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:56:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:56:49 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2021-01-28 14:56:49 --> Total execution time: 0.1354
DEBUG - 2021-01-28 14:56:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:56:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:56:57 --> Total execution time: 0.1262
DEBUG - 2021-01-28 14:57:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:57:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:57:03 --> Total execution time: 0.1304
DEBUG - 2021-01-28 14:57:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:57:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:57:08 --> Total execution time: 0.1352
DEBUG - 2021-01-28 14:57:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:57:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:57:13 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-28 14:57:13 --> Total execution time: 0.1257
DEBUG - 2021-01-28 14:57:19 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:57:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:57:20 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"770","support_lang_id":"3"}
DEBUG - 2021-01-28 14:57:20 --> Total execution time: 0.1213
DEBUG - 2021-01-28 14:57:24 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:57:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:57:24 --> get_exercise_type_list->{"lang":"37","subcategory_id":"102","support_lang_id":"3"}
DEBUG - 2021-01-28 14:57:24 --> Total execution time: 0.1511
DEBUG - 2021-01-28 14:57:29 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:57:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:57:29 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"770","support_lang_id":"3"}
DEBUG - 2021-01-28 14:57:29 --> Total execution time: 0.1231
DEBUG - 2021-01-28 14:57:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:57:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:57:31 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
ERROR - 2021-01-28 14:57:31 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2021-01-28 14:57:31 --> Total execution time: 0.1423
DEBUG - 2021-01-28 14:57:53 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:57:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 14:57:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 14:57:53 --> Total execution time: 0.1528
DEBUG - 2021-01-28 14:57:56 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:57:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:57:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 14:58:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:58:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:58:01 --> Total execution time: 0.1113
DEBUG - 2021-01-28 14:58:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:58:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:58:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:58:04 --> Total execution time: 0.1521
DEBUG - 2021-01-28 14:58:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:58:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 14:58:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-28 14:58:04 --> Total execution time: 0.1664
DEBUG - 2021-01-28 14:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:58:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:58:04 --> Total execution time: 0.1336
DEBUG - 2021-01-28 14:58:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:58:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:58:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 14:58:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-28 14:58:06 --> Total execution time: 0.1684
DEBUG - 2021-01-28 14:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:58:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 14:58:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-28 14:58:07 --> Total execution time: 0.2044
DEBUG - 2021-01-28 14:58:09 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:58:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:58:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 14:58:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:58:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:58:20 --> Total execution time: 0.3691
DEBUG - 2021-01-28 14:58:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:58:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:58:23 --> Total execution time: 0.1763
DEBUG - 2021-01-28 14:58:23 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:58:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 14:58:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-28 14:58:23 --> Total execution time: 0.1606
DEBUG - 2021-01-28 14:58:25 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:58:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 14:58:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-28 14:58:25 --> Total execution time: 0.1479
DEBUG - 2021-01-28 14:58:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:58:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:58:26 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
ERROR - 2021-01-28 14:58:26 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2021-01-28 14:58:26 --> Total execution time: 0.1096
DEBUG - 2021-01-28 14:58:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:58:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:58:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 14:58:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:58:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:58:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-28 14:58:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:58:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:58:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-28 14:58:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:58:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:58:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-28 14:58:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:58:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:58:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-28 14:58:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:58:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:58:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-28 14:58:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:58:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:58:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-28 14:58:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:58:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:58:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-28 14:58:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:58:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:58:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-28 14:59:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:59:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:59:15 --> Total execution time: 0.1482
DEBUG - 2021-01-28 14:59:18 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:59:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 14:59:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-01-28 14:59:19 --> Total execution time: 0.1606
DEBUG - 2021-01-28 14:59:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:59:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:59:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 14:59:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:59:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:59:26 --> Total execution time: 0.1389
DEBUG - 2021-01-28 14:59:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:59:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:59:28 --> Total execution time: 0.1205
DEBUG - 2021-01-28 14:59:29 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:59:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:59:29 --> Total execution time: 0.1247
DEBUG - 2021-01-28 14:59:29 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:59:29 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:59:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:59:29 --> Total execution time: 0.1328
DEBUG - 2021-01-28 14:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:59:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 14:59:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-28 14:59:29 --> Total execution time: 0.1847
DEBUG - 2021-01-28 14:59:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:59:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 14:59:30 --> Total execution time: 0.1563
DEBUG - 2021-01-28 14:59:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:59:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 14:59:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-28 14:59:31 --> Total execution time: 0.1166
DEBUG - 2021-01-28 14:59:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:59:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 14:59:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-28 14:59:32 --> Total execution time: 0.1579
DEBUG - 2021-01-28 14:59:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:59:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 14:59:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-28 14:59:32 --> Total execution time: 0.1512
DEBUG - 2021-01-28 14:59:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 14:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 14:59:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 14:59:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-28 14:59:32 --> Total execution time: 0.1387
DEBUG - 2021-01-28 14:59:35 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 14:59:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 14:59:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:00:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:00:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:00:42 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"3"}
ERROR - 2021-01-28 15:00:42 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2021-01-28 15:00:42 --> Total execution time: 0.0982
DEBUG - 2021-01-28 15:01:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:01:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:01:12 --> Total execution time: 0.1115
DEBUG - 2021-01-28 15:02:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:02:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:02:33 --> Total execution time: 0.1208
DEBUG - 2021-01-28 15:02:44 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:02:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:02:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:02:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:02:47 --> Total execution time: 0.1288
DEBUG - 2021-01-28 15:02:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:02:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:02:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:02:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:02:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:02:59 --> Total execution time: 0.1438
DEBUG - 2021-01-28 15:02:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:02:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:02:59 --> Total execution time: 0.1358
DEBUG - 2021-01-28 15:03:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:03:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:03:01 --> Total execution time: 0.1473
DEBUG - 2021-01-28 15:03:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:03:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:03:02 --> Total execution time: 0.1273
DEBUG - 2021-01-28 15:03:05 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:03:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:03:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:03:10 --> Total execution time: 0.1859
DEBUG - 2021-01-28 15:03:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:03:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-28 15:03:13 --> Total execution time: 0.1529
DEBUG - 2021-01-28 15:03:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:03:13 --> Total execution time: 0.1418
DEBUG - 2021-01-28 15:03:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:03:15 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:03:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:03:22 --> Total execution time: 0.1362
DEBUG - 2021-01-28 15:03:25 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:03:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-28 15:03:25 --> Total execution time: 0.1621
DEBUG - 2021-01-28 15:03:25 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:03:25 --> Total execution time: 0.1361
DEBUG - 2021-01-28 15:03:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:03:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:03:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:03:32 --> Total execution time: 0.1356
DEBUG - 2021-01-28 15:03:34 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:03:34 --> Total execution time: 0.1563
DEBUG - 2021-01-28 15:03:35 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:03:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-01-28 15:03:35 --> Total execution time: 0.1540
DEBUG - 2021-01-28 15:03:36 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:03:36 --> Total execution time: 0.1822
DEBUG - 2021-01-28 15:03:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:03:37 --> Total execution time: 0.1650
DEBUG - 2021-01-28 15:03:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:03:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-01-28 15:03:37 --> Total execution time: 0.1444
DEBUG - 2021-01-28 15:03:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:03:37 --> Total execution time: 0.1239
DEBUG - 2021-01-28 15:03:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:03:38 --> Total execution time: 0.1158
DEBUG - 2021-01-28 15:03:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:03:39 --> Total execution time: 0.1596
DEBUG - 2021-01-28 15:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:03:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-01-28 15:03:39 --> Total execution time: 0.1483
DEBUG - 2021-01-28 15:03:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:03:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-01-28 15:03:39 --> Total execution time: 0.2161
DEBUG - 2021-01-28 15:03:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:03:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-01-28 15:03:40 --> Total execution time: 0.1380
DEBUG - 2021-01-28 15:03:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:03:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-01-28 15:03:40 --> Total execution time: 0.1736
DEBUG - 2021-01-28 15:03:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:03:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-01-28 15:03:42 --> Total execution time: 0.1356
DEBUG - 2021-01-28 15:03:45 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:03:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:03:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:03:48 --> Total execution time: 0.1325
DEBUG - 2021-01-28 15:03:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:03:49 --> Total execution time: 0.1424
DEBUG - 2021-01-28 15:03:50 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:03:50 --> Total execution time: 0.1328
DEBUG - 2021-01-28 15:03:50 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:03:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-01-28 15:03:50 --> Total execution time: 0.1241
DEBUG - 2021-01-28 15:03:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:03:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-28 15:03:52 --> Total execution time: 0.1493
DEBUG - 2021-01-28 15:03:53 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:03:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-28 15:03:53 --> Total execution time: 0.1403
DEBUG - 2021-01-28 15:03:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:03:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:03:55 --> Total execution time: 0.1354
DEBUG - 2021-01-28 15:03:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:03:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:03:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:04:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:04:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:04:16 --> Total execution time: 0.1476
DEBUG - 2021-01-28 15:04:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:04:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:04:42 --> Total execution time: 0.1257
DEBUG - 2021-01-28 15:04:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:04:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:04:47 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
ERROR - 2021-01-28 15:04:47 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2021-01-28 15:04:47 --> Total execution time: 0.1116
DEBUG - 2021-01-28 15:04:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:04:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:04:58 --> Total execution time: 0.1308
DEBUG - 2021-01-28 15:04:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:04:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:04:59 --> Total execution time: 0.1273
DEBUG - 2021-01-28 15:05:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:05:01 --> Total execution time: 0.2554
DEBUG - 2021-01-28 15:05:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:05:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:05:01 --> Total execution time: 0.1689
DEBUG - 2021-01-28 15:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:05:01 --> Total execution time: 0.1707
DEBUG - 2021-01-28 15:05:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:05:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:05:02 --> Total execution time: 0.1909
DEBUG - 2021-01-28 15:05:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:05:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:05:04 --> Total execution time: 0.1945
DEBUG - 2021-01-28 15:05:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:05:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:05:04 --> Total execution time: 0.1645
DEBUG - 2021-01-28 15:05:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:05:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:06 --> Total execution time: 0.1363
DEBUG - 2021-01-28 15:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:05:06 --> Total execution time: 0.1238
DEBUG - 2021-01-28 15:05:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:05:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:05:19 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:05:20 --> Total execution time: 0.1527
DEBUG - 2021-01-28 15:05:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:05:21 --> Total execution time: 0.1246
DEBUG - 2021-01-28 15:05:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:05:21 --> Total execution time: 0.1728
DEBUG - 2021-01-28 15:05:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:05:22 --> Total execution time: 0.1483
DEBUG - 2021-01-28 15:05:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:05:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-28 15:05:22 --> Total execution time: 0.1704
DEBUG - 2021-01-28 15:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:05:23 --> Total execution time: 0.1483
DEBUG - 2021-01-28 15:05:24 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:24 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:05:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-28 15:05:24 --> Total execution time: 0.1472
DEBUG - 2021-01-28 15:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:05:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-28 15:05:24 --> Total execution time: 0.1404
DEBUG - 2021-01-28 15:05:24 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:05:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-28 15:05:25 --> Total execution time: 0.1737
DEBUG - 2021-01-28 15:05:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:05:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-28 15:05:26 --> Total execution time: 0.1346
DEBUG - 2021-01-28 15:05:29 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:05:29 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:05:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:05:39 --> Total execution time: 0.1543
DEBUG - 2021-01-28 15:05:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:05:39 --> Total execution time: 0.1424
DEBUG - 2021-01-28 15:05:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:05:40 --> Total execution time: 0.1416
DEBUG - 2021-01-28 15:05:41 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:05:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-01-28 15:05:42 --> Total execution time: 0.1547
DEBUG - 2021-01-28 15:05:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:05:43 --> Total execution time: 0.1549
DEBUG - 2021-01-28 15:05:43 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:05:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-28 15:05:43 --> Total execution time: 0.1885
DEBUG - 2021-01-28 15:05:45 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:05:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-28 15:05:45 --> Total execution time: 0.1403
DEBUG - 2021-01-28 15:05:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:05:48 --> Total execution time: 0.1270
DEBUG - 2021-01-28 15:05:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:05:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:05:53 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:05:53 --> Total execution time: 0.1443
DEBUG - 2021-01-28 15:05:53 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:05:53 --> Total execution time: 0.1254
DEBUG - 2021-01-28 15:05:54 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:05:54 --> Total execution time: 0.1394
DEBUG - 2021-01-28 15:05:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:05:55 --> Total execution time: 0.1416
DEBUG - 2021-01-28 15:05:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:05:55 --> Total execution time: 0.1695
DEBUG - 2021-01-28 15:05:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:05:56 --> Total execution time: 0.1400
DEBUG - 2021-01-28 15:05:56 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:05:56 --> Total execution time: 0.1537
DEBUG - 2021-01-28 15:05:56 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:05:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-28 15:05:56 --> Total execution time: 0.1301
DEBUG - 2021-01-28 15:05:56 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:56 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:05:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-28 15:05:56 --> Total execution time: 0.1407
DEBUG - 2021-01-28 15:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:05:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-28 15:05:57 --> Total execution time: 0.1493
DEBUG - 2021-01-28 15:05:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:05:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-28 15:05:58 --> Total execution time: 0.1507
DEBUG - 2021-01-28 15:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:05:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-28 15:05:58 --> Total execution time: 0.1928
DEBUG - 2021-01-28 15:05:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:05:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-28 15:05:58 --> Total execution time: 0.1747
DEBUG - 2021-01-28 15:05:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:05:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:05:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-01-28 15:05:59 --> Total execution time: 0.1697
DEBUG - 2021-01-28 15:06:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:06:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:06:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:06:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:06:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:06:01 --> Total execution time: 0.1611
DEBUG - 2021-01-28 15:06:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:06:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:06:02 --> Total execution time: 0.1277
DEBUG - 2021-01-28 15:06:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:06:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:06:02 --> Total execution time: 0.1115
DEBUG - 2021-01-28 15:07:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:07:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:07:48 --> Total execution time: 0.1420
DEBUG - 2021-01-28 15:08:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:08:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:08:49 --> Total execution time: 0.1464
DEBUG - 2021-01-28 15:08:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:08:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:08:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:08:49 --> Total execution time: 0.1291
DEBUG - 2021-01-28 15:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:08:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:08:49 --> Total execution time: 0.1272
DEBUG - 2021-01-28 15:08:50 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:08:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:08:50 --> Total execution time: 0.1394
DEBUG - 2021-01-28 15:08:50 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:08:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:08:50 --> Total execution time: 0.1386
DEBUG - 2021-01-28 15:08:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:08:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:08:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:08:51 --> Total execution time: 0.1686
DEBUG - 2021-01-28 15:08:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:08:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:08:51 --> Total execution time: 0.1379
DEBUG - 2021-01-28 15:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:08:51 --> Total execution time: 0.1591
DEBUG - 2021-01-28 15:08:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:08:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:08:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:08:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:08:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:08:52 --> Total execution time: 0.1983
DEBUG - 2021-01-28 15:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:08:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:08:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:08:52 --> Total execution time: 0.2143
DEBUG - 2021-01-28 15:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:08:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:08:52 --> Total execution time: 0.2071
DEBUG - 2021-01-28 15:08:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:08:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:08:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:08:52 --> Total execution time: 0.1645
DEBUG - 2021-01-28 15:08:53 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:08:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:08:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:08:53 --> Total execution time: 0.1587
DEBUG - 2021-01-28 15:08:54 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:08:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:08:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:08:54 --> Total execution time: 0.1285
DEBUG - 2021-01-28 15:08:54 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:08:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:08:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:08:54 --> Total execution time: 0.1359
DEBUG - 2021-01-28 15:08:54 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:08:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:08:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:08:54 --> Total execution time: 0.1339
DEBUG - 2021-01-28 15:08:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:08:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:08:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:11:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:11:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:11:11 --> Total execution time: 0.1136
DEBUG - 2021-01-28 15:18:41 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:18:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:18:41 --> Total execution time: 0.1429
DEBUG - 2021-01-28 15:18:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:18:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:18:43 --> Total execution time: 0.1108
DEBUG - 2021-01-28 15:18:43 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:18:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:18:43 --> Total execution time: 0.1048
DEBUG - 2021-01-28 15:18:44 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:18:44 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:18:44 --> Total execution time: 0.1634
DEBUG - 2021-01-28 15:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:18:44 --> Total execution time: 0.1617
DEBUG - 2021-01-28 15:18:44 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:18:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:18:45 --> Total execution time: 0.1258
DEBUG - 2021-01-28 15:18:45 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:18:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:18:45 --> Total execution time: 0.1677
DEBUG - 2021-01-28 15:18:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:18:47 --> Total execution time: 0.1326
DEBUG - 2021-01-28 15:18:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:18:47 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:18:47 --> Total execution time: 0.1686
DEBUG - 2021-01-28 15:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:18:47 --> Total execution time: 0.1986
DEBUG - 2021-01-28 15:18:50 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:18:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:18:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:18:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:18:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:18:59 --> Total execution time: 0.1513
DEBUG - 2021-01-28 15:19:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:19:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:19:03 --> Total execution time: 0.1239
DEBUG - 2021-01-28 15:19:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:19:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:19:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:19:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:19:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:19:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:19:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:19:52 --> Total execution time: 0.1275
DEBUG - 2021-01-28 15:19:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:19:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:19:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:19:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:19:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:19:55 --> 404 Page Not Found: Uploads/badger.jpg
DEBUG - 2021-01-28 15:20:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:20:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:20:12 --> Total execution time: 0.1357
DEBUG - 2021-01-28 15:20:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:20:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:20:15 --> Total execution time: 0.1457
DEBUG - 2021-01-28 15:20:17 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:20:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:20:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:20:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:20:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:20:28 --> Total execution time: 0.1901
DEBUG - 2021-01-28 15:20:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:20:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:20:31 --> Total execution time: 0.1369
DEBUG - 2021-01-28 15:20:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:20:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:20:46 --> Total execution time: 0.1374
DEBUG - 2021-01-28 15:20:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:20:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:20:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:20:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:20:58 --> Total execution time: 0.1692
DEBUG - 2021-01-28 15:20:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:20:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:20:58 --> Total execution time: 0.1576
DEBUG - 2021-01-28 15:20:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:20:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:20:59 --> Total execution time: 0.1726
DEBUG - 2021-01-28 15:20:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:21:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:21:00 --> Total execution time: 0.1177
DEBUG - 2021-01-28 15:21:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:21:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:21:01 --> Total execution time: 0.1511
DEBUG - 2021-01-28 15:21:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:21:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:21:01 --> Total execution time: 0.1190
DEBUG - 2021-01-28 15:21:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:21:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:21:03 --> Total execution time: 0.1377
DEBUG - 2021-01-28 15:21:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:21:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:21:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:23:29 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:23:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:23:29 --> Total execution time: 0.1455
DEBUG - 2021-01-28 15:23:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:23:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:23:30 --> Total execution time: 0.1356
DEBUG - 2021-01-28 15:23:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:23:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:23:32 --> Total execution time: 0.1452
DEBUG - 2021-01-28 15:23:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:23:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:23:33 --> Total execution time: 0.1464
DEBUG - 2021-01-28 15:23:35 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:23:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:23:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:28:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:28:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:28:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:28:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:28:30 --> Total execution time: 0.1543
DEBUG - 2021-01-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:28:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:28:56 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:28:56 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:28:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:28:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:28:56 --> Total execution time: 0.1455
DEBUG - 2021-01-28 15:28:56 --> Total execution time: 0.1322
DEBUG - 2021-01-28 15:29:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:29:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:29:02 --> Total execution time: 0.0955
DEBUG - 2021-01-28 15:29:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:29:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:29:06 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-28 15:29:06 --> Total execution time: 0.1158
DEBUG - 2021-01-28 15:29:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:29:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:29:12 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"770","support_lang_id":"3"}
DEBUG - 2021-01-28 15:29:12 --> Total execution time: 0.1413
DEBUG - 2021-01-28 15:29:17 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:29:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:29:18 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-28 15:29:18 --> Total execution time: 0.1540
DEBUG - 2021-01-28 15:29:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:29:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:29:27 --> Total execution time: 0.1198
DEBUG - 2021-01-28 15:29:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:29:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:29:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:29:30 --> Total execution time: 0.1577
DEBUG - 2021-01-28 15:29:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:29:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:29:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:49:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:49:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:49:31 --> Total execution time: 0.2035
DEBUG - 2021-01-28 15:49:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:49:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:49:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:49:32 --> Total execution time: 0.1593
DEBUG - 2021-01-28 15:49:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:49:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:49:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:49:34 --> Total execution time: 0.1355
DEBUG - 2021-01-28 15:49:35 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:49:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:49:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:49:35 --> Total execution time: 0.1663
DEBUG - 2021-01-28 15:49:38 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:49:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:49:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:50:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:50:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:51:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:51:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:51:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:51:01 --> Total execution time: 0.1513
DEBUG - 2021-01-28 15:51:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:51:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:51:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:51:05 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:51:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:51:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-28 15:52:09 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:52:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:52:09 --> Total execution time: 0.1327
DEBUG - 2021-01-28 15:52:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:52:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:52:12 --> Total execution time: 0.1316
DEBUG - 2021-01-28 15:52:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:52:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:52:15 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:52:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:52:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:52:22 --> Total execution time: 0.1217
DEBUG - 2021-01-28 15:52:36 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:52:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:52:36 --> Total execution time: 0.1443
DEBUG - 2021-01-28 15:52:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:52:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:52:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:52:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:52:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:52:59 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:53:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:53:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:53:03 --> Total execution time: 0.1389
DEBUG - 2021-01-28 15:53:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:53:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:53:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:53:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:53:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:53:15 --> Total execution time: 0.1563
DEBUG - 2021-01-28 15:53:16 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:53:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:53:16 --> Total execution time: 0.1511
DEBUG - 2021-01-28 15:53:17 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:53:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:53:17 --> Total execution time: 0.1518
DEBUG - 2021-01-28 15:53:18 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:53:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:53:18 --> Total execution time: 0.1374
DEBUG - 2021-01-28 15:53:18 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:53:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:53:18 --> Total execution time: 0.1590
DEBUG - 2021-01-28 15:53:19 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:53:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:53:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:53:19 --> Total execution time: 0.1482
DEBUG - 2021-01-28 15:53:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:53:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:53:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:53:20 --> Total execution time: 0.1568
DEBUG - 2021-01-28 15:53:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:53:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:53:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:53:20 --> Total execution time: 0.1383
DEBUG - 2021-01-28 15:53:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:53:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:53:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:53:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:53:20 --> Total execution time: 0.1782
DEBUG - 2021-01-28 15:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:53:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 15:53:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-28 15:53:20 --> Total execution time: 0.1421
DEBUG - 2021-01-28 15:53:23 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:53:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:53:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 15:54:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:54:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:54:52 --> Total execution time: 0.1257
DEBUG - 2021-01-28 15:54:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:54:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:54:58 --> Total execution time: 0.1112
DEBUG - 2021-01-28 15:55:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:55:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:55:03 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-28 15:55:03 --> Total execution time: 0.0974
DEBUG - 2021-01-28 15:55:07 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:55:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:55:07 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"770","support_lang_id":"3"}
DEBUG - 2021-01-28 15:55:07 --> Total execution time: 0.1178
DEBUG - 2021-01-28 15:55:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:55:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:55:11 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-28 15:55:11 --> Total execution time: 0.1274
DEBUG - 2021-01-28 15:55:31 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:55:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:55:31 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"770","support_lang_id":"3"}
DEBUG - 2021-01-28 15:55:31 --> Total execution time: 0.1418
DEBUG - 2021-01-28 15:56:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 15:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 15:56:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 15:56:39 --> Total execution time: 0.1711
DEBUG - 2021-01-28 15:56:42 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 15:56:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 15:56:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 16:08:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:08:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 16:08:55 --> Total execution time: 0.1265
DEBUG - 2021-01-28 16:08:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:08:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 16:08:55 --> Total execution time: 0.1408
DEBUG - 2021-01-28 16:08:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:08:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:08:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 16:08:57 --> Total execution time: 0.1996
DEBUG - 2021-01-28 16:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:08:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 16:08:58 --> Total execution time: 0.2572
DEBUG - 2021-01-28 16:08:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:08:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 16:08:58 --> Total execution time: 0.1417
DEBUG - 2021-01-28 16:08:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:08:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:08:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 16:08:59 --> Total execution time: 0.1461
DEBUG - 2021-01-28 16:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:08:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 16:08:59 --> Total execution time: 0.1286
DEBUG - 2021-01-28 16:09:00 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:09:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 16:09:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-28 16:09:00 --> Total execution time: 0.1250
DEBUG - 2021-01-28 16:09:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:09:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:09:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 16:09:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-28 16:09:02 --> Total execution time: 0.1911
DEBUG - 2021-01-28 16:09:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:09:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 16:09:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-28 16:09:02 --> Total execution time: 0.1900
DEBUG - 2021-01-28 16:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:09:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 16:09:02 --> Total execution time: 0.1185
DEBUG - 2021-01-28 16:09:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:09:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:09:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 16:09:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-28 16:09:03 --> Total execution time: 0.1439
DEBUG - 2021-01-28 16:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:09:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 16:09:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-28 16:09:03 --> Total execution time: 0.1114
DEBUG - 2021-01-28 16:09:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:09:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 16:09:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-28 16:09:04 --> Total execution time: 0.1307
DEBUG - 2021-01-28 16:09:04 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:09:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 16:09:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-28 16:09:04 --> Total execution time: 0.1376
DEBUG - 2021-01-28 16:09:05 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-28 16:09:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2021-01-28 16:09:05 --> Total execution time: 0.1392
DEBUG - 2021-01-28 16:09:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:09:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-28 16:09:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-28 16:35:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:35:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 16:35:12 --> Total execution time: 0.1078
DEBUG - 2021-01-28 16:35:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:35:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 16:35:21 --> Total execution time: 0.1237
DEBUG - 2021-01-28 16:35:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:35:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 16:35:33 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-28 16:35:33 --> Total execution time: 0.1158
DEBUG - 2021-01-28 16:35:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:35:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 16:35:39 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"770","support_lang_id":"3"}
DEBUG - 2021-01-28 16:35:39 --> Total execution time: 0.1177
DEBUG - 2021-01-28 16:35:53 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:35:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 16:35:53 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-28 16:35:53 --> Total execution time: 0.1357
DEBUG - 2021-01-28 16:35:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:35:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 16:35:58 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"770","support_lang_id":"3"}
DEBUG - 2021-01-28 16:35:58 --> Total execution time: 0.1064
DEBUG - 2021-01-28 16:36:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:36:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 16:36:01 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-28 16:36:01 --> Total execution time: 0.1089
DEBUG - 2021-01-28 16:36:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:36:13 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:36:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 16:36:13 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"770","support_lang_id":"3"}
DEBUG - 2021-01-28 16:36:13 --> Total execution time: 0.1393
DEBUG - 2021-01-28 16:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:36:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 16:36:13 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-28 16:36:13 --> Total execution time: 0.1387
DEBUG - 2021-01-28 16:36:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:36:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 16:36:21 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"770","support_lang_id":"3"}
DEBUG - 2021-01-28 16:36:21 --> Total execution time: 0.1649
DEBUG - 2021-01-28 16:36:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:36:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 16:36:21 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
ERROR - 2021-01-28 16:36:21 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2021-01-28 16:36:21 --> Total execution time: 0.1639
DEBUG - 2021-01-28 16:36:45 --> UTF-8 Support Enabled
DEBUG - 2021-01-28 16:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-28 16:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-28 16:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-28 16:36:45 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
ERROR - 2021-01-28 16:36:45 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2021-01-28 16:36:45 --> Total execution time: 0.1234
