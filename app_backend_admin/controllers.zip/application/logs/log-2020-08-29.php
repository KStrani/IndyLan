<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-08-29 07:30:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 07:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 07:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 07:30:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 07:30:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 07:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 07:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 07:30:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 07:30:20 --> Total execution time: 0.1265
DEBUG - 2020-08-29 08:52:00 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 08:52:00 --> No URI present. Default controller set.
DEBUG - 2020-08-29 08:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 08:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 08:52:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 08:52:01 --> Total execution time: 0.1878
DEBUG - 2020-08-29 08:52:03 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 08:52:03 --> No URI present. Default controller set.
DEBUG - 2020-08-29 08:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 08:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 08:52:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 08:52:03 --> Total execution time: 0.1297
DEBUG - 2020-08-29 09:17:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:17:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:17:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:17:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:17:30 --> Total execution time: 0.1898
DEBUG - 2020-08-29 09:17:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:17:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 09:17:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 09:19:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:19:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:19:21 --> Total execution time: 0.2701
DEBUG - 2020-08-29 09:20:00 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:20:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:20:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:20:00 --> Total execution time: 0.1307
DEBUG - 2020-08-29 09:20:02 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:20:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:20:02 --> Total execution time: 0.1376
DEBUG - 2020-08-29 09:20:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 09:20:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 09:20:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:20:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:20:12 --> Total execution time: 0.2015
DEBUG - 2020-08-29 09:26:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:26:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:26:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:26:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:26:16 --> Total execution time: 0.1603
DEBUG - 2020-08-29 09:26:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:26:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:26:18 --> Total execution time: 0.1637
DEBUG - 2020-08-29 09:26:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:26:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 09:26:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 09:31:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:31:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:31:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:31:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:31:46 --> Total execution time: 0.1551
DEBUG - 2020-08-29 09:31:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:31:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 09:31:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 09:31:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:31:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 09:31:49 --> 404 Page Not Found: Uploads/badger.jpg
DEBUG - 2020-08-29 09:32:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:32:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:32:04 --> Total execution time: 0.1521
DEBUG - 2020-08-29 09:32:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:32:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:32:04 --> Total execution time: 0.1855
DEBUG - 2020-08-29 09:32:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:32:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:32:07 --> Total execution time: 0.1303
DEBUG - 2020-08-29 09:32:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:32:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:32:07 --> Total execution time: 0.1366
DEBUG - 2020-08-29 09:32:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:32:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 09:32:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 09:32:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:32:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 09:32:10 --> 404 Page Not Found: Uploads/badger.jpg
DEBUG - 2020-08-29 09:32:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:32:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:32:23 --> Total execution time: 0.1807
DEBUG - 2020-08-29 09:32:26 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:32:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:32:26 --> Total execution time: 0.1776
DEBUG - 2020-08-29 09:32:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:32:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 09:32:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 09:32:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:32:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:32:37 --> Total execution time: 0.1638
DEBUG - 2020-08-29 09:32:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:32:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:32:40 --> Total execution time: 0.1549
DEBUG - 2020-08-29 09:32:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:32:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 09:32:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 09:32:56 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:32:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:32:56 --> Total execution time: 0.1428
DEBUG - 2020-08-29 09:32:59 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:32:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:32:59 --> Total execution time: 0.1338
DEBUG - 2020-08-29 09:33:02 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:33:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 09:33:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 09:33:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:33:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:33:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:33:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:33:32 --> Total execution time: 0.1771
DEBUG - 2020-08-29 09:33:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:33:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 09:33:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 09:33:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:33:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:33:44 --> Total execution time: 0.1548
DEBUG - 2020-08-29 09:33:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:33:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:33:47 --> Total execution time: 0.1566
DEBUG - 2020-08-29 09:33:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:33:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 09:33:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 09:35:26 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:35:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:35:26 --> Total execution time: 0.1720
DEBUG - 2020-08-29 09:35:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:35:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-29 09:35:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-08-29 09:35:29 --> Total execution time: 0.1642
DEBUG - 2020-08-29 09:35:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:35:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 09:35:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 09:35:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:35:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:35:43 --> Total execution time: 0.1558
DEBUG - 2020-08-29 09:35:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:35:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-29 09:35:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-08-29 09:35:46 --> Total execution time: 0.1554
DEBUG - 2020-08-29 09:35:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:35:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 09:35:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 09:35:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:35:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-29 09:35:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-08-29 09:35:57 --> Total execution time: 0.1407
DEBUG - 2020-08-29 09:36:00 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:36:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-29 09:36:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-08-29 09:36:01 --> Total execution time: 0.1731
DEBUG - 2020-08-29 09:36:03 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:36:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 09:36:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 09:36:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:36:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:36:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:36:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-29 09:36:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-08-29 09:36:27 --> Total execution time: 0.2069
DEBUG - 2020-08-29 09:36:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:36:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:36:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 09:36:31 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 09:36:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 09:36:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 09:36:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:36:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:36:43 --> Total execution time: 0.1513
DEBUG - 2020-08-29 09:36:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:36:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-29 09:36:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-08-29 09:36:46 --> Total execution time: 0.1830
DEBUG - 2020-08-29 09:36:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:36:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-29 09:36:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-08-29 09:36:49 --> Total execution time: 0.1885
DEBUG - 2020-08-29 09:36:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:36:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 09:36:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 09:36:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:36:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 09:36:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 09:37:00 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:37:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:37:01 --> Total execution time: 0.1589
DEBUG - 2020-08-29 09:37:02 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:37:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-29 09:37:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-08-29 09:37:03 --> Total execution time: 0.1550
DEBUG - 2020-08-29 09:37:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:37:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 09:37:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 09:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 09:37:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 09:37:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:37:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:37:12 --> Total execution time: 0.2817
DEBUG - 2020-08-29 09:37:19 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:37:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 09:37:19 --> Total execution time: 0.1608
DEBUG - 2020-08-29 09:37:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 09:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 09:37:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-29 09:37:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-08-29 09:37:22 --> Total execution time: 0.1680
DEBUG - 2020-08-29 09:37:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 09:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 09:37:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 10:17:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:17:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 10:17:23 --> Total execution time: 0.1282
DEBUG - 2020-08-29 10:17:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:17:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 10:17:30 --> Total execution time: 0.1337
DEBUG - 2020-08-29 10:17:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:17:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 10:17:36 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"1"}
ERROR - 2020-08-29 10:17:36 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-29 10:17:36 --> Total execution time: 0.1439
DEBUG - 2020-08-29 10:17:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:17:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:17:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 10:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:17:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 10:17:42 --> Total execution time: 0.1506
DEBUG - 2020-08-29 10:17:42 --> Total execution time: 0.0948
DEBUG - 2020-08-29 10:33:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:33:35 --> No URI present. Default controller set.
DEBUG - 2020-08-29 10:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:33:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 10:33:35 --> Total execution time: 0.1820
DEBUG - 2020-08-29 10:33:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:33:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 10:33:56 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:33:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 10:33:56 --> Total execution time: 0.1604
DEBUG - 2020-08-29 10:33:59 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:33:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 10:33:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 10:34:14 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:34:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 10:34:14 --> Total execution time: 0.1864
DEBUG - 2020-08-29 10:34:26 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:34:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 10:34:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:34:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 10:34:30 --> Total execution time: 0.1738
DEBUG - 2020-08-29 10:34:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:34:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 10:34:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 10:34:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:34:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 10:34:52 --> Total execution time: 0.1179
DEBUG - 2020-08-29 10:34:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:34:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 10:34:54 --> Total execution time: 0.1159
DEBUG - 2020-08-29 10:34:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:34:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 10:34:55 --> Total execution time: 0.1703
DEBUG - 2020-08-29 10:34:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:34:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 10:34:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 10:35:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:35:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 10:35:07 --> Total execution time: 0.1570
DEBUG - 2020-08-29 10:35:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:35:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 10:35:10 --> Total execution time: 0.1470
DEBUG - 2020-08-29 10:35:13 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:35:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 10:35:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 10:35:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:35:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 10:35:28 --> Total execution time: 0.1286
DEBUG - 2020-08-29 10:35:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:35:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:35:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 10:35:30 --> Total execution time: 0.1309
DEBUG - 2020-08-29 10:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:35:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 10:35:30 --> Total execution time: 0.1350
DEBUG - 2020-08-29 10:35:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:35:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-29 10:35:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-08-29 10:35:33 --> Total execution time: 0.1678
DEBUG - 2020-08-29 10:35:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:35:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 10:35:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 10:36:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:36:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 10:36:35 --> Total execution time: 0.1240
DEBUG - 2020-08-29 10:36:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:36:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 10:36:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 10:39:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:39:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-29 10:39:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-08-29 10:39:15 --> Total execution time: 0.1292
DEBUG - 2020-08-29 10:39:17 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:39:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 10:39:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 10:39:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:39:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 10:48:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:48:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-29 10:48:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-08-29 10:48:37 --> Total execution time: 0.2058
DEBUG - 2020-08-29 10:48:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 10:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 10:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 10:48:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:00:14 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:00:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:00:14 --> Total execution time: 0.1287
DEBUG - 2020-08-29 11:01:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:01:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:01:05 --> Total execution time: 0.1391
DEBUG - 2020-08-29 11:01:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:01:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:01:06 --> Total execution time: 0.1483
DEBUG - 2020-08-29 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:01:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:01:11 --> Total execution time: 0.1406
DEBUG - 2020-08-29 11:01:14 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:01:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:01:14 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-08-29 11:01:14 --> Total execution time: 0.1668
DEBUG - 2020-08-29 11:01:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:01:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:01:18 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-29 11:01:18 --> Total execution time: 0.1260
DEBUG - 2020-08-29 11:01:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:01:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:01:23 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-29 11:01:23 --> Total execution time: 0.1419
DEBUG - 2020-08-29 11:01:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:01:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:01:27 --> get_dialogue_type_1->{"slang":"38","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
ERROR - 2020-08-29 11:01:27 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-08-29 11:01:27 --> Total execution time: 0.1318
DEBUG - 2020-08-29 11:01:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:01:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:01:32 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-29 11:01:32 --> Total execution time: 0.1417
DEBUG - 2020-08-29 11:01:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:01:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:01:38 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-29 11:01:38 --> Total execution time: 0.1307
DEBUG - 2020-08-29 11:01:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:01:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:01:41 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-08-29 11:01:41 --> Total execution time: 0.1041
DEBUG - 2020-08-29 11:01:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:01:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:01:46 --> Total execution time: 0.0999
DEBUG - 2020-08-29 11:01:56 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:01:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:01:56 --> Total execution time: 0.1441
DEBUG - 2020-08-29 11:02:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:02:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:02:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:02:13 --> Total execution time: 0.1441
DEBUG - 2020-08-29 11:02:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:02:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-29 11:02:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-08-29 11:02:15 --> Total execution time: 0.1336
DEBUG - 2020-08-29 11:02:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:02:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:02:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 11:02:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:02:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:02:44 --> Total execution time: 0.1635
DEBUG - 2020-08-29 11:02:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:02:47 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 11:03:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:03:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-29 11:03:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-08-29 11:03:06 --> Total execution time: 0.1560
DEBUG - 2020-08-29 11:03:13 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:03:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:03:13 --> Total execution time: 0.1428
DEBUG - 2020-08-29 11:03:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:03:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:03:15 --> Total execution time: 0.1575
DEBUG - 2020-08-29 11:03:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:03:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-29 11:03:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-08-29 11:03:16 --> Total execution time: 0.1580
DEBUG - 2020-08-29 11:03:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:03:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-29 11:03:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-08-29 11:03:18 --> Total execution time: 0.2293
DEBUG - 2020-08-29 11:03:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:03:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:03:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 11:04:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:04:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:04:19 --> Total execution time: 0.1560
DEBUG - 2020-08-29 11:04:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:04:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-29 11:04:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-08-29 11:04:21 --> Total execution time: 0.1809
DEBUG - 2020-08-29 11:04:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:04:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:04:24 --> Total execution time: 0.1192
DEBUG - 2020-08-29 11:04:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:04:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:04:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 11:04:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:04:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:04:43 --> Total execution time: 0.1567
DEBUG - 2020-08-29 11:04:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:04:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:04:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 11:05:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:05:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:05:01 --> Total execution time: 0.1663
DEBUG - 2020-08-29 11:05:03 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:05:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:05:03 --> Total execution time: 0.1468
DEBUG - 2020-08-29 11:05:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:05:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:05:07 --> Total execution time: 0.1436
DEBUG - 2020-08-29 11:05:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:05:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:05:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:05:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-29 11:05:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-08-29 11:05:21 --> Total execution time: 0.1408
DEBUG - 2020-08-29 11:05:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:05:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:05:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 11:05:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:05:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:05:44 --> Total execution time: 0.1525
DEBUG - 2020-08-29 11:05:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:05:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:05:47 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 11:06:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:06:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:06:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:06:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-29 11:06:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-08-29 11:06:20 --> Total execution time: 0.1730
DEBUG - 2020-08-29 11:06:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:06:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:06:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 11:06:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:06:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:06:34 --> Total execution time: 0.1745
DEBUG - 2020-08-29 11:06:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:06:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:06:40 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-08-29 11:06:40 --> Total execution time: 0.1440
DEBUG - 2020-08-29 11:06:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:06:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:06:44 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-29 11:06:44 --> Total execution time: 0.1267
DEBUG - 2020-08-29 11:06:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:06:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:06:49 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-29 11:06:49 --> Total execution time: 0.1702
DEBUG - 2020-08-29 11:06:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:06:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:06:53 --> get_dialogue_type_1->{"slang":"38","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-29 11:06:53 --> Total execution time: 0.1226
DEBUG - 2020-08-29 11:07:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:07:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:07:28 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-29 11:07:28 --> Total execution time: 0.1348
DEBUG - 2020-08-29 11:07:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:07:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:07:33 --> get_dialogue_type_1->{"slang":"38","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-29 11:07:33 --> Total execution time: 0.1271
DEBUG - 2020-08-29 11:07:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:07:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:07:47 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-29 11:07:47 --> Total execution time: 0.1363
DEBUG - 2020-08-29 11:07:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:07:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:07:48 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-29 11:07:48 --> Total execution time: 0.1263
DEBUG - 2020-08-29 11:07:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:07:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:07:51 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-08-29 11:07:51 --> Total execution time: 0.1590
DEBUG - 2020-08-29 11:07:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:07:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:07:52 --> Total execution time: 0.1194
DEBUG - 2020-08-29 11:07:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:07:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:07:53 --> Total execution time: 0.1320
DEBUG - 2020-08-29 11:08:03 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:08:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:08:03 --> Total execution time: 0.1456
DEBUG - 2020-08-29 11:08:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:08:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:08:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 11:08:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:08:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:08:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:08:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-29 11:08:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-08-29 11:08:34 --> Total execution time: 0.1409
DEBUG - 2020-08-29 11:08:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:08:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:08:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 11:12:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:12:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:12:18 --> Total execution time: 0.1628
DEBUG - 2020-08-29 11:12:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:12:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-29 11:12:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-08-29 11:12:21 --> Total execution time: 0.1347
DEBUG - 2020-08-29 11:12:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:12:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:12:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-29 11:13:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:13:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:13:11 --> Total execution time: 0.1424
DEBUG - 2020-08-29 11:13:14 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:13:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:13:14 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-08-29 11:13:14 --> Total execution time: 0.1411
DEBUG - 2020-08-29 11:13:17 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:13:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:13:18 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-29 11:13:18 --> Total execution time: 0.1439
DEBUG - 2020-08-29 11:13:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:13:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:13:18 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-29 11:13:18 --> Total execution time: 0.1576
DEBUG - 2020-08-29 11:13:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:13:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:13:20 --> get_dialogue_type_1->{"slang":"38","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-29 11:13:20 --> Total execution time: 0.1452
DEBUG - 2020-08-29 11:13:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:13:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:13:33 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-29 11:13:33 --> Total execution time: 0.1489
DEBUG - 2020-08-29 11:13:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:13:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:13:35 --> get_dialogue_type_1->{"slang":"38","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-29 11:13:35 --> Total execution time: 0.1469
DEBUG - 2020-08-29 11:13:50 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:13:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:13:50 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-29 11:13:50 --> Total execution time: 0.1239
DEBUG - 2020-08-29 11:14:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:14:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:14:05 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-29 11:14:05 --> Total execution time: 0.1446
DEBUG - 2020-08-29 11:14:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:14:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:14:08 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-08-29 11:14:08 --> Total execution time: 0.1475
DEBUG - 2020-08-29 11:14:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:14:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:14:33 --> Total execution time: 0.1190
DEBUG - 2020-08-29 11:14:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:14:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:14:36 --> Total execution time: 0.1251
DEBUG - 2020-08-29 11:14:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:14:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:14:41 --> Total execution time: 0.1294
DEBUG - 2020-08-29 11:14:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:14:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:14:44 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-29 11:14:44 --> Total execution time: 0.1693
DEBUG - 2020-08-29 11:14:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:14:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:14:44 --> get_subcategory_list->{"lang":"37","category_id":"126","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-29 11:14:44 --> Total execution time: 0.1504
DEBUG - 2020-08-29 11:14:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:14:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:14:48 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-29 11:14:48 --> Total execution time: 0.1707
DEBUG - 2020-08-29 11:14:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:14:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-29 11:14:54 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-08-29 11:14:54 --> Total execution time: 0.1543
DEBUG - 2020-08-29 11:15:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:15:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:15:04 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-29 11:15:04 --> Total execution time: 0.1486
DEBUG - 2020-08-29 11:15:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:15:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:15:08 --> get_subcategory_list->{"lang":"37","category_id":"126","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-29 11:15:08 --> Total execution time: 0.1157
DEBUG - 2020-08-29 11:15:13 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:15:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:15:13 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-29 11:15:13 --> Total execution time: 0.1666
DEBUG - 2020-08-29 11:15:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:15:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:15:16 --> get_subcategory_list->{"lang":"37","category_id":"50","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-29 11:15:16 --> Total execution time: 0.1526
DEBUG - 2020-08-29 11:15:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:15:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:15:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:15:21 --> get_exercise_type_list->{"lang":"37","subcategory_id":"178","support_lang_id":"2"}
DEBUG - 2020-08-29 11:15:21 --> Total execution time: 0.1414
DEBUG - 2020-08-29 11:15:26 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:15:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:15:26 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"2","exercise_mode_id":"1","category_id":"50","subcategory_id":"178","support_lang_id":"2"}
DEBUG - 2020-08-29 11:15:26 --> Total execution time: 0.1788
DEBUG - 2020-08-29 11:15:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:15:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 11:15:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:15:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 11:15:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:15:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 11:15:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:15:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 11:15:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:15:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 11:15:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:15:32 --> UTF-8 Support Enabled
ERROR - 2020-08-29 11:15:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 11:15:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:15:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 11:15:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:15:32 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 11:15:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:15:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 11:15:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:15:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 11:15:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:15:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 11:15:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:15:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 11:15:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:15:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 11:15:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:15:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 11:15:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:15:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 11:15:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:15:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 11:15:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:15:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 11:15:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:15:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 11:15:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:15:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 11:15:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:15:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 11:15:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:15:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 11:15:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:15:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-29 11:15:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:15:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:15:44 --> Total execution time: 0.1594
DEBUG - 2020-08-29 11:15:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:15:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:15:45 --> get_exercise_type_list->{"lang":"37","subcategory_id":"178","support_lang_id":"2"}
DEBUG - 2020-08-29 11:15:45 --> Total execution time: 0.1444
DEBUG - 2020-08-29 11:15:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:15:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:15:47 --> get_subcategory_list->{"lang":"37","category_id":"50","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-29 11:15:47 --> Total execution time: 0.1472
DEBUG - 2020-08-29 11:15:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:15:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:15:48 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-29 11:15:48 --> Total execution time: 0.1674
DEBUG - 2020-08-29 11:15:50 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:15:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:15:50 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-29 11:15:50 --> Total execution time: 0.1824
DEBUG - 2020-08-29 11:15:56 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:15:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:15:57 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-29 11:15:57 --> Total execution time: 0.1815
DEBUG - 2020-08-29 11:16:00 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:16:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:16:00 --> Total execution time: 0.1314
DEBUG - 2020-08-29 11:16:02 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:16:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:16:02 --> Total execution time: 0.0987
DEBUG - 2020-08-29 11:16:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:16:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:16:07 --> Total execution time: 0.1489
DEBUG - 2020-08-29 11:16:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:16:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:16:11 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-29 11:16:11 --> Total execution time: 0.1658
DEBUG - 2020-08-29 11:16:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:16:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:16:16 --> get_subcategory_list->{"lang":"37","category_id":"50","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-29 11:16:16 --> Total execution time: 0.1500
DEBUG - 2020-08-29 11:16:17 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:16:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:16:18 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-29 11:16:18 --> Total execution time: 0.1702
DEBUG - 2020-08-29 11:16:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:16:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:16:21 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-29 11:16:21 --> Total execution time: 0.1146
DEBUG - 2020-08-29 11:16:26 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:16:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:16:26 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-29 11:16:26 --> Total execution time: 0.0991
DEBUG - 2020-08-29 11:16:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:16:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:16:30 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"2","exercise_mode_id":"1","category_id":"123","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-29 11:16:30 --> Total execution time: 0.1487
DEBUG - 2020-08-29 11:16:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:16:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:16:42 --> Total execution time: 0.1756
DEBUG - 2020-08-29 11:16:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:16:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:16:43 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-29 11:16:43 --> Total execution time: 0.1765
DEBUG - 2020-08-29 11:16:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:16:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:16:44 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-29 11:16:44 --> Total execution time: 0.1354
DEBUG - 2020-08-29 11:16:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:16:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:16:45 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-29 11:16:45 --> Total execution time: 0.1646
DEBUG - 2020-08-29 11:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:16:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:16:57 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"2"}
DEBUG - 2020-08-29 11:16:57 --> Total execution time: 0.1134
DEBUG - 2020-08-29 11:17:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:17:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:17:06 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"2"}
DEBUG - 2020-08-29 11:17:06 --> Total execution time: 0.1627
DEBUG - 2020-08-29 11:17:19 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:17:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:17:19 --> get_subcategory_list->{"lang":"37","category_id":"127","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-29 11:17:19 --> Total execution time: 0.1481
DEBUG - 2020-08-29 11:45:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:45:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:45:01 --> Total execution time: 0.1192
DEBUG - 2020-08-29 11:47:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:47:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:47:30 --> Total execution time: 0.1164
DEBUG - 2020-08-29 11:47:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:47:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:47:38 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-29 11:47:38 --> Total execution time: 0.1349
DEBUG - 2020-08-29 11:47:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:47:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:47:55 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-08-29 11:47:55 --> Total execution time: 0.1455
DEBUG - 2020-08-29 11:47:59 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:47:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:47:59 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-29 11:47:59 --> Total execution time: 0.1467
DEBUG - 2020-08-29 11:48:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:48:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:48:05 --> Total execution time: 0.1185
DEBUG - 2020-08-29 11:48:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:48:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:48:26 --> get_category_list->{"lang":"38","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-29 11:48:26 --> Total execution time: 0.1375
DEBUG - 2020-08-29 11:48:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:48:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:48:31 --> get_subcategory_list->{"lang":"38","category_id":"50","user_id":"746","support_lang_id":"2"}
DEBUG - 2020-08-29 11:48:31 --> Total execution time: 0.1679
DEBUG - 2020-08-29 11:48:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:48:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:48:34 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-08-29 11:48:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:48:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:48:37 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-08-29 11:48:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:48:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:48:43 --> get_category_list->{"lang":"38","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-29 11:48:43 --> Total execution time: 0.1158
DEBUG - 2020-08-29 11:48:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:48:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:48:47 --> get_subcategory_list->{"lang":"38","category_id":"123","user_id":"746","support_lang_id":"2"}
DEBUG - 2020-08-29 11:48:47 --> Total execution time: 0.1468
DEBUG - 2020-08-29 11:48:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:48:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:48:55 --> get_category_list->{"lang":"38","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-29 11:48:55 --> Total execution time: 0.1341
DEBUG - 2020-08-29 11:49:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:49:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:49:09 --> Total execution time: 0.1378
DEBUG - 2020-08-29 11:49:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:49:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:49:15 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-29 11:49:15 --> Total execution time: 0.1542
DEBUG - 2020-08-29 11:49:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:49:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:49:19 --> get_subcategory_list->{"lang":"37","category_id":"50","user_id":"746","support_lang_id":"2"}
DEBUG - 2020-08-29 11:49:19 --> Total execution time: 0.1434
DEBUG - 2020-08-29 11:49:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:49:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:49:22 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-08-29 11:49:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:49:25 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-08-29 11:49:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:49:29 --> get_exercise_type_list->{"lang":"37","subcategory_id":"178","support_lang_id":"2"}
DEBUG - 2020-08-29 11:49:29 --> Total execution time: 0.1274
DEBUG - 2020-08-29 11:49:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:49:34 --> get_subcategory_list->{"lang":"37","category_id":"50","user_id":"746","support_lang_id":"2"}
DEBUG - 2020-08-29 11:49:34 --> Total execution time: 0.1639
DEBUG - 2020-08-29 11:49:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:49:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:49:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:49:38 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-08-29 11:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:49:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:49:38 --> get_exercise_type_list->{"lang":"37","subcategory_id":"59","support_lang_id":"2"}
DEBUG - 2020-08-29 11:49:38 --> Total execution time: 0.1066
DEBUG - 2020-08-29 11:49:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:49:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-29 11:49:40 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-08-29 11:49:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:49:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:49:42 --> get_subcategory_list->{"lang":"37","category_id":"50","user_id":"746","support_lang_id":"2"}
DEBUG - 2020-08-29 11:49:42 --> Total execution time: 0.1711
DEBUG - 2020-08-29 11:49:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:49:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:49:44 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-29 11:49:44 --> Total execution time: 0.1434
DEBUG - 2020-08-29 11:49:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:49:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:49:44 --> Total execution time: 0.1146
DEBUG - 2020-08-29 11:49:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:49:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:49:48 --> Total execution time: 0.1463
DEBUG - 2020-08-29 11:56:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:56:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:56:53 --> get_subcategory_list->{"lang":"37","category_id":"127","user_id":"745","support_lang_id":"null"}
ERROR - 2020-08-29 11:56:53 --> Query error: Unknown column 'subcategory_name_in_' in 'field list' - Invalid query: select exercise_mode_subcategory_id,category_id,difficulty_level_id,image,subcategory_name_in_ as subcategory_name from tbl_exercise_mode_subcategories where category_id='127' AND is_active='1' AND is_delete='0' order by subcategory_name_in_ asc
ERROR - 2020-08-29 11:56:53 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 183
DEBUG - 2020-08-29 11:56:59 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:57:00 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:57:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:57:00 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"null"}
ERROR - 2020-08-29 11:57:00 --> Query error: Unknown column 'category_name_in_' in 'field list' - Invalid query: select exercise_mode_category_id,image,category_name_in_ as category_name from tbl_exercise_mode_categories where support_lang_id='null' AND exercise_mode_id='3' AND is_active='1' AND is_delete='0' order by category_name_in_ asc
ERROR - 2020-08-29 11:57:00 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 126
DEBUG - 2020-08-29 11:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:57:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:57:00 --> Total execution time: 0.1231
DEBUG - 2020-08-29 11:57:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:57:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:57:07 --> Total execution time: 0.1376
DEBUG - 2020-08-29 11:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:57:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:57:24 --> Total execution time: 0.0900
DEBUG - 2020-08-29 11:57:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:57:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:57:30 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-08-29 11:57:30 --> Total execution time: 0.1141
DEBUG - 2020-08-29 11:57:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:57:35 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-29 11:57:35 --> Total execution time: 0.1510
DEBUG - 2020-08-29 11:57:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:57:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:57:40 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-08-29 11:57:40 --> Total execution time: 0.1373
DEBUG - 2020-08-29 11:57:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:57:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:57:45 --> get_category_list->{"lang":"38","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-29 11:57:45 --> Total execution time: 0.1335
DEBUG - 2020-08-29 11:57:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:57:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:57:52 --> get_subcategory_list->{"lang":"38","category_id":"50","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-29 11:57:52 --> Total execution time: 0.1372
DEBUG - 2020-08-29 11:57:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:57:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:57:57 --> get_category_list->{"lang":"38","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-29 11:57:57 --> Total execution time: 0.1407
DEBUG - 2020-08-29 11:58:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:58:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:58:02 --> get_subcategory_list->{"lang":"38","category_id":"123","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-29 11:58:02 --> Total execution time: 0.1181
DEBUG - 2020-08-29 11:58:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:58:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:58:06 --> get_exercise_type_list->{"lang":"38","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-29 11:58:06 --> Total execution time: 0.1641
DEBUG - 2020-08-29 11:58:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:58:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:58:10 --> get_sorce_lan_word_type_8->{"slang":"38","tlang":"2","exercise_mode_id":"1","category_id":"123","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-29 11:58:10 --> Total execution time: 0.1253
DEBUG - 2020-08-29 11:58:14 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:58:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:58:14 --> get_exercise_type_list->{"lang":"38","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-29 11:58:14 --> Total execution time: 0.1789
DEBUG - 2020-08-29 11:58:17 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:58:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:58:17 --> get_subcategory_list->{"lang":"38","category_id":"123","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-29 11:58:17 --> Total execution time: 0.1575
DEBUG - 2020-08-29 11:58:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:58:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:58:21 --> get_category_list->{"lang":"38","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-29 11:58:21 --> Total execution time: 0.1119
DEBUG - 2020-08-29 11:58:26 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:58:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:58:26 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-08-29 11:58:26 --> Total execution time: 0.1729
DEBUG - 2020-08-29 11:58:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:58:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:58:31 --> get_category_list->{"lang":"38","exercise_mode_id":"3","support_lang_id":"2"}
DEBUG - 2020-08-29 11:58:31 --> Total execution time: 0.1266
DEBUG - 2020-08-29 11:58:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:58:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:58:41 --> get_subcategory_list->{"lang":"38","category_id":"127","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-29 11:58:41 --> Total execution time: 0.1490
DEBUG - 2020-08-29 11:58:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:58:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:58:45 --> get_category_list->{"lang":"38","exercise_mode_id":"3","support_lang_id":"2"}
DEBUG - 2020-08-29 11:58:45 --> Total execution time: 0.1646
DEBUG - 2020-08-29 11:58:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:58:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:58:47 --> get_category_list->{"lang":"38","exercise_mode_id":"4","support_lang_id":"2"}
DEBUG - 2020-08-29 11:58:47 --> Total execution time: 0.1612
DEBUG - 2020-08-29 11:58:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:58:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:58:56 --> get_category_list->{"lang":"38","exercise_mode_id":"3","support_lang_id":"2"}
DEBUG - 2020-08-29 11:58:56 --> Total execution time: 0.1265
DEBUG - 2020-08-29 11:59:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:59:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:59:01 --> get_category_list->{"lang":"38","exercise_mode_id":"4","support_lang_id":"2"}
DEBUG - 2020-08-29 11:59:01 --> Total execution time: 0.1422
DEBUG - 2020-08-29 11:59:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:59:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:59:12 --> get_subcategory_list->{"lang":"38","category_id":"124","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-29 11:59:12 --> Total execution time: 0.1241
DEBUG - 2020-08-29 11:59:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:59:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:59:18 --> get_exercise_type_list->{"lang":"38","subcategory_id":"274","support_lang_id":"2"}
DEBUG - 2020-08-29 11:59:18 --> Total execution time: 0.1253
DEBUG - 2020-08-29 11:59:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:59:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-29 11:59:20 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-08-29 11:59:20 --> Total execution time: 0.1331
DEBUG - 2020-08-29 11:59:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:59:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:59:25 --> get_exercise_type_list->{"lang":"38","subcategory_id":"274","support_lang_id":"2"}
DEBUG - 2020-08-29 11:59:25 --> Total execution time: 0.1361
DEBUG - 2020-08-29 11:59:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:59:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:59:32 --> get_subcategory_list->{"lang":"38","category_id":"124","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-29 11:59:32 --> Total execution time: 0.1226
DEBUG - 2020-08-29 11:59:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:59:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:59:35 --> get_exercise_type_list->{"lang":"38","subcategory_id":"274","support_lang_id":"2"}
DEBUG - 2020-08-29 11:59:35 --> Total execution time: 0.1131
DEBUG - 2020-08-29 11:59:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:59:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:59:40 --> get_grammer_type_2->{"slang":"38","tlang":"2","exercise_mode_id":"4","category_id":"124","subcategory_id":"274","support_lang_id":"2"}
ERROR - 2020-08-29 11:59:40 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-08-29 11:59:40 --> Total execution time: 0.1441
DEBUG - 2020-08-29 11:59:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:59:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:59:44 --> get_exercise_type_list->{"lang":"38","subcategory_id":"274","support_lang_id":"2"}
DEBUG - 2020-08-29 11:59:44 --> Total execution time: 0.1181
DEBUG - 2020-08-29 11:59:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:59:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:59:46 --> get_subcategory_list->{"lang":"38","category_id":"124","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-29 11:59:46 --> Total execution time: 0.1384
DEBUG - 2020-08-29 11:59:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 11:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 11:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 11:59:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 11:59:47 --> get_category_list->{"lang":"38","exercise_mode_id":"4","support_lang_id":"2"}
DEBUG - 2020-08-29 11:59:47 --> Total execution time: 0.1134
DEBUG - 2020-08-29 13:06:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-29 13:06:52 --> No URI present. Default controller set.
DEBUG - 2020-08-29 13:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-29 13:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-29 13:06:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-29 13:06:52 --> Total execution time: 0.1703
