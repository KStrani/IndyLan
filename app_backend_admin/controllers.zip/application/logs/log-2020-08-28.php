<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-08-28 03:18:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 03:18:22 --> No URI present. Default controller set.
DEBUG - 2020-08-28 03:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 03:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 03:18:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 03:18:22 --> Total execution time: 0.1573
DEBUG - 2020-08-28 04:37:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:37:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:37:30 --> Total execution time: 0.0992
DEBUG - 2020-08-28 04:37:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:37:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:37:35 --> Total execution time: 0.1009
DEBUG - 2020-08-28 04:37:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:37:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:37:47 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"1"}
ERROR - 2020-08-28 04:37:47 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-28 04:37:47 --> Total execution time: 0.1082
DEBUG - 2020-08-28 04:37:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:37:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:37:53 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
ERROR - 2020-08-28 04:37:53 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-28 04:37:53 --> Total execution time: 0.1021
DEBUG - 2020-08-28 04:37:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:37:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:37:58 --> Total execution time: 0.0974
DEBUG - 2020-08-28 04:37:59 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:37:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:37:59 --> Total execution time: 0.1117
DEBUG - 2020-08-28 04:45:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:45:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:45:27 --> Total execution time: 0.1208
DEBUG - 2020-08-28 04:45:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:45:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:45:31 --> Total execution time: 0.1135
DEBUG - 2020-08-28 04:45:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:45:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:45:40 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 04:45:40 --> Total execution time: 0.1113
DEBUG - 2020-08-28 04:45:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:45:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:45:45 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-28 04:45:45 --> Total execution time: 0.1714
DEBUG - 2020-08-28 04:45:50 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:45:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:45:50 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-28 04:45:50 --> Total execution time: 0.1680
DEBUG - 2020-08-28 04:45:56 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:45:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:45:56 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-28 04:45:56 --> Total execution time: 0.1176
DEBUG - 2020-08-28 04:45:59 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:45:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:45:59 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 04:45:59 --> Total execution time: 0.1012
DEBUG - 2020-08-28 04:46:03 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:46:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:46:03 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 04:46:03 --> Total execution time: 0.1353
DEBUG - 2020-08-28 04:46:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:46:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:46:05 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-28 04:46:05 --> Total execution time: 0.1211
DEBUG - 2020-08-28 04:46:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:46:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:46:06 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-28 04:46:06 --> Total execution time: 0.1432
DEBUG - 2020-08-28 04:46:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:46:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:46:09 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"2","exercise_mode_id":"1","category_id":"123","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-28 04:46:09 --> Total execution time: 0.1521
DEBUG - 2020-08-28 04:46:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:46:11 --> No URI present. Default controller set.
DEBUG - 2020-08-28 04:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:46:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:46:11 --> Total execution time: 0.1997
DEBUG - 2020-08-28 04:46:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:46:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:46:23 --> Total execution time: 0.2268
DEBUG - 2020-08-28 04:46:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:46:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:46:28 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-28 04:46:28 --> Total execution time: 0.1085
DEBUG - 2020-08-28 04:46:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:46:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:46:30 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-28 04:46:30 --> Total execution time: 0.1429
DEBUG - 2020-08-28 04:46:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:46:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:46:31 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 04:46:31 --> Total execution time: 0.1691
DEBUG - 2020-08-28 04:46:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:46:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:46:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:46:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:46:35 --> Total execution time: 0.1504
DEBUG - 2020-08-28 04:46:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:46:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:46:38 --> Total execution time: 0.1605
DEBUG - 2020-08-28 04:46:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:46:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 04:46:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 04:46:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:46:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:46:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:46:53 --> Total execution time: 0.1887
DEBUG - 2020-08-28 04:46:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:46:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:46:55 --> Total execution time: 0.1608
DEBUG - 2020-08-28 04:46:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:46:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 04:46:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 04:47:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:47:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:47:04 --> Total execution time: 0.1387
DEBUG - 2020-08-28 04:47:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:47:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 04:47:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-08-28 04:47:06 --> Total execution time: 0.1852
DEBUG - 2020-08-28 04:47:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:47:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 04:47:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 04:47:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:47:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:47:16 --> Total execution time: 0.1450
DEBUG - 2020-08-28 04:47:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:47:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 04:47:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 04:47:56 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:47:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:47:56 --> Total execution time: 0.1609
DEBUG - 2020-08-28 04:48:03 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:48:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:48:03 --> Total execution time: 0.1355
DEBUG - 2020-08-28 04:48:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:48:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:48:12 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 04:48:12 --> Total execution time: 0.1135
DEBUG - 2020-08-28 04:48:17 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:48:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:48:17 --> Total execution time: 0.0966
DEBUG - 2020-08-28 04:49:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:49:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:49:24 --> Total execution time: 0.1412
DEBUG - 2020-08-28 04:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:49:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:49:36 --> Total execution time: 0.1543
DEBUG - 2020-08-28 04:50:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:50:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:50:53 --> Total execution time: 0.1663
DEBUG - 2020-08-28 04:53:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:53:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:53:11 --> Total execution time: 0.1568
DEBUG - 2020-08-28 04:53:14 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:53:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:53:14 --> Total execution time: 0.1534
DEBUG - 2020-08-28 04:53:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:53:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 04:53:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 04:54:02 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:54:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:54:02 --> Total execution time: 0.1245
DEBUG - 2020-08-28 04:54:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:54:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 04:54:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 04:55:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:55:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:55:38 --> Total execution time: 0.1320
DEBUG - 2020-08-28 04:56:03 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 04:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 04:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 04:56:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 04:56:03 --> Total execution time: 0.1105
DEBUG - 2020-08-28 05:16:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 05:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 05:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 05:16:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 05:16:06 --> user_login->{"email":"rastech47@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2020-08-28 05:16:06 --> Total execution time: 0.1399
DEBUG - 2020-08-28 05:16:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 05:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 05:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 05:16:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 05:16:09 --> Total execution time: 0.1199
DEBUG - 2020-08-28 05:21:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 05:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 05:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 05:21:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 05:21:29 --> user_login->{"email":"rastech47@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2020-08-28 05:21:29 --> Total execution time: 0.1770
DEBUG - 2020-08-28 05:21:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 05:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 05:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 05:21:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 05:21:32 --> Total execution time: 0.1164
DEBUG - 2020-08-28 05:21:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 05:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 05:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 05:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 05:21:36 --> Total execution time: 0.1350
DEBUG - 2020-08-28 05:35:26 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 05:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 05:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 05:35:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 05:35:26 --> user_login->{"email":"admin@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2020-08-28 05:35:26 --> Total execution time: 0.1293
DEBUG - 2020-08-28 05:35:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 05:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 05:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 05:35:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 05:35:29 --> Total execution time: 0.1727
DEBUG - 2020-08-28 06:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 06:20:36 --> No URI present. Default controller set.
DEBUG - 2020-08-28 06:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 06:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 06:20:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 06:20:37 --> Total execution time: 0.1405
DEBUG - 2020-08-28 08:19:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:19:08 --> No URI present. Default controller set.
DEBUG - 2020-08-28 08:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 08:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 08:19:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 08:19:08 --> Total execution time: 0.2124
DEBUG - 2020-08-28 08:19:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 08:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 08:19:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 08:19:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 08:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 08:19:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 08:19:37 --> Total execution time: 0.1206
DEBUG - 2020-08-28 08:19:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:19:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 08:19:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 08:19:50 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 08:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 08:19:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 08:19:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 08:19:50 --> Total execution time: 0.1308
DEBUG - 2020-08-28 08:19:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 08:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 08:19:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 08:19:53 --> Total execution time: 0.1425
DEBUG - 2020-08-28 08:19:56 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:19:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 08:19:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 08:20:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 08:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 08:20:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 08:20:04 --> Total execution time: 0.1243
DEBUG - 2020-08-28 08:20:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 08:20:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 08:21:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 08:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 08:21:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 08:21:19 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 08:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 08:21:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 08:21:20 --> Total execution time: 0.1298
DEBUG - 2020-08-28 08:21:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:21:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 08:21:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 08:33:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 08:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 08:33:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 08:33:10 --> Total execution time: 0.1476
DEBUG - 2020-08-28 08:33:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 08:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 08:33:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 08:33:15 --> Total execution time: 0.1394
DEBUG - 2020-08-28 08:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 08:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 08:33:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 08:33:27 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 08:33:27 --> Total execution time: 0.1372
DEBUG - 2020-08-28 08:33:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 08:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 08:33:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 08:33:33 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 08:33:33 --> Total execution time: 0.1670
DEBUG - 2020-08-28 08:33:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 08:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 08:33:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 08:33:34 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 08:33:34 --> Total execution time: 0.1337
DEBUG - 2020-08-28 08:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 08:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 08:34:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 08:34:09 --> Total execution time: 0.1670
DEBUG - 2020-08-28 08:34:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 08:34:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 08:35:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 08:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 08:35:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 08:35:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 08:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 08:35:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 08:35:32 --> Total execution time: 0.1142
DEBUG - 2020-08-28 08:35:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:35:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 08:35:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 08:35:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 08:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 08:35:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 08:35:40 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 08:35:40 --> Total execution time: 0.1409
DEBUG - 2020-08-28 08:56:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 08:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 08:56:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 08:56:43 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"null"}
ERROR - 2020-08-28 08:56:43 --> Query error: Unknown column 'source_language_id' in 'where clause' - Invalid query: SELECT * FROM tbl_master_language WHERE source_language_id='null'
ERROR - 2020-08-28 08:56:43 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 121
DEBUG - 2020-08-28 08:56:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 08:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 08:56:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 08:56:51 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"null"}
ERROR - 2020-08-28 08:56:51 --> Query error: Unknown column 'source_language_id' in 'where clause' - Invalid query: SELECT * FROM tbl_master_language WHERE source_language_id='null'
ERROR - 2020-08-28 08:56:51 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 121
DEBUG - 2020-08-28 08:58:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 08:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 08:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 08:58:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 08:58:34 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"null"}
ERROR - 2020-08-28 08:58:34 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-28 08:58:34 --> Total execution time: 0.1309
DEBUG - 2020-08-28 10:01:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 10:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 10:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 10:01:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 10:01:44 --> get_category_list->{"lang":"9","exercise_mode_id":"1","support_lang_id":"1"}
ERROR - 2020-08-28 10:01:44 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-28 10:01:44 --> Total execution time: 0.1478
DEBUG - 2020-08-28 11:47:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 11:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 11:47:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 11:47:37 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 11:47:37 --> Total execution time: 0.1129
DEBUG - 2020-08-28 11:49:50 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 11:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 11:49:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 11:49:50 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
ERROR - 2020-08-28 11:49:50 --> Query error: Unknown column 'category_name_in_' in 'field list' - Invalid query: select exercise_mode_category_id,image,category_name_in_ as category_name from tbl_exercise_mode_categories where support_lang_id='2' AND exercise_mode_id='1' AND is_active='1' AND is_delete='0' order by category_name_in_ asc
ERROR - 2020-08-28 11:49:50 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 125
DEBUG - 2020-08-28 11:50:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 11:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 11:50:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 11:50:27 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 11:51:14 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 11:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 11:51:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 11:51:14 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 11:51:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 11:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 11:51:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 11:51:46 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 11:51:46 --> Total execution time: 0.1433
DEBUG - 2020-08-28 11:52:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 11:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 11:52:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 11:52:10 --> Total execution time: 0.1430
DEBUG - 2020-08-28 11:52:17 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 11:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 11:52:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 11:52:18 --> Total execution time: 0.1411
DEBUG - 2020-08-28 11:52:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 11:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 11:52:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 11:52:21 --> Total execution time: 0.1636
DEBUG - 2020-08-28 11:52:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 11:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 11:52:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 11:52:30 --> Total execution time: 0.1364
DEBUG - 2020-08-28 11:52:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 11:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 11:52:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 11:52:34 --> Total execution time: 0.1263
DEBUG - 2020-08-28 11:52:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 11:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 11:52:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 11:52:40 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 11:52:40 --> Total execution time: 0.1321
DEBUG - 2020-08-28 11:52:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 11:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 11:52:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 11:52:45 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 11:52:45 --> Total execution time: 0.1163
DEBUG - 2020-08-28 11:58:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 11:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 11:58:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 11:58:42 --> Severity: error --> Exception: syntax error, unexpected ''la' (T_ENCAPSED_AND_WHITESPACE), expecting ']' /home/langoalphademo/public_html/indylan/application/models/Api_model.php 1790
DEBUG - 2020-08-28 11:58:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 11:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 11:58:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 11:58:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 11:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 11:58:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 11:58:51 --> Total execution time: 0.2301
DEBUG - 2020-08-28 11:59:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 11:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 11:59:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 11:59:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 11:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 11:59:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 11:59:10 --> Total execution time: 0.1341
DEBUG - 2020-08-28 11:59:13 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:59:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 11:59:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 11:59:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 11:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 11:59:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 11:59:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 11:59:23 --> Total execution time: 0.1400
DEBUG - 2020-08-28 11:59:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 11:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 11:59:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 11:59:25 --> Total execution time: 0.1357
DEBUG - 2020-08-28 11:59:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:59:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 11:59:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 11:59:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 11:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 11:59:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 11:59:34 --> Total execution time: 0.1476
DEBUG - 2020-08-28 11:59:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 11:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 11:59:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 11:59:37 --> Total execution time: 0.1217
DEBUG - 2020-08-28 11:59:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 11:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 11:59:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 11:59:37 --> Total execution time: 0.1323
DEBUG - 2020-08-28 11:59:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:59:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 11:59:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 11:59:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 11:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 11:59:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 11:59:46 --> Total execution time: 0.1853
DEBUG - 2020-08-28 11:59:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 11:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 11:59:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 12:01:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:01:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 12:01:20 --> Query error: Unknown column 'subcategory_name_in_sv' in 'field list' - Invalid query: UPDATE `tbl_exercise_mode_subcategories` SET `category_id` = '123', `difficulty_level_id` = '1', `subcategory_name_in_en` = 'Scots Word Animal', `subcategory_name_in_fi` = 'Word Animal', `subcategory_name_in_sv` = 'Ordet djur', `subcategory_name_in_es` = 'Animal de la palabra', `subcategory_name_in_ru` = ' Слово Животное', `subcategory_name_in_seh` = 'Scots Word Animal', `subcategory_name_in_gd` = 'scots Animal', `subcategory_name_in_se-FI` = 'Wild Animal', `subcategory_name_in_kw` = 'water Animal', `subcategory_name_in_gl` = 'Snow Animal', `subcategory_name_in_eu` = 'all Animal', `support_lang_id` = '2'
WHERE `exercise_mode_subcategory_id` = '273'
DEBUG - 2020-08-28 12:01:20 --> Total execution time: 0.1546
DEBUG - 2020-08-28 12:01:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:01:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:01:35 --> Total execution time: 0.1910
DEBUG - 2020-08-28 12:01:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:01:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:01:47 --> Total execution time: 0.1939
DEBUG - 2020-08-28 12:01:50 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 12:01:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 12:03:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:03:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:03:30 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 12:03:30 --> Total execution time: 0.1174
DEBUG - 2020-08-28 12:03:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:03:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:03:34 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
ERROR - 2020-08-28 12:03:34 --> Query error: Unknown column 'source_language_id' in 'where clause' - Invalid query: SELECT * FROM tbl_master_language WHERE source_language_id='2'
ERROR - 2020-08-28 12:03:34 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 178
DEBUG - 2020-08-28 12:03:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:03:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:03:40 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 12:03:40 --> Total execution time: 0.1163
DEBUG - 2020-08-28 12:03:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:03:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:03:43 --> Total execution time: 0.1342
DEBUG - 2020-08-28 12:06:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:06:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:06:16 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
ERROR - 2020-08-28 12:06:16 --> Query error: Unknown column 'source_language_id' in 'where clause' - Invalid query: SELECT * FROM tbl_master_language WHERE source_language_id='2'
ERROR - 2020-08-28 12:06:16 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 178
DEBUG - 2020-08-28 12:08:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:08:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:08:23 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
ERROR - 2020-08-28 12:08:23 --> Query error: Unknown column 'source_language_id' in 'where clause' - Invalid query: SELECT * FROM tbl_master_language WHERE source_language_id='2'
ERROR - 2020-08-28 12:08:23 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 178
DEBUG - 2020-08-28 12:09:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:09:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:09:39 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
ERROR - 2020-08-28 12:09:39 --> Query error: Unknown column 'source_language_id' in 'where clause' - Invalid query: SELECT * FROM tbl_master_language WHERE source_language_id='2'
ERROR - 2020-08-28 12:09:39 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 178
DEBUG - 2020-08-28 12:10:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:10:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:10:16 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
ERROR - 2020-08-28 12:10:16 --> Query error: Unknown column 'source_language_id' in 'where clause' - Invalid query: SELECT * FROM tbl_master_language WHERE source_language_id='2'
ERROR - 2020-08-28 12:10:16 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 178
DEBUG - 2020-08-28 12:10:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:10:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:10:46 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
ERROR - 2020-08-28 12:10:46 --> Query error: Unknown column 'source_language_id' in 'where clause' - Invalid query: SELECT * FROM tbl_master_language WHERE source_language_id='2'
ERROR - 2020-08-28 12:10:46 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 178
DEBUG - 2020-08-28 12:11:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:11:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:11:27 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 12:12:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:12:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:12:01 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 12:13:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:13:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:13:25 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 12:14:02 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:14:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:14:02 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 12:14:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:14:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:14:58 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 12:14:58 --> Total execution time: 0.1599
DEBUG - 2020-08-28 12:15:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:15:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:15:20 --> Total execution time: 0.1162
DEBUG - 2020-08-28 12:15:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:15:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:15:30 --> Total execution time: 0.1116
DEBUG - 2020-08-28 12:15:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:15:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:15:36 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 12:15:36 --> Total execution time: 0.1119
DEBUG - 2020-08-28 12:15:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:15:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:15:39 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 12:15:39 --> Total execution time: 0.1267
DEBUG - 2020-08-28 12:15:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:15:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:15:45 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-28 12:15:45 --> Total execution time: 0.1395
DEBUG - 2020-08-28 12:18:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:18:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:18:30 --> Total execution time: 0.1426
DEBUG - 2020-08-28 12:18:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:18:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:18:34 --> Total execution time: 0.1355
DEBUG - 2020-08-28 12:18:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:18:44 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 12:18:44 --> Total execution time: 0.1791
DEBUG - 2020-08-28 12:18:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:18:52 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 12:18:52 --> Total execution time: 0.1648
DEBUG - 2020-08-28 12:18:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:18:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:18:56 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-28 12:18:56 --> Total execution time: 0.1759
DEBUG - 2020-08-28 12:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:19:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:19:01 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"2","exercise_mode_id":"1","category_id":"123","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-28 12:19:01 --> Total execution time: 0.1212
DEBUG - 2020-08-28 12:19:14 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:19:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:19:14 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-28 12:19:14 --> Total execution time: 0.1334
DEBUG - 2020-08-28 12:19:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:19:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:19:22 --> Total execution time: 0.1520
DEBUG - 2020-08-28 12:19:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:19:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 12:19:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-08-28 12:19:25 --> Total execution time: 0.1567
DEBUG - 2020-08-28 12:19:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:19:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:19:25 --> Total execution time: 0.1490
DEBUG - 2020-08-28 12:19:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 12:19:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 12:19:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:19:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:19:43 --> Total execution time: 0.1644
DEBUG - 2020-08-28 12:19:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:19:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 12:19:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 12:20:03 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:20:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:20:03 --> Total execution time: 0.1301
DEBUG - 2020-08-28 12:20:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:20:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 12:20:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 12:20:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:20:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:20:16 --> Total execution time: 0.1700
DEBUG - 2020-08-28 12:20:19 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:20:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 12:20:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 12:20:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:20:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:20:59 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:20:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 12:20:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-08-28 12:20:59 --> Total execution time: 0.1796
DEBUG - 2020-08-28 12:21:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:21:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 12:21:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 12:21:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:21:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:21:10 --> Total execution time: 0.1580
DEBUG - 2020-08-28 12:21:13 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:21:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 12:21:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 12:22:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:22:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:22:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:22:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 12:22:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-08-28 12:22:51 --> Total execution time: 0.1735
DEBUG - 2020-08-28 12:22:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:22:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 12:22:54 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 12:25:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:25:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:25:09 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"2","exercise_mode_id":"1","category_id":"123","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-28 12:25:09 --> Total execution time: 0.1854
DEBUG - 2020-08-28 12:25:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:25:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:25:21 --> Total execution time: 0.1434
DEBUG - 2020-08-28 12:25:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:25:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:25:23 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-28 12:25:23 --> Total execution time: 0.1449
DEBUG - 2020-08-28 12:25:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:25:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:25:26 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 12:25:26 --> Total execution time: 0.1334
DEBUG - 2020-08-28 12:25:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:25:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:25:27 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 12:25:27 --> Total execution time: 0.1614
DEBUG - 2020-08-28 12:25:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:25:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:25:30 --> Total execution time: 0.1551
DEBUG - 2020-08-28 12:27:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:27:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:27:09 --> Total execution time: 0.1204
DEBUG - 2020-08-28 12:27:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:27:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 12:27:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-08-28 12:27:12 --> Total execution time: 0.1329
DEBUG - 2020-08-28 12:27:14 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 12:27:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 12:27:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:27:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:27:22 --> Total execution time: 0.1636
DEBUG - 2020-08-28 12:27:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:27:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:27:25 --> Total execution time: 0.1683
DEBUG - 2020-08-28 12:27:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:27:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 12:27:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 12:27:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:27:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:27:33 --> Total execution time: 0.1546
DEBUG - 2020-08-28 12:27:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:27:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 12:27:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 12:30:50 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:30:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:30:50 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:30:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:30:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:30:52 --> Total execution time: 0.1622
DEBUG - 2020-08-28 12:30:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:30:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 12:30:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 12:31:02 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:31:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:31:02 --> Total execution time: 0.1203
DEBUG - 2020-08-28 12:31:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:31:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:31:05 --> Total execution time: 0.1361
DEBUG - 2020-08-28 12:31:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:31:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:31:06 --> Total execution time: 0.1659
DEBUG - 2020-08-28 12:31:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:31:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 12:31:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 12:31:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:31:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:31:15 --> Total execution time: 0.1437
DEBUG - 2020-08-28 12:31:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:31:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 12:31:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 12:31:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:31:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:31:25 --> Total execution time: 0.1559
DEBUG - 2020-08-28 12:31:26 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:31:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 12:31:26 --> Query error: Unknown column 'mode_name' in 'order clause' - Invalid query: SELECT *
FROM `tbl_exercise_type`
WHERE `exercise_mode_id` = '4'
ORDER BY `mode_name` ASC
ERROR - 2020-08-28 12:31:26 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 896
DEBUG - 2020-08-28 12:35:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:35:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:35:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:35:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:35:11 --> Total execution time: 0.1811
DEBUG - 2020-08-28 12:35:13 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:35:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 12:35:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 12:35:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:35:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:35:25 --> Total execution time: 0.1476
DEBUG - 2020-08-28 12:35:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:35:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 12:35:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-08-28 12:35:27 --> Total execution time: 0.1792
DEBUG - 2020-08-28 12:35:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:35:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 12:35:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 12:35:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:35:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:35:39 --> Total execution time: 0.1589
DEBUG - 2020-08-28 12:35:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 12:35:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 12:35:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:35:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:35:49 --> Total execution time: 0.1446
DEBUG - 2020-08-28 12:36:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:36:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:36:01 --> Total execution time: 0.1523
DEBUG - 2020-08-28 12:37:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:37:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:37:50 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:37:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 12:37:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-08-28 12:37:51 --> Total execution time: 0.1659
DEBUG - 2020-08-28 12:37:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:37:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 12:37:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 12:38:19 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:38:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:38:19 --> Total execution time: 0.1670
DEBUG - 2020-08-28 12:38:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:38:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:38:23 --> Total execution time: 0.1394
DEBUG - 2020-08-28 12:38:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:38:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:38:31 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"2"}
DEBUG - 2020-08-28 12:38:31 --> Total execution time: 0.1425
DEBUG - 2020-08-28 12:38:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:38:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:38:37 --> get_subcategory_list->{"lang":"37","category_id":"124","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 12:38:37 --> Total execution time: 0.1719
DEBUG - 2020-08-28 12:38:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:38:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:38:43 --> get_exercise_type_list->{"lang":"37","subcategory_id":"274","support_lang_id":"2"}
DEBUG - 2020-08-28 12:38:43 --> Total execution time: 0.1292
DEBUG - 2020-08-28 12:38:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:38:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 12:38:51 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-08-28 12:38:51 --> Total execution time: 0.1174
DEBUG - 2020-08-28 12:38:56 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:38:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:38:57 --> get_exercise_type_list->{"lang":"37","subcategory_id":"274","support_lang_id":"2"}
DEBUG - 2020-08-28 12:38:57 --> Total execution time: 0.1381
DEBUG - 2020-08-28 12:39:00 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:39:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:39:00 --> get_grammer_type_1->{"slang":"37","tlang":"2","exercise_mode_id":"4","category_id":"124","subcategory_id":"274","support_lang_id":"2"}
ERROR - 2020-08-28 12:39:00 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-08-28 12:39:00 --> Total execution time: 0.1468
DEBUG - 2020-08-28 12:39:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:39:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:39:05 --> get_exercise_type_list->{"lang":"37","subcategory_id":"274","support_lang_id":"2"}
DEBUG - 2020-08-28 12:39:05 --> Total execution time: 0.1470
DEBUG - 2020-08-28 12:39:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:39:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 12:39:10 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-08-28 12:39:10 --> Total execution time: 0.1201
DEBUG - 2020-08-28 12:39:14 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:39:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:39:14 --> get_exercise_type_list->{"lang":"37","subcategory_id":"274","support_lang_id":"2"}
DEBUG - 2020-08-28 12:39:14 --> Total execution time: 0.1449
DEBUG - 2020-08-28 12:39:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:39:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:39:21 --> get_grammer_type_1->{"slang":"37","tlang":"2","exercise_mode_id":"4","category_id":"124","subcategory_id":"274","support_lang_id":"2"}
ERROR - 2020-08-28 12:39:21 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-08-28 12:39:21 --> Total execution time: 0.1267
DEBUG - 2020-08-28 12:39:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:39:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:39:25 --> Total execution time: 0.1739
DEBUG - 2020-08-28 12:39:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:39:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 12:39:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 12:39:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:39:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:39:37 --> Total execution time: 0.1338
DEBUG - 2020-08-28 12:40:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:40:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:40:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 12:40:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-08-28 12:40:15 --> Total execution time: 0.1869
DEBUG - 2020-08-28 12:40:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:40:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 12:40:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 12:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:41:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:41:21 --> get_exercise_type_list->{"lang":"37","subcategory_id":"274","support_lang_id":"2"}
DEBUG - 2020-08-28 12:41:21 --> Total execution time: 0.1988
DEBUG - 2020-08-28 12:41:26 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:41:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:41:26 --> get_subcategory_list->{"lang":"37","category_id":"124","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 12:41:26 --> Total execution time: 0.1286
DEBUG - 2020-08-28 12:41:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:41:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:41:31 --> get_exercise_type_list->{"lang":"37","subcategory_id":"274","support_lang_id":"2"}
DEBUG - 2020-08-28 12:41:31 --> Total execution time: 0.1490
DEBUG - 2020-08-28 12:41:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:41:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:41:37 --> get_grammer_type_1->{"slang":"37","tlang":"2","exercise_mode_id":"4","category_id":"124","subcategory_id":"274","support_lang_id":"2"}
ERROR - 2020-08-28 12:41:37 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-08-28 12:41:37 --> Total execution time: 0.1331
DEBUG - 2020-08-28 12:41:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:41:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:41:47 --> get_exercise_type_list->{"lang":"37","subcategory_id":"274","support_lang_id":"2"}
DEBUG - 2020-08-28 12:41:47 --> Total execution time: 0.1201
DEBUG - 2020-08-28 12:42:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:42:33 --> get_grammer_type_1->{"slang":"37","tlang":"2","exercise_mode_id":"4","category_id":"124","subcategory_id":"274","support_lang_id":"2"}
ERROR - 2020-08-28 12:42:33 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-08-28 12:42:33 --> Total execution time: 0.1179
DEBUG - 2020-08-28 12:43:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 12:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 12:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 12:43:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 12:43:40 --> get_exercise_type_list->{"lang":"37","subcategory_id":"274","support_lang_id":"2"}
DEBUG - 2020-08-28 12:43:40 --> Total execution time: 0.1030
DEBUG - 2020-08-28 13:05:00 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:05:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:05:00 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"124","subcategory_id":"274","support_lang_id":"2"}
ERROR - 2020-08-28 13:05:00 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-08-28 13:05:00 --> Total execution time: 0.1450
DEBUG - 2020-08-28 13:07:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:07:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:07:10 --> Total execution time: 0.1740
DEBUG - 2020-08-28 13:07:13 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:07:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:07:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:07:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:07:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:07:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:07:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:07:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:07:21 --> 404 Page Not Found: Assets/js
DEBUG - 2020-08-28 13:07:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:07:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:07:49 --> Total execution time: 0.1442
DEBUG - 2020-08-28 13:07:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:07:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:07:51 --> Total execution time: 0.1455
DEBUG - 2020-08-28 13:07:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:07:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 13:07:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-08-28 13:07:51 --> Total execution time: 0.1598
DEBUG - 2020-08-28 13:07:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:07:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 13:07:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-08-28 13:07:54 --> Total execution time: 0.1932
DEBUG - 2020-08-28 13:07:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:07:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:07:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:14:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:14:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:14:55 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"124","subcategory_id":"274","support_lang_id":"2"}
ERROR - 2020-08-28 13:14:55 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-08-28 13:14:55 --> Total execution time: 0.1629
DEBUG - 2020-08-28 13:15:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:15:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:15:12 --> get_grammer_type_1->{"slang":"37","tlang":"9","exercise_mode_id":"4","category_id":"124","subcategory_id":"274","support_lang_id":"2"}
ERROR - 2020-08-28 13:15:12 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-08-28 13:15:12 --> Total execution time: 0.1767
DEBUG - 2020-08-28 13:15:26 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:15:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:15:26 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"124","subcategory_id":"274","support_lang_id":"2"}
ERROR - 2020-08-28 13:15:26 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-08-28 13:15:26 --> Total execution time: 0.1456
DEBUG - 2020-08-28 13:16:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:16:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 13:16:52 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-08-28 13:16:52 --> Total execution time: 0.1414
DEBUG - 2020-08-28 13:17:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:17:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:17:04 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"124","subcategory_id":"274","support_lang_id":"2"}
ERROR - 2020-08-28 13:17:04 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-08-28 13:17:04 --> Total execution time: 0.1100
DEBUG - 2020-08-28 13:18:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:18:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:18:15 --> Total execution time: 0.1499
DEBUG - 2020-08-28 13:18:17 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:18:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:18:17 --> Total execution time: 0.1322
DEBUG - 2020-08-28 13:18:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:18:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 13:18:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-08-28 13:18:18 --> Total execution time: 0.1881
DEBUG - 2020-08-28 13:18:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:18:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 13:18:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-08-28 13:18:20 --> Total execution time: 0.1404
DEBUG - 2020-08-28 13:18:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:18:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:18:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:18:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:18:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:18:29 --> Total execution time: 0.1539
DEBUG - 2020-08-28 13:18:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:18:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:18:31 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:18:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:18:49 --> Total execution time: 0.1387
DEBUG - 2020-08-28 13:18:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:18:52 --> Total execution time: 0.2238
DEBUG - 2020-08-28 13:18:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:18:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:18:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:19:03 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:19:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:19:03 --> Total execution time: 0.1424
DEBUG - 2020-08-28 13:19:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:19:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:19:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:20:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:20:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:20:28 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:20:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:20:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:20:32 --> Total execution time: 0.1581
DEBUG - 2020-08-28 13:20:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:20:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:20:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:20:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:20:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:20:40 --> Total execution time: 0.1729
DEBUG - 2020-08-28 13:20:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:20:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:20:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:25:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:25:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:25:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:25:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:25:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:25:48 --> Total execution time: 0.2309
DEBUG - 2020-08-28 13:25:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:25:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:25:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:25:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:25:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:25:59 --> Total execution time: 0.1488
DEBUG - 2020-08-28 13:26:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:26:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:26:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:26:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:26:38 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:26:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:26:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:26:41 --> Total execution time: 0.1699
DEBUG - 2020-08-28 13:26:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:26:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:26:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:27:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:27:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:27:08 --> Total execution time: 0.1192
DEBUG - 2020-08-28 13:27:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:27:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:27:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:27:19 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:27:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:27:19 --> Total execution time: 0.1555
DEBUG - 2020-08-28 13:27:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:27:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:27:22 --> Total execution time: 0.1558
DEBUG - 2020-08-28 13:27:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:27:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:27:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:27:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:27:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:27:30 --> Total execution time: 0.1955
DEBUG - 2020-08-28 13:27:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:27:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:27:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:27:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:27:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:27:44 --> Total execution time: 0.1618
DEBUG - 2020-08-28 13:27:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:27:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 13:27:44 --> Query error: Unknown column 'mode_name' in 'order clause' - Invalid query: SELECT *
FROM `tbl_exercise_type`
WHERE `exercise_mode_id` = '5'
ORDER BY `mode_name` ASC
ERROR - 2020-08-28 13:27:44 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 896
DEBUG - 2020-08-28 13:28:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:28:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:28:40 --> Total execution time: 0.1357
DEBUG - 2020-08-28 13:28:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:28:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:28:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:29:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:29:04 --> Total execution time: 0.1210
DEBUG - 2020-08-28 13:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:29:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 13:29:04 --> Query error: Unknown column 'mode_name' in 'order clause' - Invalid query: SELECT *
FROM `tbl_exercise_type`
WHERE `exercise_mode_id` = '5'
ORDER BY `mode_name` ASC
ERROR - 2020-08-28 13:29:04 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 896
DEBUG - 2020-08-28 13:29:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:29:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:29:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:29:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:29:21 --> Total execution time: 0.1631
DEBUG - 2020-08-28 13:29:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:29:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:29:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:29:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:29:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:29:29 --> Total execution time: 0.1355
DEBUG - 2020-08-28 13:29:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:29:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 13:29:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-08-28 13:29:32 --> Total execution time: 0.1808
DEBUG - 2020-08-28 13:29:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:29:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:29:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:29:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:29:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:29:40 --> Total execution time: 0.1482
DEBUG - 2020-08-28 13:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:29:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:29:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:29:56 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:29:56 --> Total execution time: 0.1562
DEBUG - 2020-08-28 13:31:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:31:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:31:10 --> Total execution time: 0.1480
DEBUG - 2020-08-28 13:31:13 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:31:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:31:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:31:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:31:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:31:34 --> Total execution time: 0.1404
DEBUG - 2020-08-28 13:31:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:31:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:31:36 --> Total execution time: 0.1696
DEBUG - 2020-08-28 13:33:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:33:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:33:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:33:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 13:33:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-08-28 13:33:08 --> Total execution time: 0.1174
DEBUG - 2020-08-28 13:33:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:33:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:33:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:33:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-28 13:33:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:33:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:33:22 --> Total execution time: 0.1572
DEBUG - 2020-08-28 13:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:33:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 13:33:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2020-08-28 13:33:25 --> Total execution time: 0.1686
DEBUG - 2020-08-28 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:33:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:44:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:44:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 13:44:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/langoalphademo/public_html/indylan/application/views/admin/add_phrases.php 41
DEBUG - 2020-08-28 13:44:27 --> Total execution time: 0.1666
DEBUG - 2020-08-28 13:44:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:44:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:44:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:44:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:44:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:44:42 --> Total execution time: 0.1399
DEBUG - 2020-08-28 13:45:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:45:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:45:15 --> Total execution time: 0.1356
DEBUG - 2020-08-28 13:46:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:46:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:46:11 --> Total execution time: 0.1741
DEBUG - 2020-08-28 13:46:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:46:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:46:16 --> Total execution time: 0.1389
DEBUG - 2020-08-28 13:46:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:46:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:46:25 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"2"}
DEBUG - 2020-08-28 13:46:25 --> Total execution time: 0.1379
DEBUG - 2020-08-28 13:46:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:46:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:46:30 --> get_subcategory_list->{"lang":"37","category_id":"125","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 13:46:30 --> Total execution time: 0.1096
DEBUG - 2020-08-28 13:46:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:46:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:46:34 --> get_exercise_type_list->{"lang":"37","subcategory_id":"275","support_lang_id":"2"}
DEBUG - 2020-08-28 13:46:34 --> Total execution time: 0.1310
DEBUG - 2020-08-28 13:46:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:46:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 13:46:39 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-08-28 13:46:39 --> Total execution time: 0.1227
DEBUG - 2020-08-28 13:48:19 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:48:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 13:48:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/langoalphademo/public_html/indylan/application/views/admin/add_phrases.php 41
DEBUG - 2020-08-28 13:48:20 --> Total execution time: 0.1931
DEBUG - 2020-08-28 13:48:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:48:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:48:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:48:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:48:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:48:27 --> Total execution time: 0.1675
DEBUG - 2020-08-28 13:48:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:48:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:48:28 --> Total execution time: 0.1601
DEBUG - 2020-08-28 13:48:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:48:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:48:29 --> Total execution time: 0.1397
DEBUG - 2020-08-28 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:48:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:48:32 --> Total execution time: 0.1430
DEBUG - 2020-08-28 13:48:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:48:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:48:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:48:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:48:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:48:46 --> Total execution time: 0.1745
DEBUG - 2020-08-28 13:48:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:48:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:48:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:48:56 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:48:56 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:48:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 13:48:57 --> Query error: Unknown column 'mode_name' in 'order clause' - Invalid query: SELECT *
FROM `tbl_exercise_type`
WHERE `exercise_mode_id` = '3'
ORDER BY `mode_name` ASC
ERROR - 2020-08-28 13:48:57 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 896
DEBUG - 2020-08-28 13:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:48:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:48:57 --> Total execution time: 0.2387
DEBUG - 2020-08-28 13:51:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:51:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:51:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:51:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:51:24 --> Total execution time: 0.1599
DEBUG - 2020-08-28 13:51:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:51:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:51:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:51:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:51:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:51:36 --> Total execution time: 0.1964
DEBUG - 2020-08-28 13:51:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:51:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:51:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:51:39 --> Total execution time: 0.1518
DEBUG - 2020-08-28 13:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:51:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 13:51:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2020-08-28 13:51:39 --> Total execution time: 0.1670
DEBUG - 2020-08-28 13:51:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:51:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 13:51:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2020-08-28 13:51:42 --> Total execution time: 0.1969
DEBUG - 2020-08-28 13:51:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:51:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:51:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:51:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:51:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 13:51:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/langoalphademo/public_html/indylan/application/views/admin/add_phrases.php 41
DEBUG - 2020-08-28 13:51:51 --> Total execution time: 0.1670
DEBUG - 2020-08-28 13:51:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:51:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:51:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:52:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:52:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:52:09 --> Total execution time: 0.1295
DEBUG - 2020-08-28 13:53:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:53:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:53:15 --> Total execution time: 0.1623
DEBUG - 2020-08-28 13:53:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:53:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 13:53:31 --> Query error: Unknown column 'phrase_sv' in 'field list' - Invalid query: INSERT INTO `tbl_phrases` (`category_id`, `subcategory_id`, `audio_file`, `phrase_en`, `phrase_fi`, `phrase_sv`, `phrase_es`, `phrase_ru`, `phrase_seh`, `phrase_gd`, `phrase_se-FI`, `phrase_kw`, `phrase_gl`, `phrase_eu`, `support_lang_id`) VALUES ('127', '276', 'test', 'hello', 'hie', 'how are you ? swedish', 'hey spanish', 'hey russi', 'i\'m fine scotish', 'hey gaelic', 'hey northern saami', 'hey cornish', 'hey galician', 'hey basque', '2')
DEBUG - 2020-08-28 13:53:31 --> Total execution time: 0.1580
DEBUG - 2020-08-28 13:53:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:53:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:53:31 --> Total execution time: 0.1411
DEBUG - 2020-08-28 13:53:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:53:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:53:37 --> Total execution time: 0.1442
DEBUG - 2020-08-28 13:53:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:53:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:53:41 --> Total execution time: 0.1356
DEBUG - 2020-08-28 13:53:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:53:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:53:47 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 13:53:47 --> Total execution time: 0.1791
DEBUG - 2020-08-28 13:53:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:53:52 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-28 13:53:52 --> Total execution time: 0.1214
DEBUG - 2020-08-28 13:53:56 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:53:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:53:56 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-28 13:53:56 --> Total execution time: 0.1045
DEBUG - 2020-08-28 13:54:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:54:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:54:01 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"2","exercise_mode_id":"1","category_id":"123","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-28 13:54:01 --> Total execution time: 0.1197
DEBUG - 2020-08-28 13:54:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:54:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:54:12 --> Total execution time: 0.0984
DEBUG - 2020-08-28 13:54:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:54:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:54:20 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-28 13:54:20 --> Total execution time: 0.1279
DEBUG - 2020-08-28 13:54:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:54:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:54:24 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"745","support_lang_id":"2"}
DEBUG - 2020-08-28 13:54:24 --> Total execution time: 0.1511
DEBUG - 2020-08-28 13:54:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:54:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:54:24 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 13:54:24 --> Total execution time: 0.1310
DEBUG - 2020-08-28 13:54:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:54:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:54:24 --> Total execution time: 0.1386
DEBUG - 2020-08-28 13:54:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:54:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:54:25 --> Total execution time: 0.0992
DEBUG - 2020-08-28 13:55:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:55:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:55:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:55:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 13:55:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2020-08-28 13:55:34 --> Total execution time: 0.1741
DEBUG - 2020-08-28 13:55:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:55:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 13:55:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 13:56:03 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:56:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:56:03 --> Total execution time: 0.1383
DEBUG - 2020-08-28 13:56:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:56:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:56:12 --> Total execution time: 0.1126
DEBUG - 2020-08-28 13:56:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:56:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:56:18 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"2"}
DEBUG - 2020-08-28 13:56:18 --> Total execution time: 0.1169
DEBUG - 2020-08-28 13:56:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:56:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:56:22 --> get_subcategory_list->{"lang":"37","category_id":"127","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 13:56:22 --> Total execution time: 0.1397
DEBUG - 2020-08-28 13:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:56:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:56:27 --> get_exercise_type_list->{"lang":"37","subcategory_id":"276","support_lang_id":"2"}
DEBUG - 2020-08-28 13:56:27 --> Total execution time: 0.1608
DEBUG - 2020-08-28 13:56:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:56:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 13:56:34 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-08-28 13:56:34 --> Total execution time: 0.1610
DEBUG - 2020-08-28 13:56:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:56:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:56:42 --> get_exercise_type_list->{"lang":"37","subcategory_id":"276","support_lang_id":"2"}
DEBUG - 2020-08-28 13:56:42 --> Total execution time: 0.1477
DEBUG - 2020-08-28 13:56:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:56:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 13:56:46 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-08-28 13:56:46 --> Total execution time: 0.1357
DEBUG - 2020-08-28 13:56:50 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:56:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:56:50 --> get_exercise_type_list->{"lang":"37","subcategory_id":"276","support_lang_id":"2"}
DEBUG - 2020-08-28 13:56:50 --> Total execution time: 0.1675
DEBUG - 2020-08-28 13:56:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:56:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 13:56:54 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-08-28 13:56:54 --> Total execution time: 0.1141
DEBUG - 2020-08-28 13:56:59 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 13:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 13:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 13:56:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 13:56:59 --> get_exercise_type_list->{"lang":"37","subcategory_id":"276","support_lang_id":"2"}
DEBUG - 2020-08-28 13:56:59 --> Total execution time: 0.1075
DEBUG - 2020-08-28 14:04:00 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:04:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 14:04:00 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-08-28 14:04:00 --> Total execution time: 0.1261
DEBUG - 2020-08-28 14:04:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:04:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:04:04 --> get_exercise_type_list->{"lang":"37","subcategory_id":"276","support_lang_id":"2"}
DEBUG - 2020-08-28 14:04:04 --> Total execution time: 0.1033
DEBUG - 2020-08-28 14:04:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:04:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:04:57 --> get_subcategory_list->{"lang":"37","category_id":"127","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 14:04:57 --> Total execution time: 0.1528
DEBUG - 2020-08-28 14:04:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:04:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:04:57 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"2"}
DEBUG - 2020-08-28 14:04:57 --> Total execution time: 0.1209
DEBUG - 2020-08-28 14:05:00 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:05:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:05:00 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"2"}
DEBUG - 2020-08-28 14:05:00 --> Total execution time: 0.1590
DEBUG - 2020-08-28 14:05:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:05:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:05:01 --> get_subcategory_list->{"lang":"37","category_id":"127","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 14:05:01 --> Total execution time: 0.1319
DEBUG - 2020-08-28 14:05:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:05:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:05:04 --> get_exercise_type_list->{"lang":"37","subcategory_id":"276","support_lang_id":"2"}
DEBUG - 2020-08-28 14:05:04 --> Total execution time: 0.1045
DEBUG - 2020-08-28 14:09:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:09:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:09:31 --> get_exercise_type_list->{"lang":"37","subcategory_id":"276","support_lang_id":"2"}
DEBUG - 2020-08-28 14:09:31 --> Total execution time: 0.1721
DEBUG - 2020-08-28 14:14:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:14:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:14:12 --> Total execution time: 0.1554
DEBUG - 2020-08-28 14:14:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:14:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:14:16 --> Total execution time: 0.1190
DEBUG - 2020-08-28 14:14:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:14:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 14:14:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 14:14:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:14:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:14:32 --> Total execution time: 0.1655
DEBUG - 2020-08-28 14:14:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:14:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 14:14:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 14:15:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:15:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:15:16 --> get_exercise_type_list->{"lang":"37","subcategory_id":"276","support_lang_id":"2"}
DEBUG - 2020-08-28 14:15:16 --> Total execution time: 0.1367
DEBUG - 2020-08-28 14:38:56 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:38:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:38:57 --> Total execution time: 0.1385
DEBUG - 2020-08-28 14:39:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:39:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:39:01 --> Total execution time: 0.1235
DEBUG - 2020-08-28 14:39:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:39:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:39:06 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
ERROR - 2020-08-28 14:39:06 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-28 14:39:06 --> Total execution time: 0.1359
DEBUG - 2020-08-28 14:39:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:39:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:39:30 --> Total execution time: 0.1630
DEBUG - 2020-08-28 14:39:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:39:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:39:34 --> Total execution time: 0.1437
DEBUG - 2020-08-28 14:39:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:39:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:39:40 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-08-28 14:39:40 --> Total execution time: 0.1254
DEBUG - 2020-08-28 14:39:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:39:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:39:44 --> get_subcategory_list->{"lang":"37","category_id":"50","user_id":"767","support_lang_id":"3"}
DEBUG - 2020-08-28 14:39:44 --> Total execution time: 0.1336
DEBUG - 2020-08-28 14:39:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:39:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:39:48 --> get_exercise_type_list->{"lang":"37","subcategory_id":"56","support_lang_id":"3"}
DEBUG - 2020-08-28 14:39:48 --> Total execution time: 0.1935
DEBUG - 2020-08-28 14:39:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:39:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:39:52 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"3","exercise_mode_id":"1","category_id":"50","subcategory_id":"56","support_lang_id":"3"}
DEBUG - 2020-08-28 14:39:52 --> Total execution time: 0.1300
DEBUG - 2020-08-28 14:39:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:39:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:39:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 14:39:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-28 14:39:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 14:39:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-28 14:39:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:39:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:39:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 14:39:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-28 14:39:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 14:39:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-28 14:39:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:39:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 14:39:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-28 14:39:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:39:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 14:39:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-28 14:39:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:39:58 --> UTF-8 Support Enabled
ERROR - 2020-08-28 14:39:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-28 14:39:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 14:39:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-28 14:40:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:40:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:40:07 --> get_exercise_type_list->{"lang":"37","subcategory_id":"56","support_lang_id":"3"}
DEBUG - 2020-08-28 14:40:07 --> Total execution time: 0.1573
DEBUG - 2020-08-28 14:40:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:40:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:40:08 --> get_subcategory_list->{"lang":"37","category_id":"50","user_id":"767","support_lang_id":"3"}
DEBUG - 2020-08-28 14:40:08 --> Total execution time: 0.1461
DEBUG - 2020-08-28 14:40:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:40:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:40:54 --> get_exercise_type_list->{"lang":"37","subcategory_id":"276","support_lang_id":"null"}
ERROR - 2020-08-28 14:40:54 --> Query error: Unknown column 'type.type_' in 'field list' - Invalid query: select type.id, type.type_ as type_name,type.image  from tbl_exercise_type type LEFT JOIN tbl_exercise_mode_categories_exercise ex ON type.id=ex.exercise_type_id where ex.category_id='276' AND ex.is_active='1' order by type.sequence asc
ERROR - 2020-08-28 14:40:54 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 288
DEBUG - 2020-08-28 14:40:59 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:40:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:40:59 --> get_subcategory_list->{"lang":"37","category_id":"127","user_id":"1","support_lang_id":"null"}
ERROR - 2020-08-28 14:40:59 --> Query error: Unknown column 'subcategory_name_in_' in 'field list' - Invalid query: select exercise_mode_subcategory_id,category_id,difficulty_level_id,image,subcategory_name_in_ as subcategory_name from tbl_exercise_mode_subcategories where category_id='127' AND is_active='1' AND is_delete='0' order by subcategory_name_in_ asc
ERROR - 2020-08-28 14:40:59 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 183
DEBUG - 2020-08-28 14:41:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:41:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:41:04 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"null"}
ERROR - 2020-08-28 14:41:04 --> Query error: Unknown column 'category_name_in_' in 'field list' - Invalid query: select exercise_mode_category_id,image,category_name_in_ as category_name from tbl_exercise_mode_categories where support_lang_id='null' AND exercise_mode_id='3' AND is_active='1' AND is_delete='0' order by category_name_in_ asc
ERROR - 2020-08-28 14:41:04 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 126
DEBUG - 2020-08-28 14:54:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:54:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:54:47 --> Total execution time: 0.1548
DEBUG - 2020-08-28 14:54:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:54:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:54:51 --> Total execution time: 0.1092
DEBUG - 2020-08-28 14:54:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:54:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:54:58 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"2"}
DEBUG - 2020-08-28 14:54:58 --> Total execution time: 0.1249
DEBUG - 2020-08-28 14:55:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:55:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:55:01 --> get_subcategory_list->{"lang":"37","category_id":"127","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 14:55:01 --> Total execution time: 0.1154
DEBUG - 2020-08-28 14:55:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:55:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:55:05 --> get_exercise_type_list->{"lang":"37","subcategory_id":"276","support_lang_id":"2"}
DEBUG - 2020-08-28 14:55:05 --> Total execution time: 0.1261
DEBUG - 2020-08-28 14:55:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:55:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:55:10 --> get_phrases_type_1->{"slang":"37","tlang":"2","exercise_mode_id":"3","category_id":"127","subcategory_id":"276","support_lang_id":"2"}
DEBUG - 2020-08-28 14:55:10 --> Total execution time: 0.1407
DEBUG - 2020-08-28 14:55:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:55:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:55:21 --> Total execution time: 0.1447
DEBUG - 2020-08-28 14:55:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:55:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:55:22 --> get_exercise_type_list->{"lang":"37","subcategory_id":"276","support_lang_id":"2"}
DEBUG - 2020-08-28 14:55:22 --> Total execution time: 0.1767
DEBUG - 2020-08-28 14:55:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:55:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:55:40 --> Total execution time: 0.1656
DEBUG - 2020-08-28 14:55:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:55:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 14:55:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-08-28 14:55:42 --> Total execution time: 0.1441
DEBUG - 2020-08-28 14:55:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 14:55:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 14:55:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:55:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:55:52 --> Total execution time: 0.1954
DEBUG - 2020-08-28 14:55:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:55:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 14:55:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 14:56:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:56:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:56:11 --> Total execution time: 0.1827
DEBUG - 2020-08-28 14:56:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:56:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:56:19 --> Total execution time: 0.1303
DEBUG - 2020-08-28 14:56:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:56:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:56:21 --> Total execution time: 0.1695
DEBUG - 2020-08-28 14:56:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:56:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 14:56:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 14:56:59 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:56:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:56:59 --> Total execution time: 0.1074
DEBUG - 2020-08-28 14:57:02 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:57:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 14:57:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 14:57:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:57:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:57:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 14:57:15 --> Query error: Unknown column 'mode_name' in 'order clause' - Invalid query: SELECT *
FROM `tbl_exercise_type`
WHERE `exercise_mode_id` = '2'
ORDER BY `mode_name` ASC
ERROR - 2020-08-28 14:57:15 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 896
DEBUG - 2020-08-28 14:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:57:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:57:15 --> Total execution time: 0.2108
DEBUG - 2020-08-28 14:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 14:57:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 14:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 14:57:24 --> 404 Page Not Found: Assets/js
DEBUG - 2020-08-28 14:57:59 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:57:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:57:59 --> Total execution time: 0.1419
DEBUG - 2020-08-28 14:58:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:58:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 14:58:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 14:58:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:58:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 14:58:04 --> 404 Page Not Found: Assets/js
DEBUG - 2020-08-28 14:58:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:58:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 14:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 14:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:58:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 14:58:09 --> Total execution time: 0.1334
DEBUG - 2020-08-28 14:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 14:58:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 14:58:09 --> Query error: Unknown column 'mode_name' in 'order clause' - Invalid query: SELECT *
FROM `tbl_exercise_type`
WHERE `exercise_mode_id` = '2'
ORDER BY `mode_name` ASC
ERROR - 2020-08-28 14:58:09 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 896
DEBUG - 2020-08-28 15:01:02 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:01:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:01:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:01:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:01:06 --> Total execution time: 0.1781
DEBUG - 2020-08-28 15:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:01:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:03:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:03:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:03:36 --> Total execution time: 0.1659
DEBUG - 2020-08-28 15:03:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:03:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 15:03:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-08-28 15:03:38 --> Total execution time: 0.1964
DEBUG - 2020-08-28 15:03:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:03:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:03:41 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:04:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:04:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:04:12 --> Total execution time: 0.1387
DEBUG - 2020-08-28 15:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:04:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:04:15 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:04:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:04:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:04:35 --> Total execution time: 0.1603
DEBUG - 2020-08-28 15:05:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:05:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:05:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:05:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 15:05:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-08-28 15:05:37 --> Total execution time: 0.1404
DEBUG - 2020-08-28 15:05:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:05:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:05:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:06:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:06:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:06:01 --> Total execution time: 0.1734
DEBUG - 2020-08-28 15:06:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:06:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:06:22 --> Total execution time: 0.1604
DEBUG - 2020-08-28 15:06:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:06:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:06:29 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-08-28 15:06:29 --> Total execution time: 0.1495
DEBUG - 2020-08-28 15:06:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:06:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:06:33 --> get_subcategory_list->{"lang":"37","category_id":"126","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 15:06:33 --> Total execution time: 0.1338
DEBUG - 2020-08-28 15:06:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:06:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:06:38 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-28 15:06:38 --> Total execution time: 0.0988
DEBUG - 2020-08-28 15:06:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:06:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 15:06:46 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-08-28 15:06:46 --> Total execution time: 0.1449
DEBUG - 2020-08-28 15:06:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:06:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:06:52 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-28 15:06:52 --> Total execution time: 0.1716
DEBUG - 2020-08-28 15:06:56 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:06:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:06:56 --> get_dialogue_type_1->{"slang":"37","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-28 15:06:56 --> Total execution time: 0.1341
DEBUG - 2020-08-28 15:07:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:07:16 --> Total execution time: 0.1203
DEBUG - 2020-08-28 15:07:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:07:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:07:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:07:59 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:07:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:08:02 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:08:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 15:08:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-08-28 15:08:02 --> Total execution time: 0.1607
DEBUG - 2020-08-28 15:08:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:08:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:08:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:08:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:08:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:08:10 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-28 15:08:10 --> Total execution time: 0.1117
DEBUG - 2020-08-28 15:08:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:08:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:08:21 --> get_dialogue_type_1->{"slang":"37","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-28 15:08:21 --> Total execution time: 0.1435
DEBUG - 2020-08-28 15:08:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:08:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:08:32 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-28 15:08:32 --> Total execution time: 0.1011
DEBUG - 2020-08-28 15:08:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:08:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:08:36 --> Total execution time: 0.1517
DEBUG - 2020-08-28 15:08:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:08:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:08:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:10:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:10:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:10:08 --> get_subcategory_list->{"lang":"37","category_id":"126","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 15:10:08 --> Total execution time: 0.1019
DEBUG - 2020-08-28 15:10:13 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:10:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:10:13 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-28 15:10:13 --> Total execution time: 0.1106
DEBUG - 2020-08-28 15:10:17 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:10:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:10:17 --> get_dialogue_type_1->{"slang":"37","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-28 15:10:17 --> Total execution time: 0.1293
DEBUG - 2020-08-28 15:10:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:10:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:10:24 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-28 15:10:24 --> Total execution time: 0.1392
DEBUG - 2020-08-28 15:10:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:10:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:10:28 --> get_subcategory_list->{"lang":"37","category_id":"126","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 15:10:28 --> Total execution time: 0.1320
DEBUG - 2020-08-28 15:10:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:10:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:10:32 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-08-28 15:10:32 --> Total execution time: 0.1159
DEBUG - 2020-08-28 15:11:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:11:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:11:06 --> Total execution time: 0.1120
DEBUG - 2020-08-28 15:11:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:11:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:11:23 --> Total execution time: 0.1507
DEBUG - 2020-08-28 15:12:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:12:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:12:11 --> Total execution time: 0.1188
DEBUG - 2020-08-28 15:12:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:12:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:12:16 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"2"}
DEBUG - 2020-08-28 15:12:16 --> Total execution time: 0.1029
DEBUG - 2020-08-28 15:12:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:12:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:12:20 --> get_subcategory_list->{"lang":"37","category_id":"127","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 15:12:20 --> Total execution time: 0.1284
DEBUG - 2020-08-28 15:12:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:12:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:12:23 --> get_exercise_type_list->{"lang":"37","subcategory_id":"276","support_lang_id":"2"}
DEBUG - 2020-08-28 15:12:23 --> Total execution time: 0.1343
DEBUG - 2020-08-28 15:12:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:12:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:12:27 --> get_phrases_type_1->{"slang":"37","tlang":"2","exercise_mode_id":"3","category_id":"127","subcategory_id":"276","support_lang_id":"2"}
DEBUG - 2020-08-28 15:12:27 --> Total execution time: 0.1382
DEBUG - 2020-08-28 15:12:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:12:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:12:31 --> get_exercise_type_list->{"lang":"37","subcategory_id":"276","support_lang_id":"2"}
DEBUG - 2020-08-28 15:12:31 --> Total execution time: 0.1569
DEBUG - 2020-08-28 15:12:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:12:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:12:33 --> get_subcategory_list->{"lang":"37","category_id":"127","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 15:12:33 --> Total execution time: 0.1497
DEBUG - 2020-08-28 15:12:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:12:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:12:35 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"2"}
DEBUG - 2020-08-28 15:12:35 --> Total execution time: 0.1144
DEBUG - 2020-08-28 15:12:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:12:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:12:40 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"2"}
DEBUG - 2020-08-28 15:12:40 --> Total execution time: 0.1477
DEBUG - 2020-08-28 15:12:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:12:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:12:44 --> get_subcategory_list->{"lang":"37","category_id":"124","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 15:12:44 --> Total execution time: 0.1427
DEBUG - 2020-08-28 15:12:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:12:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:12:48 --> get_exercise_type_list->{"lang":"37","subcategory_id":"274","support_lang_id":"2"}
DEBUG - 2020-08-28 15:12:48 --> Total execution time: 0.1470
DEBUG - 2020-08-28 15:12:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:12:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:12:52 --> get_subcategory_list->{"lang":"37","category_id":"124","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 15:12:52 --> Total execution time: 0.1363
DEBUG - 2020-08-28 15:13:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:13:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:13:18 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"2"}
DEBUG - 2020-08-28 15:13:18 --> Total execution time: 0.1451
DEBUG - 2020-08-28 15:13:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:13:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:13:57 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"2"}
DEBUG - 2020-08-28 15:13:57 --> Total execution time: 0.1313
DEBUG - 2020-08-28 15:14:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:14:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:14:01 --> get_subcategory_list->{"lang":"37","category_id":"124","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 15:14:01 --> Total execution time: 0.1248
DEBUG - 2020-08-28 15:14:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:14:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:14:41 --> get_exercise_type_list->{"lang":"37","subcategory_id":"274","support_lang_id":"2"}
DEBUG - 2020-08-28 15:14:41 --> Total execution time: 0.1640
DEBUG - 2020-08-28 15:15:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:15:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:15:01 --> Total execution time: 0.1538
DEBUG - 2020-08-28 15:15:03 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:15:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:15:03 --> get_subcategory_list->{"lang":"37","category_id":"124","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 15:15:03 --> Total execution time: 0.1197
DEBUG - 2020-08-28 15:15:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:15:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:15:04 --> Total execution time: 0.1320
DEBUG - 2020-08-28 15:15:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:15:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:15:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:15:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:15:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:15:16 --> Total execution time: 0.1357
DEBUG - 2020-08-28 15:15:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:15:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:15:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:15:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:15:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:15:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:15:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:15:39 --> Total execution time: 0.1870
DEBUG - 2020-08-28 15:15:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:15:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:15:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:15:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:15:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:15:53 --> get_exercise_type_list->{"lang":"37","subcategory_id":"274","support_lang_id":"2"}
DEBUG - 2020-08-28 15:15:53 --> Total execution time: 0.1454
DEBUG - 2020-08-28 15:15:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:15:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:15:59 --> get_grammer_type_2->{"slang":"37","tlang":"2","exercise_mode_id":"4","category_id":"124","subcategory_id":"274","support_lang_id":"2"}
ERROR - 2020-08-28 15:15:59 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-08-28 15:15:59 --> Total execution time: 0.1505
DEBUG - 2020-08-28 15:16:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:16:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:16:10 --> Total execution time: 0.1830
DEBUG - 2020-08-28 15:16:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:16:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 15:16:12 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-08-28 15:16:12 --> Total execution time: 0.1929
DEBUG - 2020-08-28 15:16:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:16:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:16:15 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:16:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:16:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:16:21 --> Total execution time: 0.1683
DEBUG - 2020-08-28 15:16:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:16:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:16:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:16:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:16:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 15:16:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-08-28 15:16:36 --> Total execution time: 0.2061
DEBUG - 2020-08-28 15:16:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:16:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:16:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:16:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:16:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:16:44 --> Total execution time: 0.1438
DEBUG - 2020-08-28 15:16:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:16:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:16:47 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:16:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:16:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:16:58 --> Total execution time: 0.1423
DEBUG - 2020-08-28 15:17:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:17:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:17:19 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:17:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 15:17:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-08-28 15:17:19 --> Total execution time: 0.1259
DEBUG - 2020-08-28 15:17:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:17:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:17:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:17:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:17:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:17:34 --> get_exercise_type_list->{"lang":"37","subcategory_id":"274","support_lang_id":"2"}
DEBUG - 2020-08-28 15:17:34 --> Total execution time: 0.1285
DEBUG - 2020-08-28 15:17:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:17:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:17:39 --> get_grammer_type_2->{"slang":"37","tlang":"2","exercise_mode_id":"4","category_id":"124","subcategory_id":"274","support_lang_id":"2"}
DEBUG - 2020-08-28 15:17:39 --> Total execution time: 0.1065
DEBUG - 2020-08-28 15:17:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:17:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:17:46 --> Total execution time: 0.1200
DEBUG - 2020-08-28 15:17:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:17:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:17:47 --> get_exercise_type_list->{"lang":"37","subcategory_id":"274","support_lang_id":"2"}
DEBUG - 2020-08-28 15:17:47 --> Total execution time: 0.1197
DEBUG - 2020-08-28 15:17:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:17:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:17:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:17:51 --> get_subcategory_list->{"lang":"37","category_id":"124","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 15:17:51 --> Total execution time: 0.1595
DEBUG - 2020-08-28 15:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:17:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:17:51 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"2"}
DEBUG - 2020-08-28 15:17:51 --> Total execution time: 0.1566
DEBUG - 2020-08-28 15:17:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:17:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:17:54 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"2"}
DEBUG - 2020-08-28 15:17:54 --> Total execution time: 0.1390
DEBUG - 2020-08-28 15:17:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:17:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:17:57 --> get_subcategory_list->{"lang":"37","category_id":"125","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 15:17:57 --> Total execution time: 0.1018
DEBUG - 2020-08-28 15:18:02 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:18:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:18:02 --> get_exercise_type_list->{"lang":"37","subcategory_id":"275","support_lang_id":"2"}
DEBUG - 2020-08-28 15:18:02 --> Total execution time: 0.1107
DEBUG - 2020-08-28 15:18:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:18:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 15:18:06 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-08-28 15:18:06 --> Total execution time: 0.1484
DEBUG - 2020-08-28 15:18:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:18:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:18:09 --> get_exercise_type_list->{"lang":"37","subcategory_id":"275","support_lang_id":"2"}
DEBUG - 2020-08-28 15:18:09 --> Total execution time: 0.1759
DEBUG - 2020-08-28 15:18:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:18:52 --> Total execution time: 0.1548
DEBUG - 2020-08-28 15:18:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:18:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 15:18:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-08-28 15:18:55 --> Total execution time: 0.1817
DEBUG - 2020-08-28 15:18:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:18:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:18:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:18:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:18:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:18:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-28 15:19:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:19:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:19:07 --> Total execution time: 0.1666
DEBUG - 2020-08-28 15:19:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:19:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:19:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:19:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:19:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:19:15 --> get_subcategory_list->{"lang":"37","category_id":"125","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 15:19:15 --> Total execution time: 0.1168
DEBUG - 2020-08-28 15:19:17 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:19:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:19:17 --> Total execution time: 0.1344
DEBUG - 2020-08-28 15:19:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:19:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:19:20 --> Total execution time: 0.1651
DEBUG - 2020-08-28 15:19:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:19:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:19:21 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"2"}
DEBUG - 2020-08-28 15:19:21 --> Total execution time: 0.1109
DEBUG - 2020-08-28 15:19:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:19:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:19:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:19:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:19:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:19:40 --> Total execution time: 0.1555
DEBUG - 2020-08-28 15:19:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:19:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:19:42 --> Total execution time: 0.1727
DEBUG - 2020-08-28 15:19:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:19:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:19:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:20:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:20:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:20:04 --> Total execution time: 0.1328
DEBUG - 2020-08-28 15:20:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:20:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:20:07 --> Total execution time: 0.1342
DEBUG - 2020-08-28 15:20:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:20:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:20:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:20:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:20:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:20:40 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"2"}
DEBUG - 2020-08-28 15:20:40 --> Total execution time: 0.1283
DEBUG - 2020-08-28 15:20:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:20:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:20:47 --> get_subcategory_list->{"lang":"37","category_id":"125","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 15:20:47 --> Total execution time: 0.1354
DEBUG - 2020-08-28 15:20:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:20:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:20:51 --> Total execution time: 0.1726
DEBUG - 2020-08-28 15:20:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:20:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:20:54 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:21:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:21:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:21:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:21:05 --> 404 Page Not Found: Assets/js
DEBUG - 2020-08-28 15:21:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:21:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:21:26 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:21:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:21:26 --> Total execution time: 0.1590
DEBUG - 2020-08-28 15:21:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:21:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:21:29 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:21:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:21:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:21:40 --> get_exercise_type_list->{"lang":"37","subcategory_id":"275","support_lang_id":"2"}
DEBUG - 2020-08-28 15:21:40 --> Total execution time: 0.0985
DEBUG - 2020-08-28 15:21:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:21:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:21:46 --> get_culture_type_1->{"slang":"37","tlang":"2","exercise_mode_id":"5","category_id":"125","subcategory_id":"275","support_lang_id":"2"}
ERROR - 2020-08-28 15:21:46 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-08-28 15:21:46 --> Total execution time: 0.1525
DEBUG - 2020-08-28 15:21:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:21:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:21:58 --> Total execution time: 0.1339
DEBUG - 2020-08-28 15:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:22:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:22:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:22:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:22:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:22:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 15:22:08 --> Query error: Unknown column 'mode_name' in 'order clause' - Invalid query: SELECT *
FROM `tbl_exercise_type`
WHERE `exercise_mode_id` = '5'
ORDER BY `mode_name` ASC
ERROR - 2020-08-28 15:22:08 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 896
DEBUG - 2020-08-28 15:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:22:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:22:08 --> Total execution time: 0.1650
DEBUG - 2020-08-28 15:22:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:22:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:22:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:22:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:22:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:22:23 --> 404 Page Not Found: Assets/js
DEBUG - 2020-08-28 15:24:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:24:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:24:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:24:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:24:24 --> Total execution time: 0.1885
DEBUG - 2020-08-28 15:24:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:24:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:24:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:24:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:24:30 --> get_exercise_type_list->{"lang":"37","subcategory_id":"275","support_lang_id":"2"}
DEBUG - 2020-08-28 15:24:30 --> Total execution time: 0.1615
DEBUG - 2020-08-28 15:25:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:25:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:25:25 --> Total execution time: 0.1590
DEBUG - 2020-08-28 15:25:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:25:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:25:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:25:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 15:25:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-08-28 15:25:27 --> Total execution time: 0.1555
DEBUG - 2020-08-28 15:25:27 --> Total execution time: 0.1580
DEBUG - 2020-08-28 15:25:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:25:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:25:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:25:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:25:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:25:30 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-28 15:25:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:25:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:25:36 --> Total execution time: 0.1355
DEBUG - 2020-08-28 15:25:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:25:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:25:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:25:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:25:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:25:48 --> Total execution time: 0.1498
DEBUG - 2020-08-28 15:27:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:27:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:27:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:27:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 15:27:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2020-08-28 15:27:07 --> Total execution time: 0.1906
DEBUG - 2020-08-28 15:27:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:27:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:27:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:27:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:27:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:27:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-28 15:27:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:27:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:27:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-28 15:27:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:27:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:27:22 --> get_subcategory_list->{"lang":"37","category_id":"125","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 15:27:22 --> Total execution time: 0.1435
DEBUG - 2020-08-28 15:27:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:27:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:27:27 --> get_exercise_type_list->{"lang":"37","subcategory_id":"278","support_lang_id":"2"}
DEBUG - 2020-08-28 15:27:27 --> Total execution time: 0.1058
DEBUG - 2020-08-28 15:27:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:27:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 15:27:32 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-08-28 15:27:32 --> Total execution time: 0.1446
DEBUG - 2020-08-28 15:27:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:27:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:27:43 --> get_exercise_type_list->{"lang":"37","subcategory_id":"278","support_lang_id":"2"}
DEBUG - 2020-08-28 15:27:43 --> Total execution time: 0.1392
DEBUG - 2020-08-28 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:27:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:27:48 --> get_subcategory_list->{"lang":"37","category_id":"125","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-28 15:27:48 --> Total execution time: 0.1488
DEBUG - 2020-08-28 15:27:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:27:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:27:52 --> get_exercise_type_list->{"lang":"37","subcategory_id":"275","support_lang_id":"2"}
DEBUG - 2020-08-28 15:27:52 --> Total execution time: 0.1286
DEBUG - 2020-08-28 15:27:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:27:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:27:59 --> get_culture_type_1->{"slang":"37","tlang":"2","exercise_mode_id":"5","category_id":"125","subcategory_id":"275","support_lang_id":"2"}
ERROR - 2020-08-28 15:27:59 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-08-28 15:27:59 --> Total execution time: 0.1240
DEBUG - 2020-08-28 15:28:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:28:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:28:10 --> Total execution time: 0.1551
DEBUG - 2020-08-28 15:28:13 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:28:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:28:13 --> Total execution time: 0.1980
DEBUG - 2020-08-28 15:28:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:28:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:28:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:28:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:28:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:28:36 --> Total execution time: 0.2213
DEBUG - 2020-08-28 15:28:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:28:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:28:39 --> Total execution time: 0.1246
DEBUG - 2020-08-28 15:28:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:28:41 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:28:50 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:28:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:28:50 --> Total execution time: 0.1713
DEBUG - 2020-08-28 15:28:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:28:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:28:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:29:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:29:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:29:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:29:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:29:18 --> Total execution time: 0.1874
DEBUG - 2020-08-28 15:29:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:29:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:29:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 15:29:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:29:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:29:39 --> Total execution time: 0.1368
DEBUG - 2020-08-28 15:29:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 15:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 15:29:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 15:29:41 --> Total execution time: 0.1321
DEBUG - 2020-08-28 15:29:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 15:29:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-28 15:29:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-28 16:32:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-28 16:32:22 --> No URI present. Default controller set.
DEBUG - 2020-08-28 16:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-28 16:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-28 16:32:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 16:32:22 --> Total execution time: 0.1900
