<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-07-20 02:39:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:20 --> No URI present. Default controller set.
DEBUG - 2020-07-20 02:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:39:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:39:21 --> Total execution time: 0.7769
DEBUG - 2020-07-20 02:39:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:21 --> No URI present. Default controller set.
DEBUG - 2020-07-20 02:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:39:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:39:21 --> Total execution time: 0.1452
DEBUG - 2020-07-20 02:39:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:39:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:39:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:39:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:39:53 --> Total execution time: 0.2690
DEBUG - 2020-07-20 02:39:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 02:39:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:54 --> UTF-8 Support Enabled
ERROR - 2020-07-20 02:39:54 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-20 02:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:54 --> 404 Page Not Found: Uploads/colours.jpg
ERROR - 2020-07-20 02:39:54 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-20 02:39:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:54 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-20 02:39:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:54 --> UTF-8 Support Enabled
ERROR - 2020-07-20 02:39:54 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-20 02:39:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:54 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-20 02:39:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:54 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-20 02:39:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:54 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-20 02:39:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:54 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-20 02:39:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:54 --> 404 Page Not Found: Uploads/employment.jpg
ERROR - 2020-07-20 02:39:54 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-20 02:39:54 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-20 02:39:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:54 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-20 02:39:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:54 --> UTF-8 Support Enabled
ERROR - 2020-07-20 02:39:54 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-20 02:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:55 --> UTF-8 Support Enabled
ERROR - 2020-07-20 02:39:55 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-20 02:39:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:55 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-20 02:39:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:55 --> 404 Page Not Found: Uploads/legal_terminology.jpg
ERROR - 2020-07-20 02:39:55 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-20 02:39:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:55 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-20 02:39:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:55 --> 404 Page Not Found: Uploads/opposites.jpg
ERROR - 2020-07-20 02:39:55 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-20 02:39:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:55 --> UTF-8 Support Enabled
ERROR - 2020-07-20 02:39:55 --> 404 Page Not Found: Uploads/professions.jpg
ERROR - 2020-07-20 02:39:55 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-20 02:39:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:55 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-20 02:39:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:55 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-20 02:39:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:55 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-20 02:39:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:55 --> UTF-8 Support Enabled
ERROR - 2020-07-20 02:39:55 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-20 02:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:55 --> UTF-8 Support Enabled
ERROR - 2020-07-20 02:39:55 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-20 02:39:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:55 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-20 02:39:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:55 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-20 02:39:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:55 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-20 02:39:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:56 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-20 02:39:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:56 --> 404 Page Not Found: Uploads/clothes.jpg
ERROR - 2020-07-20 02:39:56 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-20 02:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:56 --> 404 Page Not Found: Uploads/animals.jpg
ERROR - 2020-07-20 02:39:56 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-20 02:39:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:56 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-20 02:39:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:56 --> UTF-8 Support Enabled
ERROR - 2020-07-20 02:39:56 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-20 02:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:56 --> UTF-8 Support Enabled
ERROR - 2020-07-20 02:39:56 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-20 02:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:56 --> UTF-8 Support Enabled
ERROR - 2020-07-20 02:39:56 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-20 02:39:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:56 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-20 02:39:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:57 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-20 02:39:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:57 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
ERROR - 2020-07-20 02:39:57 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-20 02:39:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:39:57 --> UTF-8 Support Enabled
ERROR - 2020-07-20 02:39:57 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-20 02:39:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:39:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:57 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-20 02:39:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:39:57 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-20 02:41:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:41:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:41:18 --> Total execution time: 0.1444
DEBUG - 2020-07-20 02:41:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 02:41:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:19 --> 404 Page Not Found: Uploads/legal_terminology.jpg
ERROR - 2020-07-20 02:41:19 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-20 02:41:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:19 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-20 02:41:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:19 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-20 02:41:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:19 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-20 02:41:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:19 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-20 02:41:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:19 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-20 02:41:19 --> 404 Page Not Found: Uploads/animals.jpg
ERROR - 2020-07-20 02:41:19 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-20 02:41:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:19 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-20 02:41:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:19 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-20 02:41:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:19 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-20 02:41:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:20 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-20 02:41:20 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-20 02:41:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:20 --> 404 Page Not Found: Uploads/grammar.jpg
ERROR - 2020-07-20 02:41:20 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-20 02:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:20 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-20 02:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:20 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-20 02:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:20 --> 404 Page Not Found: Uploads/places.jpg
ERROR - 2020-07-20 02:41:20 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
ERROR - 2020-07-20 02:41:20 --> 404 Page Not Found: Uploads/home.jpg
ERROR - 2020-07-20 02:41:20 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-20 02:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:20 --> 404 Page Not Found: Uploads/professions.jpg
ERROR - 2020-07-20 02:41:20 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-20 02:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:20 --> 404 Page Not Found: Uploads/shapes.png
ERROR - 2020-07-20 02:41:20 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-20 02:41:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:20 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-20 02:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:20 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-20 02:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:20 --> 404 Page Not Found: Uploads/weather.jpg
ERROR - 2020-07-20 02:41:20 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-20 02:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:20 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-20 02:41:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:21 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-20 02:41:21 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-20 02:41:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:41:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:41:23 --> Total execution time: 0.1391
DEBUG - 2020-07-20 02:41:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:24 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-20 02:41:24 --> 404 Page Not Found: Uploads/animals.jpg
ERROR - 2020-07-20 02:41:24 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-20 02:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:24 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-20 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:24 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-20 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:24 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-20 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:24 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-20 02:41:24 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-20 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:24 --> UTF-8 Support Enabled
ERROR - 2020-07-20 02:41:24 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-20 02:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:24 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-20 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:24 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-20 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:24 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-20 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:24 --> 404 Page Not Found: Uploads/in_the_office.jpg
ERROR - 2020-07-20 02:41:24 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-20 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:24 --> 404 Page Not Found: Uploads/legal_terminology.jpg
ERROR - 2020-07-20 02:41:24 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-20 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:24 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-20 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:24 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-20 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:25 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-20 02:41:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:25 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-20 02:41:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:25 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-20 02:41:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:25 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-20 02:41:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:25 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-20 02:41:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:25 --> 404 Page Not Found: Uploads/sports.jpg
ERROR - 2020-07-20 02:41:25 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-20 02:41:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:25 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-20 02:41:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:25 --> 404 Page Not Found: Uploads/transport.jpg
ERROR - 2020-07-20 02:41:25 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-20 02:41:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:25 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-20 02:41:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:25 --> 404 Page Not Found: Uploads/weather.jpg
ERROR - 2020-07-20 02:41:25 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-20 02:41:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:26 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-20 02:41:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:41:26 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-20 02:41:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:41:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:41:31 --> Total execution time: 0.1535
DEBUG - 2020-07-20 02:44:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:44:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:44:22 --> Total execution time: 0.1553
DEBUG - 2020-07-20 02:44:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:44:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:44:54 --> Total execution time: 0.1396
DEBUG - 2020-07-20 02:45:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:45:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:45:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:45:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:45:14 --> Total execution time: 0.1290
DEBUG - 2020-07-20 02:45:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 02:45:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:45:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:14 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-20 02:45:14 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-20 02:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:45:14 --> UTF-8 Support Enabled
ERROR - 2020-07-20 02:45:14 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-20 02:45:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:14 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-20 02:45:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:14 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-20 02:45:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:14 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-20 02:45:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:15 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-20 02:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:15 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-20 02:45:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:45:15 --> UTF-8 Support Enabled
ERROR - 2020-07-20 02:45:15 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-20 02:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:15 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-20 02:45:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:15 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-20 02:45:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:15 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-20 02:45:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:15 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-20 02:45:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:15 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-20 02:45:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:15 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-20 02:45:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:15 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-20 02:45:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:15 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-20 02:45:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:15 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-20 02:45:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:15 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-20 02:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:15 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-20 02:45:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:15 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-20 02:45:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:15 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-20 02:45:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:45:15 --> UTF-8 Support Enabled
ERROR - 2020-07-20 02:45:15 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-20 02:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:15 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-20 02:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:45:16 --> UTF-8 Support Enabled
ERROR - 2020-07-20 02:45:16 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-20 02:45:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:16 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-20 02:45:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:16 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-20 02:45:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:16 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-20 02:45:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:16 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-20 02:45:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:16 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-20 02:45:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:16 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-20 02:45:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:45:16 --> UTF-8 Support Enabled
ERROR - 2020-07-20 02:45:16 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-20 02:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:45:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:16 --> 404 Page Not Found: Uploads/clothes.jpg
ERROR - 2020-07-20 02:45:16 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-20 02:45:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:16 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-20 02:45:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:16 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-20 02:45:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:16 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-20 02:45:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:45:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:17 --> 404 Page Not Found: Uploads/grammar.jpg
ERROR - 2020-07-20 02:45:17 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-20 02:45:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:17 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-20 02:45:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:45:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:45:17 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-20 02:49:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:49:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:49:18 --> Total execution time: 0.1659
DEBUG - 2020-07-20 02:49:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 02:49:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:19 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-20 02:49:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:19 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-20 02:49:19 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-20 02:49:19 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-20 02:49:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:19 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-20 02:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:19 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-20 02:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:19 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-20 02:49:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:19 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-20 02:49:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:19 --> UTF-8 Support Enabled
ERROR - 2020-07-20 02:49:19 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-20 02:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:19 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-20 02:49:19 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-20 02:49:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:19 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-20 02:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:19 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-20 02:49:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:20 --> UTF-8 Support Enabled
ERROR - 2020-07-20 02:49:20 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-20 02:49:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:20 --> 404 Page Not Found: Uploads/materials.jpg
ERROR - 2020-07-20 02:49:20 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-20 02:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:20 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-20 02:49:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:20 --> 404 Page Not Found: Uploads/music.jpg
ERROR - 2020-07-20 02:49:20 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-20 02:49:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:20 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
ERROR - 2020-07-20 02:49:20 --> 404 Page Not Found: Uploads/places.jpg
ERROR - 2020-07-20 02:49:20 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-20 02:49:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:20 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-20 02:49:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:20 --> 404 Page Not Found: Uploads/shapes.png
ERROR - 2020-07-20 02:49:20 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-20 02:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:20 --> 404 Page Not Found: Uploads/supermarket.jpg
ERROR - 2020-07-20 02:49:20 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-20 02:49:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:20 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-20 02:49:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:20 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-20 02:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:20 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
ERROR - 2020-07-20 02:49:20 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-20 02:49:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:21 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-20 02:49:21 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-20 02:49:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:49:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:49:24 --> Total execution time: 0.1654
DEBUG - 2020-07-20 02:49:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 02:49:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:24 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-20 02:49:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:25 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-20 02:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:25 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-20 02:49:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:25 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-20 02:49:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:25 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-20 02:49:25 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-20 02:49:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:25 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-20 02:49:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:25 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-20 02:49:25 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-20 02:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:25 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-20 02:49:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:25 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-20 02:49:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:25 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-20 02:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:25 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-20 02:49:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:25 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-20 02:49:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:25 --> 404 Page Not Found: Uploads/in_the_office.jpg
ERROR - 2020-07-20 02:49:25 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-20 02:49:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:25 --> 404 Page Not Found: Uploads/months_and_days.jpg
ERROR - 2020-07-20 02:49:25 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-20 02:49:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:25 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-20 02:49:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:26 --> UTF-8 Support Enabled
ERROR - 2020-07-20 02:49:26 --> 404 Page Not Found: Uploads/opposites.jpg
ERROR - 2020-07-20 02:49:26 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-20 02:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:26 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-20 02:49:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:26 --> UTF-8 Support Enabled
ERROR - 2020-07-20 02:49:26 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-20 02:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:26 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-20 02:49:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:26 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-20 02:49:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:26 --> 404 Page Not Found: Uploads/transport.jpg
ERROR - 2020-07-20 02:49:26 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-20 02:49:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:26 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-20 02:49:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:26 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-20 02:49:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:26 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-20 02:49:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:26 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-20 02:49:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:26 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-20 02:49:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:27 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-20 02:49:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:49:27 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-20 02:49:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:49:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:50:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:50:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:50:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:51:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:51:21 --> No URI present. Default controller set.
DEBUG - 2020-07-20 02:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:51:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:51:21 --> Total execution time: 0.1092
DEBUG - 2020-07-20 02:51:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:51:22 --> No URI present. Default controller set.
DEBUG - 2020-07-20 02:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:51:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:51:22 --> Total execution time: 0.1484
DEBUG - 2020-07-20 02:51:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:51:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:51:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:51:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:51:36 --> Total execution time: 0.1293
DEBUG - 2020-07-20 02:51:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:51:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:51:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 02:51:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:51:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:51:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-20 02:51:45 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\header.php 86
DEBUG - 2020-07-20 02:51:45 --> Total execution time: 0.1521
DEBUG - 2020-07-20 02:51:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:51:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 02:51:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 02:54:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:54:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:54:32 --> Upload class already loaded. Second attempt ignored.
ERROR - 2020-07-20 02:54:33 --> Severity: error --> Exception: Call to undefined function finfo_open() E:\xampp\htdocs\voolsy\langoadmin\system\libraries\Upload.php 1222
DEBUG - 2020-07-20 02:55:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:55:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:55:41 --> Upload class already loaded. Second attempt ignored.
ERROR - 2020-07-20 02:55:41 --> Severity: error --> Exception: Call to undefined function finfo_open() E:\xampp\htdocs\voolsy\langoadmin\system\libraries\Upload.php 1222
DEBUG - 2020-07-20 02:55:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:55:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:55:46 --> Upload class already loaded. Second attempt ignored.
ERROR - 2020-07-20 02:55:46 --> Severity: error --> Exception: Call to undefined function finfo_open() E:\xampp\htdocs\voolsy\langoadmin\system\libraries\Upload.php 1222
DEBUG - 2020-07-20 02:56:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:56:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:56:04 --> Upload class already loaded. Second attempt ignored.
ERROR - 2020-07-20 02:56:04 --> Severity: error --> Exception: Call to undefined function finfo_open() E:\xampp\htdocs\voolsy\langoadmin\system\libraries\Upload.php 1222
DEBUG - 2020-07-20 02:56:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:56:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:56:25 --> Upload class already loaded. Second attempt ignored.
ERROR - 2020-07-20 02:56:25 --> Severity: error --> Exception: Call to undefined function finfo_open() E:\xampp\htdocs\voolsy\langoadmin\system\libraries\Upload.php 1222
DEBUG - 2020-07-20 02:57:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:57:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:57:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:57:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:57:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:57:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:57:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:57:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:58:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:58:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:58:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:58:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:58:59 --> Upload class already loaded. Second attempt ignored.
ERROR - 2020-07-20 02:58:59 --> Severity: error --> Exception: Call to undefined function finfo_open() E:\xampp\htdocs\voolsy\langoadmin\system\libraries\Upload.php 1222
DEBUG - 2020-07-20 02:59:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 02:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 02:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 02:59:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 02:59:34 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:01:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:01:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:01:36 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:01:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:01:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:01:37 --> Total execution time: 0.1418
DEBUG - 2020-07-20 03:01:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:01:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:01:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:02:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:02:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:02:01 --> Total execution time: 0.1402
DEBUG - 2020-07-20 03:02:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:02:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:02:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:02:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:02:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:02:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:02:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:02:17 --> Total execution time: 0.1501
DEBUG - 2020-07-20 03:02:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:02:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:02:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:02:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:02:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:02:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:02:39 --> Total execution time: 0.1609
DEBUG - 2020-07-20 03:02:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:02:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:02:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:02:43 --> Total execution time: 0.1376
DEBUG - 2020-07-20 03:10:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:10:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:10:41 --> Total execution time: 0.1716
DEBUG - 2020-07-20 03:10:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:10:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:10:41 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:10:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:10:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:10:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:10:46 --> Total execution time: 0.1436
DEBUG - 2020-07-20 03:10:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:10:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:10:46 --> Total execution time: 0.1183
DEBUG - 2020-07-20 03:10:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:10:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:10:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:10:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:10:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:10:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:10:49 --> Total execution time: 0.1412
DEBUG - 2020-07-20 03:10:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:10:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:10:50 --> Total execution time: 0.1239
DEBUG - 2020-07-20 03:10:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:10:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:10:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:10:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:10:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:10:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:10:53 --> Total execution time: 0.1383
DEBUG - 2020-07-20 03:10:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:10:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:10:53 --> Total execution time: 0.1326
DEBUG - 2020-07-20 03:10:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:10:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:10:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:11:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:11:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:11:18 --> Total execution time: 0.1015
DEBUG - 2020-07-20 03:11:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:11:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:11:18 --> Total execution time: 0.1985
DEBUG - 2020-07-20 03:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:19 --> 404 Page Not Found: Uploads/accessories.jpg
DEBUG - 2020-07-20 03:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:19 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:11:19 --> 404 Page Not Found: Uploads/adverbs.jpg
ERROR - 2020-07-20 03:11:19 --> 404 Page Not Found: Uploads/animals_in_the_world.jpg
DEBUG - 2020-07-20 03:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:19 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:11:19 --> 404 Page Not Found: Uploads/animals_in_europe.jpg
DEBUG - 2020-07-20 03:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:19 --> 404 Page Not Found: Uploads/animals_with_hooves.jpg
DEBUG - 2020-07-20 03:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:19 --> 404 Page Not Found: Uploads/appearance.jpg
DEBUG - 2020-07-20 03:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:19 --> 404 Page Not Found: Uploads/baby_toiletries.jpg
DEBUG - 2020-07-20 03:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:19 --> 404 Page Not Found: Uploads/at_home.jpg
DEBUG - 2020-07-20 03:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:19 --> 404 Page Not Found: Uploads/At__the_dentists.JPG
DEBUG - 2020-07-20 03:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:19 --> 404 Page Not Found: Uploads/baby_clothes.jpg
ERROR - 2020-07-20 03:11:19 --> 404 Page Not Found: Uploads/bakery_and_pasta.jpg
DEBUG - 2020-07-20 03:11:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:19 --> 404 Page Not Found: Uploads/bathroom.jpg
DEBUG - 2020-07-20 03:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:20 --> 404 Page Not Found: Uploads/bedroom.jpg
DEBUG - 2020-07-20 03:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:20 --> 404 Page Not Found: Uploads/berries.jpg
DEBUG - 2020-07-20 03:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:20 --> 404 Page Not Found: Uploads/childrens_clothes.jpg
DEBUG - 2020-07-20 03:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:20 --> 404 Page Not Found: Uploads/body_parts.jpg
DEBUG - 2020-07-20 03:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:20 --> 404 Page Not Found: Uploads/birds.jpg
ERROR - 2020-07-20 03:11:20 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-20 03:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:20 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-20 03:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:20 --> 404 Page Not Found: Uploads/containers_and_portions.jpg
DEBUG - 2020-07-20 03:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:20 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:11:20 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-20 03:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:20 --> 404 Page Not Found: Uploads/cooking_verbs.jpg
DEBUG - 2020-07-20 03:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:20 --> 404 Page Not Found: Uploads/opposites_doubles.jpg
ERROR - 2020-07-20 03:11:20 --> 404 Page Not Found: Uploads/dairy.jpg
DEBUG - 2020-07-20 03:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:20 --> 404 Page Not Found: Uploads/drinks.jpg
DEBUG - 2020-07-20 03:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:20 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:11:20 --> 404 Page Not Found: Uploads/electronic_appliances.jpg
DEBUG - 2020-07-20 03:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:20 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-20 03:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:20 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-20 03:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:20 --> 404 Page Not Found: Uploads/equipment.jpg
DEBUG - 2020-07-20 03:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:20 --> 404 Page Not Found: Uploads/everyday_life.jpg
DEBUG - 2020-07-20 03:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:21 --> 404 Page Not Found: Uploads/fish_and_seafood.jpg
DEBUG - 2020-07-20 03:11:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:21 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-20 03:11:21 --> 404 Page Not Found: Uploads/face_and_head.jpg
DEBUG - 2020-07-20 03:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:21 --> 404 Page Not Found: Uploads/fixtures.jpg
DEBUG - 2020-07-20 03:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:21 --> 404 Page Not Found: Uploads/fruits.jpg
ERROR - 2020-07-20 03:11:21 --> 404 Page Not Found: Uploads/furniture.jpg
DEBUG - 2020-07-20 03:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:21 --> 404 Page Not Found: Uploads/grains_and_cereals.jpg
ERROR - 2020-07-20 03:11:21 --> 404 Page Not Found: Uploads/generic.jpg
ERROR - 2020-07-20 03:11:21 --> 404 Page Not Found: Uploads/ground_and_air.jpg
DEBUG - 2020-07-20 03:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:21 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:11:21 --> 404 Page Not Found: Uploads/illnesses.jpg
DEBUG - 2020-07-20 03:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:21 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:11:21 --> 404 Page Not Found: Uploads/herbs_and_spices.jpg
DEBUG - 2020-07-20 03:11:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:21 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-20 03:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:21 --> 404 Page Not Found: Uploads/insects.jpg
ERROR - 2020-07-20 03:11:21 --> 404 Page Not Found: Uploads/in_the_kitchen.jpg
DEBUG - 2020-07-20 03:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:21 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-20 03:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:21 --> 404 Page Not Found: Uploads/items_at_home.jpg
ERROR - 2020-07-20 03:11:21 --> 404 Page Not Found: Uploads/laundry_and_cleaning.jpg
DEBUG - 2020-07-20 03:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:21 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-20 03:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:21 --> 404 Page Not Found: Uploads/materials_and_patterns.jpg
ERROR - 2020-07-20 03:11:21 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-20 03:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:22 --> 404 Page Not Found: Uploads/meat.jpg
DEBUG - 2020-07-20 03:11:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:22 --> 404 Page Not Found: Uploads/medical_symptoms.jpg
ERROR - 2020-07-20 03:11:22 --> 404 Page Not Found: Uploads/medical_equipment.jpg
DEBUG - 2020-07-20 03:11:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:22 --> 404 Page Not Found: Uploads/medical_terms.jpg
DEBUG - 2020-07-20 03:11:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:22 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-20 03:11:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:22 --> 404 Page Not Found: Uploads/Mushrooms.jpg
DEBUG - 2020-07-20 03:11:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:22 --> 404 Page Not Found: Uploads/medication.jpg
DEBUG - 2020-07-20 03:11:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:22 --> 404 Page Not Found: Uploads/nationalities.jpg
DEBUG - 2020-07-20 03:11:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:22 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-20 03:11:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:22 --> 404 Page Not Found: Uploads/numbers_cardinals.png
DEBUG - 2020-07-20 03:11:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:22 --> 404 Page Not Found: Uploads/numbers_ordinals.png
DEBUG - 2020-07-20 03:11:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:22 --> 404 Page Not Found: Uploads/nuts_and_dried_fruit.jpg
DEBUG - 2020-07-20 03:11:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:22 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-20 03:11:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:22 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:11:22 --> 404 Page Not Found: Uploads/Ready_meals.JPG
DEBUG - 2020-07-20 03:11:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:22 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-20 03:11:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:22 --> 404 Page Not Found: Uploads/reptiles_and_amphibians.jpg
ERROR - 2020-07-20 03:11:22 --> 404 Page Not Found: Uploads/rooms.jpg
DEBUG - 2020-07-20 03:11:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:22 --> 404 Page Not Found: Uploads/scotland.jpg
ERROR - 2020-07-20 03:11:22 --> 404 Page Not Found: Uploads/Sauces_and_condiments.jpg
DEBUG - 2020-07-20 03:11:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:23 --> 404 Page Not Found: Uploads/sea_animals_and_fish.jpg
ERROR - 2020-07-20 03:11:23 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-20 03:11:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:23 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:11:23 --> 404 Page Not Found: Uploads/Toiletries.jpg
DEBUG - 2020-07-20 03:11:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:23 --> 404 Page Not Found: Uploads/Snacks_and_sweets.JPG
DEBUG - 2020-07-20 03:11:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:23 --> 404 Page Not Found: Uploads/shoes_and_trousers.jpg
DEBUG - 2020-07-20 03:11:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:23 --> 404 Page Not Found: Uploads/sport_terms.png
DEBUG - 2020-07-20 03:11:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:23 --> 404 Page Not Found: Uploads/toys_and_games.jpg
ERROR - 2020-07-20 03:11:23 --> 404 Page Not Found: Uploads/tools_and_diy.jpg
DEBUG - 2020-07-20 03:11:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:23 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-20 03:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:23 --> 404 Page Not Found: Uploads/transport.jpg
ERROR - 2020-07-20 03:11:23 --> 404 Page Not Found: Uploads/types_of_sports.jpg
DEBUG - 2020-07-20 03:11:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:23 --> 404 Page Not Found: Uploads/Vegetables.JPG
DEBUG - 2020-07-20 03:11:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:11:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:23 --> 404 Page Not Found: Uploads/2_verbs.png
ERROR - 2020-07-20 03:11:23 --> 404 Page Not Found: Uploads/weather.jpg
ERROR - 2020-07-20 03:11:23 --> 404 Page Not Found: Uploads/1_verbs.png
DEBUG - 2020-07-20 03:11:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:23 --> 404 Page Not Found: Uploads/water.jpg
DEBUG - 2020-07-20 03:11:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:11:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:11:23 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-20 03:17:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:17:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:17:43 --> Total execution time: 0.1464
DEBUG - 2020-07-20 03:17:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:17:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:17:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:17:47 --> Total execution time: 0.1265
DEBUG - 2020-07-20 03:17:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:17:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:17:48 --> Total execution time: 0.5847
DEBUG - 2020-07-20 03:17:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:17:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:17:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:49 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:17:49 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:17:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:17:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:49 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:17:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:17:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:49 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:17:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:17:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:49 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:17:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:50 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:17:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:17:50 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:17:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:17:51 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:17:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:17:51 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:17:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:17:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:51 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:17:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:17:51 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:17:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:17:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:51 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:17:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:17:51 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:17:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:17:51 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:17:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:17:52 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:17:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:17:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:52 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:17:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:17:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:52 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:17:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:17:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:52 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:17:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:17:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:17:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:18:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:18:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:18:58 --> Total execution time: 0.2880
DEBUG - 2020-07-20 03:18:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:18:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:18:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:18:58 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:18:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:18:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:18:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:18:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:18:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:18:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:18:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:18:58 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:18:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:18:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:18:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:18:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:18:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:18:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:18:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:18:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:18:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:18:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:18:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:18:59 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:18:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:18:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:18:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:18:59 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:18:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:18:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:18:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:18:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:18:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:18:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:18:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:18:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:18:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:18:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:18:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:18:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:18:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:18:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:18:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:00 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:19:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:00 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:00 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:00 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:00 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:19:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:00 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:01 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:19:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:01 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:19:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:01 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:01 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:01 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:02 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:02 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:19:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:19:07 --> Total execution time: 0.1566
DEBUG - 2020-07-20 03:19:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:19:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:19:07 --> Total execution time: 0.2535
DEBUG - 2020-07-20 03:19:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:19:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:08 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:08 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:08 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:08 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:09 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:09 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:09 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:19:09 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:09 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:09 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:19:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:09 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:10 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:10 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:10 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:10 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:10 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:19:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:10 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:11 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:11 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:11 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:11 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:19:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:19:11 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:19:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:19:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:19:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:22:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:22:18 --> Total execution time: 0.2865
DEBUG - 2020-07-20 03:22:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:22:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:19 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:22:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:19 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:22:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:19 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:22:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:19 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:22:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:20 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:22:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:20 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:22:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:20 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:22:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:20 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:22:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:20 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:22:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:21 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:22:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:21 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:22:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:21 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:22:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:21 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:22:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:21 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:22:21 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:22:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:21 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:22:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:21 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:22:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:22 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:22:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:22 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:22:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:22 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:22:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:22:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:22:45 --> Total execution time: 0.2922
DEBUG - 2020-07-20 03:22:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:22:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:46 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:22:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:47 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:22:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:47 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:22:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:47 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:22:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:47 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:48 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:22:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:48 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:22:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:48 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:22:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:22:49 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:22:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:22:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:24:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:24:19 --> Total execution time: 0.1781
DEBUG - 2020-07-20 03:24:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:24:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:25:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:25:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:25:19 --> Total execution time: 0.1053
DEBUG - 2020-07-20 03:25:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:25:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:25:19 --> Total execution time: 0.1249
DEBUG - 2020-07-20 03:25:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:25:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:25:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:27:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:27:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:27:31 --> Total execution time: 0.1238
DEBUG - 2020-07-20 03:27:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:27:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:27:31 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:27:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:27:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:27:35 --> Total execution time: 0.1383
DEBUG - 2020-07-20 03:27:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:27:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:27:35 --> Total execution time: 0.1682
DEBUG - 2020-07-20 03:27:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:27:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:27:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:27:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:27:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:27:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:27:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:27:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:27:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:27:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:27:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:27:36 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:27:36 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-20 03:27:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:27:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:27:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:27:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:27:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:27:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:27:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:27:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:27:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-20 03:30:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:30:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:30:17 --> Total execution time: 0.1330
DEBUG - 2020-07-20 03:30:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:30:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:30:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:30:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:30:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:30:21 --> Total execution time: 0.1551
DEBUG - 2020-07-20 03:30:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:30:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:30:21 --> Total execution time: 0.3135
DEBUG - 2020-07-20 03:30:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:30:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:30:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:32:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:32:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-20 03:32:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND w.support_lang_id='3' limit 0,100' at line 1 - Invalid query: select w.*,c.category_name from tbl_phrases w  LEFT JOIN tbl_exercise_mode_categories c ON c.exercise_mode_category_id=w.category_id where w.is_active='1' order by phrases_id desc  AND w.support_lang_id='3' limit 0,100 
ERROR - 2020-07-20 03:32:43 --> Severity: error --> Exception: Call to a member function result_array() on boolean E:\xampp\htdocs\voolsy\langoadmin\application\models\Admin_model.php 415
DEBUG - 2020-07-20 03:34:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:34:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:34:16 --> Total execution time: 0.2103
DEBUG - 2020-07-20 03:34:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:34:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:34:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:34:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:34:21 --> Total execution time: 0.1934
DEBUG - 2020-07-20 03:34:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:34:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:34:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:34:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:34:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:34:23 --> Total execution time: 0.1866
DEBUG - 2020-07-20 03:34:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:34:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:34:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:34:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:34:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:34:25 --> Total execution time: 0.2126
DEBUG - 2020-07-20 03:34:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:34:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:34:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:34:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:34:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:34:27 --> Total execution time: 0.1756
DEBUG - 2020-07-20 03:34:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:34:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:34:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:34:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:34:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:34:29 --> Total execution time: 0.1829
DEBUG - 2020-07-20 03:34:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:34:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:34:29 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:34:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:34:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:34:32 --> Total execution time: 0.1500
DEBUG - 2020-07-20 03:34:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:34:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:34:32 --> Total execution time: 0.1806
DEBUG - 2020-07-20 03:34:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:34:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:34:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:34:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:34:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:34:34 --> Total execution time: 0.1447
DEBUG - 2020-07-20 03:34:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:34:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:34:34 --> Total execution time: 0.1740
DEBUG - 2020-07-20 03:34:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:34:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:34:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:35:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:35:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-20 03:35:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''3' at line 1 - Invalid query: select w.*,c.category_name from tbl_phrases w  LEFT JOIN tbl_exercise_mode_categories c ON c.exercise_mode_category_id=w.category_id where w.is_active='1' AND w.support_lang_id='3
ERROR - 2020-07-20 03:35:24 --> Severity: error --> Exception: Call to a member function result_array() on boolean E:\xampp\htdocs\voolsy\langoadmin\application\models\Admin_model.php 387
DEBUG - 2020-07-20 03:35:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:35:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:35:43 --> Total execution time: 0.1683
DEBUG - 2020-07-20 03:35:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:35:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:35:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:35:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:35:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:35:47 --> Total execution time: 0.1399
DEBUG - 2020-07-20 03:35:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:35:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:35:48 --> Total execution time: 0.1189
DEBUG - 2020-07-20 03:35:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:35:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:35:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:35:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:35:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:35:50 --> Total execution time: 0.1263
DEBUG - 2020-07-20 03:35:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:35:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:35:50 --> Total execution time: 0.1222
DEBUG - 2020-07-20 03:35:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:35:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:35:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:35:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:35:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:35:52 --> Total execution time: 0.1365
DEBUG - 2020-07-20 03:35:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:35:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:35:52 --> Total execution time: 0.2414
DEBUG - 2020-07-20 03:35:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:35:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:35:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:35:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:35:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:35:54 --> Total execution time: 0.1354
DEBUG - 2020-07-20 03:35:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:35:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:35:54 --> Total execution time: 0.1185
DEBUG - 2020-07-20 03:35:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:35:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:35:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:35:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:35:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:35:56 --> Total execution time: 0.1463
DEBUG - 2020-07-20 03:35:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:35:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:35:56 --> Total execution time: 0.1288
DEBUG - 2020-07-20 03:35:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:35:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:35:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:35:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:35:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:35:58 --> Total execution time: 0.1527
DEBUG - 2020-07-20 03:35:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:35:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:35:59 --> Total execution time: 0.1227
DEBUG - 2020-07-20 03:35:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:35:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:35:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:36:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:36:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:36:03 --> Total execution time: 0.1479
DEBUG - 2020-07-20 03:36:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:36:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:36:03 --> Total execution time: 0.1416
DEBUG - 2020-07-20 03:36:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:36:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:36:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:36:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:36:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:36:05 --> Total execution time: 0.1592
DEBUG - 2020-07-20 03:36:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:36:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:36:05 --> Total execution time: 0.1358
DEBUG - 2020-07-20 03:36:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:36:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:36:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:36:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:36:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:36:06 --> Total execution time: 0.1125
DEBUG - 2020-07-20 03:36:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:36:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:36:07 --> Total execution time: 0.1573
DEBUG - 2020-07-20 03:36:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:36:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:36:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:36:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:36:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:36:08 --> Total execution time: 0.1568
DEBUG - 2020-07-20 03:36:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:36:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:36:09 --> Total execution time: 0.1997
DEBUG - 2020-07-20 03:36:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:36:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:36:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:36:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:36:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:36:11 --> Total execution time: 0.1484
DEBUG - 2020-07-20 03:36:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:36:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:36:11 --> Total execution time: 0.1436
DEBUG - 2020-07-20 03:36:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:36:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:36:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:39:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:39:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:39:41 --> Total execution time: 0.1647
DEBUG - 2020-07-20 03:39:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:39:41 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:39:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:39:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:39:44 --> Total execution time: 0.1342
DEBUG - 2020-07-20 03:39:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:39:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:39:44 --> Total execution time: 0.1193
DEBUG - 2020-07-20 03:39:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:39:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:39:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:39:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:39:47 --> Total execution time: 0.1377
DEBUG - 2020-07-20 03:39:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:39:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:39:47 --> Total execution time: 0.1143
DEBUG - 2020-07-20 03:39:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:39:47 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:39:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:39:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:39:49 --> Total execution time: 0.1221
DEBUG - 2020-07-20 03:39:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:39:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-20 03:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\header.php 86
DEBUG - 2020-07-20 03:39:49 --> Total execution time: 0.1348
DEBUG - 2020-07-20 03:39:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:39:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:39:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:39:50 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_select_translation.jpg
DEBUG - 2020-07-20 03:39:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:39:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:39:50 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_choose_the_letter.jpg
ERROR - 2020-07-20 03:39:50 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_multichoice_with_image.jpg
ERROR - 2020-07-20 03:39:50 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_multichoice_with_word.jpg
DEBUG - 2020-07-20 03:39:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:39:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:39:50 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_write_the_word.jpg
ERROR - 2020-07-20 03:39:50 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_matching.jpg
DEBUG - 2020-07-20 03:39:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:39:50 --> 404 Page Not Found: Uploads/type.png
DEBUG - 2020-07-20 03:39:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:39:50 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_listening_comprehension.jpg
DEBUG - 2020-07-20 03:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:39:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:39:50 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_flashcards.jpg
ERROR - 2020-07-20 03:39:50 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_flashcards1.jpg
DEBUG - 2020-07-20 03:39:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:39:50 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_text.jpg
DEBUG - 2020-07-20 03:39:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:39:50 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_grammar_multichoice.jpg
DEBUG - 2020-07-20 03:39:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:39:50 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_grammar_fill_the_gap.jpg
DEBUG - 2020-07-20 03:39:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:39:50 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_Culture_text.jpg
DEBUG - 2020-07-20 03:39:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:39:50 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_dialgues_multichoice.jpg
DEBUG - 2020-07-20 03:39:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:39:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:39:51 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_multichoice_with_word.jpg
ERROR - 2020-07-20 03:39:51 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_multichoice_with_image.jpg
DEBUG - 2020-07-20 03:41:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:41:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:41:39 --> Total execution time: 0.1014
DEBUG - 2020-07-20 03:41:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:41:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:41:39 --> Total execution time: 0.1191
DEBUG - 2020-07-20 03:41:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:41:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:41:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:41:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:41:45 --> Total execution time: 0.1243
DEBUG - 2020-07-20 03:41:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:41:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:41:45 --> Total execution time: 0.1241
DEBUG - 2020-07-20 03:41:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:41:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:41:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:41:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:41:48 --> Total execution time: 0.1457
DEBUG - 2020-07-20 03:41:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:41:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:41:49 --> Total execution time: 0.1208
DEBUG - 2020-07-20 03:41:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:41:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:41:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:41:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:41:50 --> Total execution time: 0.1021
DEBUG - 2020-07-20 03:41:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:41:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:41:50 --> Total execution time: 0.3655
DEBUG - 2020-07-20 03:41:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:41:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:41:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:41:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:41:51 --> Total execution time: 0.1081
DEBUG - 2020-07-20 03:41:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:41:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:41:52 --> Total execution time: 0.1702
DEBUG - 2020-07-20 03:41:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:41:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:41:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:41:53 --> Total execution time: 0.1020
DEBUG - 2020-07-20 03:41:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:41:53 --> Total execution time: 0.1202
DEBUG - 2020-07-20 03:41:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:41:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:41:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:41:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:41:54 --> Total execution time: 0.1497
DEBUG - 2020-07-20 03:41:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:41:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:41:55 --> Total execution time: 0.2533
DEBUG - 2020-07-20 03:41:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:41:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:41:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:41:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:41:56 --> Total execution time: 0.1299
DEBUG - 2020-07-20 03:41:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:41:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:41:56 --> Total execution time: 0.3020
DEBUG - 2020-07-20 03:41:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:41:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:41:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:41:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:41:57 --> Total execution time: 0.1127
DEBUG - 2020-07-20 03:41:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:41:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:41:57 --> Total execution time: 0.1282
DEBUG - 2020-07-20 03:41:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:41:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:41:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:41:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:41:58 --> Total execution time: 0.1020
DEBUG - 2020-07-20 03:41:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:41:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:41:58 --> Total execution time: 0.1576
DEBUG - 2020-07-20 03:41:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:41:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:41:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:41:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:42:00 --> Total execution time: 0.1025
DEBUG - 2020-07-20 03:42:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:42:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-20 03:42:00 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\header.php 86
DEBUG - 2020-07-20 03:42:00 --> Total execution time: 0.2693
DEBUG - 2020-07-20 03:42:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:42:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:42:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:42:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:42:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:42:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:42:00 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_multichoice_with_image.jpg
ERROR - 2020-07-20 03:42:00 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_select_translation.jpg
DEBUG - 2020-07-20 03:42:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:42:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:42:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:42:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:42:01 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_flashcards.jpg
DEBUG - 2020-07-20 03:42:01 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:42:01 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_matching.jpg
DEBUG - 2020-07-20 03:42:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:42:01 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_multichoice_with_word.jpg
DEBUG - 2020-07-20 03:42:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:42:01 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_choose_the_letter.jpg
DEBUG - 2020-07-20 03:42:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:42:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:42:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:42:01 --> 404 Page Not Found: Uploads/type.png
DEBUG - 2020-07-20 03:42:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:42:01 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_write_the_word.jpg
DEBUG - 2020-07-20 03:42:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:42:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:42:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:42:01 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_listening_comprehension.jpg
DEBUG - 2020-07-20 03:42:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:42:01 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_grammar_multichoice.jpg
DEBUG - 2020-07-20 03:42:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:42:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:42:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:42:01 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_grammar_fill_the_gap.jpg
DEBUG - 2020-07-20 03:42:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:42:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:42:01 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_flashcards1.jpg
DEBUG - 2020-07-20 03:42:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:42:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:42:01 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_text.jpg
DEBUG - 2020-07-20 03:42:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:42:01 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_dialgues_multichoice.jpg
DEBUG - 2020-07-20 03:42:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:42:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:42:01 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_Culture_text.jpg
DEBUG - 2020-07-20 03:43:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:43:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-20 03:43:56 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\header.php 86
DEBUG - 2020-07-20 03:43:56 --> Total execution time: 0.1446
DEBUG - 2020-07-20 03:43:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:43:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:43:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:43:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:43:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:43:56 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_select_translation.jpg
DEBUG - 2020-07-20 03:43:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:43:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:43:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:43:56 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_multichoice_with_word.jpg
DEBUG - 2020-07-20 03:43:57 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:43:57 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_write_the_word.jpg
DEBUG - 2020-07-20 03:43:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:43:57 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_matching.jpg
DEBUG - 2020-07-20 03:43:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:43:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:43:57 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_choose_the_letter.jpg
DEBUG - 2020-07-20 03:43:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:43:57 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:43:57 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_multichoice_with_image.jpg
DEBUG - 2020-07-20 03:43:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:43:57 --> 404 Page Not Found: Uploads/type.png
DEBUG - 2020-07-20 03:43:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:43:57 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:43:57 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_listening_comprehension.jpg
DEBUG - 2020-07-20 03:43:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:43:57 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_flashcards.jpg
DEBUG - 2020-07-20 03:43:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:43:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:43:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:43:57 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_grammar_multichoice.jpg
DEBUG - 2020-07-20 03:43:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:43:57 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_grammar_fill_the_gap.jpg
DEBUG - 2020-07-20 03:43:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:43:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:43:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:43:57 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_text.jpg
DEBUG - 2020-07-20 03:43:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:43:57 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_flashcards1.jpg
DEBUG - 2020-07-20 03:43:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:43:57 --> UTF-8 Support Enabled
ERROR - 2020-07-20 03:43:57 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_dialgues_multichoice.jpg
DEBUG - 2020-07-20 03:43:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:43:57 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_Culture_text.jpg
DEBUG - 2020-07-20 03:47:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:47:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-20 03:47:58 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\header.php 86
DEBUG - 2020-07-20 03:47:58 --> Total execution time: 0.1844
DEBUG - 2020-07-20 03:47:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:47:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:48:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:48:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:48:05 --> Total execution time: 0.1176
DEBUG - 2020-07-20 03:48:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:48:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:48:06 --> Total execution time: 0.1379
DEBUG - 2020-07-20 03:48:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:48:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:48:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:48:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:48:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:48:08 --> Total execution time: 0.1424
DEBUG - 2020-07-20 03:48:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:48:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-20 03:48:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\header.php 86
DEBUG - 2020-07-20 03:48:09 --> Total execution time: 0.1608
DEBUG - 2020-07-20 03:48:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:48:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:48:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 03:48:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:48:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:48:09 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-20 03:48:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:48:09 --> No URI present. Default controller set.
DEBUG - 2020-07-20 03:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:48:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:48:09 --> Total execution time: 0.1932
DEBUG - 2020-07-20 03:48:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:48:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:48:11 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-20 03:48:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:48:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:48:22 --> No URI present. Default controller set.
DEBUG - 2020-07-20 03:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:48:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:48:22 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-20 03:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:48:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:48:22 --> Total execution time: 0.1459
DEBUG - 2020-07-20 03:48:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:48:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:48:37 --> Total execution time: 0.1015
DEBUG - 2020-07-20 03:48:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 03:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 03:48:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 03:48:37 --> Total execution time: 0.1282
DEBUG - 2020-07-20 03:48:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 03:48:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 03:48:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 07:30:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 07:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 07:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 07:30:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 07:30:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 07:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 07:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 07:30:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 07:30:22 --> Total execution time: 0.1645
DEBUG - 2020-07-20 07:30:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 07:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 07:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 07:30:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 07:30:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 07:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 07:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 07:30:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 07:30:36 --> Total execution time: 0.2228
DEBUG - 2020-07-20 07:30:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 07:30:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 07:30:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 07:30:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 07:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 07:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 07:30:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 07:30:41 --> Total execution time: 0.3686
DEBUG - 2020-07-20 07:30:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 07:30:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 07:30:41 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 08:06:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 08:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 08:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 08:06:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 08:06:29 --> Upload class already loaded. Second attempt ignored.
ERROR - 2020-07-20 08:06:29 --> Severity: error --> Exception: Call to undefined function finfo_open() E:\xampp\htdocs\voolsy\langoadmin\system\libraries\Upload.php 1222
DEBUG - 2020-07-20 08:06:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 08:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 08:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 08:06:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 08:06:33 --> Total execution time: 0.1838
DEBUG - 2020-07-20 08:06:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 08:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 08:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 08:06:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 08:06:37 --> Total execution time: 0.1495
DEBUG - 2020-07-20 08:06:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 08:06:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 08:06:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 08:07:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 08:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 08:07:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 08:07:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 08:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 08:07:02 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-20 10:18:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 10:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 10:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 10:18:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 10:18:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 10:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 10:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 10:18:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 10:18:26 --> Total execution time: 0.1913
DEBUG - 2020-07-20 10:18:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 10:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 10:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 10:18:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 10:18:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 10:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 10:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 10:18:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 10:18:39 --> Total execution time: 0.2149
DEBUG - 2020-07-20 10:18:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 10:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 10:18:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 10:18:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 10:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 10:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 10:18:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 10:18:42 --> Total execution time: 0.2047
DEBUG - 2020-07-20 10:18:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 10:18:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 10:18:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 10:18:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 10:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 10:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 10:18:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 10:18:58 --> Upload class already loaded. Second attempt ignored.
ERROR - 2020-07-20 10:18:58 --> Severity: error --> Exception: Call to undefined function finfo_open() E:\xampp\htdocs\voolsy\langoadmin\system\libraries\Upload.php 1222
DEBUG - 2020-07-20 10:19:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 10:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 10:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 10:19:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 10:19:31 --> Upload class already loaded. Second attempt ignored.
ERROR - 2020-07-20 10:19:31 --> Severity: error --> Exception: Call to undefined function finfo_open() E:\xampp\htdocs\voolsy\langoadmin\system\libraries\Upload.php 1222
DEBUG - 2020-07-20 10:25:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 10:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 10:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 10:25:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 10:25:18 --> Upload class already loaded. Second attempt ignored.
ERROR - 2020-07-20 10:25:18 --> Severity: error --> Exception: Call to undefined function finfo_open() E:\xampp\htdocs\voolsy\langoadmin\system\libraries\Upload.php 1222
DEBUG - 2020-07-20 10:25:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 10:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 10:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 10:25:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 10:25:51 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 12:07:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 12:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 12:07:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 12:07:50 --> Total execution time: 0.1400
DEBUG - 2020-07-20 12:07:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 12:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 12:07:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 12:07:52 --> Total execution time: 0.1752
DEBUG - 2020-07-20 12:07:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:07:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 12:07:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 12:07:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 12:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 12:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 12:07:55 --> Total execution time: 0.1054
DEBUG - 2020-07-20 12:07:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 12:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 12:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 12:07:55 --> Total execution time: 0.1904
DEBUG - 2020-07-20 12:07:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:07:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 12:07:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 12:07:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 12:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 12:07:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 12:07:57 --> Total execution time: 0.1704
DEBUG - 2020-07-20 12:07:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 12:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 12:07:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 12:07:58 --> Total execution time: 0.8750
DEBUG - 2020-07-20 12:07:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:07:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 12:07:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 12:08:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 12:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 12:08:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 12:08:00 --> Total execution time: 0.1204
DEBUG - 2020-07-20 12:08:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 12:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 12:08:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 12:08:01 --> Total execution time: 0.3026
DEBUG - 2020-07-20 12:08:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:08:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 12:08:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 12:10:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 12:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 12:10:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 12:10:24 --> Total execution time: 0.1551
DEBUG - 2020-07-20 12:10:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 12:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 12:10:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 12:10:24 --> Total execution time: 0.1470
DEBUG - 2020-07-20 12:10:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:10:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 12:10:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 12:10:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 12:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 12:10:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 12:10:26 --> Total execution time: 0.1373
DEBUG - 2020-07-20 12:10:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 12:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 12:10:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 12:10:26 --> Total execution time: 0.1187
DEBUG - 2020-07-20 12:10:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:10:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 12:10:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 12:10:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 12:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 12:10:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 12:10:28 --> Total execution time: 0.1530
DEBUG - 2020-07-20 12:10:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 12:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 12:10:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 12:10:28 --> Total execution time: 0.1522
DEBUG - 2020-07-20 12:10:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:10:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 12:10:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 12:12:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 12:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 12:12:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 12:12:25 --> Total execution time: 0.1231
DEBUG - 2020-07-20 12:12:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 12:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 12:12:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 12:12:26 --> Total execution time: 0.1152
DEBUG - 2020-07-20 12:12:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:12:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 12:12:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 12:12:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 12:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 12:12:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 12:12:29 --> Total execution time: 0.1400
DEBUG - 2020-07-20 12:12:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:12:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 12:12:29 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 12:12:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 12:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 12:12:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 12:12:47 --> Total execution time: 0.1184
DEBUG - 2020-07-20 12:12:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 12:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 12:12:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-20 12:12:47 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\header.php 86
DEBUG - 2020-07-20 12:12:47 --> Total execution time: 0.2210
DEBUG - 2020-07-20 12:12:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:12:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 12:12:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 12:13:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 12:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 12:13:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 12:13:31 --> Total execution time: 0.1034
DEBUG - 2020-07-20 12:13:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 12:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 12:13:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 12:13:32 --> Total execution time: 0.1205
DEBUG - 2020-07-20 12:13:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:13:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 12:13:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 12:13:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 12:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 12:13:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 12:13:35 --> Total execution time: 0.1212
DEBUG - 2020-07-20 12:13:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 12:13:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 12:13:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 13:18:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 13:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 13:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 13:18:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 13:18:42 --> Total execution time: 0.1259
DEBUG - 2020-07-20 13:18:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 13:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 13:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 13:18:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 13:18:42 --> Total execution time: 0.1216
DEBUG - 2020-07-20 13:18:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 13:18:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 13:18:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 13:18:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 13:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 13:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 13:18:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 13:18:45 --> Total execution time: 0.1584
DEBUG - 2020-07-20 13:18:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 13:18:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 13:18:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 13:19:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 13:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 13:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 13:19:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 13:19:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 13:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 13:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 13:19:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 13:19:09 --> Total execution time: 0.1670
DEBUG - 2020-07-20 13:19:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 13:19:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 13:19:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 13:19:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 13:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 13:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 13:19:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 13:19:15 --> Total execution time: 0.1183
DEBUG - 2020-07-20 13:19:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 13:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 13:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 13:19:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 13:19:15 --> Total execution time: 0.1139
DEBUG - 2020-07-20 13:19:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 13:19:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 13:19:15 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 13:19:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 13:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 13:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 13:19:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 13:19:18 --> Total execution time: 0.1921
DEBUG - 2020-07-20 13:19:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 13:19:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 13:19:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-20 13:19:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 13:19:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 13:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 13:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 13:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 13:19:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 13:19:23 --> Total execution time: 0.1294
DEBUG - 2020-07-20 13:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 13:19:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-20 13:19:23 --> Query error: Unknown column 'mode_name' in 'order clause' - Invalid query: SELECT *
FROM `tbl_exercise_type`
WHERE `exercise_mode_id` = '1'
ORDER BY `mode_name` ASC
ERROR - 2020-07-20 13:19:23 --> Severity: error --> Exception: Call to a member function result_array() on boolean E:\xampp\htdocs\voolsy\langoadmin\application\models\Admin_model.php 822
DEBUG - 2020-07-20 13:19:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 13:19:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 13:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 13:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 13:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 13:19:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 13:19:38 --> Total execution time: 0.1659
DEBUG - 2020-07-20 13:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 13:19:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-20 13:19:38 --> Query error: Unknown column 'mode_name' in 'order clause' - Invalid query: SELECT *
FROM `tbl_exercise_type`
WHERE `exercise_mode_id` = ''
ORDER BY `mode_name` ASC
ERROR - 2020-07-20 13:19:38 --> Severity: error --> Exception: Call to a member function result_array() on boolean E:\xampp\htdocs\voolsy\langoadmin\application\models\Admin_model.php 822
DEBUG - 2020-07-20 13:19:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 13:19:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 13:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 13:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 13:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 13:19:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-20 13:19:45 --> Query error: Unknown column 'mode_name' in 'order clause' - Invalid query: SELECT *
FROM `tbl_exercise_type`
WHERE `exercise_mode_id` = '1'
ORDER BY `mode_name` ASC
ERROR - 2020-07-20 13:19:45 --> Severity: error --> Exception: Call to a member function result_array() on boolean E:\xampp\htdocs\voolsy\langoadmin\application\models\Admin_model.php 822
DEBUG - 2020-07-20 13:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 13:19:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 13:19:45 --> Total execution time: 0.1830
DEBUG - 2020-07-20 13:52:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 13:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 13:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 13:52:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 13:52:17 --> Total execution time: 0.1523
DEBUG - 2020-07-20 13:52:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 13:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-20 13:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-20 13:52:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-20 13:52:17 --> Total execution time: 0.1715
DEBUG - 2020-07-20 13:52:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-20 13:52:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-20 13:52:18 --> 404 Page Not Found: Assets/chosen
