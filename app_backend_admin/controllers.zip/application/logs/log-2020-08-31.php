<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-08-31 04:23:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 04:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 04:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 04:23:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 04:23:22 --> Total execution time: 0.1407
DEBUG - 2020-08-31 04:23:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 04:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 04:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 04:23:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 04:23:29 --> Total execution time: 0.1479
DEBUG - 2020-08-31 04:23:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 04:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 04:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 04:23:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 04:23:35 --> Total execution time: 0.1325
DEBUG - 2020-08-31 04:23:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 04:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 04:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 04:23:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 04:23:46 --> get_subcategory_list->{"lang":"37","category_id":"50","user_id":"767","support_lang_id":"null"}
ERROR - 2020-08-31 04:23:46 --> Query error: Unknown column 'subcategory_name_in_' in 'field list' - Invalid query: select exercise_mode_subcategory_id,category_id,difficulty_level_id,image,subcategory_name_in_ as subcategory_name from tbl_exercise_mode_subcategories where category_id='50' AND is_active='1' AND is_delete='0' order by subcategory_name_in_ asc
ERROR - 2020-08-31 04:23:46 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_model.php 183
DEBUG - 2020-08-31 04:24:00 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 04:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 04:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 04:24:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 04:24:00 --> Total execution time: 0.1378
DEBUG - 2020-08-31 04:24:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 04:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 04:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 04:24:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 04:24:04 --> Total execution time: 0.1246
DEBUG - 2020-08-31 04:24:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 04:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 04:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 04:24:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 04:24:12 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
ERROR - 2020-08-31 04:24:12 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-31 04:24:12 --> Total execution time: 0.1362
DEBUG - 2020-08-31 04:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 04:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 04:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 04:24:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 04:24:18 --> Total execution time: 0.1277
DEBUG - 2020-08-31 04:24:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 04:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 04:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 04:24:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 04:24:22 --> Total execution time: 0.1762
DEBUG - 2020-08-31 04:24:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 04:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 04:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 04:24:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 04:24:27 --> Total execution time: 0.1399
DEBUG - 2020-08-31 04:24:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 04:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 04:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 04:24:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 04:24:41 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-08-31 04:24:41 --> Total execution time: 0.1505
DEBUG - 2020-08-31 04:24:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 04:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 04:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 04:24:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 04:24:47 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"767","support_lang_id":"3"}
DEBUG - 2020-08-31 04:24:47 --> Total execution time: 0.1269
DEBUG - 2020-08-31 04:24:52 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 04:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 04:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 04:24:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 04:24:52 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-08-31 04:24:52 --> Total execution time: 0.1502
DEBUG - 2020-08-31 04:26:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 04:26:05 --> No URI present. Default controller set.
DEBUG - 2020-08-31 04:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 04:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 04:26:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 04:26:05 --> Total execution time: 0.1687
DEBUG - 2020-08-31 05:52:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 05:52:24 --> No URI present. Default controller set.
DEBUG - 2020-08-31 05:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 05:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 05:52:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 05:52:24 --> Total execution time: 0.1382
DEBUG - 2020-08-31 08:45:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 08:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 08:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 08:45:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 08:45:24 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"767","support_lang_id":"3"}
DEBUG - 2020-08-31 08:45:24 --> Total execution time: 0.1483
DEBUG - 2020-08-31 10:48:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 10:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 10:48:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 10:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 10:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 10:48:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 10:48:05 --> Total execution time: 0.1440
DEBUG - 2020-08-31 10:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 10:48:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 10:48:05 --> Total execution time: 0.1315
DEBUG - 2020-08-31 10:48:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 10:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 10:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 10:48:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 10:48:27 --> Total execution time: 0.1743
DEBUG - 2020-08-31 10:48:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 10:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 10:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 10:48:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 10:48:30 --> Total execution time: 0.1618
DEBUG - 2020-08-31 10:48:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 10:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 10:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 10:48:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 10:48:35 --> Total execution time: 0.1708
DEBUG - 2020-08-31 10:48:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 10:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 10:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 10:48:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 10:48:39 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2020-08-31 10:48:39 --> Total execution time: 0.1270
DEBUG - 2020-08-31 10:48:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 10:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 10:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 10:48:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 10:48:44 --> get_subcategory_list->{"lang":"38","category_id":"94","user_id":"746","support_lang_id":"3"}
DEBUG - 2020-08-31 10:48:44 --> Total execution time: 0.1486
DEBUG - 2020-08-31 10:48:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 10:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 10:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 10:48:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 10:48:47 --> get_exercise_type_list->{"lang":"38","subcategory_id":"232","support_lang_id":"3"}
DEBUG - 2020-08-31 10:48:47 --> Total execution time: 0.1385
DEBUG - 2020-08-31 10:48:53 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 10:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 10:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 10:48:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 10:48:53 --> get_dialogue_type_1->{"slang":"38","tlang":"3","exercise_mode_id":"2","category_id":"94","subcategory_id":"232","support_lang_id":"3"}
ERROR - 2020-08-31 10:48:53 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-08-31 10:48:53 --> Total execution time: 0.1279
DEBUG - 2020-08-31 10:48:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 10:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 10:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 10:48:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 10:48:57 --> get_exercise_type_list->{"lang":"38","subcategory_id":"232","support_lang_id":"3"}
DEBUG - 2020-08-31 10:48:57 --> Total execution time: 0.0965
DEBUG - 2020-08-31 10:49:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 10:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 10:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 10:49:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 10:49:01 --> get_dialogue_type_1->{"slang":"38","tlang":"3","exercise_mode_id":"2","category_id":"94","subcategory_id":"232","support_lang_id":"3"}
ERROR - 2020-08-31 10:49:01 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-08-31 10:49:01 --> Total execution time: 0.1373
DEBUG - 2020-08-31 10:49:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 10:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 10:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 10:49:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 10:49:05 --> get_exercise_type_list->{"lang":"38","subcategory_id":"232","support_lang_id":"3"}
DEBUG - 2020-08-31 10:49:05 --> Total execution time: 0.1463
DEBUG - 2020-08-31 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 10:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 10:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 10:49:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 10:49:07 --> get_subcategory_list->{"lang":"38","category_id":"94","user_id":"746","support_lang_id":"3"}
DEBUG - 2020-08-31 10:49:07 --> Total execution time: 0.1292
DEBUG - 2020-08-31 10:49:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 10:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 10:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 10:49:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 10:49:12 --> get_exercise_type_list->{"lang":"38","subcategory_id":"233","support_lang_id":"3"}
DEBUG - 2020-08-31 10:49:12 --> Total execution time: 0.1003
DEBUG - 2020-08-31 10:49:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 10:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 10:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 10:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 10:49:16 --> get_dialogue_type_1->{"slang":"38","tlang":"3","exercise_mode_id":"2","category_id":"94","subcategory_id":"233","support_lang_id":"3"}
ERROR - 2020-08-31 10:49:16 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-08-31 10:49:16 --> Total execution time: 0.1206
DEBUG - 2020-08-31 10:49:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 10:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 10:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 10:49:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 10:49:20 --> get_exercise_type_list->{"lang":"38","subcategory_id":"233","support_lang_id":"3"}
DEBUG - 2020-08-31 10:49:20 --> Total execution time: 0.1135
DEBUG - 2020-08-31 10:49:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 10:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 10:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 10:49:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 10:49:24 --> get_subcategory_list->{"lang":"38","category_id":"94","user_id":"746","support_lang_id":"3"}
DEBUG - 2020-08-31 10:49:24 --> Total execution time: 0.1627
DEBUG - 2020-08-31 10:49:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 10:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 10:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 10:49:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 10:49:28 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2020-08-31 10:49:28 --> Total execution time: 0.1106
DEBUG - 2020-08-31 11:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:32:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:32:24 --> Total execution time: 0.1724
DEBUG - 2020-08-31 11:32:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:32:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:32:28 --> Total execution time: 0.1561
DEBUG - 2020-08-31 11:32:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:32:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:32:34 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-31 11:32:34 --> Total execution time: 0.1520
DEBUG - 2020-08-31 11:32:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:32:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:32:38 --> get_subcategory_list->{"lang":"37","category_id":"50","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-31 11:32:38 --> Total execution time: 0.1744
DEBUG - 2020-08-31 11:32:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-31 11:32:46 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-08-31 11:32:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:32:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-31 11:32:49 --> 404 Page Not Found: Uploads/ironman.jpg
DEBUG - 2020-08-31 11:32:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:32:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:32:54 --> get_exercise_type_list->{"lang":"37","subcategory_id":"178","support_lang_id":"2"}
DEBUG - 2020-08-31 11:32:54 --> Total execution time: 0.1457
DEBUG - 2020-08-31 11:32:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:32:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:32:58 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"2","exercise_mode_id":"1","category_id":"50","subcategory_id":"178","support_lang_id":"2"}
DEBUG - 2020-08-31 11:32:58 --> Total execution time: 0.1567
DEBUG - 2020-08-31 11:33:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:33:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-31 11:33:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-31 11:33:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:33:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:33:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-31 11:33:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-31 11:33:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-31 11:33:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-31 11:33:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:33:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-31 11:33:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-31 11:33:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:33:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:33:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-31 11:33:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-31 11:33:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-31 11:33:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-31 11:33:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:33:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-31 11:33:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-31 11:33:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:33:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-31 11:33:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-31 11:33:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:33:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-31 11:33:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-31 11:33:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-31 11:33:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-31 11:33:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-31 11:33:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-31 11:33:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:33:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-31 11:33:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-31 11:33:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-31 11:33:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-08-31 11:33:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:33:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:33:11 --> get_exercise_type_list->{"lang":"37","subcategory_id":"178","support_lang_id":"2"}
DEBUG - 2020-08-31 11:33:11 --> Total execution time: 0.1170
DEBUG - 2020-08-31 11:33:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:33:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:33:12 --> get_subcategory_list->{"lang":"37","category_id":"50","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-31 11:33:12 --> Total execution time: 0.1569
DEBUG - 2020-08-31 11:33:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:33:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:33:12 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-31 11:33:12 --> Total execution time: 0.1146
DEBUG - 2020-08-31 11:33:13 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:33:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:33:13 --> Total execution time: 0.1444
DEBUG - 2020-08-31 11:33:14 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:33:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:33:14 --> Total execution time: 0.1227
DEBUG - 2020-08-31 11:53:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:53:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:53:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:53:36 --> Total execution time: 0.1141
DEBUG - 2020-08-31 11:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:53:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:53:36 --> Total execution time: 0.1642
DEBUG - 2020-08-31 11:53:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:53:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:53:42 --> Total execution time: 0.1203
DEBUG - 2020-08-31 11:53:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:53:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:53:59 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-08-31 11:53:59 --> Total execution time: 0.1296
DEBUG - 2020-08-31 11:54:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:54:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:54:01 --> get_subcategory_list->{"lang":"37","category_id":"126","user_id":"746","support_lang_id":"2"}
DEBUG - 2020-08-31 11:54:01 --> Total execution time: 0.1232
DEBUG - 2020-08-31 11:54:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:54:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:54:06 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-31 11:54:06 --> Total execution time: 0.1047
DEBUG - 2020-08-31 11:54:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:54:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:54:10 --> get_dialogue_type_1->{"slang":"37","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
ERROR - 2020-08-31 11:54:10 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-08-31 11:54:10 --> Total execution time: 0.1191
DEBUG - 2020-08-31 11:54:19 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:54:19 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:54:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:54:19 --> get_subcategory_list->{"lang":"37","category_id":"126","user_id":"746","support_lang_id":"2"}
DEBUG - 2020-08-31 11:54:19 --> Total execution time: 0.1339
DEBUG - 2020-08-31 11:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:54:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:54:19 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-31 11:54:19 --> Total execution time: 0.1536
DEBUG - 2020-08-31 11:54:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:54:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:54:20 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-08-31 11:54:20 --> Total execution time: 0.1441
DEBUG - 2020-08-31 11:54:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:54:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:54:21 --> Total execution time: 0.1683
DEBUG - 2020-08-31 11:54:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:54:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:54:22 --> Total execution time: 0.1661
DEBUG - 2020-08-31 11:54:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:54:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:54:30 --> Total execution time: 0.1737
DEBUG - 2020-08-31 11:54:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:54:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:54:33 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-08-31 11:54:33 --> Total execution time: 0.1146
DEBUG - 2020-08-31 11:54:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:54:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:54:36 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"746","support_lang_id":"2"}
DEBUG - 2020-08-31 11:54:36 --> Total execution time: 0.1359
DEBUG - 2020-08-31 11:54:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:54:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:54:39 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-31 11:54:39 --> Total execution time: 0.0982
DEBUG - 2020-08-31 11:54:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:54:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:54:42 --> get_dialogue_type_1->{"slang":"38","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-31 11:54:42 --> Total execution time: 0.1433
DEBUG - 2020-08-31 11:58:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:58:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:58:45 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-08-31 11:58:45 --> Total execution time: 0.1249
DEBUG - 2020-08-31 11:58:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:58:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:58:45 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"746","support_lang_id":"2"}
DEBUG - 2020-08-31 11:58:45 --> Total execution time: 0.1065
DEBUG - 2020-08-31 11:58:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:58:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:58:46 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-08-31 11:58:46 --> Total execution time: 0.1240
DEBUG - 2020-08-31 11:58:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:58:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:58:47 --> Total execution time: 0.1507
DEBUG - 2020-08-31 11:58:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 11:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 11:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 11:58:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 11:58:47 --> Total execution time: 0.1607
DEBUG - 2020-08-31 16:04:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 16:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 16:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 16:04:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 16:04:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 16:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 16:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 16:04:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 16:04:47 --> Total execution time: 0.1193
DEBUG - 2020-08-31 16:05:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 16:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 16:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 16:05:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 16:05:19 --> UTF-8 Support Enabled
DEBUG - 2020-08-31 16:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-31 16:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-31 16:05:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-31 16:05:19 --> Total execution time: 0.1573
