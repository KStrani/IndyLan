<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-10-05 05:05:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:05:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:05:34 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"88","subcategory_id":"89","support_lang_id":"3"}
DEBUG - 2020-10-05 05:05:34 --> Total execution time: 0.1673
DEBUG - 2020-10-05 05:06:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:06:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:06:05 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
ERROR - 2020-10-05 05:06:05 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-05 05:06:05 --> Total execution time: 0.1139
DEBUG - 2020-10-05 05:13:53 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:13:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:13:53 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-05 05:13:53 --> Total execution time: 0.1031
DEBUG - 2020-10-05 05:14:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:14:52 --> No URI present. Default controller set.
DEBUG - 2020-10-05 05:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:14:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:14:53 --> Total execution time: 0.1777
DEBUG - 2020-10-05 05:15:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:15:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:15:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:15:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:15:17 --> Total execution time: 0.1396
DEBUG - 2020-10-05 05:15:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:15:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:15:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:15:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:15:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:15:28 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:15:31 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:15:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:15:31 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-10-05 05:15:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:15:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:15:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:15:43 --> Total execution time: 0.1231
DEBUG - 2020-10-05 05:15:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:15:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:15:47 --> Total execution time: 0.1485
DEBUG - 2020-10-05 05:15:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:15:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:15:48 --> Total execution time: 0.1069
DEBUG - 2020-10-05 05:15:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:15:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:15:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:15:49 --> Total execution time: 0.1757
DEBUG - 2020-10-05 05:15:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:15:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:15:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:15:53 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:15:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:15:53 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-05 05:15:53 --> Total execution time: 0.1163
DEBUG - 2020-10-05 05:15:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:15:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:15:56 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:15:57 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:15:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:15:57 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-10-05 05:15:57 --> Total execution time: 0.1504
DEBUG - 2020-10-05 05:16:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:16:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:16:00 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:16:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:16:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:16:00 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-05 05:16:00 --> Total execution time: 0.1610
DEBUG - 2020-10-05 05:16:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:16:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:16:04 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-05 05:16:04 --> Total execution time: 0.1024
DEBUG - 2020-10-05 05:16:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:16:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:16:56 --> Total execution time: 0.1487
DEBUG - 2020-10-05 05:16:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:16:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:16:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:17:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:17:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:17:15 --> Total execution time: 0.1289
DEBUG - 2020-10-05 05:17:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:17:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:17:24 --> Total execution time: 0.1422
DEBUG - 2020-10-05 05:17:31 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:17:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:17:31 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-05 05:17:31 --> Total execution time: 0.1103
DEBUG - 2020-10-05 05:17:35 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:17:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:17:35 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:17:35 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:17:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:17:36 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-10-05 05:17:36 --> Total execution time: 0.1300
DEBUG - 2020-10-05 05:17:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:17:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:17:39 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:17:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:17:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:17:39 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-05 05:17:39 --> Total execution time: 0.1625
DEBUG - 2020-10-05 05:17:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:17:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:17:47 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-05 05:17:47 --> Total execution time: 0.1695
DEBUG - 2020-10-05 05:18:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:18:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:18:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:18:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:18:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:18:06 --> 404 Page Not Found: Assets/js
DEBUG - 2020-10-05 05:21:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:21:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:21:09 --> Total execution time: 0.1717
DEBUG - 2020-10-05 05:21:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:21:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:21:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:22:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:22:47 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-05 05:22:47 --> Total execution time: 0.1393
DEBUG - 2020-10-05 05:23:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:23:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:23:30 --> Total execution time: 0.1432
DEBUG - 2020-10-05 05:23:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:23:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:23:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:23:33 --> Total execution time: 0.1499
DEBUG - 2020-10-05 05:23:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:23:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:23:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:23:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:23:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:23:47 --> Total execution time: 0.1352
DEBUG - 2020-10-05 05:23:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:23:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:23:48 --> Total execution time: 0.1578
DEBUG - 2020-10-05 05:23:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:23:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:23:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:23:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:23:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:23:59 --> 404 Page Not Found: Assets/js
DEBUG - 2020-10-05 05:24:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:24:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:24:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:24:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:24:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:24:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:24:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:24:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:24:46 --> Total execution time: 0.1645
DEBUG - 2020-10-05 05:24:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:24:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:24:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:24:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:24:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:24:56 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-05 05:24:56 --> Total execution time: 0.1604
DEBUG - 2020-10-05 05:25:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:25:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:25:30 --> Total execution time: 0.1184
DEBUG - 2020-10-05 05:25:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:25:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:25:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:25:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:25:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:25:53 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:25:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:25:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:25:53 --> Total execution time: 0.1365
DEBUG - 2020-10-05 05:25:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:25:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:25:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:26:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:26:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:26:04 --> Total execution time: 0.1216
DEBUG - 2020-10-05 05:26:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:26:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:26:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:26:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:26:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:26:15 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-05 05:26:15 --> Total execution time: 0.1383
DEBUG - 2020-10-05 05:29:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:29:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:29:03 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-05 05:29:03 --> Total execution time: 0.1429
DEBUG - 2020-10-05 05:29:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:29:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:30:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:30:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:30:01 --> Total execution time: 0.1343
DEBUG - 2020-10-05 05:30:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:30:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:30:02 --> Total execution time: 0.1008
DEBUG - 2020-10-05 05:30:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:30:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:30:11 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-05 05:30:11 --> Total execution time: 0.1098
DEBUG - 2020-10-05 05:30:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:30:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:30:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:30:14 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:30:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:30:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:30:16 --> Total execution time: 0.1281
DEBUG - 2020-10-05 05:30:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:30:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:30:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:30:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:30:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:30:21 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:30:25 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:30:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:30:25 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-10-05 05:30:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:30:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:30:26 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-10-05 05:30:26 --> Total execution time: 0.1225
DEBUG - 2020-10-05 05:30:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:30:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:30:28 --> Total execution time: 0.1634
DEBUG - 2020-10-05 05:30:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:30:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:30:29 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:30:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:30:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:30:30 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-05 05:30:30 --> Total execution time: 0.1236
DEBUG - 2020-10-05 05:30:31 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:30:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:30:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:30:31 --> Total execution time: 0.1402
DEBUG - 2020-10-05 05:30:35 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:30:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:30:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:30:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:30:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:30:36 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-05 05:30:36 --> Total execution time: 0.0987
DEBUG - 2020-10-05 05:31:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:31:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:31:01 --> Total execution time: 0.1201
DEBUG - 2020-10-05 05:31:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:31:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:31:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:31:08 --> Total execution time: 0.1511
DEBUG - 2020-10-05 05:31:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:31:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:31:10 --> Total execution time: 0.1292
DEBUG - 2020-10-05 05:31:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:31:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:31:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:31:11 --> Total execution time: 0.1391
DEBUG - 2020-10-05 05:31:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:31:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:31:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:31:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:31:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:31:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:31:30 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-10-05 05:31:30 --> Total execution time: 0.1178
DEBUG - 2020-10-05 05:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:31:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:31:30 --> Total execution time: 0.1307
DEBUG - 2020-10-05 05:31:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:31:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:31:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:31:33 --> Total execution time: 0.1839
DEBUG - 2020-10-05 05:31:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:31:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:31:33 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:31:35 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:31:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:31:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:31:35 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:31:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:31:35 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-05 05:31:35 --> Total execution time: 0.1126
DEBUG - 2020-10-05 05:31:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:31:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:31:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:31:39 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:31:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:31:39 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2020-10-05 05:31:39 --> Total execution time: 0.1227
DEBUG - 2020-10-05 05:31:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:31:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:31:41 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:31:45 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:31:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:31:45 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-10-05 05:31:45 --> Total execution time: 0.1110
DEBUG - 2020-10-05 05:31:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:31:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:31:49 --> get_subcategory_list->{"lang":"37","category_id":"89","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-10-05 05:31:49 --> Total execution time: 0.1288
DEBUG - 2020-10-05 05:31:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:31:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:31:52 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"769","support_lang_id":"3"}
DEBUG - 2020-10-05 05:31:52 --> Total execution time: 0.0999
DEBUG - 2020-10-05 05:31:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:31:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:31:55 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:31:57 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:31:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:31:57 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-05 05:31:57 --> Total execution time: 0.1221
DEBUG - 2020-10-05 05:31:57 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:31:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:31:57 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:32:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:32:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:32:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:32:06 --> Total execution time: 0.1257
DEBUG - 2020-10-05 05:32:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:32:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:32:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:32:09 --> Total execution time: 0.1486
DEBUG - 2020-10-05 05:32:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:32:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:32:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:32:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:32:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:32:14 --> get_exercise_type_list->{"lang":"37","subcategory_id":"97","support_lang_id":"3"}
DEBUG - 2020-10-05 05:32:14 --> Total execution time: 0.1062
DEBUG - 2020-10-05 05:32:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:32:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:32:18 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"89","subcategory_id":"97","support_lang_id":"3"}
ERROR - 2020-10-05 05:32:18 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-05 05:32:18 --> Total execution time: 0.1136
DEBUG - 2020-10-05 05:32:23 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:32:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:32:24 --> get_subcategory_list->{"lang":"37","category_id":"89","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-10-05 05:32:24 --> Total execution time: 0.1238
DEBUG - 2020-10-05 05:32:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:32:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:32:26 --> get_grammer_type_2->{"slang":"37","tlang":"3","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
ERROR - 2020-10-05 05:32:26 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-05 05:32:26 --> Total execution time: 0.1051
DEBUG - 2020-10-05 05:33:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:33:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:33:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:33:18 --> Total execution time: 0.1568
DEBUG - 2020-10-05 05:33:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:33:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:33:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:33:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:33:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:33:22 --> Total execution time: 0.1373
DEBUG - 2020-10-05 05:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:33:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:33:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:33:25 --> Total execution time: 0.1465
DEBUG - 2020-10-05 05:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:33:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:35:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:35:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:35:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:35:40 --> Total execution time: 0.1576
DEBUG - 2020-10-05 05:35:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:35:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:35:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:35:44 --> Total execution time: 0.1594
DEBUG - 2020-10-05 05:35:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:35:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:35:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:35:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:35:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:35:51 --> Total execution time: 0.1254
DEBUG - 2020-10-05 05:35:53 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:35:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:35:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:35:53 --> Total execution time: 0.1642
DEBUG - 2020-10-05 05:35:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:35:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:35:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:36:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:36:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:36:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:36:02 --> Total execution time: 0.1372
DEBUG - 2020-10-05 05:36:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:36:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:36:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:36:05 --> Total execution time: 0.1864
DEBUG - 2020-10-05 05:36:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:36:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:36:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:36:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:36:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:36:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:36:14 --> Total execution time: 0.1736
DEBUG - 2020-10-05 05:36:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:36:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:36:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:36:17 --> Total execution time: 0.1334
DEBUG - 2020-10-05 05:36:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:36:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:36:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:36:25 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:36:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:36:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:36:25 --> Total execution time: 0.1740
DEBUG - 2020-10-05 05:36:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:36:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:36:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:36:28 --> Total execution time: 0.1549
DEBUG - 2020-10-05 05:36:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:36:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:36:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:36:35 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:36:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:36:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:36:35 --> Total execution time: 0.1415
DEBUG - 2020-10-05 05:36:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:36:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:36:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:36:38 --> Total execution time: 0.1566
DEBUG - 2020-10-05 05:36:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:36:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:36:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:36:46 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:36:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:36:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:36:46 --> Total execution time: 0.1494
DEBUG - 2020-10-05 05:36:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:36:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:36:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:36:49 --> Total execution time: 0.1426
DEBUG - 2020-10-05 05:36:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:36:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:36:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:36:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:36:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:36:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:36:58 --> Total execution time: 0.1114
DEBUG - 2020-10-05 05:37:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:37:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:37:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:37:01 --> Total execution time: 0.1310
DEBUG - 2020-10-05 05:37:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:37:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:37:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:37:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:37:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:37:11 --> Total execution time: 0.1697
DEBUG - 2020-10-05 05:37:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:37:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:37:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:37:14 --> Total execution time: 0.1505
DEBUG - 2020-10-05 05:37:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:37:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:37:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:37:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:37:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:37:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:37:25 --> Total execution time: 0.1573
DEBUG - 2020-10-05 05:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:37:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:37:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:37:28 --> Total execution time: 0.1559
DEBUG - 2020-10-05 05:37:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:37:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:37:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:38:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:38:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:38:11 --> Total execution time: 0.1290
DEBUG - 2020-10-05 05:38:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:38:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:38:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:38:13 --> Total execution time: 0.2058
DEBUG - 2020-10-05 05:38:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:38:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:38:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:38:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:38:21 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:38:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:38:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:38:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:38:51 --> Total execution time: 0.1624
DEBUG - 2020-10-05 05:38:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:38:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:38:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:41:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:41:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:41:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:41:16 --> Total execution time: 0.1423
DEBUG - 2020-10-05 05:41:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:41:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:41:17 --> Total execution time: 0.1372
DEBUG - 2020-10-05 05:41:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:41:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:41:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:41:18 --> Total execution time: 0.1356
DEBUG - 2020-10-05 05:41:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:41:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:41:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:41:21 --> Total execution time: 0.1170
DEBUG - 2020-10-05 05:41:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:41:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:41:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:41:22 --> Total execution time: 0.1318
DEBUG - 2020-10-05 05:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:41:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:41:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:41:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:41:31 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:41:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:41:31 --> Total execution time: 0.1256
DEBUG - 2020-10-05 05:41:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:41:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:41:32 --> Total execution time: 0.1798
DEBUG - 2020-10-05 05:41:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:41:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:41:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:41:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:41:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:41:45 --> Total execution time: 0.1271
DEBUG - 2020-10-05 05:41:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:41:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:41:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:41:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:41:57 --> Total execution time: 0.1146
DEBUG - 2020-10-05 05:41:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:41:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:41:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:42:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:42:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:42:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:42:04 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:42:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:42:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:42:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:42:07 --> Total execution time: 0.1206
DEBUG - 2020-10-05 05:42:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:42:08 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-10-05 05:42:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:42:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:42:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:42:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:42:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:42:17 --> Total execution time: 0.1500
DEBUG - 2020-10-05 05:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:42:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:42:17 --> Total execution time: 0.1911
DEBUG - 2020-10-05 05:42:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:42:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:42:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:42:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:42:18 --> Total execution time: 0.1909
ERROR - 2020-10-05 05:42:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:42:18 --> Total execution time: 0.1643
DEBUG - 2020-10-05 05:42:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:42:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:42:18 --> Total execution time: 0.1302
DEBUG - 2020-10-05 05:42:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:42:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:42:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:42:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:42:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:42:20 --> Total execution time: 0.1879
DEBUG - 2020-10-05 05:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:42:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:42:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:42:20 --> Total execution time: 0.1681
ERROR - 2020-10-05 05:42:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:42:20 --> Total execution time: 0.2317
DEBUG - 2020-10-05 05:42:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:42:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:42:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:42:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:42:21 --> Total execution time: 0.1809
DEBUG - 2020-10-05 05:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:42:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:42:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:42:21 --> Total execution time: 0.1400
DEBUG - 2020-10-05 05:42:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:42:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:42:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:42:21 --> Total execution time: 0.1371
DEBUG - 2020-10-05 05:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:42:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:42:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:42:21 --> Total execution time: 0.1740
DEBUG - 2020-10-05 05:42:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:42:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:42:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:42:23 --> Total execution time: 0.1303
DEBUG - 2020-10-05 05:42:23 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:42:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:42:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:42:23 --> Total execution time: 0.1226
DEBUG - 2020-10-05 05:42:23 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:42:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:42:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:42:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:42:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:42:24 --> Total execution time: 0.1537
DEBUG - 2020-10-05 05:42:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:42:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:42:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:42:26 --> Total execution time: 0.1174
DEBUG - 2020-10-05 05:42:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:42:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:42:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:42:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:42:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:42:50 --> Total execution time: 0.1443
DEBUG - 2020-10-05 05:42:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:42:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 05:42:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-10-05 05:42:52 --> Total execution time: 0.1735
DEBUG - 2020-10-05 05:42:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:42:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:42:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-10-05 05:51:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:51:13 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:51:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:51:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:51:15 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:51:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:51:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:51:27 --> No URI present. Default controller set.
DEBUG - 2020-10-05 05:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:51:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:51:27 --> Total execution time: 0.1437
DEBUG - 2020-10-05 05:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:51:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:51:27 --> Total execution time: 0.1415
DEBUG - 2020-10-05 05:51:29 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:51:29 --> No URI present. Default controller set.
DEBUG - 2020-10-05 05:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:51:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:51:30 --> Total execution time: 0.1244
DEBUG - 2020-10-05 05:51:31 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:51:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:51:31 --> Total execution time: 0.1144
DEBUG - 2020-10-05 05:51:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:51:36 --> No URI present. Default controller set.
DEBUG - 2020-10-05 05:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:51:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:51:36 --> Total execution time: 0.1421
DEBUG - 2020-10-05 05:51:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:51:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:51:37 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-05 05:51:37 --> Total execution time: 0.1435
DEBUG - 2020-10-05 05:51:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:51:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:51:39 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:51:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:51:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:51:42 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:52:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:52:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:52:10 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:52:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:52:10 --> No URI present. Default controller set.
DEBUG - 2020-10-05 05:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:52:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:52:10 --> Total execution time: 0.1387
DEBUG - 2020-10-05 05:52:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:52:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:52:15 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:52:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:52:15 --> No URI present. Default controller set.
DEBUG - 2020-10-05 05:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:52:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:52:15 --> Total execution time: 0.1164
DEBUG - 2020-10-05 05:52:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:52:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:52:18 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:52:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:52:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:52:19 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-05 05:52:19 --> Total execution time: 0.1069
DEBUG - 2020-10-05 05:52:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:52:20 --> No URI present. Default controller set.
DEBUG - 2020-10-05 05:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:52:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:52:20 --> Total execution time: 0.1305
DEBUG - 2020-10-05 05:52:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:52:22 --> No URI present. Default controller set.
DEBUG - 2020-10-05 05:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:52:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:52:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:52:22 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"746","support_lang_id":"3"}
DEBUG - 2020-10-05 05:52:22 --> Total execution time: 0.1390
DEBUG - 2020-10-05 05:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:52:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:52:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:52:22 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:52:22 --> Total execution time: 0.1857
DEBUG - 2020-10-05 05:52:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:52:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 05:52:24 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 05:52:25 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:52:25 --> No URI present. Default controller set.
DEBUG - 2020-10-05 05:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:52:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:52:26 --> Total execution time: 0.1271
DEBUG - 2020-10-05 05:52:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:52:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:52:26 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-05 05:52:26 --> Total execution time: 0.1704
DEBUG - 2020-10-05 05:52:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:52:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:52:30 --> No URI present. Default controller set.
DEBUG - 2020-10-05 05:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:52:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:52:30 --> get_grammer_type_2->{"slang":"37","tlang":"3","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
ERROR - 2020-10-05 05:52:30 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-05 05:52:30 --> Total execution time: 0.1319
DEBUG - 2020-10-05 05:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:52:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:52:30 --> Total execution time: 0.1529
DEBUG - 2020-10-05 05:52:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 05:52:32 --> No URI present. Default controller set.
DEBUG - 2020-10-05 05:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 05:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 05:52:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 05:52:32 --> Total execution time: 0.1656
DEBUG - 2020-10-05 06:01:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 06:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 06:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 06:01:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 06:01:50 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-05 06:01:50 --> Total execution time: 0.1147
DEBUG - 2020-10-05 06:20:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 06:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 06:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 06:20:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 06:20:41 --> Total execution time: 0.0991
DEBUG - 2020-10-05 06:20:57 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 06:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 06:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 06:20:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 06:20:57 --> Total execution time: 0.1399
DEBUG - 2020-10-05 06:21:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 06:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 06:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 06:21:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 06:21:13 --> Total execution time: 0.1203
DEBUG - 2020-10-05 06:22:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 06:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 06:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 06:22:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 06:22:17 --> Total execution time: 0.1121
DEBUG - 2020-10-05 13:39:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 13:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 13:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 13:39:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 13:39:47 --> Total execution time: 0.1142
DEBUG - 2020-10-05 13:39:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 13:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 13:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 13:39:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 13:39:54 --> Total execution time: 0.1086
DEBUG - 2020-10-05 13:40:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 13:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 13:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 13:40:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 13:40:18 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-05 13:40:18 --> Total execution time: 0.0992
DEBUG - 2020-10-05 13:40:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 13:40:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 13:40:21 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 13:40:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 13:40:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 13:40:24 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 13:40:25 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 13:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 13:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 13:40:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 13:40:25 --> get_subcategory_list->{"lang":"37","category_id":"81","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-05 13:40:25 --> Total execution time: 0.1531
DEBUG - 2020-10-05 13:40:28 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 13:40:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 13:40:28 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 13:40:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 13:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 13:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 13:40:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 13:40:30 --> get_exercise_type_list->{"lang":"37","subcategory_id":"93","support_lang_id":"3"}
DEBUG - 2020-10-05 13:40:30 --> Total execution time: 0.0933
DEBUG - 2020-10-05 13:40:31 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 13:40:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-05 13:40:31 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-10-05 13:40:35 --> UTF-8 Support Enabled
DEBUG - 2020-10-05 13:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-05 13:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-05 13:40:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 13:40:35 --> get_grammer_type_2->{"slang":"37","tlang":"3","exercise_mode_id":"4","category_id":"81","subcategory_id":"93","support_lang_id":"3"}
ERROR - 2020-10-05 13:40:35 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-05 13:40:35 --> Total execution time: 0.1292
