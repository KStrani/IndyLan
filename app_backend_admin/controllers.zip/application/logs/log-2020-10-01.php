<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-10-01 15:45:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-01 15:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-01 15:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-01 15:45:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-01 15:45:12 --> Total execution time: 0.2294
DEBUG - 2020-10-01 15:45:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-01 15:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-01 15:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-01 15:45:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-01 15:45:17 --> Total execution time: 0.1050
DEBUG - 2020-10-01 15:45:25 --> UTF-8 Support Enabled
DEBUG - 2020-10-01 15:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-01 15:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-01 15:45:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-01 15:45:25 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2020-10-01 15:45:25 --> Total execution time: 0.1218
DEBUG - 2020-10-01 15:45:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-01 15:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-01 15:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-01 15:45:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-01 15:45:31 --> get_subcategory_list->{"lang":"37","category_id":"67","user_id":"1","support_lang_id":"1"}
DEBUG - 2020-10-01 15:45:31 --> Total execution time: 0.1177
DEBUG - 2020-10-01 15:45:35 --> UTF-8 Support Enabled
DEBUG - 2020-10-01 15:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-01 15:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-01 15:45:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-01 15:45:36 --> get_exercise_type_list->{"lang":"37","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2020-10-01 15:45:36 --> Total execution time: 0.1121
DEBUG - 2020-10-01 15:45:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-01 15:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-01 15:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-01 15:45:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-01 15:45:51 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"1","exercise_mode_id":"1","category_id":"67","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2020-10-01 15:45:51 --> Total execution time: 0.1535
DEBUG - 2020-10-01 15:45:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-01 15:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-01 15:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-01 15:45:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-01 15:45:55 --> get_exercise_type_list->{"lang":"37","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2020-10-01 15:45:55 --> Total execution time: 0.1071
