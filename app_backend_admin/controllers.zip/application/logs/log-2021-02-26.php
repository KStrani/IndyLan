<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-02-26 05:55:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 05:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 05:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 05:55:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 05:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 05:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 05:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 05:55:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 05:55:55 --> Total execution time: 0.1576
DEBUG - 2021-02-26 05:56:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 05:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 05:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 05:56:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 05:56:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 05:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 05:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 05:56:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 05:56:21 --> Total execution time: 0.1522
DEBUG - 2021-02-26 05:56:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 05:56:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 05:56:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 05:58:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 05:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 05:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 05:58:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 05:58:19 --> Total execution time: 0.1482
DEBUG - 2021-02-26 05:58:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 05:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 05:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 05:58:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 05:58:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 05:58:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 05:58:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 05:58:22 --> Total execution time: 0.1713
DEBUG - 2021-02-26 05:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 05:58:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 05:58:22 --> Total execution time: 0.1304
DEBUG - 2021-02-26 05:58:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 05:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 05:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 05:58:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 05:58:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 05:58:23 --> Total execution time: 0.1693
DEBUG - 2021-02-26 05:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 05:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 05:58:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 05:58:23 --> Total execution time: 0.1592
DEBUG - 2021-02-26 05:58:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 05:58:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 05:58:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 05:58:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 05:58:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 05:58:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 05:58:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 05:58:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 05:58:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:00:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:00:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:00:44 --> Total execution time: 0.1557
DEBUG - 2021-02-26 06:00:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:00:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:00:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:00:46 --> Total execution time: 0.1929
DEBUG - 2021-02-26 06:00:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:00:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:00:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:00:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:00:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:00:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:00:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:00:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:00:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:00:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:00:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:00:54 --> Total execution time: 0.1825
DEBUG - 2021-02-26 06:00:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:00:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:00:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:00:57 --> Total execution time: 0.2062
DEBUG - 2021-02-26 06:00:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:00:59 --> UTF-8 Support Enabled
ERROR - 2021-02-26 06:00:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:00:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:00:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:01:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:01:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:01:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:02:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:02:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:02:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:02:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:02:50 --> Total execution time: 0.1643
DEBUG - 2021-02-26 06:02:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:02:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:02:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:02:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:02:53 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-02-26 06:02:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:02:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:02:55 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-02-26 06:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:02:55 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-02-26 06:03:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:03:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:03:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:03:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:03:35 --> Total execution time: 0.1398
DEBUG - 2021-02-26 06:03:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:03:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:03:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:03:35 --> Total execution time: 0.1273
DEBUG - 2021-02-26 06:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:03:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:03:35 --> Total execution time: 0.2047
DEBUG - 2021-02-26 06:03:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:03:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:03:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:03:37 --> Total execution time: 0.1554
DEBUG - 2021-02-26 06:03:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:03:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:03:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:03:38 --> Total execution time: 0.1477
DEBUG - 2021-02-26 06:03:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:03:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:03:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:03:38 --> Total execution time: 0.1655
DEBUG - 2021-02-26 06:03:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:03:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:03:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:03:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:03:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:03:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:03:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:03:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:03:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:03:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:03:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:03:50 --> Total execution time: 0.1364
DEBUG - 2021-02-26 06:03:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:03:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:03:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:03:52 --> Total execution time: 0.1436
DEBUG - 2021-02-26 06:03:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:03:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:03:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:03:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:03:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:03:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:03:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:03:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:03:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:04:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:04:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:04:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:04:01 --> Total execution time: 0.1628
DEBUG - 2021-02-26 06:04:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:04:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:04:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:04:03 --> Total execution time: 0.1386
DEBUG - 2021-02-26 06:04:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:04:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:04:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:04:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:04:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:04:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:04:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:04:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:04:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:05:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:05:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:05:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:05:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:05:32 --> Total execution time: 0.1587
DEBUG - 2021-02-26 06:05:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:05:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:05:34 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-02-26 06:05:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:05:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:05:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:05:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:05:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:05:36 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-02-26 06:05:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:05:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:05:37 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-02-26 06:05:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:05:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:05:46 --> Total execution time: 0.1374
DEBUG - 2021-02-26 06:05:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:05:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:05:47 --> Total execution time: 0.1253
DEBUG - 2021-02-26 06:05:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:05:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:05:47 --> Total execution time: 0.1292
DEBUG - 2021-02-26 06:05:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:05:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:05:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:05:47 --> Total execution time: 0.1513
DEBUG - 2021-02-26 06:05:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:05:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:05:47 --> Total execution time: 0.1431
DEBUG - 2021-02-26 06:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:05:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:05:47 --> Total execution time: 0.1338
DEBUG - 2021-02-26 06:05:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:05:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:05:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:05:49 --> Total execution time: 0.1498
DEBUG - 2021-02-26 06:05:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:05:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:05:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:05:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:05:49 --> Total execution time: 0.1659
DEBUG - 2021-02-26 06:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:05:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:05:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:05:49 --> Total execution time: 0.2139
DEBUG - 2021-02-26 06:05:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:05:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:05:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:05:49 --> Total execution time: 0.1245
DEBUG - 2021-02-26 06:05:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:05:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:05:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:05:49 --> Total execution time: 0.1600
DEBUG - 2021-02-26 06:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:05:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:05:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:05:49 --> Total execution time: 0.1239
DEBUG - 2021-02-26 06:05:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:05:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:05:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:05:50 --> Total execution time: 0.1337
DEBUG - 2021-02-26 06:05:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:05:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:05:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:05:52 --> Total execution time: 0.1526
DEBUG - 2021-02-26 06:05:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:05:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:05:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:05:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:05:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:05:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:05:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:05:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:05:57 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:06:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:06:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:06:02 --> Total execution time: 0.1787
DEBUG - 2021-02-26 06:06:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:06:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:06:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:06:05 --> Total execution time: 0.1583
DEBUG - 2021-02-26 06:06:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:06:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:06:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:06:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:06:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:06:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:06:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:06:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:06:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:06:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:06:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:06:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:06:28 --> Total execution time: 0.1531
DEBUG - 2021-02-26 06:06:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:06:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:06:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:06:31 --> Total execution time: 0.1421
DEBUG - 2021-02-26 06:06:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:06:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:06:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:06:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:06:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:06:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:06:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:06:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:06:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:06:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:06:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:06:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:06:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:06:51 --> Total execution time: 0.1641
DEBUG - 2021-02-26 06:06:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:06:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:06:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:06:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:06:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:06:54 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-02-26 06:06:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:06:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:06:56 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-02-26 06:06:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:06:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:06:56 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-02-26 06:07:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:07:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:07:00 --> Total execution time: 0.1642
DEBUG - 2021-02-26 06:07:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:07:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:07:01 --> Total execution time: 0.1338
DEBUG - 2021-02-26 06:07:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:07:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:07:01 --> Total execution time: 0.1237
DEBUG - 2021-02-26 06:07:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:07:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:07:01 --> Total execution time: 0.1714
DEBUG - 2021-02-26 06:07:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:07:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:07:01 --> Total execution time: 0.1574
DEBUG - 2021-02-26 06:07:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:07:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:07:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:07:03 --> Total execution time: 0.1812
DEBUG - 2021-02-26 06:07:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:07:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:07:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:07:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:07:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:07:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:07:04 --> Total execution time: 0.1892
DEBUG - 2021-02-26 06:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:07:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:07:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:07:04 --> Total execution time: 0.1907
DEBUG - 2021-02-26 06:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:07:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:07:04 --> UTF-8 Support Enabled
ERROR - 2021-02-26 06:07:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:07:04 --> Total execution time: 0.2012
DEBUG - 2021-02-26 06:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:07:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:07:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:07:04 --> Total execution time: 0.1438
DEBUG - 2021-02-26 06:07:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:07:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:07:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:07:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:07:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:07:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:07:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:07:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:07:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:07:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:07:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:07:12 --> Total execution time: 0.1653
DEBUG - 2021-02-26 06:07:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:07:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:07:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:07:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:07:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:07:33 --> Total execution time: 0.1401
DEBUG - 2021-02-26 06:07:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:07:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:07:38 --> Total execution time: 0.1541
DEBUG - 2021-02-26 06:10:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:10:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:10:46 --> Total execution time: 0.1582
DEBUG - 2021-02-26 06:10:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:10:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:10:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:10:48 --> Total execution time: 0.1390
DEBUG - 2021-02-26 06:10:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:10:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:10:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:10:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:10:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:10:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:10:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:10:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:10:54 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:10:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:10:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:10:57 --> Total execution time: 0.1474
DEBUG - 2021-02-26 06:11:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:11:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:11:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:11:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:11:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:11:06 --> Total execution time: 0.1619
DEBUG - 2021-02-26 06:11:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:11:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:11:12 --> Total execution time: 0.1253
DEBUG - 2021-02-26 06:14:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:14:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:14:22 --> Total execution time: 0.1549
DEBUG - 2021-02-26 06:14:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:14:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:14:23 --> Total execution time: 0.1376
DEBUG - 2021-02-26 06:14:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:14:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:14:25 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:14:25 --> Total execution time: 0.1580
DEBUG - 2021-02-26 06:14:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:14:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:14:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:14:26 --> Total execution time: 0.1759
DEBUG - 2021-02-26 06:14:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:14:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:14:29 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:14:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:14:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:14:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:14:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:14:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:14:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:14:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:14:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:14:42 --> Total execution time: 0.1688
DEBUG - 2021-02-26 06:14:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:14:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:14:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:14:45 --> Total execution time: 0.1781
DEBUG - 2021-02-26 06:14:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:14:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:14:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:14:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:14:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:14:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:14:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:14:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:14:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:14:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:14:53 --> Total execution time: 0.1514
DEBUG - 2021-02-26 06:14:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:14:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:14:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:14:56 --> Total execution time: 0.1637
DEBUG - 2021-02-26 06:14:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:14:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:14:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:14:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:14:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:14:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:15:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:15:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:15:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:15:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:15:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:15:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:15:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:15:25 --> Total execution time: 0.1511
DEBUG - 2021-02-26 06:15:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:15:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:15:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:15:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:15:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:15:28 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-02-26 06:15:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:15:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:15:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:15:30 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-02-26 06:15:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:15:30 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-02-26 06:15:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:15:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:15:59 --> Total execution time: 0.1339
DEBUG - 2021-02-26 06:15:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:15:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:15:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:15:59 --> Total execution time: 0.1282
DEBUG - 2021-02-26 06:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:15:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:15:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:15:59 --> Total execution time: 0.1362
DEBUG - 2021-02-26 06:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:16:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:16:00 --> Total execution time: 0.1680
DEBUG - 2021-02-26 06:16:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:16:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:16:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:16:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:16:02 --> Total execution time: 0.2713
DEBUG - 2021-02-26 06:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:16:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:16:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:16:02 --> Total execution time: 0.1909
DEBUG - 2021-02-26 06:16:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:16:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:16:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:16:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:16:02 --> Total execution time: 0.1847
DEBUG - 2021-02-26 06:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:16:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:16:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:16:02 --> Total execution time: 0.2202
DEBUG - 2021-02-26 06:16:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:16:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:16:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:16:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:16:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:16:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:16:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:16:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:16:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:16:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:16:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:16:20 --> Total execution time: 0.1829
DEBUG - 2021-02-26 06:16:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:16:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:16:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:16:23 --> Total execution time: 0.1517
DEBUG - 2021-02-26 06:16:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:16:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:16:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:16:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:16:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:16:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:16:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:16:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:16:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:16:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:16:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:16:39 --> Total execution time: 0.1249
DEBUG - 2021-02-26 06:16:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:16:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:16:41 --> Total execution time: 0.1295
DEBUG - 2021-02-26 06:16:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:16:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:16:41 --> Total execution time: 0.1259
DEBUG - 2021-02-26 06:16:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:16:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:16:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:16:41 --> Total execution time: 0.1369
DEBUG - 2021-02-26 06:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:16:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:16:41 --> Total execution time: 0.1682
DEBUG - 2021-02-26 06:16:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:16:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:16:44 --> Total execution time: 0.1281
DEBUG - 2021-02-26 06:16:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:16:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:16:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:16:44 --> Total execution time: 0.1467
DEBUG - 2021-02-26 06:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:16:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:16:44 --> Total execution time: 0.2019
DEBUG - 2021-02-26 06:16:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:16:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:16:47 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:16:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:16:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:16:55 --> Total execution time: 0.1548
DEBUG - 2021-02-26 06:17:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:17:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:17:00 --> Total execution time: 0.1517
DEBUG - 2021-02-26 06:17:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:17:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:17:31 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:17:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:17:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:17:34 --> Total execution time: 0.1379
DEBUG - 2021-02-26 06:17:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:17:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:17:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:17:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:17:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:17:42 --> Total execution time: 0.1702
DEBUG - 2021-02-26 06:17:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:17:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:17:42 --> Total execution time: 0.1263
DEBUG - 2021-02-26 06:17:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:17:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:17:43 --> Total execution time: 0.1607
DEBUG - 2021-02-26 06:17:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:17:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:17:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:17:44 --> Total execution time: 0.1403
DEBUG - 2021-02-26 06:17:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:17:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:17:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:17:45 --> Total execution time: 0.1373
DEBUG - 2021-02-26 06:17:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:17:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:17:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:17:46 --> Total execution time: 0.1375
DEBUG - 2021-02-26 06:17:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:17:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:17:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:17:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:17:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:17:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:17:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:17:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:17:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:17:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:17:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:17:59 --> Total execution time: 0.1197
DEBUG - 2021-02-26 06:18:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:18:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:18:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:18:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:18:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:18:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:18:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:18:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:18:21 --> Total execution time: 0.1685
DEBUG - 2021-02-26 06:18:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:18:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:18:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:18:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:18:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:18:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:18:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:18:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:18:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:18:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:18:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:18:38 --> Total execution time: 0.1457
DEBUG - 2021-02-26 06:18:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:18:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:18:41 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:19:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:19:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:19:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:19:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:19:09 --> Total execution time: 0.1170
DEBUG - 2021-02-26 06:19:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:19:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:19:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:19:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:19:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:19:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:19:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:19:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:19:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:19:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:19:21 --> Total execution time: 0.1119
DEBUG - 2021-02-26 06:19:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:19:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:19:23 --> Total execution time: 0.1400
DEBUG - 2021-02-26 06:19:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:19:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:19:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:19:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:19:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:19:46 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:19:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:19:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:19:48 --> Total execution time: 0.1332
DEBUG - 2021-02-26 06:19:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:19:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:19:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:19:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:19:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:19:56 --> Total execution time: 0.1655
DEBUG - 2021-02-26 06:19:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:19:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:19:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:19:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:19:58 --> Total execution time: 0.1633
DEBUG - 2021-02-26 06:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:19:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:19:58 --> Total execution time: 0.1326
DEBUG - 2021-02-26 06:20:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:20:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:20:01 --> Total execution time: 0.1379
DEBUG - 2021-02-26 06:20:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:20:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:20:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:20:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:20:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:20:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:20:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:20:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:20:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:20:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:20:10 --> Total execution time: 0.1692
DEBUG - 2021-02-26 06:20:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:20:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:20:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:20:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:20:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:20:30 --> Total execution time: 0.1295
DEBUG - 2021-02-26 06:20:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:20:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:20:31 --> Total execution time: 0.1490
DEBUG - 2021-02-26 06:20:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:20:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:20:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:20:32 --> Total execution time: 0.1280
DEBUG - 2021-02-26 06:20:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:20:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:20:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:20:33 --> Total execution time: 0.1640
DEBUG - 2021-02-26 06:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:20:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:20:33 --> Total execution time: 0.1268
DEBUG - 2021-02-26 06:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:20:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:20:33 --> Total execution time: 0.1865
DEBUG - 2021-02-26 06:20:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:20:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:20:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:20:34 --> Total execution time: 0.1360
DEBUG - 2021-02-26 06:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:20:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:20:34 --> Total execution time: 0.1314
DEBUG - 2021-02-26 06:20:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:20:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:20:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:20:35 --> Total execution time: 0.1504
DEBUG - 2021-02-26 06:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:20:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:20:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:20:35 --> Total execution time: 0.1900
DEBUG - 2021-02-26 06:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:20:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:20:35 --> Total execution time: 0.1366
DEBUG - 2021-02-26 06:20:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:20:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:20:36 --> Total execution time: 0.1279
DEBUG - 2021-02-26 06:20:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:20:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:20:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:20:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:20:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:20:44 --> Total execution time: 0.1399
DEBUG - 2021-02-26 06:20:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:20:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:20:46 --> Total execution time: 0.1273
DEBUG - 2021-02-26 06:20:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:20:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:20:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:26:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:26:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:26:35 --> Total execution time: 0.1295
DEBUG - 2021-02-26 06:26:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:26:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:26:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:26:38 --> Total execution time: 0.2139
DEBUG - 2021-02-26 06:26:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:26:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:26:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:26:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:26:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:26:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:26:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:27:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:27:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:27:31 --> Total execution time: 0.1836
DEBUG - 2021-02-26 06:27:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:27:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:27:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:28:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:28:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:28:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:28:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:28:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:28:16 --> Total execution time: 0.1592
DEBUG - 2021-02-26 06:28:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:28:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:28:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:28:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:28:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:28:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:28:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:28:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:28:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:28:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:28:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:28:28 --> Total execution time: 0.1772
DEBUG - 2021-02-26 06:28:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:28:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:28:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:28:29 --> Total execution time: 0.1307
DEBUG - 2021-02-26 06:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:28:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:28:30 --> Total execution time: 0.1241
DEBUG - 2021-02-26 06:28:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:28:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:28:30 --> Total execution time: 0.1566
DEBUG - 2021-02-26 06:28:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:28:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:28:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:28:31 --> Total execution time: 0.1933
DEBUG - 2021-02-26 06:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:28:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:28:31 --> Total execution time: 0.1258
DEBUG - 2021-02-26 06:28:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:28:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:28:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:28:32 --> Total execution time: 0.1859
DEBUG - 2021-02-26 06:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:28:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:28:32 --> Total execution time: 0.1315
DEBUG - 2021-02-26 06:28:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:28:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:28:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:28:34 --> Total execution time: 0.1340
DEBUG - 2021-02-26 06:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:28:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:28:34 --> Total execution time: 0.1465
DEBUG - 2021-02-26 06:28:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:28:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:28:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:29:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:29:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:29:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:29:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:29:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:29:05 --> Total execution time: 0.1459
DEBUG - 2021-02-26 06:29:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:29:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:29:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:29:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:29:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:29:13 --> Total execution time: 0.1728
DEBUG - 2021-02-26 06:29:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:29:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-26 06:29:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-26 06:29:16 --> Total execution time: 0.1144
DEBUG - 2021-02-26 06:29:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:29:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:29:17 --> Total execution time: 0.1483
DEBUG - 2021-02-26 06:29:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:29:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:29:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:29:18 --> Total execution time: 0.1647
DEBUG - 2021-02-26 06:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:29:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:29:18 --> Total execution time: 0.1744
DEBUG - 2021-02-26 06:29:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:29:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:29:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-26 06:29:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:29:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:29:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:29:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-26 06:29:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-26 06:30:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-26 06:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-26 06:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-26 06:30:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-26 06:30:02 --> Total execution time: 0.1591
