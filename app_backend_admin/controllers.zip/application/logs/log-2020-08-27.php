<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-08-27 03:39:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:39:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:39:01 --> Total execution time: 0.1703
DEBUG - 2020-08-27 03:39:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:39:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:39:21 --> Total execution time: 0.1267
DEBUG - 2020-08-27 03:39:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:39:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:39:27 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-27 03:39:27 --> Total execution time: 0.1154
DEBUG - 2020-08-27 03:39:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:39:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:39:33 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-27 03:39:33 --> Total execution time: 0.1167
DEBUG - 2020-08-27 03:39:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:39:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:39:39 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 03:39:39 --> Total execution time: 0.1470
DEBUG - 2020-08-27 03:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:40:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:40:14 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"2","exercise_mode_id":"1","category_id":"123","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 03:40:14 --> Total execution time: 0.1399
DEBUG - 2020-08-27 03:40:19 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:40:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:40:19 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 03:40:19 --> Total execution time: 0.1153
DEBUG - 2020-08-27 03:48:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:48:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:48:20 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 03:48:20 --> Total execution time: 0.1359
DEBUG - 2020-08-27 03:50:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:50:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:50:18 --> Total execution time: 0.1323
DEBUG - 2020-08-27 03:50:23 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:50:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:50:23 --> Total execution time: 0.1363
DEBUG - 2020-08-27 03:50:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:50:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:50:30 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-27 03:50:30 --> Total execution time: 0.1461
DEBUG - 2020-08-27 03:50:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:50:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:50:34 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-27 03:50:34 --> Total execution time: 0.1003
DEBUG - 2020-08-27 03:50:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:50:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:50:38 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 03:50:38 --> Total execution time: 0.1135
DEBUG - 2020-08-27 03:50:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:50:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:50:42 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"2","exercise_mode_id":"1","category_id":"123","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 03:50:42 --> Total execution time: 0.1135
DEBUG - 2020-08-27 03:51:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:51:15 --> No URI present. Default controller set.
DEBUG - 2020-08-27 03:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:51:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:51:16 --> Total execution time: 0.1620
DEBUG - 2020-08-27 03:53:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:53:08 --> No URI present. Default controller set.
DEBUG - 2020-08-27 03:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:53:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:53:09 --> Total execution time: 0.1649
DEBUG - 2020-08-27 03:53:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:53:20 --> No URI present. Default controller set.
DEBUG - 2020-08-27 03:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:53:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:53:20 --> Total execution time: 0.1801
DEBUG - 2020-08-27 03:56:00 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:56:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:56:03 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:56:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:56:03 --> Total execution time: 0.1603
DEBUG - 2020-08-27 03:56:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:56:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-27 03:56:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-27 03:56:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:56:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:56:38 --> Total execution time: 0.1675
DEBUG - 2020-08-27 03:56:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-27 03:56:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-08-27 03:56:42 --> Total execution time: 0.1486
DEBUG - 2020-08-27 03:56:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:56:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-27 03:56:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-27 03:57:00 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:57:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:57:00 --> Total execution time: 0.1544
DEBUG - 2020-08-27 03:57:02 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:57:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-27 03:57:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-27 03:57:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:57:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:57:12 --> Total execution time: 0.1680
DEBUG - 2020-08-27 03:57:38 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:57:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:57:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:57:38 --> Total execution time: 0.1165
DEBUG - 2020-08-27 03:57:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:57:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:57:41 --> Total execution time: 0.1442
DEBUG - 2020-08-27 03:57:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:57:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-27 03:57:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-27 03:57:56 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:57:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:57:56 --> Total execution time: 0.1593
DEBUG - 2020-08-27 03:57:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:57:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:57:58 --> Total execution time: 0.1710
DEBUG - 2020-08-27 03:58:06 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 03:58:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 03:58:06 --> Total execution time: 0.1503
DEBUG - 2020-08-27 03:58:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:58:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 03:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 03:58:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-27 03:58:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 03:58:15 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-27 04:00:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:00:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:00:48 --> Total execution time: 0.1754
DEBUG - 2020-08-27 04:00:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-27 04:00:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-27 04:00:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:00:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-27 04:00:55 --> 404 Page Not Found: Assets/js
DEBUG - 2020-08-27 04:01:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:01:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:01:05 --> Total execution time: 0.1283
DEBUG - 2020-08-27 04:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:01:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:01:08 --> Total execution time: 0.1761
DEBUG - 2020-08-27 04:01:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:01:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:01:51 --> Total execution time: 0.1679
DEBUG - 2020-08-27 04:01:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:01:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-27 04:01:54 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-27 04:02:02 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:02:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:02:02 --> Total execution time: 0.1204
DEBUG - 2020-08-27 04:02:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:02:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:02:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:02:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-27 04:02:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-08-27 04:02:31 --> Total execution time: 0.1992
DEBUG - 2020-08-27 04:02:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:02:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-27 04:02:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-27 04:02:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:02:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:02:44 --> Total execution time: 0.1348
DEBUG - 2020-08-27 04:02:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:02:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-27 04:02:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-27 04:02:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:02:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:02:57 --> Total execution time: 0.1723
DEBUG - 2020-08-27 04:03:00 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:03:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:03:00 --> Total execution time: 0.1525
DEBUG - 2020-08-27 04:03:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:03:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:03:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:03:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-27 04:03:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-08-27 04:03:47 --> Total execution time: 0.1598
DEBUG - 2020-08-27 04:03:50 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:03:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-27 04:03:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-27 04:04:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:04:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:04:16 --> Total execution time: 0.1034
DEBUG - 2020-08-27 04:04:22 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:04:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:04:22 --> Total execution time: 0.1514
DEBUG - 2020-08-27 04:04:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:04:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:04:28 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-27 04:04:28 --> Total execution time: 0.1288
DEBUG - 2020-08-27 04:04:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:04:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:04:31 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-27 04:04:31 --> Total execution time: 0.1485
DEBUG - 2020-08-27 04:04:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:04:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:04:35 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 04:04:35 --> Total execution time: 0.1126
DEBUG - 2020-08-27 04:04:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:04:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:04:39 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"2","exercise_mode_id":"1","category_id":"123","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 04:04:39 --> Total execution time: 0.1473
DEBUG - 2020-08-27 04:04:50 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:04:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:04:50 --> Total execution time: 0.1151
DEBUG - 2020-08-27 04:04:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:04:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:04:54 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"2","exercise_mode_id":"1","category_id":"123","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 04:04:54 --> Total execution time: 0.1275
DEBUG - 2020-08-27 04:06:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:06:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:06:41 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 04:06:41 --> Total execution time: 0.1313
DEBUG - 2020-08-27 04:06:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:06:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:06:46 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"2","exercise_mode_id":"1","category_id":"123","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 04:06:46 --> Total execution time: 0.1618
DEBUG - 2020-08-27 04:06:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:06:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:06:54 --> Total execution time: 0.1647
DEBUG - 2020-08-27 04:07:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:07:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:07:24 --> Total execution time: 0.1300
DEBUG - 2020-08-27 04:07:29 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:07:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:07:29 --> Total execution time: 0.1230
DEBUG - 2020-08-27 04:07:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:07:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:07:37 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-27 04:07:37 --> Total execution time: 0.1154
DEBUG - 2020-08-27 04:07:42 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:07:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:07:42 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-27 04:07:42 --> Total execution time: 0.1470
DEBUG - 2020-08-27 04:07:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:07:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:07:46 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 04:07:46 --> Total execution time: 0.1366
DEBUG - 2020-08-27 04:07:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:07:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:07:51 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"2","exercise_mode_id":"1","category_id":"123","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 04:07:51 --> Total execution time: 0.1438
DEBUG - 2020-08-27 04:10:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:10:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:10:30 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 04:10:30 --> Total execution time: 0.1486
DEBUG - 2020-08-27 04:10:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:10:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:10:30 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-27 04:10:30 --> Total execution time: 0.1608
DEBUG - 2020-08-27 04:10:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:10:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:10:31 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-27 04:10:31 --> Total execution time: 0.1195
DEBUG - 2020-08-27 04:10:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:10:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:10:33 --> Total execution time: 0.1349
DEBUG - 2020-08-27 04:10:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:10:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:10:36 --> Total execution time: 0.1332
DEBUG - 2020-08-27 04:10:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:10:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:10:41 --> Total execution time: 0.1311
DEBUG - 2020-08-27 04:10:45 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:10:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:10:45 --> Total execution time: 0.0975
DEBUG - 2020-08-27 04:10:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:10:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:10:51 --> Total execution time: 0.1300
DEBUG - 2020-08-27 04:10:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:10:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:10:55 --> Total execution time: 0.1435
DEBUG - 2020-08-27 04:11:07 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:11:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:11:07 --> Total execution time: 0.1520
DEBUG - 2020-08-27 04:11:12 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:11:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:11:12 --> Total execution time: 0.1784
DEBUG - 2020-08-27 04:12:05 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:12:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:12:06 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"","exercise_mode_id":"1","category_id":"123","subcategory_id":"273","support_lang_id":"2"}
ERROR - 2020-08-27 04:12:06 --> {"status":0,"message":"Parameters not passed","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-08-27 04:12:06 --> Total execution time: 0.1629
DEBUG - 2020-08-27 04:12:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:12:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:12:16 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"123","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 04:12:16 --> Total execution time: 0.1346
DEBUG - 2020-08-27 04:15:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:15:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:15:51 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"123","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 04:15:51 --> Total execution time: 0.1263
DEBUG - 2020-08-27 04:15:59 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:15:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-27 04:15:59 --> 404 Page Not Found: Sv/uploads
DEBUG - 2020-08-27 04:21:43 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:21:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:21:43 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"123","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 04:21:43 --> Total execution time: 0.1325
DEBUG - 2020-08-27 04:21:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:21:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:21:57 --> Total execution time: 0.1290
DEBUG - 2020-08-27 04:22:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:22:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:22:04 --> Total execution time: 0.1262
DEBUG - 2020-08-27 04:22:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:22:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:22:11 --> Total execution time: 0.1318
DEBUG - 2020-08-27 04:22:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:22:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:22:18 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-27 04:22:18 --> Total execution time: 0.1445
DEBUG - 2020-08-27 04:22:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:22:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:22:24 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-27 04:22:24 --> Total execution time: 0.1453
DEBUG - 2020-08-27 04:22:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:22:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:22:28 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 04:22:28 --> Total execution time: 0.1736
DEBUG - 2020-08-27 04:22:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:22:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:22:32 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"2","exercise_mode_id":"1","category_id":"123","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 04:22:32 --> Total execution time: 0.1238
DEBUG - 2020-08-27 04:22:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:22:46 --> Total execution time: 0.1718
DEBUG - 2020-08-27 04:22:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:22:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:22:49 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 04:22:49 --> Total execution time: 0.1431
DEBUG - 2020-08-27 04:22:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:22:55 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-27 04:22:55 --> Total execution time: 0.2062
DEBUG - 2020-08-27 04:22:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:22:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:22:57 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-27 04:22:57 --> Total execution time: 0.1226
DEBUG - 2020-08-27 04:23:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:23:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:23:28 --> Total execution time: 0.1338
DEBUG - 2020-08-27 04:23:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:23:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-27 04:23:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-27 04:26:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:26:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:26:48 --> Total execution time: 0.1159
DEBUG - 2020-08-27 04:26:56 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:26:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:26:56 --> Total execution time: 0.0999
DEBUG - 2020-08-27 04:27:09 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:27:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:27:09 --> Total execution time: 0.1365
DEBUG - 2020-08-27 04:27:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:27:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:27:51 --> Total execution time: 0.1567
DEBUG - 2020-08-27 04:27:55 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:27:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-27 04:27:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-08-27 04:27:55 --> Total execution time: 0.1554
DEBUG - 2020-08-27 04:27:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:27:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-27 04:27:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-27 04:28:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:28:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:28:04 --> Total execution time: 0.1327
DEBUG - 2020-08-27 04:28:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:28:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-27 04:28:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-27 04:43:19 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:43:19 --> Total execution time: 0.1262
DEBUG - 2020-08-27 04:43:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:43:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-27 04:43:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-08-27 04:43:21 --> Total execution time: 0.2076
DEBUG - 2020-08-27 04:43:24 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:43:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-27 04:43:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-27 04:58:13 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:58:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:58:13 --> Total execution time: 0.1411
DEBUG - 2020-08-27 04:58:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:58:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:58:25 --> Total execution time: 0.1518
DEBUG - 2020-08-27 04:58:44 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:58:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:58:44 --> Total execution time: 0.1336
DEBUG - 2020-08-27 04:58:59 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 04:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 04:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 04:58:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 04:58:59 --> Total execution time: 0.1910
DEBUG - 2020-08-27 05:08:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 05:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 05:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 05:08:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 05:08:04 --> Total execution time: 0.1374
DEBUG - 2020-08-27 05:08:11 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 05:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 05:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 05:08:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 05:08:11 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-27 05:08:11 --> Total execution time: 0.1202
DEBUG - 2020-08-27 05:08:21 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 05:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 05:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 05:08:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 05:08:22 --> Total execution time: 0.1777
DEBUG - 2020-08-27 05:08:26 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 05:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 05:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 05:08:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 05:08:26 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-27 05:08:26 --> Total execution time: 0.1395
DEBUG - 2020-08-27 05:08:31 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 05:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 05:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 05:08:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 05:08:31 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-27 05:08:31 --> Total execution time: 0.1633
DEBUG - 2020-08-27 05:08:34 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 05:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 05:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 05:08:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 05:08:34 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 05:08:34 --> Total execution time: 0.1467
DEBUG - 2020-08-27 05:08:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 05:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 05:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 05:08:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 05:08:39 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"2","exercise_mode_id":"1","category_id":"123","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 05:08:39 --> Total execution time: 0.1487
DEBUG - 2020-08-27 07:40:26 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 07:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 07:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 07:40:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 07:40:26 --> Total execution time: 0.1061
DEBUG - 2020-08-27 08:14:28 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:14:28 --> No URI present. Default controller set.
DEBUG - 2020-08-27 08:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 08:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 08:14:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 08:14:28 --> Total execution time: 0.1564
DEBUG - 2020-08-27 08:14:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 08:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 08:14:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 08:14:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 08:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 08:14:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 08:14:51 --> Total execution time: 0.1714
DEBUG - 2020-08-27 08:14:54 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:14:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-27 08:14:54 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-27 08:15:10 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 08:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 08:15:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 08:15:10 --> Total execution time: 0.1595
DEBUG - 2020-08-27 08:15:13 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 08:15:13 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 08:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 08:15:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 08:15:13 --> Total execution time: 0.1567
DEBUG - 2020-08-27 08:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 08:15:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-27 08:15:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-08-27 08:15:13 --> Total execution time: 0.1671
DEBUG - 2020-08-27 08:15:16 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:15:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-27 08:15:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-27 08:19:46 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 08:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 08:19:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 08:19:46 --> Total execution time: 0.1785
DEBUG - 2020-08-27 08:19:49 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:19:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-27 08:19:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-27 08:19:58 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 08:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 08:19:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 08:19:58 --> Total execution time: 0.2126
DEBUG - 2020-08-27 08:20:15 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 08:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 08:20:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 08:20:15 --> Total execution time: 0.1333
DEBUG - 2020-08-27 08:20:18 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:20:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-27 08:20:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-27 08:20:25 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 08:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 08:20:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 08:20:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 08:20:25 --> Total execution time: 0.1662
DEBUG - 2020-08-27 08:20:27 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 08:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 08:20:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 08:20:27 --> Total execution time: 0.1326
DEBUG - 2020-08-27 08:20:30 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:20:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-27 08:20:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-27 08:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 08:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 08:20:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 08:20:36 --> Total execution time: 0.1288
DEBUG - 2020-08-27 08:20:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 08:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 08:20:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 08:20:41 --> Total execution time: 0.1245
DEBUG - 2020-08-27 08:21:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 08:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 08:21:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 08:21:39 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 08:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 08:21:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-27 08:21:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-08-27 08:21:39 --> Total execution time: 0.1818
DEBUG - 2020-08-27 08:21:41 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:21:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-08-27 08:21:41 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-08-27 08:21:47 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 08:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 08:21:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 08:21:47 --> Total execution time: 0.1376
DEBUG - 2020-08-27 08:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 08:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 08:21:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 08:21:51 --> Total execution time: 0.1286
DEBUG - 2020-08-27 08:21:57 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 08:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 08:21:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 08:21:57 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-27 08:21:57 --> Total execution time: 0.1775
DEBUG - 2020-08-27 08:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 08:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 08:22:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 08:22:01 --> get_subcategory_list->{"lang":"37","category_id":"123","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-08-27 08:22:01 --> Total execution time: 0.1645
DEBUG - 2020-08-27 08:22:04 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 08:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 08:22:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 08:22:05 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 08:22:05 --> Total execution time: 0.1169
DEBUG - 2020-08-27 08:22:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 08:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 08:22:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 08:22:09 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"2","exercise_mode_id":"1","category_id":"123","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 08:22:09 --> Total execution time: 0.1529
DEBUG - 2020-08-27 08:22:20 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 08:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 08:22:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 08:22:20 --> get_exercise_type_list->{"lang":"37","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 08:22:20 --> Total execution time: 0.1363
DEBUG - 2020-08-27 08:27:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 08:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 08:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 08:27:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 08:27:36 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"2","exercise_mode_id":"1","category_id":"123","subcategory_id":"273","support_lang_id":"2"}
DEBUG - 2020-08-27 08:27:36 --> Total execution time: 0.1153
DEBUG - 2020-08-27 09:17:19 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 09:17:19 --> No URI present. Default controller set.
DEBUG - 2020-08-27 09:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 09:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 09:17:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 09:17:19 --> Total execution time: 0.1162
DEBUG - 2020-08-27 11:59:32 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 11:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 11:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 11:59:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 11:59:33 --> Total execution time: 0.1558
DEBUG - 2020-08-27 11:59:33 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 11:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 11:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 11:59:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 11:59:34 --> Total execution time: 0.1270
DEBUG - 2020-08-27 11:59:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 11:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 11:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 11:59:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 11:59:36 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 11:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 11:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 11:59:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 11:59:40 --> UTF-8 Support Enabled
DEBUG - 2020-08-27 11:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-27 11:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-27 11:59:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 11:59:40 --> Total execution time: 0.1688
