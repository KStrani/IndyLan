<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-09-15 12:46:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-15 12:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-15 12:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-15 12:46:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 12:46:59 --> Total execution time: 0.1494
DEBUG - 2020-09-15 12:47:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-15 12:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-15 12:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-15 12:47:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 12:47:03 --> Total execution time: 0.1274
DEBUG - 2020-09-15 12:47:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-15 12:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-15 12:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-15 12:47:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 12:47:09 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-15 12:47:09 --> Total execution time: 0.1166
DEBUG - 2020-09-15 12:47:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-15 12:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-15 12:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-15 12:47:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 12:47:14 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-15 12:47:14 --> Total execution time: 0.1309
DEBUG - 2020-09-15 12:47:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-15 12:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-15 12:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-15 12:47:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 12:47:18 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-15 12:47:18 --> Total execution time: 0.1809
DEBUG - 2020-09-15 12:47:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-15 12:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-15 12:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-15 12:47:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 12:47:22 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"3","exercise_mode_id":"1","category_id":"62","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-15 12:47:22 --> Total execution time: 0.1746
DEBUG - 2020-09-15 12:47:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-15 12:47:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-15 12:47:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-15 12:47:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-15 12:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-15 12:47:28 --> UTF-8 Support Enabled
ERROR - 2020-09-15 12:47:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-15 12:47:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-15 12:47:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-15 12:47:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-15 12:47:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-15 12:47:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-15 12:47:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-15 12:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-15 12:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-15 12:47:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 12:47:29 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-09-15 12:47:29 --> Total execution time: 0.1090
