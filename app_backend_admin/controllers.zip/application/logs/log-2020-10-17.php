<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-10-17 11:27:39 --> UTF-8 Support Enabled
DEBUG - 2020-10-17 11:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-17 11:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-17 11:27:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-17 11:27:39 --> Total execution time: 0.1689
DEBUG - 2020-10-17 11:27:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-17 11:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-17 11:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-17 11:27:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-17 11:27:44 --> Total execution time: 0.1146
DEBUG - 2020-10-17 11:27:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-17 11:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-17 11:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-17 11:27:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-17 11:27:52 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-17 11:27:52 --> Total execution time: 0.1181
DEBUG - 2020-10-17 11:27:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-17 11:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-17 11:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-17 11:27:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-17 11:27:55 --> get_subcategory_list->{"lang":"37","category_id":"62","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-17 11:27:55 --> Total execution time: 0.1321
DEBUG - 2020-10-17 11:27:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-17 11:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-17 11:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-17 11:27:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-17 11:27:59 --> get_exercise_type_list->{"lang":"37","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-10-17 11:27:59 --> Total execution time: 0.1133
DEBUG - 2020-10-17 11:28:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-17 11:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-17 11:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-17 11:28:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-17 11:28:02 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"62","subcategory_id":"101","support_lang_id":"3"}
DEBUG - 2020-10-17 11:28:02 --> Total execution time: 0.1238
DEBUG - 2020-10-17 11:28:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-17 11:28:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-17 11:28:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-17 11:28:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-17 11:28:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-17 11:28:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-10-17 11:28:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-17 11:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-17 11:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-17 11:28:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-17 11:28:12 --> Total execution time: 0.0993
DEBUG - 2020-10-17 11:28:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-17 11:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-17 11:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-17 11:28:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-17 11:28:41 --> Total execution time: 0.1135
DEBUG - 2020-10-17 11:28:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-17 11:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-17 11:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-17 11:28:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-17 11:28:44 --> Total execution time: 0.1190
DEBUG - 2020-10-17 11:28:53 --> UTF-8 Support Enabled
DEBUG - 2020-10-17 11:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-17 11:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-17 11:28:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-17 11:28:53 --> get_category_list->{"lang":"38","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-17 11:28:53 --> Total execution time: 0.1003
DEBUG - 2020-10-17 11:28:57 --> UTF-8 Support Enabled
DEBUG - 2020-10-17 11:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-17 11:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-17 11:28:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-17 11:28:58 --> get_subcategory_list->{"lang":"38","category_id":"124","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-17 11:28:58 --> Total execution time: 0.1430
DEBUG - 2020-10-17 11:29:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-17 11:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-17 11:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-17 11:29:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-17 11:29:01 --> get_exercise_type_list->{"lang":"38","subcategory_id":"274","support_lang_id":"3"}
DEBUG - 2020-10-17 11:29:01 --> Total execution time: 0.1280
DEBUG - 2020-10-17 11:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-17 11:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-17 11:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-17 11:29:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-17 11:29:05 --> get_grammer_type_2->{"slang":"38","tlang":"38","exercise_mode_id":"4","category_id":"124","subcategory_id":"274","support_lang_id":"3"}
ERROR - 2020-10-17 11:29:05 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-10-17 11:29:05 --> Total execution time: 0.1236
DEBUG - 2020-10-17 11:29:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-17 11:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-17 11:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-17 11:29:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-17 11:29:09 --> get_exercise_type_list->{"lang":"38","subcategory_id":"274","support_lang_id":"3"}
DEBUG - 2020-10-17 11:29:09 --> Total execution time: 0.1462
DEBUG - 2020-10-17 11:29:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-17 11:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-17 11:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-17 11:29:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-17 11:29:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-17 11:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-17 11:29:10 --> get_subcategory_list->{"lang":"38","category_id":"124","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-10-17 11:29:10 --> Total execution time: 0.1712
DEBUG - 2020-10-17 11:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-17 11:29:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-17 11:29:10 --> get_category_list->{"lang":"38","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2020-10-17 11:29:10 --> Total execution time: 0.1189
DEBUG - 2020-10-17 11:29:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-17 11:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-17 11:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-17 11:29:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-17 11:29:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-17 11:29:11 --> Total execution time: 0.1689
DEBUG - 2020-10-17 11:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-17 11:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-10-17 11:29:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-17 11:29:11 --> Total execution time: 0.1372
