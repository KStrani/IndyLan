<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-09-01 05:53:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-01 05:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-01 05:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-01 05:53:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-01 05:53:33 --> Total execution time: 0.1511
