<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-07-17 10:12:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:15 --> No URI present. Default controller set.
DEBUG - 2020-07-17 10:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 10:12:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 10:12:15 --> Total execution time: 0.7631
DEBUG - 2020-07-17 10:12:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 10:12:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 10:12:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 10:12:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 10:12:33 --> Total execution time: 0.1581
DEBUG - 2020-07-17 10:12:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 10:12:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 10:12:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 10:12:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 10:12:46 --> Total execution time: 0.3685
DEBUG - 2020-07-17 10:12:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 10:12:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:46 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 10:12:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:46 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-17 10:12:46 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 10:12:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:47 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 10:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:47 --> 404 Page Not Found: Uploads/countries.jpg
ERROR - 2020-07-17 10:12:47 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-17 10:12:47 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 10:12:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:47 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 10:12:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:47 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 10:12:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:47 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
ERROR - 2020-07-17 10:12:47 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 10:12:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:47 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 10:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:47 --> 404 Page Not Found: Uploads/health_care.jpg
ERROR - 2020-07-17 10:12:47 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 10:12:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:47 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 10:12:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:47 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 10:12:47 --> UTF-8 Support Enabled
ERROR - 2020-07-17 10:12:47 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 10:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:47 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 10:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:47 --> 404 Page Not Found: Uploads/music.jpg
ERROR - 2020-07-17 10:12:47 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 10:12:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:47 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 10:12:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:48 --> 404 Page Not Found: Uploads/professions.jpg
ERROR - 2020-07-17 10:12:48 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 10:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:48 --> UTF-8 Support Enabled
ERROR - 2020-07-17 10:12:48 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 10:12:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:48 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 10:12:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:48 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 10:12:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:48 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 10:12:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:48 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 10:12:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:48 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 10:12:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:48 --> 404 Page Not Found: Uploads/travel.jpg
ERROR - 2020-07-17 10:12:48 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 10:12:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:49 --> 404 Page Not Found: Uploads/animals.jpg
ERROR - 2020-07-17 10:12:49 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 10:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:49 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 10:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:49 --> 404 Page Not Found: Uploads/colours.jpg
ERROR - 2020-07-17 10:12:49 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 10:12:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:49 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 10:12:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:49 --> UTF-8 Support Enabled
ERROR - 2020-07-17 10:12:49 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 10:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:49 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-17 10:12:49 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 10:12:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:49 --> 404 Page Not Found: Uploads/health_care.jpg
ERROR - 2020-07-17 10:12:49 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 10:12:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:49 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 10:12:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:49 --> 404 Page Not Found: Uploads/in_the_office.jpg
ERROR - 2020-07-17 10:12:49 --> 404 Page Not Found: Uploads/home.jpg
ERROR - 2020-07-17 10:12:49 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 10:12:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:50 --> 404 Page Not Found: Uploads/months_and_days.jpg
ERROR - 2020-07-17 10:12:50 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 10:12:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:50 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 10:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:50 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 10:12:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:50 --> 404 Page Not Found: Uploads/numbers.png
ERROR - 2020-07-17 10:12:50 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 10:12:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:50 --> 404 Page Not Found: Uploads/professions.jpg
ERROR - 2020-07-17 10:12:50 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 10:12:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 10:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:50 --> 404 Page Not Found: Uploads/shapes.png
ERROR - 2020-07-17 10:12:50 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 10:12:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 10:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 10:12:50 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 13:30:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:30:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:30:58 --> 404 Page Not Found: Admin_master/change_language
DEBUG - 2020-07-17 13:31:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 13:31:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 13:31:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 13:31:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 13:31:02 --> Total execution time: 0.1330
DEBUG - 2020-07-17 13:31:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 13:31:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 13:31:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 13:31:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 13:31:15 --> Total execution time: 0.1247
DEBUG - 2020-07-17 13:31:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 13:31:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:16 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-17 13:31:16 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 13:31:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:16 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:31:16 --> 404 Page Not Found: Uploads/countries.jpg
ERROR - 2020-07-17 13:31:16 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 13:31:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:16 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-17 13:31:16 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 13:31:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:16 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:16 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:16 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:31:16 --> 404 Page Not Found: Uploads/grammar.jpg
ERROR - 2020-07-17 13:31:16 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 13:31:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:16 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
ERROR - 2020-07-17 13:31:16 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 13:31:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:16 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:31:16 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:16 --> 404 Page Not Found: Uploads/in_the_office.jpg
ERROR - 2020-07-17 13:31:16 --> 404 Page Not Found: Uploads/materials.jpg
ERROR - 2020-07-17 13:31:16 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 13:31:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:16 --> 404 Page Not Found: Uploads/music.jpg
ERROR - 2020-07-17 13:31:16 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 13:31:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:17 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 13:31:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:17 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 13:31:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:17 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 13:31:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:17 --> 404 Page Not Found: Uploads/professions.jpg
ERROR - 2020-07-17 13:31:17 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 13:31:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:17 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 13:31:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:17 --> 404 Page Not Found: Uploads/sports.jpg
ERROR - 2020-07-17 13:31:17 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 13:31:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:17 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 13:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:17 --> 404 Page Not Found: Uploads/transport.jpg
ERROR - 2020-07-17 13:31:17 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 13:31:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:17 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 13:31:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:17 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 13:31:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:18 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 13:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:18 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:31:18 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 13:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:18 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:31:18 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 13:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:18 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-17 13:31:18 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 13:31:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:18 --> 404 Page Not Found: Uploads/countries.jpg
ERROR - 2020-07-17 13:31:18 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 13:31:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:18 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:31:18 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 13:31:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:18 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 13:31:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:18 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 13:31:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:18 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 13:31:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:18 --> 404 Page Not Found: Uploads/home.jpg
ERROR - 2020-07-17 13:31:18 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 13:31:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:18 --> 404 Page Not Found: Uploads/legal_terminology.jpg
ERROR - 2020-07-17 13:31:18 --> 404 Page Not Found: Uploads/materials.jpg
ERROR - 2020-07-17 13:31:18 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 13:31:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:18 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 13:31:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:18 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 13:31:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 13:31:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-17 13:31:26 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\header.php 86
DEBUG - 2020-07-17 13:31:26 --> Total execution time: 0.2797
DEBUG - 2020-07-17 13:31:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:31:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:31:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 13:32:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 13:32:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 13:32:23 --> Total execution time: 0.1209
DEBUG - 2020-07-17 13:32:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 13:32:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 13:32:23 --> Total execution time: 0.1235
DEBUG - 2020-07-17 13:32:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 13:32:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:23 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 13:32:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:23 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 13:32:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:23 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 13:32:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:32:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:23 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 13:32:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:23 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-17 13:32:23 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 13:32:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:23 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 13:32:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:24 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:24 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-17 13:32:24 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:24 --> 404 Page Not Found: Uploads/grammar.jpg
ERROR - 2020-07-17 13:32:24 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:24 --> 404 Page Not Found: Uploads/home.jpg
ERROR - 2020-07-17 13:32:24 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:24 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 13:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:24 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:32:24 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:32:24 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 13:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:24 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:24 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 13:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:24 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:24 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:24 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:32:24 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:32:24 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 13:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:24 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:24 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:24 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:24 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 13:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:24 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:24 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 13:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:32:25 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:32:25 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 13:32:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:25 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 13:32:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:32:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:32:25 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 13:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 13:33:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 13:33:25 --> Total execution time: 0.1002
DEBUG - 2020-07-17 13:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 13:33:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 13:33:25 --> Total execution time: 0.2989
DEBUG - 2020-07-17 13:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:26 --> 404 Page Not Found: Uploads/adverbs.jpg
ERROR - 2020-07-17 13:33:26 --> 404 Page Not Found: Uploads/accessories.jpg
ERROR - 2020-07-17 13:33:26 --> 404 Page Not Found: Uploads/appearance.jpg
DEBUG - 2020-07-17 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:26 --> 404 Page Not Found: Uploads/animals_with_hooves.jpg
DEBUG - 2020-07-17 13:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:26 --> 404 Page Not Found: Uploads/animals_in_the_world.jpg
ERROR - 2020-07-17 13:33:26 --> 404 Page Not Found: Uploads/animals_in_europe.jpg
DEBUG - 2020-07-17 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:26 --> 404 Page Not Found: Uploads/at_home.jpg
ERROR - 2020-07-17 13:33:26 --> 404 Page Not Found: Uploads/At__the_dentists.JPG
DEBUG - 2020-07-17 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:26 --> 404 Page Not Found: Uploads/baby_clothes.jpg
DEBUG - 2020-07-17 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:26 --> 404 Page Not Found: Uploads/bakery_and_pasta.jpg
DEBUG - 2020-07-17 13:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:26 --> 404 Page Not Found: Uploads/baby_toiletries.jpg
ERROR - 2020-07-17 13:33:26 --> 404 Page Not Found: Uploads/bathroom.jpg
DEBUG - 2020-07-17 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:26 --> 404 Page Not Found: Uploads/birds.jpg
ERROR - 2020-07-17 13:33:26 --> 404 Page Not Found: Uploads/berries.jpg
ERROR - 2020-07-17 13:33:26 --> 404 Page Not Found: Uploads/body_parts.jpg
DEBUG - 2020-07-17 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:26 --> 404 Page Not Found: Uploads/clothes.jpg
ERROR - 2020-07-17 13:33:26 --> 404 Page Not Found: Uploads/bedroom.jpg
DEBUG - 2020-07-17 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:26 --> 404 Page Not Found: Uploads/childrens_clothes.jpg
DEBUG - 2020-07-17 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:27 --> 404 Page Not Found: Uploads/cooking_verbs.jpg
DEBUG - 2020-07-17 13:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:27 --> 404 Page Not Found: Uploads/containers_and_portions.jpg
DEBUG - 2020-07-17 13:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:27 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 13:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:27 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 13:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:27 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:33:27 --> 404 Page Not Found: Uploads/dairy.jpg
DEBUG - 2020-07-17 13:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:27 --> 404 Page Not Found: Uploads/opposites_doubles.jpg
DEBUG - 2020-07-17 13:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:27 --> 404 Page Not Found: Uploads/drinks.jpg
DEBUG - 2020-07-17 13:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:27 --> 404 Page Not Found: Uploads/everyday_life.jpg
ERROR - 2020-07-17 13:33:27 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 13:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:27 --> 404 Page Not Found: Uploads/electronic_appliances.jpg
DEBUG - 2020-07-17 13:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:27 --> 404 Page Not Found: Uploads/employment.jpg
ERROR - 2020-07-17 13:33:27 --> 404 Page Not Found: Uploads/equipment.jpg
DEBUG - 2020-07-17 13:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:27 --> 404 Page Not Found: Uploads/fish_and_seafood.jpg
DEBUG - 2020-07-17 13:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:27 --> 404 Page Not Found: Uploads/face_and_head.jpg
ERROR - 2020-07-17 13:33:27 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 13:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:27 --> 404 Page Not Found: Uploads/fixtures.jpg
DEBUG - 2020-07-17 13:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:27 --> 404 Page Not Found: Uploads/fruits.jpg
DEBUG - 2020-07-17 13:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:27 --> 404 Page Not Found: Uploads/furniture.jpg
DEBUG - 2020-07-17 13:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:27 --> 404 Page Not Found: Uploads/ground_and_air.jpg
ERROR - 2020-07-17 13:33:27 --> 404 Page Not Found: Uploads/grains_and_cereals.jpg
ERROR - 2020-07-17 13:33:27 --> 404 Page Not Found: Uploads/generic.jpg
DEBUG - 2020-07-17 13:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:28 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 13:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:28 --> 404 Page Not Found: Uploads/illnesses.jpg
DEBUG - 2020-07-17 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:28 --> 404 Page Not Found: Uploads/herbs_and_spices.jpg
DEBUG - 2020-07-17 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:28 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:33:28 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:28 --> 404 Page Not Found: Uploads/in_the_kitchen.jpg
ERROR - 2020-07-17 13:33:28 --> 404 Page Not Found: Uploads/insects.jpg
DEBUG - 2020-07-17 13:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:28 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:28 --> 404 Page Not Found: Uploads/items_at_home.jpg
DEBUG - 2020-07-17 13:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:28 --> 404 Page Not Found: Uploads/laundry_and_cleaning.jpg
DEBUG - 2020-07-17 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:28 --> 404 Page Not Found: Uploads/meat.jpg
DEBUG - 2020-07-17 13:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:28 --> 404 Page Not Found: Uploads/materials.jpg
ERROR - 2020-07-17 13:33:28 --> 404 Page Not Found: Uploads/medical_terms.jpg
ERROR - 2020-07-17 13:33:28 --> 404 Page Not Found: Uploads/materials_and_patterns.jpg
DEBUG - 2020-07-17 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:28 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:33:28 --> 404 Page Not Found: Uploads/medical_symptoms.jpg
DEBUG - 2020-07-17 13:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:28 --> 404 Page Not Found: Uploads/medical_equipment.jpg
DEBUG - 2020-07-17 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:28 --> 404 Page Not Found: Uploads/months_and_days.jpg
ERROR - 2020-07-17 13:33:28 --> 404 Page Not Found: Uploads/nationalities.jpg
DEBUG - 2020-07-17 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:28 --> 404 Page Not Found: Uploads/music.jpg
ERROR - 2020-07-17 13:33:28 --> 404 Page Not Found: Uploads/medication.jpg
DEBUG - 2020-07-17 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:28 --> 404 Page Not Found: Uploads/Mushrooms.jpg
DEBUG - 2020-07-17 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:28 --> 404 Page Not Found: Uploads/numbers_cardinals.png
DEBUG - 2020-07-17 13:33:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:29 --> 404 Page Not Found: Uploads/numbers_ordinals.png
ERROR - 2020-07-17 13:33:29 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 13:33:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:29 --> 404 Page Not Found: Uploads/professions.jpg
ERROR - 2020-07-17 13:33:29 --> 404 Page Not Found: Uploads/nuts_and_dried_fruit.jpg
DEBUG - 2020-07-17 13:33:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:29 --> 404 Page Not Found: Uploads/reptiles_and_amphibians.jpg
DEBUG - 2020-07-17 13:33:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:29 --> 404 Page Not Found: Uploads/Ready_meals.JPG
DEBUG - 2020-07-17 13:33:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:29 --> 404 Page Not Found: Uploads/sea_animals_and_fish.jpg
ERROR - 2020-07-17 13:33:29 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 13:33:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:29 --> 404 Page Not Found: Uploads/Sauces_and_condiments.jpg
ERROR - 2020-07-17 13:33:29 --> 404 Page Not Found: Uploads/rooms.jpg
DEBUG - 2020-07-17 13:33:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:29 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 13:33:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:29 --> 404 Page Not Found: Uploads/shoes_and_trousers.jpg
DEBUG - 2020-07-17 13:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:29 --> 404 Page Not Found: Uploads/sport_terms.png
DEBUG - 2020-07-17 13:33:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:29 --> 404 Page Not Found: Uploads/Snacks_and_sweets.JPG
DEBUG - 2020-07-17 13:33:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:29 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:33:29 --> 404 Page Not Found: Uploads/tools_and_diy.jpg
DEBUG - 2020-07-17 13:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:29 --> 404 Page Not Found: Uploads/Toiletries.jpg
DEBUG - 2020-07-17 13:33:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:29 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:33:29 --> 404 Page Not Found: Uploads/types_of_sports.jpg
DEBUG - 2020-07-17 13:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:29 --> 404 Page Not Found: Uploads/transport.jpg
ERROR - 2020-07-17 13:33:29 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 13:33:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:29 --> 404 Page Not Found: Uploads/toys_and_games.jpg
DEBUG - 2020-07-17 13:33:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:30 --> 404 Page Not Found: Uploads/Vegetables.JPG
DEBUG - 2020-07-17 13:33:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:30 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:33:30 --> 404 Page Not Found: Uploads/1_verbs.png
DEBUG - 2020-07-17 13:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:33:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:30 --> 404 Page Not Found: Uploads/2_verbs.png
ERROR - 2020-07-17 13:33:30 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 13:33:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:33:30 --> 404 Page Not Found: Uploads/water.jpg
ERROR - 2020-07-17 13:33:30 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 13:36:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 13:36:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 13:36:12 --> Total execution time: 0.0995
DEBUG - 2020-07-17 13:36:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 13:36:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 13:36:13 --> Total execution time: 0.5928
DEBUG - 2020-07-17 13:36:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 13:36:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:13 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:36:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:13 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 13:36:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:13 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:36:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:13 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 13:36:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:14 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 13:36:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:14 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 13:36:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:14 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:36:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:14 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 13:36:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:14 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 13:36:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:15 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 13:36:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:15 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 13:36:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:15 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:36:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:15 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:36:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:16 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 13:36:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:16 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 13:36:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:16 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:36:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:16 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 13:36:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:16 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:36:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 13:36:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 13:36:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 13:36:34 --> Total execution time: 0.1000
DEBUG - 2020-07-17 13:36:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 13:36:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 13:36:34 --> Total execution time: 0.2101
DEBUG - 2020-07-17 13:36:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 13:36:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:35 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 13:36:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:35 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-17 13:36:35 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 13:36:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:35 --> 404 Page Not Found: Uploads/clothes.jpg
ERROR - 2020-07-17 13:36:35 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 13:36:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:35 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 13:36:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:35 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 13:36:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:35 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:36:35 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 13:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:35 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 13:36:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:35 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-17 13:36:35 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 13:36:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:35 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 13:36:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:35 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:36:35 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 13:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:35 --> 404 Page Not Found: Uploads/materials.jpg
ERROR - 2020-07-17 13:36:35 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 13:36:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:35 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 13:36:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:35 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 13:36:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:35 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 13:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:36 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 13:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:36 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
ERROR - 2020-07-17 13:36:36 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 13:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:36 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:36:36 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 13:36:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:36 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 13:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:36 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 13:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:36 --> 404 Page Not Found: Uploads/shapes.png
ERROR - 2020-07-17 13:36:36 --> 404 Page Not Found: Uploads/sports.jpg
ERROR - 2020-07-17 13:36:36 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 13:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:36 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 13:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:36 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 13:36:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:36 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 13:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:36 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 13:36:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:36:37 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 13:36:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 13:36:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 13:36:53 --> Total execution time: 0.1788
DEBUG - 2020-07-17 13:38:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:38:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:38:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 13:38:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:38:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:38:11 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 13:49:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 13:49:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 13:49:35 --> Total execution time: 0.1421
DEBUG - 2020-07-17 13:49:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 13:49:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:35 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 13:49:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:35 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 13:49:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:35 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 13:49:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:49:35 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:49:35 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 13:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:49:35 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:49:35 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 13:49:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:35 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 13:49:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:35 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 13:49:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:49:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:35 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
ERROR - 2020-07-17 13:49:35 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 13:49:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:35 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 13:49:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:36 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:36 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:36 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:36 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:36 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:36 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:36 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:36 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:36 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:36 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:36 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
ERROR - 2020-07-17 13:49:36 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:36 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:36 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:36 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:36 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:36 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 13:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:36 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 13:49:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:49:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:37 --> 404 Page Not Found: Uploads/travel.jpg
ERROR - 2020-07-17 13:49:37 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 13:49:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:37 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 13:49:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:49:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:37 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-17 13:49:37 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 13:49:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 13:49:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 13:49:40 --> Total execution time: 0.1349
DEBUG - 2020-07-17 13:49:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:41 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 13:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:41 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:41 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 13:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:41 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:41 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:41 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:41 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-17 13:49:41 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:49:41 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:49:41 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 13:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:41 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:41 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:41 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:41 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:41 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:41 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 13:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:41 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:41 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:41 --> 404 Page Not Found: Uploads/music.jpg
ERROR - 2020-07-17 13:49:41 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:49:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:42 --> 404 Page Not Found: Uploads/opposites.jpg
ERROR - 2020-07-17 13:49:42 --> 404 Page Not Found: Uploads/numbers.png
ERROR - 2020-07-17 13:49:42 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:42 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:42 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:42 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 13:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:49:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:42 --> 404 Page Not Found: Uploads/scotland.jpg
ERROR - 2020-07-17 13:49:42 --> 404 Page Not Found: Uploads/sports.jpg
ERROR - 2020-07-17 13:49:42 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:49:42 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:49:42 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 13:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:49:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:42 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
ERROR - 2020-07-17 13:49:42 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:49:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:49:42 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 13:50:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 13:50:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 13:50:00 --> Total execution time: 0.1418
DEBUG - 2020-07-17 13:50:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 13:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:01 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 13:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:01 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 13:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:50:01 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:50:01 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 13:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:01 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-17 13:50:01 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 13:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:01 --> 404 Page Not Found: Uploads/colours.jpg
ERROR - 2020-07-17 13:50:01 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 13:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:01 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 13:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:01 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-17 13:50:01 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 13:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:01 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 13:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:01 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 13:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:01 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 13:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:01 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:50:01 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 13:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:50:01 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:50:01 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 13:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:01 --> 404 Page Not Found: Uploads/numbers.png
ERROR - 2020-07-17 13:50:01 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 13:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:02 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 13:50:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:02 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 13:50:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:02 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 13:50:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:50:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:02 --> 404 Page Not Found: Uploads/places.jpg
ERROR - 2020-07-17 13:50:02 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 13:50:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:02 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 13:50:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:02 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 13:50:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:02 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 13:50:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:02 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 13:50:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:50:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:02 --> 404 Page Not Found: Uploads/supermarket.jpg
ERROR - 2020-07-17 13:50:02 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 13:50:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:02 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 13:50:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:02 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 13:50:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:02 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 13:50:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:03 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 13:50:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:50:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:03 --> 404 Page Not Found: Uploads/animals.jpg
ERROR - 2020-07-17 13:50:03 --> 404 Page Not Found: Uploads/in_the_office.jpg
ERROR - 2020-07-17 13:50:03 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 13:50:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:03 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 13:50:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 13:50:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 13:50:06 --> Total execution time: 0.1518
DEBUG - 2020-07-17 13:50:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 13:50:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:06 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 13:50:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:50:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:06 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-17 13:50:06 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 13:50:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:06 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 13:50:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:06 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 13:50:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:06 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 13:50:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:50:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:07 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-17 13:50:07 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 13:50:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:07 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 13:50:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:07 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 13:50:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:07 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 13:50:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:07 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 13:50:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:07 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 13:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:50:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:07 --> 404 Page Not Found: Uploads/home.jpg
ERROR - 2020-07-17 13:50:07 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 13:50:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:07 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 13:50:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:07 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 13:50:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:07 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 13:50:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:07 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 13:50:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:07 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 13:50:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:07 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 13:50:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:50:07 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:50:07 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 13:50:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:07 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 13:50:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:07 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 13:50:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:08 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 13:50:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:08 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 13:50:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:08 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 13:50:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:50:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:08 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 13:50:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:08 --> 404 Page Not Found: Uploads/transport.jpg
ERROR - 2020-07-17 13:50:08 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 13:50:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:08 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 13:50:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:50:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:50:08 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 13:59:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 13:59:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 13:59:58 --> Total execution time: 0.1513
DEBUG - 2020-07-17 13:59:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:59:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:59:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 13:59:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:59:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:59:59 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 13:59:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:59:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:59:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:59:59 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-17 13:59:59 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 13:59:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:59:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:59:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:59:59 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 13:59:59 --> UTF-8 Support Enabled
ERROR - 2020-07-17 13:59:59 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 13:59:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:59:59 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 13:59:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:59:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:59:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:59:59 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-17 13:59:59 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 13:59:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:59:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:59:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:59:59 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 13:59:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:59:59 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 13:59:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:59:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:59:59 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 13:59:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:59:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:59:59 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 13:59:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:59:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:59:59 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 13:59:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:59:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 13:59:59 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 13:59:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 13:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 13:59:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:00 --> UTF-8 Support Enabled
ERROR - 2020-07-17 14:00:00 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 14:00:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:00 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 14:00:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:00 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 14:00:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:00 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 14:00:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:00 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 14:00:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:00:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:00 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
ERROR - 2020-07-17 14:00:00 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 14:00:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:00 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 14:00:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:00 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 14:00:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:00:00 --> UTF-8 Support Enabled
ERROR - 2020-07-17 14:00:00 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 14:00:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:00 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 14:00:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:00 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 14:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:00:00 --> UTF-8 Support Enabled
ERROR - 2020-07-17 14:00:00 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 14:00:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:00 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 14:00:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:00 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 14:00:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:00:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:00 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
ERROR - 2020-07-17 14:00:00 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 14:00:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:01 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-17 14:00:01 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 14:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:01 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 14:00:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:01 --> 404 Page Not Found: Uploads/countries.jpg
ERROR - 2020-07-17 14:00:01 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 14:00:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:01 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 14:00:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:01 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 14:00:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:01 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-17 14:00:01 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 14:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:01 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 14:00:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:01 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 14:00:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:01 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 14:00:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:01 --> 404 Page Not Found: Uploads/music.jpg
ERROR - 2020-07-17 14:00:01 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 14:00:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 14:00:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:04 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 14:00:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:10 --> 404 Page Not Found: Admin_master/change_language
DEBUG - 2020-07-17 14:00:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 14:00:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 14:00:49 --> Total execution time: 0.1584
DEBUG - 2020-07-17 14:00:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 14:00:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:50 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 14:00:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:00:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:50 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 14:00:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:50 --> UTF-8 Support Enabled
ERROR - 2020-07-17 14:00:50 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 14:00:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:50 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 14:00:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:50 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 14:00:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:50 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 14:00:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:00:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:50 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-17 14:00:50 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 14:00:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:50 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 14:00:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:50 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 14:00:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:50 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 14:00:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:51 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 14:00:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:00:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:51 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 14:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:51 --> 404 Page Not Found: Uploads/home.jpg
ERROR - 2020-07-17 14:00:51 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 14:00:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:51 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 14:00:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:51 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 14:00:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:51 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 14:00:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:51 --> 404 Page Not Found: Uploads/numbers.png
ERROR - 2020-07-17 14:00:51 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 14:00:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:51 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 14:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:51 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 14:00:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:51 --> 404 Page Not Found: Uploads/professions.jpg
ERROR - 2020-07-17 14:00:51 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 14:00:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:51 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 14:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:51 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 14:00:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:52 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:52 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 14:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:52 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:52 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:52 --> 404 Page Not Found: Uploads/weather.jpg
ERROR - 2020-07-17 14:00:52 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:52 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:52 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:52 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:00:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:53 --> UTF-8 Support Enabled
ERROR - 2020-07-17 14:00:53 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 14:00:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:53 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 14:00:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:53 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 14:00:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:00:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:53 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-17 14:00:53 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 14:00:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:00:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:53 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 14:00:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:00:53 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 14:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:10 --> 404 Page Not Found: Admin_master/change_language
DEBUG - 2020-07-17 14:01:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 14:01:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 14:01:18 --> Total execution time: 0.1425
DEBUG - 2020-07-17 14:01:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 14:01:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 14:01:18 --> Total execution time: 0.1252
DEBUG - 2020-07-17 14:01:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 14:01:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:19 --> 404 Page Not Found: Uploads/adverbs.jpg
ERROR - 2020-07-17 14:01:19 --> 404 Page Not Found: Uploads/accessories.jpg
DEBUG - 2020-07-17 14:01:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:19 --> 404 Page Not Found: Uploads/animals_with_hooves.jpg
DEBUG - 2020-07-17 14:01:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:19 --> 404 Page Not Found: Uploads/animals_in_the_world.jpg
DEBUG - 2020-07-17 14:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:19 --> UTF-8 Support Enabled
ERROR - 2020-07-17 14:01:19 --> 404 Page Not Found: Uploads/appearance.jpg
DEBUG - 2020-07-17 14:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:19 --> 404 Page Not Found: Uploads/animals_in_europe.jpg
DEBUG - 2020-07-17 14:01:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:19 --> 404 Page Not Found: Uploads/at_home.jpg
DEBUG - 2020-07-17 14:01:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:19 --> 404 Page Not Found: Uploads/At__the_dentists.JPG
DEBUG - 2020-07-17 14:01:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:19 --> 404 Page Not Found: Uploads/baby_clothes.jpg
ERROR - 2020-07-17 14:01:19 --> 404 Page Not Found: Uploads/bathroom.jpg
DEBUG - 2020-07-17 14:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:19 --> 404 Page Not Found: Uploads/baby_toiletries.jpg
DEBUG - 2020-07-17 14:01:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:19 --> 404 Page Not Found: Uploads/bakery_and_pasta.jpg
DEBUG - 2020-07-17 14:01:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:19 --> 404 Page Not Found: Uploads/bedroom.jpg
DEBUG - 2020-07-17 14:01:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:19 --> UTF-8 Support Enabled
ERROR - 2020-07-17 14:01:19 --> 404 Page Not Found: Uploads/childrens_clothes.jpg
DEBUG - 2020-07-17 14:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:19 --> 404 Page Not Found: Uploads/body_parts.jpg
ERROR - 2020-07-17 14:01:19 --> 404 Page Not Found: Uploads/berries.jpg
ERROR - 2020-07-17 14:01:19 --> 404 Page Not Found: Uploads/birds.jpg
DEBUG - 2020-07-17 14:01:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:20 --> UTF-8 Support Enabled
ERROR - 2020-07-17 14:01:20 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 14:01:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:20 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 14:01:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:20 --> 404 Page Not Found: Uploads/dairy.jpg
DEBUG - 2020-07-17 14:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:20 --> 404 Page Not Found: Uploads/containers_and_portions.jpg
ERROR - 2020-07-17 14:01:20 --> 404 Page Not Found: Uploads/countries.jpg
ERROR - 2020-07-17 14:01:20 --> 404 Page Not Found: Uploads/cooking_verbs.jpg
DEBUG - 2020-07-17 14:01:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:20 --> UTF-8 Support Enabled
ERROR - 2020-07-17 14:01:20 --> 404 Page Not Found: Uploads/opposites_doubles.jpg
DEBUG - 2020-07-17 14:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:20 --> 404 Page Not Found: Uploads/equipment.jpg
ERROR - 2020-07-17 14:01:20 --> 404 Page Not Found: Uploads/drinks.jpg
DEBUG - 2020-07-17 14:01:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:21 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 14:01:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:21 --> 404 Page Not Found: Uploads/electronic_appliances.jpg
DEBUG - 2020-07-17 14:01:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:21 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 14:01:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:21 --> 404 Page Not Found: Uploads/everyday_life.jpg
ERROR - 2020-07-17 14:01:21 --> 404 Page Not Found: Uploads/face_and_head.jpg
DEBUG - 2020-07-17 14:01:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:21 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 14:01:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:21 --> 404 Page Not Found: Uploads/fish_and_seafood.jpg
ERROR - 2020-07-17 14:01:21 --> 404 Page Not Found: Uploads/fruits.jpg
DEBUG - 2020-07-17 14:01:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:21 --> 404 Page Not Found: Uploads/fixtures.jpg
DEBUG - 2020-07-17 14:01:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:22 --> 404 Page Not Found: Uploads/furniture.jpg
DEBUG - 2020-07-17 14:01:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:22 --> 404 Page Not Found: Uploads/generic.jpg
DEBUG - 2020-07-17 14:01:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:22 --> 404 Page Not Found: Uploads/herbs_and_spices.jpg
ERROR - 2020-07-17 14:01:22 --> 404 Page Not Found: Uploads/ground_and_air.jpg
DEBUG - 2020-07-17 14:01:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:22 --> 404 Page Not Found: Uploads/grains_and_cereals.jpg
DEBUG - 2020-07-17 14:01:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:22 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 14:01:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:22 --> 404 Page Not Found: Uploads/in_the_kitchen.jpg
DEBUG - 2020-07-17 14:01:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:22 --> 404 Page Not Found: Uploads/illnesses.jpg
DEBUG - 2020-07-17 14:01:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:23 --> 404 Page Not Found: Uploads/items_at_home.jpg
DEBUG - 2020-07-17 14:01:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:23 --> 404 Page Not Found: Uploads/in_the_office.jpg
ERROR - 2020-07-17 14:01:23 --> 404 Page Not Found: Uploads/insects.jpg
DEBUG - 2020-07-17 14:01:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:23 --> 404 Page Not Found: Uploads/laundry_and_cleaning.jpg
DEBUG - 2020-07-17 14:01:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:23 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 14:01:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:23 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 14:01:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:23 --> 404 Page Not Found: Uploads/medical_equipment.jpg
DEBUG - 2020-07-17 14:01:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:23 --> 404 Page Not Found: Uploads/materials_and_patterns.jpg
DEBUG - 2020-07-17 14:01:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:23 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 14:01:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:23 --> 404 Page Not Found: Uploads/meat.jpg
DEBUG - 2020-07-17 14:01:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:23 --> 404 Page Not Found: Uploads/medical_symptoms.jpg
DEBUG - 2020-07-17 14:01:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:23 --> 404 Page Not Found: Uploads/medication.jpg
DEBUG - 2020-07-17 14:01:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:23 --> 404 Page Not Found: Uploads/medical_terms.jpg
DEBUG - 2020-07-17 14:01:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:23 --> 404 Page Not Found: Uploads/Mushrooms.jpg
DEBUG - 2020-07-17 14:01:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:24 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 14:01:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:24 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 14:01:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:24 --> 404 Page Not Found: Uploads/nationalities.jpg
DEBUG - 2020-07-17 14:01:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:24 --> 404 Page Not Found: Uploads/nuts_and_dried_fruit.jpg
DEBUG - 2020-07-17 14:01:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:24 --> UTF-8 Support Enabled
ERROR - 2020-07-17 14:01:24 --> 404 Page Not Found: Uploads/numbers_cardinals.png
DEBUG - 2020-07-17 14:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:24 --> UTF-8 Support Enabled
ERROR - 2020-07-17 14:01:24 --> 404 Page Not Found: Uploads/numbers_ordinals.png
DEBUG - 2020-07-17 14:01:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:24 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 14:01:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:24 --> 404 Page Not Found: Uploads/Ready_meals.JPG
DEBUG - 2020-07-17 14:01:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:24 --> 404 Page Not Found: Uploads/reptiles_and_amphibians.jpg
ERROR - 2020-07-17 14:01:24 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 14:01:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:24 --> 404 Page Not Found: Uploads/rooms.jpg
DEBUG - 2020-07-17 14:01:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:24 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 14:01:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:24 --> 404 Page Not Found: Uploads/Sauces_and_condiments.jpg
DEBUG - 2020-07-17 14:01:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:25 --> 404 Page Not Found: Uploads/sea_animals_and_fish.jpg
DEBUG - 2020-07-17 14:01:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:25 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 14:01:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:25 --> 404 Page Not Found: Uploads/shoes_and_trousers.jpg
DEBUG - 2020-07-17 14:01:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:25 --> 404 Page Not Found: Uploads/sport_terms.png
DEBUG - 2020-07-17 14:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:25 --> 404 Page Not Found: Uploads/Snacks_and_sweets.JPG
DEBUG - 2020-07-17 14:01:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:25 --> 404 Page Not Found: Uploads/Toiletries.jpg
DEBUG - 2020-07-17 14:01:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:25 --> 404 Page Not Found: Uploads/tools_and_diy.jpg
DEBUG - 2020-07-17 14:01:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:25 --> 404 Page Not Found: Uploads/toys_and_games.jpg
DEBUG - 2020-07-17 14:01:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:25 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 14:01:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:25 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 14:01:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:25 --> 404 Page Not Found: Uploads/types_of_sports.jpg
DEBUG - 2020-07-17 14:01:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:25 --> 404 Page Not Found: Uploads/Vegetables.JPG
DEBUG - 2020-07-17 14:01:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:25 --> UTF-8 Support Enabled
ERROR - 2020-07-17 14:01:25 --> 404 Page Not Found: Uploads/1_verbs.png
DEBUG - 2020-07-17 14:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:25 --> 404 Page Not Found: Uploads/2_verbs.png
DEBUG - 2020-07-17 14:01:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:26 --> UTF-8 Support Enabled
ERROR - 2020-07-17 14:01:26 --> 404 Page Not Found: Uploads/water.jpg
DEBUG - 2020-07-17 14:01:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:26 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 14:01:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:26 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 14:01:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 14:01:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 14:01:40 --> Total execution time: 0.1687
DEBUG - 2020-07-17 14:01:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 14:01:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:41 --> 404 Page Not Found: Uploads/animals_in_europe.jpg
ERROR - 2020-07-17 14:01:41 --> 404 Page Not Found: Uploads/accessories.jpg
DEBUG - 2020-07-17 14:01:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:41 --> 404 Page Not Found: Uploads/appearance.jpg
DEBUG - 2020-07-17 14:01:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:41 --> 404 Page Not Found: Uploads/adverbs.jpg
DEBUG - 2020-07-17 14:01:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:41 --> 404 Page Not Found: Uploads/animals_with_hooves.jpg
DEBUG - 2020-07-17 14:01:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:41 --> 404 Page Not Found: Uploads/animals_in_the_world.jpg
DEBUG - 2020-07-17 14:01:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:41 --> 404 Page Not Found: Uploads/baby_clothes.jpg
ERROR - 2020-07-17 14:01:41 --> 404 Page Not Found: Uploads/At__the_dentists.JPG
DEBUG - 2020-07-17 14:01:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:41 --> 404 Page Not Found: Uploads/baby_toiletries.jpg
DEBUG - 2020-07-17 14:01:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:41 --> 404 Page Not Found: Uploads/at_home.jpg
DEBUG - 2020-07-17 14:01:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:41 --> 404 Page Not Found: Uploads/bathroom.jpg
DEBUG - 2020-07-17 14:01:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:41 --> 404 Page Not Found: Uploads/bakery_and_pasta.jpg
DEBUG - 2020-07-17 14:01:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:41 --> UTF-8 Support Enabled
ERROR - 2020-07-17 14:01:41 --> 404 Page Not Found: Uploads/berries.jpg
DEBUG - 2020-07-17 14:01:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:41 --> 404 Page Not Found: Uploads/bedroom.jpg
DEBUG - 2020-07-17 14:01:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:41 --> 404 Page Not Found: Uploads/body_parts.jpg
ERROR - 2020-07-17 14:01:41 --> 404 Page Not Found: Uploads/birds.jpg
DEBUG - 2020-07-17 14:01:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:42 --> UTF-8 Support Enabled
ERROR - 2020-07-17 14:01:42 --> 404 Page Not Found: Uploads/childrens_clothes.jpg
DEBUG - 2020-07-17 14:01:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:42 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 14:01:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:42 --> 404 Page Not Found: Uploads/containers_and_portions.jpg
DEBUG - 2020-07-17 14:01:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:42 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 14:01:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:42 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 14:01:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:42 --> 404 Page Not Found: Uploads/cooking_verbs.jpg
DEBUG - 2020-07-17 14:01:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:42 --> 404 Page Not Found: Uploads/drinks.jpg
DEBUG - 2020-07-17 14:01:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:42 --> 404 Page Not Found: Uploads/dairy.jpg
DEBUG - 2020-07-17 14:01:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:42 --> 404 Page Not Found: Uploads/opposites_doubles.jpg
ERROR - 2020-07-17 14:01:42 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 14:01:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:43 --> 404 Page Not Found: Uploads/electronic_appliances.jpg
DEBUG - 2020-07-17 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:43 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:43 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:43 --> 404 Page Not Found: Uploads/equipment.jpg
DEBUG - 2020-07-17 14:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:43 --> UTF-8 Support Enabled
ERROR - 2020-07-17 14:01:43 --> 404 Page Not Found: Uploads/everyday_life.jpg
DEBUG - 2020-07-17 14:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:43 --> 404 Page Not Found: Uploads/face_and_head.jpg
DEBUG - 2020-07-17 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:43 --> 404 Page Not Found: Uploads/fish_and_seafood.jpg
DEBUG - 2020-07-17 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:43 --> 404 Page Not Found: Uploads/fixtures.jpg
DEBUG - 2020-07-17 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:43 --> 404 Page Not Found: Uploads/generic.jpg
ERROR - 2020-07-17 14:01:43 --> 404 Page Not Found: Uploads/grains_and_cereals.jpg
ERROR - 2020-07-17 14:01:43 --> 404 Page Not Found: Uploads/fruits.jpg
DEBUG - 2020-07-17 14:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:43 --> 404 Page Not Found: Uploads/furniture.jpg
DEBUG - 2020-07-17 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:43 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:43 --> 404 Page Not Found: Uploads/herbs_and_spices.jpg
DEBUG - 2020-07-17 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:43 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 14:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:43 --> 404 Page Not Found: Uploads/ground_and_air.jpg
ERROR - 2020-07-17 14:01:43 --> 404 Page Not Found: Uploads/in_the_kitchen.jpg
ERROR - 2020-07-17 14:01:43 --> 404 Page Not Found: Uploads/illnesses.jpg
DEBUG - 2020-07-17 14:01:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:44 --> 404 Page Not Found: Uploads/items_at_home.jpg
DEBUG - 2020-07-17 14:01:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:44 --> 404 Page Not Found: Uploads/insects.jpg
DEBUG - 2020-07-17 14:01:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:44 --> 404 Page Not Found: Uploads/materials.jpg
ERROR - 2020-07-17 14:01:44 --> 404 Page Not Found: Uploads/legal_terminology.jpg
ERROR - 2020-07-17 14:01:44 --> 404 Page Not Found: Uploads/materials_and_patterns.jpg
DEBUG - 2020-07-17 14:01:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:44 --> 404 Page Not Found: Uploads/laundry_and_cleaning.jpg
DEBUG - 2020-07-17 14:01:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:44 --> 404 Page Not Found: Uploads/meat.jpg
DEBUG - 2020-07-17 14:01:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:44 --> 404 Page Not Found: Uploads/medical_terms.jpg
ERROR - 2020-07-17 14:01:44 --> 404 Page Not Found: Uploads/medical_equipment.jpg
ERROR - 2020-07-17 14:01:44 --> 404 Page Not Found: Uploads/medical_symptoms.jpg
DEBUG - 2020-07-17 14:01:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:44 --> 404 Page Not Found: Uploads/medication.jpg
DEBUG - 2020-07-17 14:01:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:44 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 14:01:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:45 --> 404 Page Not Found: Uploads/Mushrooms.jpg
DEBUG - 2020-07-17 14:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:45 --> UTF-8 Support Enabled
ERROR - 2020-07-17 14:01:45 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 14:01:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:45 --> 404 Page Not Found: Uploads/numbers_cardinals.png
ERROR - 2020-07-17 14:01:45 --> 404 Page Not Found: Uploads/nationalities.jpg
DEBUG - 2020-07-17 14:01:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:45 --> 404 Page Not Found: Uploads/nuts_and_dried_fruit.jpg
DEBUG - 2020-07-17 14:01:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:45 --> 404 Page Not Found: Uploads/numbers_ordinals.png
DEBUG - 2020-07-17 14:01:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:45 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 14:01:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:45 --> UTF-8 Support Enabled
ERROR - 2020-07-17 14:01:45 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 14:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:45 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 14:01:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:45 --> 404 Page Not Found: Uploads/reptiles_and_amphibians.jpg
DEBUG - 2020-07-17 14:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:45 --> 404 Page Not Found: Uploads/Ready_meals.JPG
DEBUG - 2020-07-17 14:01:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:45 --> UTF-8 Support Enabled
ERROR - 2020-07-17 14:01:45 --> 404 Page Not Found: Uploads/rooms.jpg
DEBUG - 2020-07-17 14:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:45 --> 404 Page Not Found: Uploads/Sauces_and_condiments.jpg
DEBUG - 2020-07-17 14:01:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:45 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 14:01:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:45 --> 404 Page Not Found: Uploads/sea_animals_and_fish.jpg
DEBUG - 2020-07-17 14:01:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:46 --> UTF-8 Support Enabled
ERROR - 2020-07-17 14:01:46 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 14:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:46 --> 404 Page Not Found: Uploads/shoes_and_trousers.jpg
DEBUG - 2020-07-17 14:01:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:46 --> 404 Page Not Found: Uploads/sport_terms.png
DEBUG - 2020-07-17 14:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:46 --> UTF-8 Support Enabled
ERROR - 2020-07-17 14:01:46 --> 404 Page Not Found: Uploads/Toiletries.jpg
DEBUG - 2020-07-17 14:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:46 --> 404 Page Not Found: Uploads/Snacks_and_sweets.JPG
DEBUG - 2020-07-17 14:01:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:46 --> 404 Page Not Found: Uploads/tools_and_diy.jpg
DEBUG - 2020-07-17 14:01:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:46 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 14:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:46 --> 404 Page Not Found: Uploads/toys_and_games.jpg
DEBUG - 2020-07-17 14:01:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:46 --> 404 Page Not Found: Uploads/types_of_sports.jpg
ERROR - 2020-07-17 14:01:46 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 14:01:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:46 --> 404 Page Not Found: Uploads/Vegetables.JPG
DEBUG - 2020-07-17 14:01:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:46 --> 404 Page Not Found: Uploads/2_verbs.png
DEBUG - 2020-07-17 14:01:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:46 --> 404 Page Not Found: Uploads/water.jpg
DEBUG - 2020-07-17 14:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:46 --> 404 Page Not Found: Uploads/1_verbs.png
DEBUG - 2020-07-17 14:01:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:46 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 14:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:46 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 14:01:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:01:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:01:56 --> 404 Page Not Found: Admin_master/change_language
DEBUG - 2020-07-17 14:02:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:02:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:02:14 --> 404 Page Not Found: Admin_master/change_language
DEBUG - 2020-07-17 14:02:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:02:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:02:39 --> 404 Page Not Found: Admin_master/change_language
DEBUG - 2020-07-17 14:03:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 14:03:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 14:04:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 14:04:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 14:04:07 --> Total execution time: 0.1639
DEBUG - 2020-07-17 14:04:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 14:04:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 14:04:14 --> Total execution time: 0.1409
DEBUG - 2020-07-17 14:04:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 14:04:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 14:04:14 --> Total execution time: 0.1215
DEBUG - 2020-07-17 14:04:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 14:04:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:14 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 14:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:04:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:15 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-17 14:04:15 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 14:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:15 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 14:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:15 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 14:04:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:15 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 14:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:15 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 14:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:04:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:15 --> 404 Page Not Found: Uploads/grammar.jpg
ERROR - 2020-07-17 14:04:15 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 14:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:15 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 14:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:15 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 14:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:15 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 14:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:15 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 14:04:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:16 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 14:04:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:16 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 14:04:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:16 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 14:04:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:16 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 14:04:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:04:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:16 --> 404 Page Not Found: Uploads/numbers.png
ERROR - 2020-07-17 14:04:16 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 14:04:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:04:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:16 --> 404 Page Not Found: Uploads/opposites.jpg
ERROR - 2020-07-17 14:04:16 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 14:04:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:16 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 14:04:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:16 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 14:04:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:16 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 14:04:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:16 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 14:04:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:04:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:16 --> 404 Page Not Found: Uploads/sports.jpg
ERROR - 2020-07-17 14:04:16 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 14:04:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:04:17 --> UTF-8 Support Enabled
ERROR - 2020-07-17 14:04:17 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 14:04:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:17 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 14:04:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:17 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 14:04:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:17 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 14:04:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:17 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 14:04:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:04:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:04:17 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-17 14:04:17 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 14:04:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 14:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 14:04:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 14:04:24 --> Total execution time: 0.1327
DEBUG - 2020-07-17 14:26:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:26:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:26:44 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) E:\xampp\htdocs\voolsy\langoadmin\application\controllers\Admin_master.php 4272
DEBUG - 2020-07-17 14:32:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 14:32:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 14:32:36 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) E:\xampp\htdocs\voolsy\langoadmin\application\controllers\Admin_master.php 4275
DEBUG - 2020-07-17 15:04:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:04:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:04:50 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) E:\xampp\htdocs\voolsy\langoadmin\application\controllers\Admin_master.php 4275
DEBUG - 2020-07-17 15:05:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:05:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:05:41 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) E:\xampp\htdocs\voolsy\langoadmin\application\controllers\Admin_master.php 4275
DEBUG - 2020-07-17 15:06:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:06:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:06:29 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) E:\xampp\htdocs\voolsy\langoadmin\application\controllers\Admin_master.php 4276
DEBUG - 2020-07-17 15:07:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:07:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:07:21 --> Total execution time: 0.1580
DEBUG - 2020-07-17 15:07:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 15:07:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:22 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 15:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:07:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:07:22 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:07:22 --> 404 Page Not Found: Uploads/clothes.jpg
ERROR - 2020-07-17 15:07:22 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:07:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:22 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-17 15:07:22 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 15:07:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:22 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 15:07:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:22 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 15:07:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:22 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 15:07:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:07:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:23 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-17 15:07:23 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 15:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:23 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 15:07:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:23 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:07:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:23 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 15:07:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:23 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 15:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:23 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 15:07:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:23 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 15:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:23 --> 404 Page Not Found: Uploads/months_and_days.jpg
ERROR - 2020-07-17 15:07:23 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 15:07:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:23 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
ERROR - 2020-07-17 15:07:23 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 15:07:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:23 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 15:07:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:23 --> 404 Page Not Found: Uploads/places.jpg
ERROR - 2020-07-17 15:07:23 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 15:07:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:23 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 15:07:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:07:24 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:07:24 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 15:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:07:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:24 --> 404 Page Not Found: Uploads/sports.jpg
ERROR - 2020-07-17 15:07:24 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 15:07:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:07:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:24 --> 404 Page Not Found: Uploads/transport.jpg
ERROR - 2020-07-17 15:07:24 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 15:07:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:24 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 15:07:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:24 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 15:07:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:24 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 15:07:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:07:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:25 --> 404 Page Not Found: Uploads/clothes.jpg
ERROR - 2020-07-17 15:07:25 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-17 15:07:25 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:07:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:25 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 15:07:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:25 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 15:07:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:25 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 15:07:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:07:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:25 --> 404 Page Not Found: Uploads/grammar.jpg
ERROR - 2020-07-17 15:07:25 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 15:07:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:25 --> 404 Page Not Found: Uploads/employment.jpg
ERROR - 2020-07-17 15:07:25 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 15:07:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:07:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:25 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
ERROR - 2020-07-17 15:07:25 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 15:07:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:07:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:25 --> 404 Page Not Found: Uploads/materials.jpg
ERROR - 2020-07-17 15:07:25 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 15:07:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:25 --> 404 Page Not Found: Uploads/legal_terminology.jpg
ERROR - 2020-07-17 15:07:25 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 15:07:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:07:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:07:25 --> 404 Page Not Found: Uploads/music.jpg
ERROR - 2020-07-17 15:07:25 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 15:08:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:08:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:08:44 --> Total execution time: 0.1291
DEBUG - 2020-07-17 15:09:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:09:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:09:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:09:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:09:43 --> Total execution time: 0.1605
DEBUG - 2020-07-17 15:10:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:10:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:18:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:18:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:18:35 --> Total execution time: 0.1529
DEBUG - 2020-07-17 15:18:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 15:18:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:35 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:18:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:18:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:35 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-17 15:18:35 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 15:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:18:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:35 --> 404 Page Not Found: Uploads/clothes.jpg
ERROR - 2020-07-17 15:18:35 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 15:18:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:36 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 15:18:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:36 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 15:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:36 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-17 15:18:36 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 15:18:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:36 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:18:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:36 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 15:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:36 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 15:18:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:36 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 15:18:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:36 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 15:18:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:36 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 15:18:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:18:36 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:18:36 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 15:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:36 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 15:18:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:36 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 15:18:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:36 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 15:18:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:37 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 15:18:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:37 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 15:18:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:37 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 15:18:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:37 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 15:18:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:37 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 15:18:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:37 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 15:18:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:37 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 15:18:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:37 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 15:18:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:37 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 15:18:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:37 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 15:18:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:37 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 15:18:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:18:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:37 --> 404 Page Not Found: Uploads/weather.jpg
ERROR - 2020-07-17 15:18:37 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 15:18:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:38 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:18:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:38 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 15:18:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:18:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:38 --> 404 Page Not Found: Uploads/colours.jpg
ERROR - 2020-07-17 15:18:38 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 15:18:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:38 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 15:18:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:38 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 15:18:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:39 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-17 15:18:39 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 15:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:39 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 15:18:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:39 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 15:18:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:39 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 15:18:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:39 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:18:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:18:39 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:18:39 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 15:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:39 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 15:18:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:39 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 15:18:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:18:39 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 15:18:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:18:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:18:42 --> Total execution time: 0.1181
DEBUG - 2020-07-17 15:26:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:26:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:26:48 --> Total execution time: 0.1365
DEBUG - 2020-07-17 15:26:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 15:26:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:49 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 15:26:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:49 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:26:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:49 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 15:26:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:26:49 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:26:49 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 15:26:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:49 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 15:26:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:49 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 15:26:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:26:49 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:26:49 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 15:26:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:50 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 15:26:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:50 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 15:26:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:50 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 15:26:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:50 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 15:26:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:50 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:26:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:26:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:50 --> 404 Page Not Found: Uploads/home.jpg
ERROR - 2020-07-17 15:26:50 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 15:26:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:50 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 15:26:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:26:50 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:26:50 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 15:26:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:50 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 15:26:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:50 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 15:26:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:50 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 15:26:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:26:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:50 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
ERROR - 2020-07-17 15:26:50 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 15:26:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:50 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 15:26:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:51 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 15:26:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:51 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 15:26:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:51 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 15:26:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:51 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 15:26:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:51 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 15:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:26:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:51 --> 404 Page Not Found: Uploads/sports.jpg
ERROR - 2020-07-17 15:26:51 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 15:26:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:51 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 15:26:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:51 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 15:26:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:51 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 15:26:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:52 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:26:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:52 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 15:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:52 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 15:26:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:52 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-17 15:26:52 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 15:26:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:52 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 15:26:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:26:52 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:26:52 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 15:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:52 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 15:26:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:52 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 15:26:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:53 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 15:26:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:53 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 15:26:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:53 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:26:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:53 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 15:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:53 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 15:26:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:53 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 15:26:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:53 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 15:26:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:53 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 15:26:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:26:53 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 15:32:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:32:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:32:20 --> Total execution time: 0.1499
DEBUG - 2020-07-17 15:32:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 15:32:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:21 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:32:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:21 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 15:32:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:21 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 15:32:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:21 --> 404 Page Not Found: Uploads/colours.jpg
ERROR - 2020-07-17 15:32:21 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 15:32:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:21 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:22 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:22 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 15:32:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:22 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:22 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:22 --> 404 Page Not Found: Uploads/grammar.jpg
ERROR - 2020-07-17 15:32:22 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:22 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:22 --> 404 Page Not Found: Uploads/legal_terminology.jpg
ERROR - 2020-07-17 15:32:22 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:22 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 15:32:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:23 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 15:32:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:23 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 15:32:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:23 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 15:32:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:23 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 15:32:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:23 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 15:32:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:23 --> 404 Page Not Found: Uploads/places.jpg
ERROR - 2020-07-17 15:32:23 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 15:32:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:23 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 15:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:24 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 15:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:24 --> 404 Page Not Found: Uploads/shapes.png
ERROR - 2020-07-17 15:32:24 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 15:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:24 --> 404 Page Not Found: Uploads/transport.jpg
ERROR - 2020-07-17 15:32:24 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 15:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-17 15:32:24 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 15:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:24 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 15:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:24 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-17 15:32:24 --> 404 Page Not Found: Uploads/grammar.jpg
ERROR - 2020-07-17 15:32:24 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 15:32:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:25 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:32:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:32:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:32:31 --> Total execution time: 0.1582
DEBUG - 2020-07-17 15:32:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:31 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 15:32:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:32 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 15:32:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:32 --> 404 Page Not Found: Uploads/clothes.jpg
ERROR - 2020-07-17 15:32:32 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-17 15:32:32 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 15:32:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:32 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:32:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:32 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 15:32:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:32 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 15:32:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:32 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:32:32 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 15:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:32 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-17 15:32:32 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 15:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:32 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 15:32:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:32 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:32:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:32 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 15:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:32 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 15:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:32 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 15:32:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:33 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 15:32:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:33 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 15:32:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:33 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:32:33 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 15:32:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:33 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 15:32:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:33 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 15:32:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:33 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 15:32:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:33 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 15:32:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:33 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 15:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:33 --> 404 Page Not Found: Uploads/scotland.jpg
ERROR - 2020-07-17 15:32:33 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 15:32:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:33 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 15:32:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:33 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 15:32:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:33 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 15:32:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:33 --> 404 Page Not Found: Uploads/travel.jpg
ERROR - 2020-07-17 15:32:33 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 15:32:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:33 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 15:32:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:34 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 15:32:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:35 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:32:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:35 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:32:35 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 15:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:35 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-17 15:32:35 --> 404 Page Not Found: Uploads/clothes.jpg
ERROR - 2020-07-17 15:32:35 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 15:32:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:35 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 15:32:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:35 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:32:35 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 15:32:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:35 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 15:32:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:35 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 15:32:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:35 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 15:32:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:35 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 15:32:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:35 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:32:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:36 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 15:32:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:36 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 15:32:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:36 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 15:32:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:36 --> 404 Page Not Found: Uploads/materials.jpg
ERROR - 2020-07-17 15:32:36 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 15:32:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:36 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 15:32:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:36 --> 404 Page Not Found: Uploads/supermarket.jpg
ERROR - 2020-07-17 15:32:36 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 15:32:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:36 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 15:32:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:36 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 15:32:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:32:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:32:44 --> Total execution time: 0.1412
DEBUG - 2020-07-17 15:32:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:32:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:32:53 --> Total execution time: 0.1549
DEBUG - 2020-07-17 15:32:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 15:32:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:53 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:32:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:54 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:32:54 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 15:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:54 --> 404 Page Not Found: Uploads/countries.jpg
ERROR - 2020-07-17 15:32:54 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 15:32:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:54 --> 404 Page Not Found: Uploads/clothes.jpg
ERROR - 2020-07-17 15:32:54 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 15:32:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:54 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 15:32:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:54 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-17 15:32:54 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 15:32:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:54 --> 404 Page Not Found: Uploads/grammar.jpg
ERROR - 2020-07-17 15:32:54 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 15:32:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:54 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:32:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:54 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 15:32:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:54 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 15:32:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:54 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 15:32:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:54 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:32:54 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 15:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:54 --> 404 Page Not Found: Uploads/months_and_days.jpg
ERROR - 2020-07-17 15:32:54 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 15:32:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:55 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 15:32:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:55 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 15:32:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:55 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 15:32:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:55 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 15:32:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:55 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 15:32:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:55 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 15:32:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:55 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:32:55 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 15:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:55 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 15:32:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:55 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 15:32:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:55 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 15:32:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:55 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 15:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:55 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 15:32:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:55 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 15:32:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:56 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 15:32:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:32:56 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:32:56 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 15:32:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:32:56 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:33:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:33:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:33:07 --> Total execution time: 0.1622
DEBUG - 2020-07-17 15:33:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:33:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:33:09 --> Total execution time: 0.1636
DEBUG - 2020-07-17 15:33:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 15:33:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:10 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:33:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:10 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:33:10 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 15:33:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:10 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 15:33:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:10 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 15:33:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:10 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 15:33:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:10 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 15:33:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:10 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-17 15:33:10 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 15:33:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:10 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 15:33:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:10 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 15:33:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:10 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:33:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:11 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 15:33:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:11 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 15:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:11 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 15:33:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:11 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 15:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:11 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 15:33:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:11 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 15:33:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:11 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 15:33:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:11 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 15:33:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:11 --> 404 Page Not Found: Uploads/opposites.jpg
ERROR - 2020-07-17 15:33:11 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 15:33:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:11 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 15:33:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:11 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 15:33:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:11 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 15:33:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:11 --> 404 Page Not Found: Uploads/transport.jpg
ERROR - 2020-07-17 15:33:11 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 15:33:11 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:33:12 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 15:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:12 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 15:33:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:12 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:33:12 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 15:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:12 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 15:33:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:12 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 15:33:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:12 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 15:33:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:12 --> 404 Page Not Found: Uploads/animals.jpg
ERROR - 2020-07-17 15:33:12 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 15:33:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:33:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:33:18 --> Total execution time: 0.1402
DEBUG - 2020-07-17 15:33:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:33:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:33:21 --> Total execution time: 0.1558
DEBUG - 2020-07-17 15:33:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 15:33:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:22 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:33:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:22 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:33:22 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 15:33:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:22 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 15:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:22 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:33:22 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 15:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:22 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:33:22 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 15:33:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:22 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 15:33:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:22 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:33:22 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 15:33:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:22 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-17 15:33:22 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:33:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:22 --> 404 Page Not Found: Uploads/employment.jpg
ERROR - 2020-07-17 15:33:22 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 15:33:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:22 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 15:33:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:23 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 15:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:23 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:33:23 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 15:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:23 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 15:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:23 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 15:33:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:23 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 15:33:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:23 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 15:33:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:23 --> 404 Page Not Found: Uploads/opposites.jpg
ERROR - 2020-07-17 15:33:23 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 15:33:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:23 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
ERROR - 2020-07-17 15:33:23 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 15:33:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:23 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 15:33:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:23 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 15:33:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:23 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:33:23 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 15:33:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:23 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 15:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:23 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 15:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:23 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 15:33:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:23 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 15:33:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:23 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 15:33:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:24 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 15:33:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:24 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 15:33:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:33:24 --> 404 Page Not Found: Uploads/animals.jpg
ERROR - 2020-07-17 15:33:24 --> 404 Page Not Found: Uploads/numbers.png
ERROR - 2020-07-17 15:33:24 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 15:33:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:33:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:33:51 --> Total execution time: 0.1044
DEBUG - 2020-07-17 15:34:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:34:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:34:16 --> Total execution time: 0.1272
DEBUG - 2020-07-17 15:34:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 15:34:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:16 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:34:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:34:16 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:34:16 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 15:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:34:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:16 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 15:34:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:16 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:34:16 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 15:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:34:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:16 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-17 15:34:16 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 15:34:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:17 --> 404 Page Not Found: Uploads/grammar.jpg
ERROR - 2020-07-17 15:34:17 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 15:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:17 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 15:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:17 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 15:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:17 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:17 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 15:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:17 --> 404 Page Not Found: Uploads/materials.jpg
ERROR - 2020-07-17 15:34:17 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 15:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:17 --> 404 Page Not Found: Uploads/home.jpg
ERROR - 2020-07-17 15:34:17 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 15:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:17 --> 404 Page Not Found: Uploads/music.jpg
ERROR - 2020-07-17 15:34:17 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 15:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:17 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 15:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:34:17 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:34:17 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 15:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:17 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 15:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:17 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 15:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:17 --> 404 Page Not Found: Uploads/scotland.jpg
ERROR - 2020-07-17 15:34:17 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 15:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:17 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 15:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:17 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 15:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:18 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 15:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:18 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 15:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:18 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 15:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:18 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 15:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:18 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 15:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:34:18 --> 404 Page Not Found: Uploads/animals.jpg
ERROR - 2020-07-17 15:34:18 --> 404 Page Not Found: Uploads/months_and_days.jpg
ERROR - 2020-07-17 15:34:18 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 15:36:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:36:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:36:11 --> Total execution time: 0.1442
DEBUG - 2020-07-17 15:36:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:36:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:36:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:36:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:36:20 --> Total execution time: 0.1352
DEBUG - 2020-07-17 15:36:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:36:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:36:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:36:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:36:32 --> Total execution time: 0.1269
DEBUG - 2020-07-17 15:36:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:36:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:36:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:36:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:36:44 --> Total execution time: 0.1506
DEBUG - 2020-07-17 15:36:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 15:36:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:36:45 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:36:45 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:36:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:45 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 15:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:36:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:45 --> 404 Page Not Found: Uploads/clothes.jpg
ERROR - 2020-07-17 15:36:45 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 15:36:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:36:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:45 --> 404 Page Not Found: Uploads/colours.jpg
ERROR - 2020-07-17 15:36:45 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 15:36:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:36:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:45 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:36:45 --> 404 Page Not Found: Uploads/health_care.jpg
ERROR - 2020-07-17 15:36:45 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 15:36:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:45 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:36:45 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:36:45 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 15:36:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:45 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 15:36:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:45 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 15:36:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:45 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 15:36:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:45 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 15:36:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:45 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 15:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:36:45 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:36:45 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 15:36:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:45 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 15:36:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:45 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 15:36:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:36:46 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:36:46 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 15:36:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:46 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 15:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:36:46 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:36:46 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 15:36:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:46 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 15:36:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:46 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 15:36:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:46 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 15:36:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:46 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 15:36:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:36:46 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:36:46 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 15:36:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:46 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 15:36:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:46 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 15:36:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:46 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 15:36:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:46 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 15:36:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:46 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 15:36:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:47 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 15:36:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:47 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 15:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:47 --> 404 Page Not Found: Uploads/animals.jpg
ERROR - 2020-07-17 15:36:47 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-17 15:36:47 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 15:36:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:47 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 15:36:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:47 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 15:36:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:47 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 15:36:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:47 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-17 15:36:47 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 15:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:47 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 15:36:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:47 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:36:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:47 --> 404 Page Not Found: Uploads/in_the_office.jpg
ERROR - 2020-07-17 15:36:47 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 15:36:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:47 --> 404 Page Not Found: Uploads/music.jpg
ERROR - 2020-07-17 15:36:47 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 15:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:36:47 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 15:36:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:36:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:36:54 --> Total execution time: 0.1370
DEBUG - 2020-07-17 15:37:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:37:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:37:04 --> Total execution time: 0.1260
DEBUG - 2020-07-17 15:37:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:37:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:37:04 --> Total execution time: 0.1314
DEBUG - 2020-07-17 15:37:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 15:37:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:04 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:37:04 --> 404 Page Not Found: Uploads/accessories.jpg
DEBUG - 2020-07-17 15:37:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:04 --> 404 Page Not Found: Uploads/adverbs.jpg
DEBUG - 2020-07-17 15:37:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:04 --> 404 Page Not Found: Uploads/animals_with_hooves.jpg
DEBUG - 2020-07-17 15:37:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:04 --> 404 Page Not Found: Uploads/appearance.jpg
DEBUG - 2020-07-17 15:37:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:04 --> 404 Page Not Found: Uploads/animals_in_europe.jpg
ERROR - 2020-07-17 15:37:04 --> 404 Page Not Found: Uploads/animals_in_the_world.jpg
DEBUG - 2020-07-17 15:37:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:05 --> 404 Page Not Found: Uploads/at_home.jpg
DEBUG - 2020-07-17 15:37:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:05 --> 404 Page Not Found: Uploads/baby_clothes.jpg
DEBUG - 2020-07-17 15:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:05 --> 404 Page Not Found: Uploads/At__the_dentists.JPG
DEBUG - 2020-07-17 15:37:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:05 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:37:05 --> 404 Page Not Found: Uploads/baby_toiletries.jpg
DEBUG - 2020-07-17 15:37:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:05 --> 404 Page Not Found: Uploads/bathroom.jpg
ERROR - 2020-07-17 15:37:05 --> 404 Page Not Found: Uploads/bakery_and_pasta.jpg
DEBUG - 2020-07-17 15:37:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:05 --> 404 Page Not Found: Uploads/bedroom.jpg
DEBUG - 2020-07-17 15:37:05 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:37:05 --> 404 Page Not Found: Uploads/birds.jpg
DEBUG - 2020-07-17 15:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:05 --> 404 Page Not Found: Uploads/berries.jpg
DEBUG - 2020-07-17 15:37:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:05 --> 404 Page Not Found: Uploads/childrens_clothes.jpg
DEBUG - 2020-07-17 15:37:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:05 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:37:05 --> 404 Page Not Found: Uploads/body_parts.jpg
DEBUG - 2020-07-17 15:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:05 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 15:37:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:05 --> 404 Page Not Found: Uploads/colours.jpg
ERROR - 2020-07-17 15:37:05 --> 404 Page Not Found: Uploads/containers_and_portions.jpg
DEBUG - 2020-07-17 15:37:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:05 --> 404 Page Not Found: Uploads/cooking_verbs.jpg
DEBUG - 2020-07-17 15:37:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:05 --> 404 Page Not Found: Uploads/dairy.jpg
DEBUG - 2020-07-17 15:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:05 --> 404 Page Not Found: Uploads/countries.jpg
ERROR - 2020-07-17 15:37:05 --> 404 Page Not Found: Uploads/opposites_doubles.jpg
DEBUG - 2020-07-17 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:06 --> 404 Page Not Found: Uploads/electronic_appliances.jpg
ERROR - 2020-07-17 15:37:06 --> 404 Page Not Found: Uploads/drinks.jpg
DEBUG - 2020-07-17 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:06 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:06 --> 404 Page Not Found: Uploads/everyday_life.jpg
DEBUG - 2020-07-17 15:37:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:06 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-17 15:37:06 --> 404 Page Not Found: Uploads/equipment.jpg
DEBUG - 2020-07-17 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:06 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:06 --> 404 Page Not Found: Uploads/face_and_head.jpg
ERROR - 2020-07-17 15:37:06 --> 404 Page Not Found: Uploads/fruits.jpg
DEBUG - 2020-07-17 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:06 --> 404 Page Not Found: Uploads/fish_and_seafood.jpg
DEBUG - 2020-07-17 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:06 --> 404 Page Not Found: Uploads/fixtures.jpg
DEBUG - 2020-07-17 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:06 --> 404 Page Not Found: Uploads/furniture.jpg
DEBUG - 2020-07-17 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:06 --> 404 Page Not Found: Uploads/ground_and_air.jpg
DEBUG - 2020-07-17 15:37:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:06 --> 404 Page Not Found: Uploads/grains_and_cereals.jpg
DEBUG - 2020-07-17 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:06 --> 404 Page Not Found: Uploads/generic.jpg
DEBUG - 2020-07-17 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:06 --> 404 Page Not Found: Uploads/herbs_and_spices.jpg
DEBUG - 2020-07-17 15:37:06 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:37:06 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:37:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:06 --> 404 Page Not Found: Uploads/illnesses.jpg
DEBUG - 2020-07-17 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:06 --> 404 Page Not Found: Uploads/in_the_kitchen.jpg
DEBUG - 2020-07-17 15:37:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:06 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 15:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:07 --> 404 Page Not Found: Uploads/insects.jpg
DEBUG - 2020-07-17 15:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:07 --> 404 Page Not Found: Uploads/legal_terminology.jpg
ERROR - 2020-07-17 15:37:07 --> 404 Page Not Found: Uploads/items_at_home.jpg
DEBUG - 2020-07-17 15:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:07 --> 404 Page Not Found: Uploads/laundry_and_cleaning.jpg
DEBUG - 2020-07-17 15:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:07 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:37:07 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 15:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:07 --> 404 Page Not Found: Uploads/materials_and_patterns.jpg
DEBUG - 2020-07-17 15:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:07 --> 404 Page Not Found: Uploads/meat.jpg
DEBUG - 2020-07-17 15:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:07 --> 404 Page Not Found: Uploads/medical_symptoms.jpg
ERROR - 2020-07-17 15:37:07 --> 404 Page Not Found: Uploads/medical_equipment.jpg
DEBUG - 2020-07-17 15:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:07 --> 404 Page Not Found: Uploads/medical_terms.jpg
DEBUG - 2020-07-17 15:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:07 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 15:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:07 --> 404 Page Not Found: Uploads/medication.jpg
DEBUG - 2020-07-17 15:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:07 --> 404 Page Not Found: Uploads/Mushrooms.jpg
DEBUG - 2020-07-17 15:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:07 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:37:07 --> 404 Page Not Found: Uploads/numbers_cardinals.png
DEBUG - 2020-07-17 15:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:07 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 15:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:07 --> 404 Page Not Found: Uploads/nationalities.jpg
DEBUG - 2020-07-17 15:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:07 --> 404 Page Not Found: Uploads/nuts_and_dried_fruit.jpg
DEBUG - 2020-07-17 15:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:07 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 15:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:07 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:37:07 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
ERROR - 2020-07-17 15:37:07 --> 404 Page Not Found: Uploads/numbers_ordinals.png
DEBUG - 2020-07-17 15:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:07 --> 404 Page Not Found: Uploads/Ready_meals.JPG
DEBUG - 2020-07-17 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:08 --> 404 Page Not Found: Uploads/reptiles_and_amphibians.jpg
DEBUG - 2020-07-17 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:08 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 15:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:08 --> 404 Page Not Found: Uploads/scotland.jpg
ERROR - 2020-07-17 15:37:08 --> 404 Page Not Found: Uploads/sea_animals_and_fish.jpg
DEBUG - 2020-07-17 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:08 --> 404 Page Not Found: Uploads/rooms.jpg
ERROR - 2020-07-17 15:37:08 --> 404 Page Not Found: Uploads/Sauces_and_condiments.jpg
DEBUG - 2020-07-17 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:08 --> 404 Page Not Found: Uploads/shoes_and_trousers.jpg
DEBUG - 2020-07-17 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:08 --> 404 Page Not Found: Uploads/toys_and_games.jpg
DEBUG - 2020-07-17 15:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:08 --> 404 Page Not Found: Uploads/Snacks_and_sweets.JPG
ERROR - 2020-07-17 15:37:08 --> 404 Page Not Found: Uploads/Toiletries.jpg
DEBUG - 2020-07-17 15:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:08 --> 404 Page Not Found: Uploads/sport_terms.png
DEBUG - 2020-07-17 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:08 --> 404 Page Not Found: Uploads/tools_and_diy.jpg
DEBUG - 2020-07-17 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:08 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:08 --> 404 Page Not Found: Uploads/Vegetables.JPG
DEBUG - 2020-07-17 15:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:08 --> 404 Page Not Found: Uploads/types_of_sports.jpg
DEBUG - 2020-07-17 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:08 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:37:08 --> 404 Page Not Found: Uploads/1_verbs.png
DEBUG - 2020-07-17 15:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:08 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:08 --> 404 Page Not Found: Uploads/2_verbs.png
DEBUG - 2020-07-17 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:08 --> 404 Page Not Found: Uploads/water.jpg
ERROR - 2020-07-17 15:37:08 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:09 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 15:37:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:37:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:37:24 --> Total execution time: 0.1383
DEBUG - 2020-07-17 15:37:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 15:37:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:25 --> 404 Page Not Found: Uploads/accessories.jpg
ERROR - 2020-07-17 15:37:25 --> 404 Page Not Found: Uploads/appearance.jpg
DEBUG - 2020-07-17 15:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:25 --> 404 Page Not Found: Uploads/animals_in_europe.jpg
ERROR - 2020-07-17 15:37:25 --> 404 Page Not Found: Uploads/animals_in_the_world.jpg
DEBUG - 2020-07-17 15:37:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:25 --> 404 Page Not Found: Uploads/adverbs.jpg
DEBUG - 2020-07-17 15:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:25 --> 404 Page Not Found: Uploads/animals_with_hooves.jpg
DEBUG - 2020-07-17 15:37:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:25 --> 404 Page Not Found: Uploads/baby_clothes.jpg
DEBUG - 2020-07-17 15:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:25 --> 404 Page Not Found: Uploads/At__the_dentists.JPG
ERROR - 2020-07-17 15:37:25 --> 404 Page Not Found: Uploads/at_home.jpg
DEBUG - 2020-07-17 15:37:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:25 --> 404 Page Not Found: Uploads/bakery_and_pasta.jpg
DEBUG - 2020-07-17 15:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:25 --> 404 Page Not Found: Uploads/bathroom.jpg
DEBUG - 2020-07-17 15:37:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:25 --> 404 Page Not Found: Uploads/baby_toiletries.jpg
DEBUG - 2020-07-17 15:37:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:26 --> 404 Page Not Found: Uploads/childrens_clothes.jpg
DEBUG - 2020-07-17 15:37:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:26 --> 404 Page Not Found: Uploads/body_parts.jpg
ERROR - 2020-07-17 15:37:26 --> 404 Page Not Found: Uploads/birds.jpg
DEBUG - 2020-07-17 15:37:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:26 --> 404 Page Not Found: Uploads/berries.jpg
DEBUG - 2020-07-17 15:37:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:26 --> 404 Page Not Found: Uploads/bedroom.jpg
DEBUG - 2020-07-17 15:37:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:26 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 15:37:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:26 --> 404 Page Not Found: Uploads/cooking_verbs.jpg
ERROR - 2020-07-17 15:37:26 --> 404 Page Not Found: Uploads/colours.jpg
ERROR - 2020-07-17 15:37:26 --> 404 Page Not Found: Uploads/containers_and_portions.jpg
DEBUG - 2020-07-17 15:37:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:26 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 15:37:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:26 --> 404 Page Not Found: Uploads/dairy.jpg
DEBUG - 2020-07-17 15:37:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:26 --> 404 Page Not Found: Uploads/opposites_doubles.jpg
DEBUG - 2020-07-17 15:37:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:26 --> 404 Page Not Found: Uploads/electronic_appliances.jpg
ERROR - 2020-07-17 15:37:26 --> 404 Page Not Found: Uploads/drinks.jpg
DEBUG - 2020-07-17 15:37:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:26 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 15:37:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:26 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 15:37:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:27 --> 404 Page Not Found: Uploads/equipment.jpg
DEBUG - 2020-07-17 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:27 --> 404 Page Not Found: Uploads/everyday_life.jpg
DEBUG - 2020-07-17 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:27 --> 404 Page Not Found: Uploads/fish_and_seafood.jpg
ERROR - 2020-07-17 15:37:27 --> 404 Page Not Found: Uploads/face_and_head.jpg
DEBUG - 2020-07-17 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:27 --> 404 Page Not Found: Uploads/fixtures.jpg
DEBUG - 2020-07-17 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:27 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:27 --> 404 Page Not Found: Uploads/fruits.jpg
DEBUG - 2020-07-17 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:27 --> 404 Page Not Found: Uploads/grains_and_cereals.jpg
DEBUG - 2020-07-17 15:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:27 --> 404 Page Not Found: Uploads/generic.jpg
DEBUG - 2020-07-17 15:37:27 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:37:27 --> 404 Page Not Found: Uploads/furniture.jpg
DEBUG - 2020-07-17 15:37:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:27 --> 404 Page Not Found: Uploads/ground_and_air.jpg
DEBUG - 2020-07-17 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:27 --> 404 Page Not Found: Uploads/herbs_and_spices.jpg
DEBUG - 2020-07-17 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:27 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
ERROR - 2020-07-17 15:37:27 --> 404 Page Not Found: Uploads/in_the_kitchen.jpg
DEBUG - 2020-07-17 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:27 --> 404 Page Not Found: Uploads/in_the_office.jpg
ERROR - 2020-07-17 15:37:27 --> 404 Page Not Found: Uploads/illnesses.jpg
DEBUG - 2020-07-17 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:27 --> 404 Page Not Found: Uploads/insects.jpg
DEBUG - 2020-07-17 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:27 --> 404 Page Not Found: Uploads/items_at_home.jpg
DEBUG - 2020-07-17 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:27 --> 404 Page Not Found: Uploads/laundry_and_cleaning.jpg
ERROR - 2020-07-17 15:37:27 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 15:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:28 --> 404 Page Not Found: Uploads/materials.jpg
ERROR - 2020-07-17 15:37:28 --> 404 Page Not Found: Uploads/materials_and_patterns.jpg
DEBUG - 2020-07-17 15:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:28 --> 404 Page Not Found: Uploads/meat.jpg
DEBUG - 2020-07-17 15:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:28 --> 404 Page Not Found: Uploads/medical_equipment.jpg
DEBUG - 2020-07-17 15:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:28 --> 404 Page Not Found: Uploads/medical_terms.jpg
DEBUG - 2020-07-17 15:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:28 --> 404 Page Not Found: Uploads/medical_symptoms.jpg
DEBUG - 2020-07-17 15:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:28 --> 404 Page Not Found: Uploads/medication.jpg
ERROR - 2020-07-17 15:37:28 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 15:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:28 --> 404 Page Not Found: Uploads/Mushrooms.jpg
DEBUG - 2020-07-17 15:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:28 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 15:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:28 --> 404 Page Not Found: Uploads/numbers_cardinals.png
ERROR - 2020-07-17 15:37:28 --> 404 Page Not Found: Uploads/nationalities.jpg
DEBUG - 2020-07-17 15:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:28 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:37:28 --> 404 Page Not Found: Uploads/nuts_and_dried_fruit.jpg
DEBUG - 2020-07-17 15:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:28 --> 404 Page Not Found: Uploads/numbers_ordinals.png
DEBUG - 2020-07-17 15:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:28 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
ERROR - 2020-07-17 15:37:28 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 15:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:28 --> 404 Page Not Found: Uploads/rooms.jpg
DEBUG - 2020-07-17 15:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:28 --> 404 Page Not Found: Uploads/Ready_meals.JPG
DEBUG - 2020-07-17 15:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:28 --> 404 Page Not Found: Uploads/reptiles_and_amphibians.jpg
ERROR - 2020-07-17 15:37:28 --> 404 Page Not Found: Uploads/Sauces_and_condiments.jpg
DEBUG - 2020-07-17 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:29 --> 404 Page Not Found: Uploads/sea_animals_and_fish.jpg
ERROR - 2020-07-17 15:37:29 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:29 --> 404 Page Not Found: Uploads/shoes_and_trousers.jpg
ERROR - 2020-07-17 15:37:29 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:29 --> 404 Page Not Found: Uploads/Snacks_and_sweets.JPG
DEBUG - 2020-07-17 15:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:29 --> 404 Page Not Found: Uploads/sport_terms.png
DEBUG - 2020-07-17 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:29 --> 404 Page Not Found: Uploads/tools_and_diy.jpg
DEBUG - 2020-07-17 15:37:29 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:37:29 --> 404 Page Not Found: Uploads/Toiletries.jpg
DEBUG - 2020-07-17 15:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:29 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 15:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:29 --> 404 Page Not Found: Uploads/toys_and_games.jpg
DEBUG - 2020-07-17 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:29 --> 404 Page Not Found: Uploads/types_of_sports.jpg
DEBUG - 2020-07-17 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:29 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:29 --> 404 Page Not Found: Uploads/water.jpg
DEBUG - 2020-07-17 15:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:29 --> 404 Page Not Found: Uploads/2_verbs.png
DEBUG - 2020-07-17 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:29 --> 404 Page Not Found: Uploads/Vegetables.JPG
DEBUG - 2020-07-17 15:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:29 --> 404 Page Not Found: Uploads/1_verbs.png
DEBUG - 2020-07-17 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:29 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 15:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:29 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 15:37:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:37:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:37:48 --> Total execution time: 0.1027
DEBUG - 2020-07-17 15:37:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:37:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:37:52 --> Total execution time: 0.1316
DEBUG - 2020-07-17 15:37:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 15:37:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:37:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:37:57 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 15:38:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:38:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:38:04 --> Total execution time: 0.1675
DEBUG - 2020-07-17 15:38:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:38:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:38:12 --> Total execution time: 0.1480
DEBUG - 2020-07-17 15:38:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:38:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:38:12 --> Total execution time: 0.1322
DEBUG - 2020-07-17 15:38:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 15:38:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:13 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:38:13 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:13 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:38:13 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 15:38:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:13 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 15:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:13 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:38:13 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 15:38:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:13 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 15:38:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:13 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 15:38:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:13 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 15:38:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:13 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 15:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:13 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-17 15:38:13 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 15:38:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:13 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 15:38:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:14 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:38:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:14 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 15:38:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:14 --> 404 Page Not Found: Uploads/legal_terminology.jpg
ERROR - 2020-07-17 15:38:14 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 15:38:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:14 --> 404 Page Not Found: Uploads/materials.jpg
ERROR - 2020-07-17 15:38:14 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 15:38:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:14 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:38:14 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 15:38:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:14 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 15:38:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:14 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 15:38:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:14 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 15:38:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:14 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 15:38:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:14 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 15:38:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:14 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 15:38:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:14 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 15:38:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:14 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 15:38:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:14 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 15:38:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:15 --> 404 Page Not Found: Uploads/travel.jpg
ERROR - 2020-07-17 15:38:15 --> 404 Page Not Found: Uploads/transport.jpg
ERROR - 2020-07-17 15:38:15 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 15:38:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:15 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 15:38:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:15 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 15:38:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:15 --> 404 Page Not Found: Uploads/animals.jpg
ERROR - 2020-07-17 15:38:15 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 15:38:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:38:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:38:43 --> Total execution time: 0.1318
DEBUG - 2020-07-17 15:38:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 15:38:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:44 --> 404 Page Not Found: Uploads/colours.jpg
ERROR - 2020-07-17 15:38:44 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:38:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:44 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:38:44 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 15:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:44 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-17 15:38:44 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 15:38:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:44 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 15:38:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:44 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-17 15:38:44 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 15:38:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:44 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:38:44 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-17 15:38:44 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 15:38:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:44 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 15:38:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:45 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:38:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:45 --> 404 Page Not Found: Uploads/legal_terminology.jpg
ERROR - 2020-07-17 15:38:45 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 15:38:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:45 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 15:38:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:45 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 15:38:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:45 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 15:38:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:45 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:38:45 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 15:38:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:45 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 15:38:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:45 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 15:38:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:45 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 15:38:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:45 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 15:38:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:45 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 15:38:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:45 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 15:38:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:45 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 15:38:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:46 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 15:38:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:46 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 15:38:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:46 --> 404 Page Not Found: Uploads/transport.jpg
ERROR - 2020-07-17 15:38:46 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 15:38:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:46 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
ERROR - 2020-07-17 15:38:46 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 15:38:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:46 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 15:38:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:46 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 15:38:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:46 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-17 15:38:46 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:38:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:38:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:38:51 --> Total execution time: 0.1565
DEBUG - 2020-07-17 15:38:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 15:38:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:51 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:38:51 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 15:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:51 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-17 15:38:51 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 15:38:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:51 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:38:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:51 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 15:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:52 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 15:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:52 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 15:38:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:52 --> 404 Page Not Found: Uploads/employment.jpg
ERROR - 2020-07-17 15:38:52 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 15:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:52 --> 404 Page Not Found: Uploads/health_care.jpg
ERROR - 2020-07-17 15:38:52 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 15:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:52 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:52 --> 404 Page Not Found: Uploads/months_and_days.jpg
ERROR - 2020-07-17 15:38:52 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 15:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:52 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 15:38:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:52 --> 404 Page Not Found: Uploads/in_the_office.jpg
ERROR - 2020-07-17 15:38:52 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 15:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:52 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 15:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:52 --> 404 Page Not Found: Uploads/professions.jpg
ERROR - 2020-07-17 15:38:52 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 15:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:52 --> 404 Page Not Found: Uploads/opposites.jpg
ERROR - 2020-07-17 15:38:52 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 15:38:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:53 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 15:38:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:53 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 15:38:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:53 --> 404 Page Not Found: Uploads/shapes.png
ERROR - 2020-07-17 15:38:53 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 15:38:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:53 --> 404 Page Not Found: Uploads/transport.jpg
ERROR - 2020-07-17 15:38:53 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 15:38:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:38:53 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:38:53 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 15:38:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:53 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 15:38:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:53 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 15:38:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:54 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 15:38:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:38:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:54 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:38:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:38:54 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 15:53:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:53:52 --> Total execution time: 0.1425
DEBUG - 2020-07-17 15:53:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 15:53:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:53:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:53:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:53 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-17 15:53:53 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-17 15:53:53 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:53:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:53 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 15:53:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:53 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 15:53:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:53 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 15:53:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:53:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:53 --> 404 Page Not Found: Uploads/employment.jpg
ERROR - 2020-07-17 15:53:53 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 15:53:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:53:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:53 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 15:53:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:53 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-17 15:53:53 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 15:53:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:53 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:53:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:54 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 15:53:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:54 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 15:53:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:53:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:54 --> 404 Page Not Found: Uploads/legal_terminology.jpg
ERROR - 2020-07-17 15:53:54 --> 404 Page Not Found: Uploads/months_and_days.jpg
ERROR - 2020-07-17 15:53:54 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 15:53:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:54 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 15:53:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:54 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 15:53:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:53:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:54 --> 404 Page Not Found: Uploads/numbers.png
ERROR - 2020-07-17 15:53:54 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 15:53:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:53:54 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:53:54 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 15:53:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:54 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 15:53:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:54 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 15:53:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:54 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 15:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:53:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:54 --> 404 Page Not Found: Uploads/supermarket.jpg
ERROR - 2020-07-17 15:53:54 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 15:53:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:54 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 15:53:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:54 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 15:53:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:55 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 15:53:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:55 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 15:53:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:55 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 15:53:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:56 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-17 15:53:56 --> 404 Page Not Found: Uploads/clothes.jpg
ERROR - 2020-07-17 15:53:56 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 15:53:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:56 --> 404 Page Not Found: Uploads/countries.jpg
ERROR - 2020-07-17 15:53:56 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 15:53:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:56 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 15:53:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:56 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 15:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:56 --> 404 Page Not Found: Uploads/grammar.jpg
ERROR - 2020-07-17 15:53:56 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 15:53:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:56 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
ERROR - 2020-07-17 15:53:56 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 15:53:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:56 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 15:53:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:57 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 15:53:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:57 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 15:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:57 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 15:53:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:57 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 15:53:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:57 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 15:53:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:57 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 15:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:57 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 15:53:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:57 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 15:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:53:57 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 15:54:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:54:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:54:02 --> Total execution time: 0.1457
DEBUG - 2020-07-17 15:54:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 15:54:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:03 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:54:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:03 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-17 15:54:03 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 15:54:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:03 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 15:54:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:03 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 15:54:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:03 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 15:54:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:03 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 15:54:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:04 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 15:54:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:04 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 15:54:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:04 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 15:54:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:04 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 15:54:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:04 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:54:04 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 15:54:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:04 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 15:54:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:04 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:54:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:04 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 15:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:04 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:54:04 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 15:54:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:04 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 15:54:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:04 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 15:54:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:04 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 15:54:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:04 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 15:54:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:04 --> 404 Page Not Found: Uploads/places.jpg
ERROR - 2020-07-17 15:54:04 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 15:54:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:04 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 15:54:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:05 --> 404 Page Not Found: Uploads/shapes.png
ERROR - 2020-07-17 15:54:05 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 15:54:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:05 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 15:54:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:05 --> 404 Page Not Found: Uploads/transport.jpg
ERROR - 2020-07-17 15:54:05 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 15:54:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:05 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 15:54:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:05 --> 404 Page Not Found: Uploads/weather.jpg
ERROR - 2020-07-17 15:54:05 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 15:54:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:06 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 15:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-17 15:54:06 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 15:54:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:06 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:54:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:06 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
ERROR - 2020-07-17 15:54:06 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 15:54:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:06 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 15:54:06 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:54:06 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 15:54:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:06 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 15:54:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:54:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:54:46 --> Total execution time: 0.1540
DEBUG - 2020-07-17 15:54:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 15:54:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:46 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 15:54:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:46 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 15:54:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:46 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 15:54:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:47 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-17 15:54:47 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:47 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 15:54:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:47 --> 404 Page Not Found: Uploads/employment.jpg
ERROR - 2020-07-17 15:54:47 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-17 15:54:47 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 15:54:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:47 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:54:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:47 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:54:47 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 15:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:47 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 15:54:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:47 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 15:54:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:47 --> 404 Page Not Found: Uploads/home.jpg
ERROR - 2020-07-17 15:54:47 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 15:54:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:47 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 15:54:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:47 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 15:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:47 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 15:54:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:47 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 15:54:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:47 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
ERROR - 2020-07-17 15:54:47 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 15:54:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:48 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 15:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:48 --> 404 Page Not Found: Uploads/professions.jpg
ERROR - 2020-07-17 15:54:48 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 15:54:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:48 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 15:54:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:48 --> 404 Page Not Found: Uploads/sports.jpg
ERROR - 2020-07-17 15:54:48 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 15:54:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:48 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 15:54:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:48 --> 404 Page Not Found: Uploads/weather.jpg
ERROR - 2020-07-17 15:54:48 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 15:54:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:48 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 15:54:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:48 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 15:54:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:49 --> 404 Page Not Found: Uploads/clothes.jpg
ERROR - 2020-07-17 15:54:49 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 15:54:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:49 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 15:54:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:49 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 15:54:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:49 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 15:54:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:49 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 15:54:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:50 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 15:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:50 --> 404 Page Not Found: Uploads/employment.jpg
ERROR - 2020-07-17 15:54:50 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 15:54:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:50 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 15:54:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:50 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 15:54:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:50 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:54:50 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 15:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:50 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 15:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:50 --> 404 Page Not Found: Uploads/legal_terminology.jpg
ERROR - 2020-07-17 15:54:50 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:54:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:50 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 15:54:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:50 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 15:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:50 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 15:54:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:50 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 15:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:50 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 15:54:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:50 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 15:54:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:54:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:54:57 --> Total execution time: 0.1828
DEBUG - 2020-07-17 15:54:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 15:54:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 15:54:57 --> Total execution time: 0.1248
DEBUG - 2020-07-17 15:54:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 15:54:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:58 --> 404 Page Not Found: Uploads/accessories.jpg
ERROR - 2020-07-17 15:54:58 --> 404 Page Not Found: Uploads/adverbs.jpg
DEBUG - 2020-07-17 15:54:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:58 --> 404 Page Not Found: Uploads/animals_in_europe.jpg
ERROR - 2020-07-17 15:54:58 --> 404 Page Not Found: Uploads/animals_in_the_world.jpg
DEBUG - 2020-07-17 15:54:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:58 --> 404 Page Not Found: Uploads/appearance.jpg
DEBUG - 2020-07-17 15:54:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:58 --> 404 Page Not Found: Uploads/animals_with_hooves.jpg
DEBUG - 2020-07-17 15:54:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:58 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:54:58 --> 404 Page Not Found: Uploads/at_home.jpg
DEBUG - 2020-07-17 15:54:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:58 --> 404 Page Not Found: Uploads/bathroom.jpg
DEBUG - 2020-07-17 15:54:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:58 --> 404 Page Not Found: Uploads/At__the_dentists.JPG
DEBUG - 2020-07-17 15:54:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:58 --> 404 Page Not Found: Uploads/baby_clothes.jpg
DEBUG - 2020-07-17 15:54:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:58 --> 404 Page Not Found: Uploads/baby_toiletries.jpg
DEBUG - 2020-07-17 15:54:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:58 --> 404 Page Not Found: Uploads/bakery_and_pasta.jpg
DEBUG - 2020-07-17 15:54:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:59 --> 404 Page Not Found: Uploads/bedroom.jpg
DEBUG - 2020-07-17 15:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:59 --> 404 Page Not Found: Uploads/body_parts.jpg
DEBUG - 2020-07-17 15:54:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:59 --> 404 Page Not Found: Uploads/birds.jpg
ERROR - 2020-07-17 15:54:59 --> 404 Page Not Found: Uploads/berries.jpg
DEBUG - 2020-07-17 15:54:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:59 --> 404 Page Not Found: Uploads/childrens_clothes.jpg
DEBUG - 2020-07-17 15:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:59 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 15:54:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:59 --> 404 Page Not Found: Uploads/colours.jpg
ERROR - 2020-07-17 15:54:59 --> 404 Page Not Found: Uploads/containers_and_portions.jpg
DEBUG - 2020-07-17 15:54:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:59 --> 404 Page Not Found: Uploads/cooking_verbs.jpg
DEBUG - 2020-07-17 15:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:59 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 15:54:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:59 --> 404 Page Not Found: Uploads/dairy.jpg
DEBUG - 2020-07-17 15:54:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:59 --> 404 Page Not Found: Uploads/opposites_doubles.jpg
DEBUG - 2020-07-17 15:54:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:59 --> 404 Page Not Found: Uploads/drinks.jpg
DEBUG - 2020-07-17 15:54:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:59 --> 404 Page Not Found: Uploads/electronic_appliances.jpg
DEBUG - 2020-07-17 15:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:59 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 15:54:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:54:59 --> 404 Page Not Found: Uploads/equipment.jpg
DEBUG - 2020-07-17 15:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:00 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 15:55:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:00 --> 404 Page Not Found: Uploads/everyday_life.jpg
DEBUG - 2020-07-17 15:55:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:00 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-17 15:55:00 --> 404 Page Not Found: Uploads/face_and_head.jpg
DEBUG - 2020-07-17 15:55:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:00 --> 404 Page Not Found: Uploads/fixtures.jpg
ERROR - 2020-07-17 15:55:00 --> 404 Page Not Found: Uploads/fruits.jpg
DEBUG - 2020-07-17 15:55:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:00 --> 404 Page Not Found: Uploads/fish_and_seafood.jpg
DEBUG - 2020-07-17 15:55:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:00 --> 404 Page Not Found: Uploads/furniture.jpg
DEBUG - 2020-07-17 15:55:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:00 --> 404 Page Not Found: Uploads/grains_and_cereals.jpg
ERROR - 2020-07-17 15:55:00 --> 404 Page Not Found: Uploads/generic.jpg
DEBUG - 2020-07-17 15:55:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:00 --> 404 Page Not Found: Uploads/ground_and_air.jpg
ERROR - 2020-07-17 15:55:00 --> 404 Page Not Found: Uploads/herbs_and_spices.jpg
DEBUG - 2020-07-17 15:55:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:00 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 15:55:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:00 --> 404 Page Not Found: Uploads/illnesses.jpg
DEBUG - 2020-07-17 15:55:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:55:00 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:55:00 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 15:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:00 --> 404 Page Not Found: Uploads/in_the_kitchen.jpg
DEBUG - 2020-07-17 15:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:00 --> 404 Page Not Found: Uploads/insects.jpg
DEBUG - 2020-07-17 15:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:00 --> 404 Page Not Found: Uploads/items_at_home.jpg
DEBUG - 2020-07-17 15:55:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:01 --> 404 Page Not Found: Uploads/laundry_and_cleaning.jpg
DEBUG - 2020-07-17 15:55:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:55:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:01 --> 404 Page Not Found: Uploads/meat.jpg
ERROR - 2020-07-17 15:55:01 --> 404 Page Not Found: Uploads/medical_equipment.jpg
DEBUG - 2020-07-17 15:55:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:55:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:01 --> 404 Page Not Found: Uploads/materials_and_patterns.jpg
ERROR - 2020-07-17 15:55:01 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 15:55:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:01 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 15:55:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:01 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 15:55:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:01 --> 404 Page Not Found: Uploads/medical_symptoms.jpg
DEBUG - 2020-07-17 15:55:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:55:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:01 --> 404 Page Not Found: Uploads/medical_terms.jpg
ERROR - 2020-07-17 15:55:01 --> 404 Page Not Found: Uploads/medication.jpg
DEBUG - 2020-07-17 15:55:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:01 --> 404 Page Not Found: Uploads/Mushrooms.jpg
DEBUG - 2020-07-17 15:55:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:01 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:02 --> 404 Page Not Found: Uploads/nuts_and_dried_fruit.jpg
ERROR - 2020-07-17 15:55:02 --> 404 Page Not Found: Uploads/numbers_ordinals.png
DEBUG - 2020-07-17 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:02 --> 404 Page Not Found: Uploads/numbers_cardinals.png
DEBUG - 2020-07-17 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:02 --> 404 Page Not Found: Uploads/nationalities.jpg
DEBUG - 2020-07-17 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:02 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 15:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:02 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:02 --> 404 Page Not Found: Uploads/Ready_meals.JPG
ERROR - 2020-07-17 15:55:02 --> 404 Page Not Found: Uploads/reptiles_and_amphibians.jpg
DEBUG - 2020-07-17 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:02 --> 404 Page Not Found: Uploads/rooms.jpg
DEBUG - 2020-07-17 15:55:02 --> UTF-8 Support Enabled
ERROR - 2020-07-17 15:55:02 --> 404 Page Not Found: Uploads/Sauces_and_condiments.jpg
DEBUG - 2020-07-17 15:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:02 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:02 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:02 --> 404 Page Not Found: Uploads/shapes.png
ERROR - 2020-07-17 15:55:02 --> 404 Page Not Found: Uploads/sea_animals_and_fish.jpg
DEBUG - 2020-07-17 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:03 --> 404 Page Not Found: Uploads/shoes_and_trousers.jpg
DEBUG - 2020-07-17 15:55:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:03 --> 404 Page Not Found: Uploads/Snacks_and_sweets.JPG
DEBUG - 2020-07-17 15:55:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:55:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:03 --> 404 Page Not Found: Uploads/sport_terms.png
ERROR - 2020-07-17 15:55:03 --> 404 Page Not Found: Uploads/Toiletries.jpg
DEBUG - 2020-07-17 15:55:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:03 --> 404 Page Not Found: Uploads/tools_and_diy.jpg
DEBUG - 2020-07-17 15:55:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:03 --> 404 Page Not Found: Uploads/toys_and_games.jpg
DEBUG - 2020-07-17 15:55:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:55:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:03 --> 404 Page Not Found: Uploads/travel.jpg
ERROR - 2020-07-17 15:55:03 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 15:55:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:03 --> 404 Page Not Found: Uploads/Vegetables.JPG
DEBUG - 2020-07-17 15:55:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:03 --> 404 Page Not Found: Uploads/types_of_sports.jpg
DEBUG - 2020-07-17 15:55:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:03 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 15:55:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:03 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 15:55:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 15:55:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:03 --> 404 Page Not Found: Uploads/water.jpg
DEBUG - 2020-07-17 15:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 15:55:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 15:55:03 --> 404 Page Not Found: Uploads/2_verbs.png
ERROR - 2020-07-17 15:55:03 --> 404 Page Not Found: Uploads/1_verbs.png
DEBUG - 2020-07-17 16:12:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:12:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:12:56 --> Total execution time: 0.1488
DEBUG - 2020-07-17 16:13:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:13:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:13:01 --> Total execution time: 0.1444
DEBUG - 2020-07-17 16:13:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:13:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:13:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:13:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:15:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:15:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:16:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:16:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:16:19 --> Total execution time: 0.1564
DEBUG - 2020-07-17 16:16:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:16:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:20 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 16:16:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:16:20 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:16:20 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 16:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:16:20 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:16:20 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 16:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:16:20 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:16:20 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 16:16:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:20 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 16:16:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:21 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 16:16:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:16:21 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:16:21 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 16:16:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:21 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 16:16:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:16:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:21 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-17 16:16:21 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 16:16:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:21 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 16:16:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:21 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 16:16:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:21 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 16:16:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:21 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 16:16:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:16:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:21 --> 404 Page Not Found: Uploads/months_and_days.jpg
ERROR - 2020-07-17 16:16:21 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 16:16:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:16:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:21 --> 404 Page Not Found: Uploads/legal_terminology.jpg
ERROR - 2020-07-17 16:16:21 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 16:16:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:21 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 16:16:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:16:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:22 --> 404 Page Not Found: Uploads/opposites.jpg
ERROR - 2020-07-17 16:16:22 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 16:16:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:22 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 16:16:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:22 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 16:16:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:22 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 16:16:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:22 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 16:16:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:22 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 16:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:16:22 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:16:22 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 16:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:16:22 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:16:22 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 16:16:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:22 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 16:16:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:16:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:22 --> 404 Page Not Found: Uploads/transport.jpg
ERROR - 2020-07-17 16:16:22 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 16:16:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:23 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 16:16:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:23 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 16:16:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:16:23 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 16:16:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:16:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:16:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:16:29 --> Total execution time: 0.1375
DEBUG - 2020-07-17 16:17:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:17:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:20:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:20:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:20:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:20:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:20:34 --> Total execution time: 0.1446
DEBUG - 2020-07-17 16:20:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:20:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:34 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 16:20:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:34 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 16:20:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:35 --> 404 Page Not Found: Uploads/countries.jpg
ERROR - 2020-07-17 16:20:35 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 16:20:35 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:20:35 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 16:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:35 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 16:20:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:35 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 16:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:35 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 16:20:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:35 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 16:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:35 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 16:20:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:35 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 16:20:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:35 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 16:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:35 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 16:20:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:35 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:20:35 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 16:20:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:35 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 16:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:35 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 16:20:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:35 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:20:35 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 16:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:35 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 16:20:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:35 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 16:20:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:36 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 16:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:36 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 16:20:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:36 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 16:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:36 --> 404 Page Not Found: Uploads/scotland.jpg
ERROR - 2020-07-17 16:20:36 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 16:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:36 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 16:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:36 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 16:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:36 --> 404 Page Not Found: Uploads/supermarket.jpg
ERROR - 2020-07-17 16:20:36 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 16:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:36 --> 404 Page Not Found: Uploads/weather.jpg
ERROR - 2020-07-17 16:20:36 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 16:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:36 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 16:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:36 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 16:20:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:37 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 16:20:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:37 --> 404 Page Not Found: Uploads/colours.jpg
ERROR - 2020-07-17 16:20:37 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 16:20:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:37 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-17 16:20:37 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 16:20:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:37 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 16:20:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:37 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:20:37 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 16:20:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:37 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-17 16:20:37 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 16:20:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:37 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 16:20:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:37 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 16:20:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:38 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 16:20:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:38 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 16:20:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:38 --> 404 Page Not Found: Uploads/in_the_office.jpg
ERROR - 2020-07-17 16:20:38 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 16:20:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:38 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 16:20:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:38 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 16:20:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:20:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:20:44 --> Total execution time: 0.1650
DEBUG - 2020-07-17 16:20:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:20:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:20:45 --> Total execution time: 0.2381
DEBUG - 2020-07-17 16:20:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:20:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:45 --> 404 Page Not Found: Uploads/adverbs.jpg
ERROR - 2020-07-17 16:20:45 --> 404 Page Not Found: Uploads/accessories.jpg
DEBUG - 2020-07-17 16:20:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:45 --> 404 Page Not Found: Uploads/animals_in_europe.jpg
DEBUG - 2020-07-17 16:20:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:45 --> 404 Page Not Found: Uploads/animals_in_the_world.jpg
ERROR - 2020-07-17 16:20:45 --> 404 Page Not Found: Uploads/appearance.jpg
DEBUG - 2020-07-17 16:20:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:45 --> 404 Page Not Found: Uploads/animals_with_hooves.jpg
DEBUG - 2020-07-17 16:20:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:45 --> 404 Page Not Found: Uploads/baby_toiletries.jpg
DEBUG - 2020-07-17 16:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:45 --> 404 Page Not Found: Uploads/at_home.jpg
ERROR - 2020-07-17 16:20:45 --> 404 Page Not Found: Uploads/At__the_dentists.JPG
DEBUG - 2020-07-17 16:20:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:45 --> 404 Page Not Found: Uploads/baby_clothes.jpg
DEBUG - 2020-07-17 16:20:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:46 --> 404 Page Not Found: Uploads/bakery_and_pasta.jpg
DEBUG - 2020-07-17 16:20:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:46 --> 404 Page Not Found: Uploads/bathroom.jpg
DEBUG - 2020-07-17 16:20:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:46 --> 404 Page Not Found: Uploads/berries.jpg
ERROR - 2020-07-17 16:20:46 --> 404 Page Not Found: Uploads/birds.jpg
DEBUG - 2020-07-17 16:20:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:46 --> 404 Page Not Found: Uploads/bedroom.jpg
ERROR - 2020-07-17 16:20:46 --> 404 Page Not Found: Uploads/body_parts.jpg
DEBUG - 2020-07-17 16:20:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:46 --> 404 Page Not Found: Uploads/childrens_clothes.jpg
DEBUG - 2020-07-17 16:20:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:46 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:20:46 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 16:20:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:46 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 16:20:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:46 --> 404 Page Not Found: Uploads/cooking_verbs.jpg
ERROR - 2020-07-17 16:20:46 --> 404 Page Not Found: Uploads/containers_and_portions.jpg
DEBUG - 2020-07-17 16:20:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:46 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 16:20:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:46 --> 404 Page Not Found: Uploads/dairy.jpg
DEBUG - 2020-07-17 16:20:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:46 --> 404 Page Not Found: Uploads/drinks.jpg
DEBUG - 2020-07-17 16:20:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:46 --> 404 Page Not Found: Uploads/employment.jpg
ERROR - 2020-07-17 16:20:46 --> 404 Page Not Found: Uploads/opposites_doubles.jpg
ERROR - 2020-07-17 16:20:46 --> 404 Page Not Found: Uploads/electronic_appliances.jpg
DEBUG - 2020-07-17 16:20:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:47 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:20:47 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 16:20:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:47 --> 404 Page Not Found: Uploads/equipment.jpg
DEBUG - 2020-07-17 16:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:47 --> 404 Page Not Found: Uploads/everyday_life.jpg
DEBUG - 2020-07-17 16:20:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:47 --> 404 Page Not Found: Uploads/fish_and_seafood.jpg
DEBUG - 2020-07-17 16:20:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:47 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 16:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:47 --> 404 Page Not Found: Uploads/face_and_head.jpg
DEBUG - 2020-07-17 16:20:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:47 --> 404 Page Not Found: Uploads/fixtures.jpg
DEBUG - 2020-07-17 16:20:47 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:20:47 --> 404 Page Not Found: Uploads/furniture.jpg
DEBUG - 2020-07-17 16:20:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:47 --> 404 Page Not Found: Uploads/grains_and_cereals.jpg
ERROR - 2020-07-17 16:20:47 --> 404 Page Not Found: Uploads/generic.jpg
DEBUG - 2020-07-17 16:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:47 --> 404 Page Not Found: Uploads/fruits.jpg
DEBUG - 2020-07-17 16:20:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:47 --> 404 Page Not Found: Uploads/ground_and_air.jpg
DEBUG - 2020-07-17 16:20:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:47 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 16:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:47 --> 404 Page Not Found: Uploads/herbs_and_spices.jpg
DEBUG - 2020-07-17 16:20:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:47 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:20:47 --> 404 Page Not Found: Uploads/in_the_kitchen.jpg
DEBUG - 2020-07-17 16:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:47 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:20:48 --> 404 Page Not Found: Uploads/illnesses.jpg
DEBUG - 2020-07-17 16:20:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:48 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 16:20:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:48 --> 404 Page Not Found: Uploads/insects.jpg
DEBUG - 2020-07-17 16:20:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:48 --> 404 Page Not Found: Uploads/laundry_and_cleaning.jpg
DEBUG - 2020-07-17 16:20:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:48 --> 404 Page Not Found: Uploads/items_at_home.jpg
DEBUG - 2020-07-17 16:20:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:48 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:20:48 --> 404 Page Not Found: Uploads/materials_and_patterns.jpg
DEBUG - 2020-07-17 16:20:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:48 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 16:20:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:48 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 16:20:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:48 --> 404 Page Not Found: Uploads/meat.jpg
DEBUG - 2020-07-17 16:20:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:48 --> 404 Page Not Found: Uploads/medical_symptoms.jpg
DEBUG - 2020-07-17 16:20:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:48 --> 404 Page Not Found: Uploads/medical_equipment.jpg
DEBUG - 2020-07-17 16:20:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:48 --> 404 Page Not Found: Uploads/medication.jpg
DEBUG - 2020-07-17 16:20:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:48 --> 404 Page Not Found: Uploads/medical_terms.jpg
DEBUG - 2020-07-17 16:20:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:48 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 16:20:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:48 --> 404 Page Not Found: Uploads/nationalities.jpg
DEBUG - 2020-07-17 16:20:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:48 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 16:20:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:48 --> 404 Page Not Found: Uploads/Mushrooms.jpg
DEBUG - 2020-07-17 16:20:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:49 --> 404 Page Not Found: Uploads/numbers_cardinals.png
DEBUG - 2020-07-17 16:20:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:49 --> 404 Page Not Found: Uploads/nuts_and_dried_fruit.jpg
DEBUG - 2020-07-17 16:20:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:49 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
ERROR - 2020-07-17 16:20:49 --> 404 Page Not Found: Uploads/numbers_ordinals.png
DEBUG - 2020-07-17 16:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:49 --> 404 Page Not Found: Uploads/Ready_meals.JPG
DEBUG - 2020-07-17 16:20:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:49 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 16:20:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:49 --> 404 Page Not Found: Uploads/reptiles_and_amphibians.jpg
DEBUG - 2020-07-17 16:20:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:49 --> 404 Page Not Found: Uploads/rooms.jpg
DEBUG - 2020-07-17 16:20:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:49 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 16:20:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:49 --> 404 Page Not Found: Uploads/Sauces_and_condiments.jpg
ERROR - 2020-07-17 16:20:49 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 16:20:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:49 --> 404 Page Not Found: Uploads/sea_animals_and_fish.jpg
DEBUG - 2020-07-17 16:20:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:49 --> 404 Page Not Found: Uploads/shoes_and_trousers.jpg
ERROR - 2020-07-17 16:20:49 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 16:20:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:49 --> 404 Page Not Found: Uploads/Snacks_and_sweets.JPG
DEBUG - 2020-07-17 16:20:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:49 --> 404 Page Not Found: Uploads/sport_terms.png
DEBUG - 2020-07-17 16:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:49 --> 404 Page Not Found: Uploads/Toiletries.jpg
DEBUG - 2020-07-17 16:20:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:49 --> 404 Page Not Found: Uploads/tools_and_diy.jpg
DEBUG - 2020-07-17 16:20:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:50 --> 404 Page Not Found: Uploads/toys_and_games.jpg
ERROR - 2020-07-17 16:20:50 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 16:20:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:50 --> 404 Page Not Found: Uploads/travel.jpg
ERROR - 2020-07-17 16:20:50 --> 404 Page Not Found: Uploads/Vegetables.JPG
DEBUG - 2020-07-17 16:20:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:50 --> 404 Page Not Found: Uploads/types_of_sports.jpg
DEBUG - 2020-07-17 16:20:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:50 --> 404 Page Not Found: Uploads/1_verbs.png
DEBUG - 2020-07-17 16:20:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:50 --> 404 Page Not Found: Uploads/2_verbs.png
ERROR - 2020-07-17 16:20:50 --> 404 Page Not Found: Uploads/water.jpg
DEBUG - 2020-07-17 16:20:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:50 --> 404 Page Not Found: Uploads/weather.jpg
ERROR - 2020-07-17 16:20:50 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 16:20:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:20:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:20:59 --> Total execution time: 0.1143
DEBUG - 2020-07-17 16:20:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:20:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:20:59 --> Total execution time: 0.1310
DEBUG - 2020-07-17 16:20:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:20:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:20:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:59 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 16:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:20:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:20:59 --> 404 Page Not Found: Uploads/animals.jpg
ERROR - 2020-07-17 16:20:59 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:00 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:00 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:00 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:00 --> 404 Page Not Found: Uploads/employment.jpg
ERROR - 2020-07-17 16:21:00 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-17 16:21:00 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:00 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:00 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:00 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:00 --> 404 Page Not Found: Uploads/home.jpg
ERROR - 2020-07-17 16:21:00 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:00 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 16:21:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:00 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:00 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 16:21:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:00 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:00 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:00 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 16:21:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:01 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 16:21:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:01 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 16:21:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:01 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 16:21:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:01 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 16:21:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:01 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 16:21:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:01 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 16:21:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:01 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 16:21:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:01 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 16:21:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:01 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 16:21:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:01 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 16:21:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:01 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 16:21:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:02 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 16:21:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:02 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 16:21:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:21:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:21:04 --> Total execution time: 0.1245
DEBUG - 2020-07-17 16:21:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:21:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:21:04 --> Total execution time: 0.1618
DEBUG - 2020-07-17 16:21:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:05 --> 404 Page Not Found: Uploads/accessories.jpg
DEBUG - 2020-07-17 16:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:05 --> 404 Page Not Found: Uploads/adverbs.jpg
DEBUG - 2020-07-17 16:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:05 --> 404 Page Not Found: Uploads/animals_in_europe.jpg
DEBUG - 2020-07-17 16:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:05 --> 404 Page Not Found: Uploads/appearance.jpg
DEBUG - 2020-07-17 16:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:05 --> 404 Page Not Found: Uploads/animals_in_the_world.jpg
ERROR - 2020-07-17 16:21:05 --> 404 Page Not Found: Uploads/animals_with_hooves.jpg
DEBUG - 2020-07-17 16:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:05 --> 404 Page Not Found: Uploads/At__the_dentists.JPG
DEBUG - 2020-07-17 16:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:05 --> 404 Page Not Found: Uploads/baby_clothes.jpg
ERROR - 2020-07-17 16:21:05 --> 404 Page Not Found: Uploads/at_home.jpg
DEBUG - 2020-07-17 16:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:05 --> 404 Page Not Found: Uploads/baby_toiletries.jpg
DEBUG - 2020-07-17 16:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:05 --> 404 Page Not Found: Uploads/bathroom.jpg
ERROR - 2020-07-17 16:21:05 --> 404 Page Not Found: Uploads/bakery_and_pasta.jpg
DEBUG - 2020-07-17 16:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:05 --> 404 Page Not Found: Uploads/berries.jpg
ERROR - 2020-07-17 16:21:05 --> 404 Page Not Found: Uploads/birds.jpg
DEBUG - 2020-07-17 16:21:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:06 --> 404 Page Not Found: Uploads/bedroom.jpg
DEBUG - 2020-07-17 16:21:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:06 --> 404 Page Not Found: Uploads/body_parts.jpg
DEBUG - 2020-07-17 16:21:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:06 --> 404 Page Not Found: Uploads/childrens_clothes.jpg
DEBUG - 2020-07-17 16:21:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:06 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 16:21:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:06 --> 404 Page Not Found: Uploads/containers_and_portions.jpg
ERROR - 2020-07-17 16:21:06 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 16:21:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:06 --> 404 Page Not Found: Uploads/cooking_verbs.jpg
DEBUG - 2020-07-17 16:21:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:06 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 16:21:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:06 --> 404 Page Not Found: Uploads/dairy.jpg
DEBUG - 2020-07-17 16:21:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:06 --> 404 Page Not Found: Uploads/opposites_doubles.jpg
DEBUG - 2020-07-17 16:21:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:06 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:06 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 16:21:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:06 --> 404 Page Not Found: Uploads/drinks.jpg
ERROR - 2020-07-17 16:21:06 --> 404 Page Not Found: Uploads/electronic_appliances.jpg
DEBUG - 2020-07-17 16:21:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:07 --> 404 Page Not Found: Uploads/equipment.jpg
DEBUG - 2020-07-17 16:21:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:07 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:21:07 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 16:21:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:07 --> 404 Page Not Found: Uploads/everyday_life.jpg
DEBUG - 2020-07-17 16:21:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:07 --> 404 Page Not Found: Uploads/face_and_head.jpg
ERROR - 2020-07-17 16:21:07 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 16:21:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:07 --> 404 Page Not Found: Uploads/fish_and_seafood.jpg
DEBUG - 2020-07-17 16:21:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:07 --> 404 Page Not Found: Uploads/fruits.jpg
ERROR - 2020-07-17 16:21:07 --> 404 Page Not Found: Uploads/furniture.jpg
DEBUG - 2020-07-17 16:21:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:07 --> 404 Page Not Found: Uploads/fixtures.jpg
DEBUG - 2020-07-17 16:21:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:07 --> 404 Page Not Found: Uploads/ground_and_air.jpg
DEBUG - 2020-07-17 16:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:07 --> 404 Page Not Found: Uploads/generic.jpg
ERROR - 2020-07-17 16:21:07 --> 404 Page Not Found: Uploads/grains_and_cereals.jpg
DEBUG - 2020-07-17 16:21:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:07 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:21:07 --> 404 Page Not Found: Uploads/herbs_and_spices.jpg
DEBUG - 2020-07-17 16:21:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:07 --> 404 Page Not Found: Uploads/in_the_kitchen.jpg
DEBUG - 2020-07-17 16:21:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:07 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
ERROR - 2020-07-17 16:21:07 --> 404 Page Not Found: Uploads/illnesses.jpg
ERROR - 2020-07-17 16:21:07 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 16:21:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:07 --> 404 Page Not Found: Uploads/insects.jpg
DEBUG - 2020-07-17 16:21:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:08 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:21:08 --> 404 Page Not Found: Uploads/laundry_and_cleaning.jpg
DEBUG - 2020-07-17 16:21:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:08 --> 404 Page Not Found: Uploads/legal_terminology.jpg
ERROR - 2020-07-17 16:21:08 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 16:21:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:08 --> 404 Page Not Found: Uploads/materials_and_patterns.jpg
DEBUG - 2020-07-17 16:21:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:08 --> 404 Page Not Found: Uploads/items_at_home.jpg
DEBUG - 2020-07-17 16:21:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:08 --> 404 Page Not Found: Uploads/meat.jpg
DEBUG - 2020-07-17 16:21:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:08 --> 404 Page Not Found: Uploads/medical_terms.jpg
DEBUG - 2020-07-17 16:21:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:08 --> 404 Page Not Found: Uploads/medication.jpg
DEBUG - 2020-07-17 16:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:08 --> 404 Page Not Found: Uploads/medical_symptoms.jpg
ERROR - 2020-07-17 16:21:08 --> 404 Page Not Found: Uploads/medical_equipment.jpg
DEBUG - 2020-07-17 16:21:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:08 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 16:21:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:08 --> 404 Page Not Found: Uploads/Mushrooms.jpg
DEBUG - 2020-07-17 16:21:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:08 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 16:21:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:09 --> 404 Page Not Found: Uploads/nationalities.jpg
DEBUG - 2020-07-17 16:21:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:09 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 16:21:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:09 --> 404 Page Not Found: Uploads/numbers_cardinals.png
DEBUG - 2020-07-17 16:21:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:09 --> 404 Page Not Found: Uploads/nuts_and_dried_fruit.jpg
DEBUG - 2020-07-17 16:21:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:09 --> 404 Page Not Found: Uploads/numbers_ordinals.png
DEBUG - 2020-07-17 16:21:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:09 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 16:21:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:09 --> 404 Page Not Found: Uploads/Ready_meals.JPG
DEBUG - 2020-07-17 16:21:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:09 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 16:21:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:09 --> 404 Page Not Found: Uploads/rooms.jpg
DEBUG - 2020-07-17 16:21:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:09 --> 404 Page Not Found: Uploads/reptiles_and_amphibians.jpg
DEBUG - 2020-07-17 16:21:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:09 --> 404 Page Not Found: Uploads/Sauces_and_condiments.jpg
DEBUG - 2020-07-17 16:21:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:09 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 16:21:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:09 --> 404 Page Not Found: Uploads/sea_animals_and_fish.jpg
ERROR - 2020-07-17 16:21:09 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 16:21:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:09 --> 404 Page Not Found: Uploads/shoes_and_trousers.jpg
DEBUG - 2020-07-17 16:21:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:09 --> 404 Page Not Found: Uploads/sport_terms.png
DEBUG - 2020-07-17 16:21:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:09 --> 404 Page Not Found: Uploads/Snacks_and_sweets.JPG
DEBUG - 2020-07-17 16:21:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:10 --> 404 Page Not Found: Uploads/Toiletries.jpg
DEBUG - 2020-07-17 16:21:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:10 --> 404 Page Not Found: Uploads/toys_and_games.jpg
DEBUG - 2020-07-17 16:21:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:10 --> 404 Page Not Found: Uploads/tools_and_diy.jpg
DEBUG - 2020-07-17 16:21:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:10 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 16:21:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:10 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 16:21:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:10 --> 404 Page Not Found: Uploads/types_of_sports.jpg
DEBUG - 2020-07-17 16:21:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:10 --> 404 Page Not Found: Uploads/2_verbs.png
ERROR - 2020-07-17 16:21:10 --> 404 Page Not Found: Uploads/Vegetables.JPG
DEBUG - 2020-07-17 16:21:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:10 --> 404 Page Not Found: Uploads/1_verbs.png
DEBUG - 2020-07-17 16:21:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:10 --> 404 Page Not Found: Uploads/water.jpg
DEBUG - 2020-07-17 16:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:10 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
ERROR - 2020-07-17 16:21:10 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 16:21:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:21:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:21:47 --> Total execution time: 0.1439
DEBUG - 2020-07-17 16:21:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:21:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:21:48 --> Total execution time: 0.3807
DEBUG - 2020-07-17 16:21:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:21:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:48 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:21:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:49 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:21:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:49 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:21:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:49 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:21:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:49 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:21:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:50 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:21:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:50 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:21:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:50 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:21:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:50 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:51 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:21:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:51 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:21:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:51 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:21:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:51 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:21:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:52 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 16:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:52 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:21:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:52 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:21:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:52 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:21:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:52 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:21:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:52 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:21:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:21:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:21:55 --> Total execution time: 0.1312
DEBUG - 2020-07-17 16:21:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:21:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:21:55 --> Total execution time: 0.1615
DEBUG - 2020-07-17 16:21:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:55 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 16:21:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:55 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 16:21:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:56 --> 404 Page Not Found: Uploads/countries.jpg
ERROR - 2020-07-17 16:21:56 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 16:21:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:56 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 16:21:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:56 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 16:21:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:56 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:21:56 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 16:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:56 --> 404 Page Not Found: Uploads/employment.jpg
ERROR - 2020-07-17 16:21:56 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 16:21:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:56 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 16:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:56 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:21:56 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 16:21:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:56 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 16:21:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:56 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 16:21:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:56 --> 404 Page Not Found: Uploads/in_the_office.jpg
ERROR - 2020-07-17 16:21:56 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 16:21:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:56 --> 404 Page Not Found: Uploads/months_and_days.jpg
ERROR - 2020-07-17 16:21:56 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 16:21:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:56 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 16:21:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:57 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 16:21:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:57 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 16:21:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:57 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:21:57 --> 404 Page Not Found: Uploads/scotland.jpg
ERROR - 2020-07-17 16:21:57 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 16:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:57 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 16:21:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:57 --> 404 Page Not Found: Uploads/shapes.png
ERROR - 2020-07-17 16:21:57 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 16:21:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:57 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 16:21:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:57 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 16:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:57 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 16:21:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:57 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 16:21:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:57 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
ERROR - 2020-07-17 16:21:57 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 16:21:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:21:57 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 16:22:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:22:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:22:14 --> Total execution time: 0.1395
DEBUG - 2020-07-17 16:22:14 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:22:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:15 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 16:22:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:15 --> 404 Page Not Found: Uploads/colours.jpg
ERROR - 2020-07-17 16:22:15 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 16:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:22:15 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:22:15 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 16:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:15 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 16:22:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:15 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 16:22:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:22:15 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:22:15 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 16:22:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:15 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 16:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:22:15 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:22:15 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 16:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:15 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 16:22:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:15 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 16:22:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:15 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 16:22:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:15 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 16:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:15 --> 404 Page Not Found: Uploads/legal_terminology.jpg
ERROR - 2020-07-17 16:22:15 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 16:22:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:15 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 16:22:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:15 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 16:22:15 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:15 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 16:22:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:16 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 16:22:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:22:16 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:22:16 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 16:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:16 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
ERROR - 2020-07-17 16:22:16 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 16:22:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:16 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 16:22:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:16 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 16:22:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:16 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 16:22:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:16 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 16:22:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:16 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 16:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:16 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 16:22:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:16 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 16:22:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:16 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
ERROR - 2020-07-17 16:22:16 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 16:22:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:17 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 16:22:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:22:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:22:17 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 16:24:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:24:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:24:16 --> Total execution time: 0.1585
DEBUG - 2020-07-17 16:24:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:24:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:24:16 --> Total execution time: 0.1229
DEBUG - 2020-07-17 16:24:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:17 --> 404 Page Not Found: Uploads/appearance.jpg
DEBUG - 2020-07-17 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:17 --> 404 Page Not Found: Uploads/accessories.jpg
DEBUG - 2020-07-17 16:24:17 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:24:17 --> 404 Page Not Found: Uploads/adverbs.jpg
DEBUG - 2020-07-17 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:17 --> 404 Page Not Found: Uploads/animals_in_the_world.jpg
ERROR - 2020-07-17 16:24:17 --> 404 Page Not Found: Uploads/animals_in_europe.jpg
ERROR - 2020-07-17 16:24:17 --> 404 Page Not Found: Uploads/animals_with_hooves.jpg
DEBUG - 2020-07-17 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:17 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:24:17 --> 404 Page Not Found: Uploads/At__the_dentists.JPG
DEBUG - 2020-07-17 16:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:17 --> 404 Page Not Found: Uploads/baby_toiletries.jpg
DEBUG - 2020-07-17 16:24:17 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:24:17 --> 404 Page Not Found: Uploads/baby_clothes.jpg
DEBUG - 2020-07-17 16:24:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:17 --> 404 Page Not Found: Uploads/bakery_and_pasta.jpg
DEBUG - 2020-07-17 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:17 --> 404 Page Not Found: Uploads/at_home.jpg
DEBUG - 2020-07-17 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:17 --> 404 Page Not Found: Uploads/bathroom.jpg
DEBUG - 2020-07-17 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:17 --> 404 Page Not Found: Uploads/bedroom.jpg
DEBUG - 2020-07-17 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:17 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:24:17 --> 404 Page Not Found: Uploads/childrens_clothes.jpg
DEBUG - 2020-07-17 16:24:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:17 --> 404 Page Not Found: Uploads/berries.jpg
DEBUG - 2020-07-17 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:17 --> 404 Page Not Found: Uploads/body_parts.jpg
DEBUG - 2020-07-17 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:17 --> 404 Page Not Found: Uploads/birds.jpg
DEBUG - 2020-07-17 16:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:18 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 16:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:18 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 16:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:18 --> 404 Page Not Found: Uploads/containers_and_portions.jpg
DEBUG - 2020-07-17 16:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:18 --> 404 Page Not Found: Uploads/countries.jpg
ERROR - 2020-07-17 16:24:18 --> 404 Page Not Found: Uploads/cooking_verbs.jpg
DEBUG - 2020-07-17 16:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:18 --> 404 Page Not Found: Uploads/opposites_doubles.jpg
DEBUG - 2020-07-17 16:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:18 --> 404 Page Not Found: Uploads/dairy.jpg
DEBUG - 2020-07-17 16:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:18 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 16:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:18 --> 404 Page Not Found: Uploads/drinks.jpg
DEBUG - 2020-07-17 16:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:18 --> 404 Page Not Found: Uploads/electronic_appliances.jpg
DEBUG - 2020-07-17 16:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:18 --> 404 Page Not Found: Uploads/equipment.jpg
ERROR - 2020-07-17 16:24:18 --> 404 Page Not Found: Uploads/everyday_life.jpg
DEBUG - 2020-07-17 16:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:18 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 16:24:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:19 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 16:24:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:19 --> 404 Page Not Found: Uploads/face_and_head.jpg
DEBUG - 2020-07-17 16:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:19 --> 404 Page Not Found: Uploads/fish_and_seafood.jpg
DEBUG - 2020-07-17 16:24:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:19 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:24:19 --> 404 Page Not Found: Uploads/furniture.jpg
DEBUG - 2020-07-17 16:24:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:19 --> 404 Page Not Found: Uploads/fruits.jpg
DEBUG - 2020-07-17 16:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:19 --> 404 Page Not Found: Uploads/fixtures.jpg
DEBUG - 2020-07-17 16:24:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:19 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:24:19 --> 404 Page Not Found: Uploads/illnesses.jpg
ERROR - 2020-07-17 16:24:19 --> 404 Page Not Found: Uploads/herbs_and_spices.jpg
DEBUG - 2020-07-17 16:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:19 --> 404 Page Not Found: Uploads/generic.jpg
DEBUG - 2020-07-17 16:24:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:19 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 16:24:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:19 --> 404 Page Not Found: Uploads/grains_and_cereals.jpg
ERROR - 2020-07-17 16:24:19 --> 404 Page Not Found: Uploads/ground_and_air.jpg
DEBUG - 2020-07-17 16:24:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:19 --> 404 Page Not Found: Uploads/in_the_office.jpg
ERROR - 2020-07-17 16:24:19 --> 404 Page Not Found: Uploads/in_the_kitchen.jpg
DEBUG - 2020-07-17 16:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:19 --> 404 Page Not Found: Uploads/insects.jpg
DEBUG - 2020-07-17 16:24:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:19 --> 404 Page Not Found: Uploads/items_at_home.jpg
ERROR - 2020-07-17 16:24:19 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 16:24:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:19 --> 404 Page Not Found: Uploads/laundry_and_cleaning.jpg
DEBUG - 2020-07-17 16:24:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:20 --> 404 Page Not Found: Uploads/meat.jpg
ERROR - 2020-07-17 16:24:20 --> 404 Page Not Found: Uploads/materials_and_patterns.jpg
DEBUG - 2020-07-17 16:24:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:20 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 16:24:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:20 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:24:20 --> 404 Page Not Found: Uploads/medical_symptoms.jpg
DEBUG - 2020-07-17 16:24:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:20 --> 404 Page Not Found: Uploads/medical_terms.jpg
ERROR - 2020-07-17 16:24:20 --> 404 Page Not Found: Uploads/medical_equipment.jpg
DEBUG - 2020-07-17 16:24:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:20 --> 404 Page Not Found: Uploads/medication.jpg
ERROR - 2020-07-17 16:24:20 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 16:24:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:20 --> 404 Page Not Found: Uploads/Mushrooms.jpg
DEBUG - 2020-07-17 16:24:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:20 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 16:24:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:20 --> 404 Page Not Found: Uploads/numbers_cardinals.png
ERROR - 2020-07-17 16:24:20 --> 404 Page Not Found: Uploads/nationalities.jpg
DEBUG - 2020-07-17 16:24:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:20 --> 404 Page Not Found: Uploads/nuts_and_dried_fruit.jpg
ERROR - 2020-07-17 16:24:20 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
ERROR - 2020-07-17 16:24:20 --> 404 Page Not Found: Uploads/numbers_ordinals.png
DEBUG - 2020-07-17 16:24:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:20 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 16:24:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:20 --> 404 Page Not Found: Uploads/Ready_meals.JPG
DEBUG - 2020-07-17 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:21 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:21 --> 404 Page Not Found: Uploads/reptiles_and_amphibians.jpg
DEBUG - 2020-07-17 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:21 --> 404 Page Not Found: Uploads/Sauces_and_condiments.jpg
ERROR - 2020-07-17 16:24:21 --> 404 Page Not Found: Uploads/rooms.jpg
DEBUG - 2020-07-17 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:21 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:21 --> 404 Page Not Found: Uploads/sea_animals_and_fish.jpg
DEBUG - 2020-07-17 16:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:21 --> 404 Page Not Found: Uploads/shapes.png
ERROR - 2020-07-17 16:24:21 --> 404 Page Not Found: Uploads/shoes_and_trousers.jpg
DEBUG - 2020-07-17 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:21 --> 404 Page Not Found: Uploads/sport_terms.png
ERROR - 2020-07-17 16:24:21 --> 404 Page Not Found: Uploads/Snacks_and_sweets.JPG
DEBUG - 2020-07-17 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:21 --> 404 Page Not Found: Uploads/Toiletries.jpg
DEBUG - 2020-07-17 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:21 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:21 --> 404 Page Not Found: Uploads/toys_and_games.jpg
DEBUG - 2020-07-17 16:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:21 --> 404 Page Not Found: Uploads/tools_and_diy.jpg
DEBUG - 2020-07-17 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:21 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 16:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:21 --> 404 Page Not Found: Uploads/types_of_sports.jpg
DEBUG - 2020-07-17 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:21 --> 404 Page Not Found: Uploads/1_verbs.png
DEBUG - 2020-07-17 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:21 --> 404 Page Not Found: Uploads/2_verbs.png
DEBUG - 2020-07-17 16:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:21 --> 404 Page Not Found: Uploads/Vegetables.JPG
DEBUG - 2020-07-17 16:24:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:22 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:22 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:24:22 --> 404 Page Not Found: Uploads/water.jpg
DEBUG - 2020-07-17 16:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:22 --> 404 Page Not Found: Uploads/weather.jpg
ERROR - 2020-07-17 16:24:22 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 16:24:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:24:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:24:26 --> Total execution time: 0.1516
DEBUG - 2020-07-17 16:24:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:24:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:26 --> 404 Page Not Found: Uploads/accessories.jpg
DEBUG - 2020-07-17 16:24:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:26 --> 404 Page Not Found: Uploads/animals_in_the_world.jpg
ERROR - 2020-07-17 16:24:26 --> 404 Page Not Found: Uploads/appearance.jpg
DEBUG - 2020-07-17 16:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:26 --> 404 Page Not Found: Uploads/animals_with_hooves.jpg
ERROR - 2020-07-17 16:24:26 --> 404 Page Not Found: Uploads/animals_in_europe.jpg
DEBUG - 2020-07-17 16:24:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:26 --> 404 Page Not Found: Uploads/adverbs.jpg
DEBUG - 2020-07-17 16:24:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:27 --> 404 Page Not Found: Uploads/bakery_and_pasta.jpg
ERROR - 2020-07-17 16:24:27 --> 404 Page Not Found: Uploads/At__the_dentists.JPG
DEBUG - 2020-07-17 16:24:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:27 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:24:27 --> 404 Page Not Found: Uploads/at_home.jpg
DEBUG - 2020-07-17 16:24:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:27 --> 404 Page Not Found: Uploads/baby_clothes.jpg
DEBUG - 2020-07-17 16:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:27 --> 404 Page Not Found: Uploads/baby_toiletries.jpg
DEBUG - 2020-07-17 16:24:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:27 --> 404 Page Not Found: Uploads/bathroom.jpg
DEBUG - 2020-07-17 16:24:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:27 --> 404 Page Not Found: Uploads/bedroom.jpg
DEBUG - 2020-07-17 16:24:27 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:24:27 --> 404 Page Not Found: Uploads/birds.jpg
DEBUG - 2020-07-17 16:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:27 --> 404 Page Not Found: Uploads/berries.jpg
DEBUG - 2020-07-17 16:24:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:27 --> 404 Page Not Found: Uploads/body_parts.jpg
DEBUG - 2020-07-17 16:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:27 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 16:24:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:27 --> 404 Page Not Found: Uploads/childrens_clothes.jpg
DEBUG - 2020-07-17 16:24:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:27 --> 404 Page Not Found: Uploads/cooking_verbs.jpg
DEBUG - 2020-07-17 16:24:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:27 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 16:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:27 --> 404 Page Not Found: Uploads/containers_and_portions.jpg
DEBUG - 2020-07-17 16:24:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:27 --> 404 Page Not Found: Uploads/dairy.jpg
ERROR - 2020-07-17 16:24:27 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 16:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:28 --> 404 Page Not Found: Uploads/drinks.jpg
DEBUG - 2020-07-17 16:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:28 --> 404 Page Not Found: Uploads/opposites_doubles.jpg
DEBUG - 2020-07-17 16:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:28 --> 404 Page Not Found: Uploads/employment.jpg
ERROR - 2020-07-17 16:24:28 --> 404 Page Not Found: Uploads/electronic_appliances.jpg
DEBUG - 2020-07-17 16:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:28 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-17 16:24:28 --> 404 Page Not Found: Uploads/equipment.jpg
DEBUG - 2020-07-17 16:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:28 --> 404 Page Not Found: Uploads/face_and_head.jpg
ERROR - 2020-07-17 16:24:28 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 16:24:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:28 --> 404 Page Not Found: Uploads/fish_and_seafood.jpg
DEBUG - 2020-07-17 16:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:28 --> 404 Page Not Found: Uploads/fruits.jpg
DEBUG - 2020-07-17 16:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:28 --> 404 Page Not Found: Uploads/everyday_life.jpg
DEBUG - 2020-07-17 16:24:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:28 --> 404 Page Not Found: Uploads/fixtures.jpg
DEBUG - 2020-07-17 16:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:28 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
ERROR - 2020-07-17 16:24:28 --> 404 Page Not Found: Uploads/furniture.jpg
DEBUG - 2020-07-17 16:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:28 --> 404 Page Not Found: Uploads/generic.jpg
DEBUG - 2020-07-17 16:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:29 --> 404 Page Not Found: Uploads/ground_and_air.jpg
DEBUG - 2020-07-17 16:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:29 --> 404 Page Not Found: Uploads/herbs_and_spices.jpg
DEBUG - 2020-07-17 16:24:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:29 --> 404 Page Not Found: Uploads/grains_and_cereals.jpg
DEBUG - 2020-07-17 16:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:29 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 16:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:29 --> 404 Page Not Found: Uploads/in_the_kitchen.jpg
ERROR - 2020-07-17 16:24:29 --> 404 Page Not Found: Uploads/illnesses.jpg
DEBUG - 2020-07-17 16:24:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:29 --> 404 Page Not Found: Uploads/insects.jpg
DEBUG - 2020-07-17 16:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:29 --> 404 Page Not Found: Uploads/laundry_and_cleaning.jpg
ERROR - 2020-07-17 16:24:29 --> 404 Page Not Found: Uploads/items_at_home.jpg
DEBUG - 2020-07-17 16:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:29 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 16:24:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:29 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 16:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:29 --> 404 Page Not Found: Uploads/materials_and_patterns.jpg
DEBUG - 2020-07-17 16:24:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:29 --> 404 Page Not Found: Uploads/medical_equipment.jpg
DEBUG - 2020-07-17 16:24:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:29 --> 404 Page Not Found: Uploads/meat.jpg
DEBUG - 2020-07-17 16:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:29 --> 404 Page Not Found: Uploads/medical_symptoms.jpg
DEBUG - 2020-07-17 16:24:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:30 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 16:24:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:30 --> 404 Page Not Found: Uploads/medical_terms.jpg
ERROR - 2020-07-17 16:24:30 --> 404 Page Not Found: Uploads/medication.jpg
DEBUG - 2020-07-17 16:24:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:30 --> 404 Page Not Found: Uploads/Mushrooms.jpg
DEBUG - 2020-07-17 16:24:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:30 --> 404 Page Not Found: Uploads/nationalities.jpg
ERROR - 2020-07-17 16:24:30 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 16:24:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:30 --> 404 Page Not Found: Uploads/numbers_cardinals.png
DEBUG - 2020-07-17 16:24:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:30 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 16:24:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:30 --> 404 Page Not Found: Uploads/numbers_ordinals.png
ERROR - 2020-07-17 16:24:30 --> 404 Page Not Found: Uploads/nuts_and_dried_fruit.jpg
DEBUG - 2020-07-17 16:24:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:30 --> 404 Page Not Found: Uploads/professions.jpg
ERROR - 2020-07-17 16:24:30 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 16:24:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:30 --> 404 Page Not Found: Uploads/Ready_meals.JPG
DEBUG - 2020-07-17 16:24:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:30 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:24:30 --> 404 Page Not Found: Uploads/Sauces_and_condiments.jpg
DEBUG - 2020-07-17 16:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:30 --> 404 Page Not Found: Uploads/rooms.jpg
ERROR - 2020-07-17 16:24:30 --> 404 Page Not Found: Uploads/reptiles_and_amphibians.jpg
DEBUG - 2020-07-17 16:24:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:30 --> 404 Page Not Found: Uploads/sea_animals_and_fish.jpg
DEBUG - 2020-07-17 16:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:31 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 16:24:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:31 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 16:24:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:31 --> 404 Page Not Found: Uploads/shoes_and_trousers.jpg
DEBUG - 2020-07-17 16:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:31 --> 404 Page Not Found: Uploads/Snacks_and_sweets.JPG
DEBUG - 2020-07-17 16:24:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:31 --> 404 Page Not Found: Uploads/sport_terms.png
ERROR - 2020-07-17 16:24:31 --> 404 Page Not Found: Uploads/Toiletries.jpg
DEBUG - 2020-07-17 16:24:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:31 --> 404 Page Not Found: Uploads/tools_and_diy.jpg
DEBUG - 2020-07-17 16:24:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:31 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:24:31 --> 404 Page Not Found: Uploads/toys_and_games.jpg
DEBUG - 2020-07-17 16:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:31 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 16:24:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:31 --> 404 Page Not Found: Uploads/types_of_sports.jpg
DEBUG - 2020-07-17 16:24:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:31 --> 404 Page Not Found: Uploads/Vegetables.JPG
DEBUG - 2020-07-17 16:24:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:31 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 16:24:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:31 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:24:31 --> 404 Page Not Found: Uploads/1_verbs.png
DEBUG - 2020-07-17 16:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:31 --> 404 Page Not Found: Uploads/2_verbs.png
DEBUG - 2020-07-17 16:24:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:31 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
ERROR - 2020-07-17 16:24:31 --> 404 Page Not Found: Uploads/water.jpg
DEBUG - 2020-07-17 16:24:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:31 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 16:24:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:24:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:24:53 --> Total execution time: 0.1361
DEBUG - 2020-07-17 16:24:53 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:24:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:54 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:24:54 --> 404 Page Not Found: Uploads/adverbs.jpg
DEBUG - 2020-07-17 16:24:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:54 --> 404 Page Not Found: Uploads/accessories.jpg
DEBUG - 2020-07-17 16:24:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:54 --> 404 Page Not Found: Uploads/appearance.jpg
ERROR - 2020-07-17 16:24:54 --> 404 Page Not Found: Uploads/animals_in_the_world.jpg
DEBUG - 2020-07-17 16:24:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:54 --> 404 Page Not Found: Uploads/animals_in_europe.jpg
DEBUG - 2020-07-17 16:24:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:54 --> 404 Page Not Found: Uploads/animals_with_hooves.jpg
DEBUG - 2020-07-17 16:24:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:54 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:24:54 --> 404 Page Not Found: Uploads/At__the_dentists.JPG
DEBUG - 2020-07-17 16:24:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:54 --> 404 Page Not Found: Uploads/baby_toiletries.jpg
DEBUG - 2020-07-17 16:24:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:54 --> 404 Page Not Found: Uploads/at_home.jpg
DEBUG - 2020-07-17 16:24:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:54 --> 404 Page Not Found: Uploads/bakery_and_pasta.jpg
DEBUG - 2020-07-17 16:24:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:54 --> 404 Page Not Found: Uploads/baby_clothes.jpg
DEBUG - 2020-07-17 16:24:54 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:54 --> 404 Page Not Found: Uploads/bathroom.jpg
DEBUG - 2020-07-17 16:24:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:55 --> 404 Page Not Found: Uploads/body_parts.jpg
DEBUG - 2020-07-17 16:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:55 --> 404 Page Not Found: Uploads/birds.jpg
DEBUG - 2020-07-17 16:24:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:55 --> 404 Page Not Found: Uploads/berries.jpg
DEBUG - 2020-07-17 16:24:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:55 --> 404 Page Not Found: Uploads/bedroom.jpg
DEBUG - 2020-07-17 16:24:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:55 --> 404 Page Not Found: Uploads/childrens_clothes.jpg
DEBUG - 2020-07-17 16:24:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:55 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 16:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:55 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:24:55 --> 404 Page Not Found: Uploads/containers_and_portions.jpg
DEBUG - 2020-07-17 16:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:55 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 16:24:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:55 --> 404 Page Not Found: Uploads/cooking_verbs.jpg
DEBUG - 2020-07-17 16:24:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:55 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 16:24:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:55 --> 404 Page Not Found: Uploads/opposites_doubles.jpg
ERROR - 2020-07-17 16:24:55 --> 404 Page Not Found: Uploads/dairy.jpg
DEBUG - 2020-07-17 16:24:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:55 --> 404 Page Not Found: Uploads/electronic_appliances.jpg
DEBUG - 2020-07-17 16:24:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:55 --> 404 Page Not Found: Uploads/drinks.jpg
DEBUG - 2020-07-17 16:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:55 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 16:24:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:56 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-17 16:24:56 --> 404 Page Not Found: Uploads/face_and_head.jpg
DEBUG - 2020-07-17 16:24:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:56 --> 404 Page Not Found: Uploads/equipment.jpg
DEBUG - 2020-07-17 16:24:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:56 --> 404 Page Not Found: Uploads/everyday_life.jpg
DEBUG - 2020-07-17 16:24:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:56 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 16:24:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:56 --> 404 Page Not Found: Uploads/fish_and_seafood.jpg
DEBUG - 2020-07-17 16:24:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:56 --> 404 Page Not Found: Uploads/fruits.jpg
DEBUG - 2020-07-17 16:24:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:56 --> 404 Page Not Found: Uploads/fixtures.jpg
DEBUG - 2020-07-17 16:24:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:56 --> 404 Page Not Found: Uploads/generic.jpg
DEBUG - 2020-07-17 16:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:56 --> 404 Page Not Found: Uploads/grains_and_cereals.jpg
ERROR - 2020-07-17 16:24:56 --> 404 Page Not Found: Uploads/furniture.jpg
DEBUG - 2020-07-17 16:24:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:56 --> 404 Page Not Found: Uploads/ground_and_air.jpg
DEBUG - 2020-07-17 16:24:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:56 --> 404 Page Not Found: Uploads/herbs_and_spices.jpg
DEBUG - 2020-07-17 16:24:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:56 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 16:24:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:56 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:24:56 --> 404 Page Not Found: Uploads/illnesses.jpg
DEBUG - 2020-07-17 16:24:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:56 --> 404 Page Not Found: Uploads/in_the_office.jpg
ERROR - 2020-07-17 16:24:56 --> 404 Page Not Found: Uploads/in_the_kitchen.jpg
DEBUG - 2020-07-17 16:24:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:57 --> 404 Page Not Found: Uploads/insects.jpg
DEBUG - 2020-07-17 16:24:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:57 --> 404 Page Not Found: Uploads/items_at_home.jpg
DEBUG - 2020-07-17 16:24:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:57 --> 404 Page Not Found: Uploads/laundry_and_cleaning.jpg
DEBUG - 2020-07-17 16:24:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:57 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 16:24:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:57 --> 404 Page Not Found: Uploads/materials_and_patterns.jpg
ERROR - 2020-07-17 16:24:57 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 16:24:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:57 --> 404 Page Not Found: Uploads/meat.jpg
DEBUG - 2020-07-17 16:24:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:57 --> 404 Page Not Found: Uploads/medical_equipment.jpg
DEBUG - 2020-07-17 16:24:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:57 --> 404 Page Not Found: Uploads/medical_symptoms.jpg
DEBUG - 2020-07-17 16:24:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:57 --> 404 Page Not Found: Uploads/months_and_days.jpg
ERROR - 2020-07-17 16:24:57 --> 404 Page Not Found: Uploads/medication.jpg
DEBUG - 2020-07-17 16:24:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:57 --> 404 Page Not Found: Uploads/medical_terms.jpg
DEBUG - 2020-07-17 16:24:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:57 --> 404 Page Not Found: Uploads/nationalities.jpg
DEBUG - 2020-07-17 16:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:57 --> 404 Page Not Found: Uploads/music.jpg
ERROR - 2020-07-17 16:24:57 --> 404 Page Not Found: Uploads/Mushrooms.jpg
DEBUG - 2020-07-17 16:24:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:57 --> 404 Page Not Found: Uploads/numbers_cardinals.png
ERROR - 2020-07-17 16:24:57 --> 404 Page Not Found: Uploads/nuts_and_dried_fruit.jpg
DEBUG - 2020-07-17 16:24:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:58 --> 404 Page Not Found: Uploads/numbers_ordinals.png
DEBUG - 2020-07-17 16:24:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:58 --> 404 Page Not Found: Uploads/professions.jpg
ERROR - 2020-07-17 16:24:58 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 16:24:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:58 --> 404 Page Not Found: Uploads/Ready_meals.JPG
DEBUG - 2020-07-17 16:24:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:58 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 16:24:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:58 --> 404 Page Not Found: Uploads/reptiles_and_amphibians.jpg
DEBUG - 2020-07-17 16:24:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:58 --> 404 Page Not Found: Uploads/rooms.jpg
DEBUG - 2020-07-17 16:24:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:58 --> 404 Page Not Found: Uploads/Sauces_and_condiments.jpg
DEBUG - 2020-07-17 16:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:58 --> 404 Page Not Found: Uploads/sea_animals_and_fish.jpg
DEBUG - 2020-07-17 16:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:58 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 16:24:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:58 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 16:24:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:58 --> 404 Page Not Found: Uploads/tools_and_diy.jpg
DEBUG - 2020-07-17 16:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:58 --> 404 Page Not Found: Uploads/shoes_and_trousers.jpg
DEBUG - 2020-07-17 16:24:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:58 --> 404 Page Not Found: Uploads/Toiletries.jpg
DEBUG - 2020-07-17 16:24:58 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:24:58 --> 404 Page Not Found: Uploads/sport_terms.png
DEBUG - 2020-07-17 16:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:58 --> 404 Page Not Found: Uploads/Snacks_and_sweets.JPG
DEBUG - 2020-07-17 16:24:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:58 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:24:58 --> 404 Page Not Found: Uploads/toys_and_games.jpg
DEBUG - 2020-07-17 16:24:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:58 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 16:24:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:58 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:24:58 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 16:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:58 --> 404 Page Not Found: Uploads/types_of_sports.jpg
ERROR - 2020-07-17 16:24:58 --> 404 Page Not Found: Uploads/Vegetables.JPG
DEBUG - 2020-07-17 16:24:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:59 --> 404 Page Not Found: Uploads/1_verbs.png
DEBUG - 2020-07-17 16:24:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:24:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:59 --> 404 Page Not Found: Uploads/water.jpg
ERROR - 2020-07-17 16:24:59 --> 404 Page Not Found: Uploads/weather.jpg
ERROR - 2020-07-17 16:24:59 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 16:24:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:24:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:24:59 --> 404 Page Not Found: Uploads/2_verbs.png
DEBUG - 2020-07-17 16:25:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:25:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:25:59 --> Total execution time: 0.1241
DEBUG - 2020-07-17 16:25:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:25:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:26:00 --> Total execution time: 0.3498
DEBUG - 2020-07-17 16:26:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:26:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:00 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:26:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:00 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:01 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:26:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:01 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:26:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:01 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:26:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:01 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:02 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:26:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:02 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:26:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:02 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:26:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:02 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:26:02 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:26:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:03 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:26:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:03 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:26:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:03 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:26:03 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:26:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:03 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:26:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:04 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:26:04 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:26:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:05 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:26:05 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:26:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:26:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:05 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 16:26:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:26:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:26:16 --> Total execution time: 0.1321
DEBUG - 2020-07-17 16:26:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:26:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:26:17 --> Total execution time: 0.1152
DEBUG - 2020-07-17 16:26:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:26:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:17 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:26:17 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 16:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:17 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:26:17 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 16:26:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:17 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-17 16:26:17 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 16:26:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:17 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 16:26:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:17 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 16:26:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:17 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:26:17 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-17 16:26:18 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 16:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:18 --> 404 Page Not Found: Uploads/employment.jpg
ERROR - 2020-07-17 16:26:18 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 16:26:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:18 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 16:26:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:18 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 16:26:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:18 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 16:26:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:18 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 16:26:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:18 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 16:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:18 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 16:26:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:18 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 16:26:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:18 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 16:26:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:18 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 16:26:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:18 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 16:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:18 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 16:26:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:18 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 16:26:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:18 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:26:18 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 16:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:18 --> 404 Page Not Found: Uploads/professions.jpg
ERROR - 2020-07-17 16:26:18 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 16:26:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:19 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 16:26:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:19 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 16:26:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:19 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 16:26:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:19 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 16:26:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:19 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 16:26:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:19 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 16:26:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:19 --> 404 Page Not Found: Uploads/animals.jpg
ERROR - 2020-07-17 16:26:19 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 16:26:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:20 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 16:26:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:26:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:26:36 --> Total execution time: 0.1054
DEBUG - 2020-07-17 16:26:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:26:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:26:36 --> Total execution time: 0.1356
DEBUG - 2020-07-17 16:26:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:26:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:36 --> 404 Page Not Found: Uploads/accessories.jpg
DEBUG - 2020-07-17 16:26:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:37 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:26:37 --> 404 Page Not Found: Uploads/animals_in_europe.jpg
DEBUG - 2020-07-17 16:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:37 --> 404 Page Not Found: Uploads/adverbs.jpg
DEBUG - 2020-07-17 16:26:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:37 --> 404 Page Not Found: Uploads/animals_in_the_world.jpg
DEBUG - 2020-07-17 16:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:37 --> 404 Page Not Found: Uploads/animals_with_hooves.jpg
DEBUG - 2020-07-17 16:26:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:37 --> 404 Page Not Found: Uploads/appearance.jpg
DEBUG - 2020-07-17 16:26:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:37 --> 404 Page Not Found: Uploads/at_home.jpg
DEBUG - 2020-07-17 16:26:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:37 --> 404 Page Not Found: Uploads/baby_clothes.jpg
DEBUG - 2020-07-17 16:26:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:37 --> 404 Page Not Found: Uploads/At__the_dentists.JPG
DEBUG - 2020-07-17 16:26:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:37 --> 404 Page Not Found: Uploads/bakery_and_pasta.jpg
DEBUG - 2020-07-17 16:26:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:37 --> 404 Page Not Found: Uploads/baby_toiletries.jpg
DEBUG - 2020-07-17 16:26:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:38 --> 404 Page Not Found: Uploads/bathroom.jpg
DEBUG - 2020-07-17 16:26:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:38 --> 404 Page Not Found: Uploads/bedroom.jpg
DEBUG - 2020-07-17 16:26:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:38 --> 404 Page Not Found: Uploads/berries.jpg
DEBUG - 2020-07-17 16:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:38 --> 404 Page Not Found: Uploads/birds.jpg
DEBUG - 2020-07-17 16:26:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:38 --> 404 Page Not Found: Uploads/body_parts.jpg
DEBUG - 2020-07-17 16:26:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:38 --> 404 Page Not Found: Uploads/childrens_clothes.jpg
DEBUG - 2020-07-17 16:26:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:38 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 16:26:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:38 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 16:26:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:38 --> 404 Page Not Found: Uploads/containers_and_portions.jpg
DEBUG - 2020-07-17 16:26:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:38 --> 404 Page Not Found: Uploads/cooking_verbs.jpg
ERROR - 2020-07-17 16:26:38 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 16:26:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:38 --> 404 Page Not Found: Uploads/dairy.jpg
DEBUG - 2020-07-17 16:26:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:38 --> 404 Page Not Found: Uploads/opposites_doubles.jpg
DEBUG - 2020-07-17 16:26:38 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:39 --> 404 Page Not Found: Uploads/drinks.jpg
DEBUG - 2020-07-17 16:26:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:39 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 16:26:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:39 --> 404 Page Not Found: Uploads/electronic_appliances.jpg
DEBUG - 2020-07-17 16:26:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:39 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 16:26:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:39 --> 404 Page Not Found: Uploads/equipment.jpg
DEBUG - 2020-07-17 16:26:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:39 --> 404 Page Not Found: Uploads/everyday_life.jpg
DEBUG - 2020-07-17 16:26:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:39 --> 404 Page Not Found: Uploads/face_and_head.jpg
DEBUG - 2020-07-17 16:26:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:39 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:26:39 --> 404 Page Not Found: Uploads/fixtures.jpg
ERROR - 2020-07-17 16:26:39 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 16:26:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:39 --> 404 Page Not Found: Uploads/fish_and_seafood.jpg
DEBUG - 2020-07-17 16:26:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:39 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:26:39 --> 404 Page Not Found: Uploads/fruits.jpg
DEBUG - 2020-07-17 16:26:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:39 --> 404 Page Not Found: Uploads/furniture.jpg
DEBUG - 2020-07-17 16:26:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:39 --> 404 Page Not Found: Uploads/grains_and_cereals.jpg
ERROR - 2020-07-17 16:26:39 --> 404 Page Not Found: Uploads/herbs_and_spices.jpg
DEBUG - 2020-07-17 16:26:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:39 --> 404 Page Not Found: Uploads/generic.jpg
DEBUG - 2020-07-17 16:26:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:39 --> 404 Page Not Found: Uploads/ground_and_air.jpg
DEBUG - 2020-07-17 16:26:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:39 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 16:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:40 --> 404 Page Not Found: Uploads/illnesses.jpg
DEBUG - 2020-07-17 16:26:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:40 --> 404 Page Not Found: Uploads/items_at_home.jpg
DEBUG - 2020-07-17 16:26:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:40 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 16:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:40 --> 404 Page Not Found: Uploads/in_the_kitchen.jpg
DEBUG - 2020-07-17 16:26:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:40 --> 404 Page Not Found: Uploads/insects.jpg
DEBUG - 2020-07-17 16:26:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:40 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 16:26:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:40 --> 404 Page Not Found: Uploads/laundry_and_cleaning.jpg
DEBUG - 2020-07-17 16:26:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:40 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 16:26:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:40 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:26:40 --> 404 Page Not Found: Uploads/materials_and_patterns.jpg
DEBUG - 2020-07-17 16:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:40 --> 404 Page Not Found: Uploads/meat.jpg
DEBUG - 2020-07-17 16:26:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:40 --> 404 Page Not Found: Uploads/medical_equipment.jpg
DEBUG - 2020-07-17 16:26:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:40 --> 404 Page Not Found: Uploads/medical_terms.jpg
ERROR - 2020-07-17 16:26:40 --> 404 Page Not Found: Uploads/medical_symptoms.jpg
DEBUG - 2020-07-17 16:26:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:40 --> 404 Page Not Found: Uploads/Mushrooms.jpg
DEBUG - 2020-07-17 16:26:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:41 --> 404 Page Not Found: Uploads/medication.jpg
ERROR - 2020-07-17 16:26:41 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 16:26:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:41 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 16:26:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:41 --> 404 Page Not Found: Uploads/nationalities.jpg
ERROR - 2020-07-17 16:26:41 --> 404 Page Not Found: Uploads/numbers_cardinals.png
DEBUG - 2020-07-17 16:26:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:41 --> 404 Page Not Found: Uploads/nuts_and_dried_fruit.jpg
DEBUG - 2020-07-17 16:26:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:41 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:26:41 --> 404 Page Not Found: Uploads/numbers_ordinals.png
DEBUG - 2020-07-17 16:26:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:41 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 16:26:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:41 --> 404 Page Not Found: Uploads/Ready_meals.JPG
DEBUG - 2020-07-17 16:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:41 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
ERROR - 2020-07-17 16:26:41 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 16:26:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:41 --> 404 Page Not Found: Uploads/reptiles_and_amphibians.jpg
ERROR - 2020-07-17 16:26:41 --> 404 Page Not Found: Uploads/rooms.jpg
DEBUG - 2020-07-17 16:26:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:41 --> 404 Page Not Found: Uploads/Sauces_and_condiments.jpg
DEBUG - 2020-07-17 16:26:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:41 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 16:26:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:41 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 16:26:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:41 --> 404 Page Not Found: Uploads/sea_animals_and_fish.jpg
DEBUG - 2020-07-17 16:26:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:42 --> 404 Page Not Found: Uploads/shoes_and_trousers.jpg
ERROR - 2020-07-17 16:26:42 --> 404 Page Not Found: Uploads/Snacks_and_sweets.JPG
DEBUG - 2020-07-17 16:26:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:42 --> 404 Page Not Found: Uploads/sport_terms.png
ERROR - 2020-07-17 16:26:42 --> 404 Page Not Found: Uploads/Toiletries.jpg
ERROR - 2020-07-17 16:26:42 --> 404 Page Not Found: Uploads/tools_and_diy.jpg
DEBUG - 2020-07-17 16:26:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:42 --> 404 Page Not Found: Uploads/toys_and_games.jpg
ERROR - 2020-07-17 16:26:42 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 16:26:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:42 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 16:26:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:42 --> 404 Page Not Found: Uploads/Vegetables.JPG
ERROR - 2020-07-17 16:26:42 --> 404 Page Not Found: Uploads/types_of_sports.jpg
DEBUG - 2020-07-17 16:26:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:26:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:42 --> 404 Page Not Found: Uploads/2_verbs.png
ERROR - 2020-07-17 16:26:42 --> 404 Page Not Found: Uploads/water.jpg
DEBUG - 2020-07-17 16:26:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:42 --> 404 Page Not Found: Uploads/1_verbs.png
DEBUG - 2020-07-17 16:26:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:42 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 16:26:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:26:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:26:42 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 16:28:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:28:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:28:28 --> Total execution time: 0.1597
DEBUG - 2020-07-17 16:28:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:29 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:28:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:29 --> 404 Page Not Found: Uploads/adverbs.jpg
DEBUG - 2020-07-17 16:28:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:29 --> 404 Page Not Found: Uploads/accessories.jpg
DEBUG - 2020-07-17 16:28:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:29 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:28:29 --> 404 Page Not Found: Uploads/animals_in_the_world.jpg
DEBUG - 2020-07-17 16:28:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:29 --> 404 Page Not Found: Uploads/animals_in_europe.jpg
DEBUG - 2020-07-17 16:28:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:29 --> 404 Page Not Found: Uploads/animals_with_hooves.jpg
DEBUG - 2020-07-17 16:28:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:29 --> 404 Page Not Found: Uploads/appearance.jpg
DEBUG - 2020-07-17 16:28:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:29 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:28:29 --> 404 Page Not Found: Uploads/baby_toiletries.jpg
DEBUG - 2020-07-17 16:28:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:29 --> 404 Page Not Found: Uploads/At__the_dentists.JPG
DEBUG - 2020-07-17 16:28:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:29 --> 404 Page Not Found: Uploads/baby_clothes.jpg
ERROR - 2020-07-17 16:28:29 --> 404 Page Not Found: Uploads/at_home.jpg
DEBUG - 2020-07-17 16:28:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:29 --> 404 Page Not Found: Uploads/bakery_and_pasta.jpg
DEBUG - 2020-07-17 16:28:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:29 --> 404 Page Not Found: Uploads/bathroom.jpg
DEBUG - 2020-07-17 16:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:30 --> 404 Page Not Found: Uploads/bedroom.jpg
DEBUG - 2020-07-17 16:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:30 --> 404 Page Not Found: Uploads/childrens_clothes.jpg
ERROR - 2020-07-17 16:28:30 --> 404 Page Not Found: Uploads/berries.jpg
DEBUG - 2020-07-17 16:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:30 --> 404 Page Not Found: Uploads/birds.jpg
DEBUG - 2020-07-17 16:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:30 --> 404 Page Not Found: Uploads/body_parts.jpg
DEBUG - 2020-07-17 16:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:30 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 16:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:30 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:28:30 --> 404 Page Not Found: Uploads/cooking_verbs.jpg
DEBUG - 2020-07-17 16:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:30 --> 404 Page Not Found: Uploads/dairy.jpg
DEBUG - 2020-07-17 16:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:30 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:28:30 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 16:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:30 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 16:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:30 --> 404 Page Not Found: Uploads/containers_and_portions.jpg
DEBUG - 2020-07-17 16:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:30 --> 404 Page Not Found: Uploads/opposites_doubles.jpg
DEBUG - 2020-07-17 16:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:30 --> 404 Page Not Found: Uploads/drinks.jpg
DEBUG - 2020-07-17 16:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:30 --> 404 Page Not Found: Uploads/electronic_appliances.jpg
DEBUG - 2020-07-17 16:28:30 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:28:30 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 16:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:30 --> 404 Page Not Found: Uploads/equipment.jpg
DEBUG - 2020-07-17 16:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:31 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 16:28:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:31 --> 404 Page Not Found: Uploads/face_and_head.jpg
ERROR - 2020-07-17 16:28:31 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-17 16:28:31 --> 404 Page Not Found: Uploads/everyday_life.jpg
DEBUG - 2020-07-17 16:28:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:31 --> 404 Page Not Found: Uploads/fish_and_seafood.jpg
DEBUG - 2020-07-17 16:28:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:31 --> 404 Page Not Found: Uploads/fixtures.jpg
DEBUG - 2020-07-17 16:28:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:31 --> 404 Page Not Found: Uploads/fruits.jpg
DEBUG - 2020-07-17 16:28:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:31 --> 404 Page Not Found: Uploads/grains_and_cereals.jpg
ERROR - 2020-07-17 16:28:31 --> 404 Page Not Found: Uploads/furniture.jpg
ERROR - 2020-07-17 16:28:31 --> 404 Page Not Found: Uploads/generic.jpg
DEBUG - 2020-07-17 16:28:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:31 --> 404 Page Not Found: Uploads/ground_and_air.jpg
ERROR - 2020-07-17 16:28:31 --> 404 Page Not Found: Uploads/herbs_and_spices.jpg
DEBUG - 2020-07-17 16:28:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:31 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 16:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:31 --> 404 Page Not Found: Uploads/in_the_kitchen.jpg
DEBUG - 2020-07-17 16:28:31 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:31 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:28:31 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 16:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:31 --> 404 Page Not Found: Uploads/illnesses.jpg
DEBUG - 2020-07-17 16:28:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:32 --> 404 Page Not Found: Uploads/insects.jpg
ERROR - 2020-07-17 16:28:32 --> 404 Page Not Found: Uploads/items_at_home.jpg
DEBUG - 2020-07-17 16:28:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:32 --> 404 Page Not Found: Uploads/laundry_and_cleaning.jpg
DEBUG - 2020-07-17 16:28:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:32 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 16:28:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:32 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 16:28:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:32 --> 404 Page Not Found: Uploads/materials_and_patterns.jpg
DEBUG - 2020-07-17 16:28:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:32 --> 404 Page Not Found: Uploads/meat.jpg
ERROR - 2020-07-17 16:28:32 --> 404 Page Not Found: Uploads/medical_equipment.jpg
DEBUG - 2020-07-17 16:28:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:32 --> 404 Page Not Found: Uploads/medical_terms.jpg
DEBUG - 2020-07-17 16:28:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:32 --> 404 Page Not Found: Uploads/medication.jpg
DEBUG - 2020-07-17 16:28:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:32 --> 404 Page Not Found: Uploads/medical_symptoms.jpg
ERROR - 2020-07-17 16:28:32 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 16:28:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:32 --> 404 Page Not Found: Uploads/music.jpg
ERROR - 2020-07-17 16:28:32 --> 404 Page Not Found: Uploads/Mushrooms.jpg
DEBUG - 2020-07-17 16:28:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:32 --> 404 Page Not Found: Uploads/numbers_cardinals.png
DEBUG - 2020-07-17 16:28:32 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:32 --> 404 Page Not Found: Uploads/nationalities.jpg
DEBUG - 2020-07-17 16:28:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:33 --> 404 Page Not Found: Uploads/numbers_ordinals.png
DEBUG - 2020-07-17 16:28:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:33 --> 404 Page Not Found: Uploads/nuts_and_dried_fruit.jpg
DEBUG - 2020-07-17 16:28:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:33 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 16:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:33 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 16:28:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:33 --> 404 Page Not Found: Uploads/Ready_meals.JPG
DEBUG - 2020-07-17 16:28:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:33 --> 404 Page Not Found: Uploads/reptiles_and_amphibians.jpg
DEBUG - 2020-07-17 16:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:33 --> 404 Page Not Found: Uploads/Sauces_and_condiments.jpg
DEBUG - 2020-07-17 16:28:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:33 --> 404 Page Not Found: Uploads/sea_animals_and_fish.jpg
DEBUG - 2020-07-17 16:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:33 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 16:28:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:33 --> 404 Page Not Found: Uploads/rooms.jpg
DEBUG - 2020-07-17 16:28:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:33 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 16:28:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:33 --> 404 Page Not Found: Uploads/sport_terms.png
DEBUG - 2020-07-17 16:28:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:33 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 16:28:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:33 --> 404 Page Not Found: Uploads/shoes_and_trousers.jpg
ERROR - 2020-07-17 16:28:33 --> 404 Page Not Found: Uploads/Snacks_and_sweets.JPG
DEBUG - 2020-07-17 16:28:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:33 --> 404 Page Not Found: Uploads/Toiletries.jpg
DEBUG - 2020-07-17 16:28:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:34 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:28:34 --> 404 Page Not Found: Uploads/tools_and_diy.jpg
DEBUG - 2020-07-17 16:28:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:34 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 16:28:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:34 --> 404 Page Not Found: Uploads/toys_and_games.jpg
DEBUG - 2020-07-17 16:28:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:34 --> 404 Page Not Found: Uploads/types_of_sports.jpg
DEBUG - 2020-07-17 16:28:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:34 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 16:28:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:34 --> 404 Page Not Found: Uploads/1_verbs.png
DEBUG - 2020-07-17 16:28:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:34 --> 404 Page Not Found: Uploads/Vegetables.JPG
DEBUG - 2020-07-17 16:28:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:34 --> 404 Page Not Found: Uploads/2_verbs.png
DEBUG - 2020-07-17 16:28:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:34 --> 404 Page Not Found: Uploads/water.jpg
DEBUG - 2020-07-17 16:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:34 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:28:34 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 16:28:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:34 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 16:28:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:28:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:28:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:28:40 --> Total execution time: 0.1245
DEBUG - 2020-07-17 16:28:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:28:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:28:45 --> Total execution time: 0.1333
DEBUG - 2020-07-17 16:28:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:28:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:28:45 --> Total execution time: 0.1340
DEBUG - 2020-07-17 16:28:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:28:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:46 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:28:46 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 16:28:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:46 --> 404 Page Not Found: Uploads/animals.jpg
ERROR - 2020-07-17 16:28:46 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 16:28:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:46 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
ERROR - 2020-07-17 16:28:46 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 16:28:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:46 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 16:28:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:46 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 16:28:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:46 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 16:28:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:46 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 16:28:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:46 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:28:46 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 16:28:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:47 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 16:28:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:47 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 16:28:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:47 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 16:28:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:47 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 16:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:47 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:28:47 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 16:28:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:47 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 16:28:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:47 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 16:28:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:47 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 16:28:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:47 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 16:28:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:47 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 16:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:47 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:28:47 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 16:28:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:47 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 16:28:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:47 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 16:28:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:47 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 16:28:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:48 --> 404 Page Not Found: Uploads/shapes.png
ERROR - 2020-07-17 16:28:48 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 16:28:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:48 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 16:28:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:48 --> 404 Page Not Found: Uploads/transport.jpg
ERROR - 2020-07-17 16:28:48 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 16:28:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:48 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 16:28:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:48 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 16:28:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:48 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 16:28:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:48 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 16:28:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:48 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 16:28:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:28:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:28:51 --> Total execution time: 0.1463
DEBUG - 2020-07-17 16:28:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:28:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:28:52 --> Total execution time: 0.1575
DEBUG - 2020-07-17 16:28:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:28:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:52 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 16:28:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:28:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:28:55 --> Total execution time: 0.1564
DEBUG - 2020-07-17 16:28:55 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:28:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:28:56 --> Total execution time: 0.1193
DEBUG - 2020-07-17 16:28:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:28:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:56 --> 404 Page Not Found: Uploads/clothes.jpg
ERROR - 2020-07-17 16:28:56 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 16:28:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:56 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 16:28:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:56 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 16:28:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:56 --> 404 Page Not Found: Uploads/body.jpg
DEBUG - 2020-07-17 16:28:56 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:56 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 16:28:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:57 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:28:57 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 16:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:57 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 16:28:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:57 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 16:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:57 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 16:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:57 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 16:28:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:57 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 16:28:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:57 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 16:28:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:57 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 16:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:57 --> 404 Page Not Found: Uploads/in_the_office.jpg
ERROR - 2020-07-17 16:28:57 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 16:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:57 --> 404 Page Not Found: Uploads/legal_terminology.jpg
ERROR - 2020-07-17 16:28:57 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 16:28:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:57 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 16:28:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:57 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:28:57 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 16:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:57 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 16:28:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:58 --> 404 Page Not Found: Uploads/numbers.png
ERROR - 2020-07-17 16:28:58 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 16:28:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:58 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 16:28:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:58 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 16:28:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:58 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:28:58 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 16:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:58 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 16:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:28:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:58 --> 404 Page Not Found: Uploads/sports.jpg
ERROR - 2020-07-17 16:28:58 --> 404 Page Not Found: Uploads/weather.jpg
ERROR - 2020-07-17 16:28:58 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 16:28:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:58 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 16:28:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:59 --> 404 Page Not Found: Assets/js
DEBUG - 2020-07-17 16:28:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:59 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 16:28:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:28:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:28:59 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 16:29:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:29:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:29:01 --> Total execution time: 0.1411
DEBUG - 2020-07-17 16:29:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:29:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:29:02 --> Total execution time: 0.3443
DEBUG - 2020-07-17 16:29:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:29:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:02 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:29:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:02 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:29:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:02 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:29:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:03 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:29:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:03 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:29:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:04 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:29:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:04 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:29:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:04 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:29:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:05 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:29:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:05 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:29:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:05 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:29:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:05 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:29:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:05 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:29:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:05 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:29:05 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:29:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:29:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:29:08 --> Total execution time: 0.1268
DEBUG - 2020-07-17 16:29:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:29:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:29:08 --> Total execution time: 0.1268
DEBUG - 2020-07-17 16:29:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:29:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:09 --> 404 Page Not Found: Uploads/animals_with_hooves.jpg
DEBUG - 2020-07-17 16:29:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:09 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:29:09 --> 404 Page Not Found: Uploads/accessories.jpg
DEBUG - 2020-07-17 16:29:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:09 --> 404 Page Not Found: Uploads/animals_in_europe.jpg
DEBUG - 2020-07-17 16:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:09 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:29:09 --> 404 Page Not Found: Uploads/adverbs.jpg
ERROR - 2020-07-17 16:29:09 --> 404 Page Not Found: Uploads/animals_in_the_world.jpg
DEBUG - 2020-07-17 16:29:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:09 --> 404 Page Not Found: Uploads/appearance.jpg
DEBUG - 2020-07-17 16:29:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:09 --> 404 Page Not Found: Uploads/at_home.jpg
DEBUG - 2020-07-17 16:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:09 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:29:09 --> 404 Page Not Found: Uploads/At__the_dentists.JPG
DEBUG - 2020-07-17 16:29:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:09 --> 404 Page Not Found: Uploads/baby_toiletries.jpg
DEBUG - 2020-07-17 16:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:09 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:29:09 --> 404 Page Not Found: Uploads/bathroom.jpg
ERROR - 2020-07-17 16:29:09 --> 404 Page Not Found: Uploads/bakery_and_pasta.jpg
DEBUG - 2020-07-17 16:29:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:09 --> 404 Page Not Found: Uploads/baby_clothes.jpg
DEBUG - 2020-07-17 16:29:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:10 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:29:10 --> 404 Page Not Found: Uploads/bedroom.jpg
DEBUG - 2020-07-17 16:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:10 --> 404 Page Not Found: Uploads/childrens_clothes.jpg
DEBUG - 2020-07-17 16:29:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:10 --> 404 Page Not Found: Uploads/berries.jpg
ERROR - 2020-07-17 16:29:10 --> 404 Page Not Found: Uploads/birds.jpg
ERROR - 2020-07-17 16:29:10 --> 404 Page Not Found: Uploads/body_parts.jpg
DEBUG - 2020-07-17 16:29:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:10 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 16:29:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:10 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:29:10 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 16:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:10 --> 404 Page Not Found: Uploads/cooking_verbs.jpg
DEBUG - 2020-07-17 16:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:10 --> 404 Page Not Found: Uploads/dairy.jpg
ERROR - 2020-07-17 16:29:10 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 16:29:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:10 --> 404 Page Not Found: Uploads/containers_and_portions.jpg
DEBUG - 2020-07-17 16:29:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:10 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:29:10 --> 404 Page Not Found: Uploads/opposites_doubles.jpg
DEBUG - 2020-07-17 16:29:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:10 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-17 16:29:10 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 16:29:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:10 --> 404 Page Not Found: Uploads/electronic_appliances.jpg
ERROR - 2020-07-17 16:29:10 --> 404 Page Not Found: Uploads/drinks.jpg
DEBUG - 2020-07-17 16:29:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:10 --> 404 Page Not Found: Uploads/equipment.jpg
DEBUG - 2020-07-17 16:29:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:10 --> 404 Page Not Found: Uploads/everyday_life.jpg
DEBUG - 2020-07-17 16:29:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:10 --> 404 Page Not Found: Uploads/face_and_head.jpg
DEBUG - 2020-07-17 16:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:10 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 16:29:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:11 --> 404 Page Not Found: Uploads/fish_and_seafood.jpg
ERROR - 2020-07-17 16:29:11 --> 404 Page Not Found: Uploads/fixtures.jpg
DEBUG - 2020-07-17 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:11 --> 404 Page Not Found: Uploads/fruits.jpg
DEBUG - 2020-07-17 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:11 --> 404 Page Not Found: Uploads/grains_and_cereals.jpg
DEBUG - 2020-07-17 16:29:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:11 --> 404 Page Not Found: Uploads/furniture.jpg
DEBUG - 2020-07-17 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:11 --> 404 Page Not Found: Uploads/generic.jpg
DEBUG - 2020-07-17 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:11 --> 404 Page Not Found: Uploads/ground_and_air.jpg
DEBUG - 2020-07-17 16:29:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:11 --> 404 Page Not Found: Uploads/herbs_and_spices.jpg
DEBUG - 2020-07-17 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:11 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:11 --> 404 Page Not Found: Uploads/in_the_kitchen.jpg
ERROR - 2020-07-17 16:29:11 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:11 --> 404 Page Not Found: Uploads/illnesses.jpg
DEBUG - 2020-07-17 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:11 --> 404 Page Not Found: Uploads/items_at_home.jpg
DEBUG - 2020-07-17 16:29:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:11 --> 404 Page Not Found: Uploads/insects.jpg
DEBUG - 2020-07-17 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:11 --> 404 Page Not Found: Uploads/laundry_and_cleaning.jpg
DEBUG - 2020-07-17 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:11 --> 404 Page Not Found: Uploads/materials_and_patterns.jpg
DEBUG - 2020-07-17 16:29:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:11 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:11 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:11 --> 404 Page Not Found: Uploads/meat.jpg
ERROR - 2020-07-17 16:29:11 --> 404 Page Not Found: Uploads/medical_equipment.jpg
DEBUG - 2020-07-17 16:29:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:12 --> 404 Page Not Found: Uploads/medical_symptoms.jpg
DEBUG - 2020-07-17 16:29:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:12 --> 404 Page Not Found: Uploads/medical_terms.jpg
DEBUG - 2020-07-17 16:29:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:12 --> 404 Page Not Found: Uploads/medication.jpg
DEBUG - 2020-07-17 16:29:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:12 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 16:29:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:12 --> 404 Page Not Found: Uploads/Mushrooms.jpg
ERROR - 2020-07-17 16:29:12 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 16:29:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:12 --> 404 Page Not Found: Uploads/numbers_cardinals.png
DEBUG - 2020-07-17 16:29:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:12 --> 404 Page Not Found: Uploads/nationalities.jpg
ERROR - 2020-07-17 16:29:12 --> 404 Page Not Found: Uploads/nuts_and_dried_fruit.jpg
DEBUG - 2020-07-17 16:29:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:12 --> 404 Page Not Found: Uploads/numbers_ordinals.png
DEBUG - 2020-07-17 16:29:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:12 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
ERROR - 2020-07-17 16:29:12 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 16:29:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:12 --> 404 Page Not Found: Uploads/reptiles_and_amphibians.jpg
DEBUG - 2020-07-17 16:29:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:12 --> 404 Page Not Found: Uploads/Ready_meals.JPG
DEBUG - 2020-07-17 16:29:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:12 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:29:12 --> 404 Page Not Found: Uploads/rooms.jpg
DEBUG - 2020-07-17 16:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:12 --> 404 Page Not Found: Uploads/Sauces_and_condiments.jpg
DEBUG - 2020-07-17 16:29:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:12 --> 404 Page Not Found: Uploads/sea_animals_and_fish.jpg
ERROR - 2020-07-17 16:29:12 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 16:29:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:12 --> 404 Page Not Found: Uploads/sport_terms.png
ERROR - 2020-07-17 16:29:12 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 16:29:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:13 --> 404 Page Not Found: Uploads/Snacks_and_sweets.JPG
DEBUG - 2020-07-17 16:29:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:13 --> 404 Page Not Found: Uploads/shoes_and_trousers.jpg
DEBUG - 2020-07-17 16:29:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:13 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:29:13 --> 404 Page Not Found: Uploads/tools_and_diy.jpg
DEBUG - 2020-07-17 16:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:13 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:29:13 --> 404 Page Not Found: Uploads/Toiletries.jpg
DEBUG - 2020-07-17 16:29:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:13 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 16:29:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:13 --> 404 Page Not Found: Uploads/toys_and_games.jpg
DEBUG - 2020-07-17 16:29:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:13 --> 404 Page Not Found: Uploads/types_of_sports.jpg
ERROR - 2020-07-17 16:29:13 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 16:29:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:13 --> 404 Page Not Found: Uploads/1_verbs.png
DEBUG - 2020-07-17 16:29:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:13 --> 404 Page Not Found: Uploads/2_verbs.png
DEBUG - 2020-07-17 16:29:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:13 --> 404 Page Not Found: Uploads/water.jpg
DEBUG - 2020-07-17 16:29:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:13 --> 404 Page Not Found: Uploads/Vegetables.JPG
DEBUG - 2020-07-17 16:29:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:13 --> 404 Page Not Found: Uploads/weather.jpg
ERROR - 2020-07-17 16:29:13 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 16:29:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:29:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:29:16 --> Total execution time: 0.1352
DEBUG - 2020-07-17 16:29:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:29:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:29:17 --> Total execution time: 0.3457
DEBUG - 2020-07-17 16:29:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:29:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:18 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:29:18 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:29:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:18 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:29:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:18 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:29:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:19 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:29:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:19 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:29:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:19 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:29:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:19 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:29:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:20 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:29:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:20 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:29:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:20 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:29:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:20 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:29:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:21 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:29:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:21 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:29:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:21 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:29:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:29:30 --> Total execution time: 0.1265
DEBUG - 2020-07-17 16:29:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:29:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:29:30 --> Total execution time: 0.1367
DEBUG - 2020-07-17 16:29:30 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:29:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:29:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:29:33 --> Total execution time: 0.1257
DEBUG - 2020-07-17 16:29:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:29:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:29:33 --> Total execution time: 0.1547
DEBUG - 2020-07-17 16:29:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:29:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:33 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:29:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:33 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:29:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:33 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:29:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:29:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:29:35 --> Total execution time: 0.1384
DEBUG - 2020-07-17 16:29:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:29:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:29:36 --> Total execution time: 0.3949
DEBUG - 2020-07-17 16:29:36 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:29:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:29:43 --> Total execution time: 0.1570
DEBUG - 2020-07-17 16:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:29:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:29:43 --> Total execution time: 0.2875
DEBUG - 2020-07-17 16:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:29:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:29:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:29:45 --> Total execution time: 0.1638
DEBUG - 2020-07-17 16:29:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:29:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:29:46 --> Total execution time: 0.1503
DEBUG - 2020-07-17 16:29:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:29:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:29:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:33:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:33:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:33:07 --> Total execution time: 0.1492
DEBUG - 2020-07-17 16:33:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:33:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:33:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:33:10 --> Total execution time: 0.1430
DEBUG - 2020-07-17 16:33:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:33:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:33:10 --> Total execution time: 0.1269
DEBUG - 2020-07-17 16:33:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:33:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:33:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:33:12 --> Total execution time: 0.1280
DEBUG - 2020-07-17 16:33:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:33:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:33:13 --> Total execution time: 0.2873
DEBUG - 2020-07-17 16:33:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:33:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:33:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:33:18 --> Total execution time: 0.1706
DEBUG - 2020-07-17 16:33:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:33:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:33:19 --> Total execution time: 0.1497
DEBUG - 2020-07-17 16:33:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:33:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:19 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:33:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:19 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:33:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:19 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:33:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:33:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:33:21 --> Total execution time: 0.1405
DEBUG - 2020-07-17 16:33:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:33:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:33:21 --> Total execution time: 0.1597
DEBUG - 2020-07-17 16:33:21 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:33:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:33:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:33:23 --> Total execution time: 0.1593
DEBUG - 2020-07-17 16:33:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:33:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:33:23 --> Total execution time: 0.4050
DEBUG - 2020-07-17 16:33:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:33:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:24 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:33:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:24 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:33:24 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:33:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:24 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:25 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:33:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:25 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:33:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:26 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:33:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:26 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:33:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:26 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:33:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:27 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:33:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:27 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:33:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:27 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:33:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:27 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:33:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:27 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:33:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:27 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:33:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:33:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:33:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:33:40 --> Total execution time: 0.1181
DEBUG - 2020-07-17 16:33:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:33:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:33:40 --> Total execution time: 0.2330
DEBUG - 2020-07-17 16:33:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:33:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:40 --> 404 Page Not Found: Uploads/accessories.jpg
DEBUG - 2020-07-17 16:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:41 --> 404 Page Not Found: Uploads/adverbs.jpg
DEBUG - 2020-07-17 16:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:41 --> 404 Page Not Found: Uploads/animals_in_europe.jpg
DEBUG - 2020-07-17 16:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:41 --> 404 Page Not Found: Uploads/animals_with_hooves.jpg
DEBUG - 2020-07-17 16:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:41 --> 404 Page Not Found: Uploads/appearance.jpg
DEBUG - 2020-07-17 16:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:41 --> 404 Page Not Found: Uploads/animals_in_the_world.jpg
DEBUG - 2020-07-17 16:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:41 --> 404 Page Not Found: Uploads/at_home.jpg
DEBUG - 2020-07-17 16:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:41 --> 404 Page Not Found: Uploads/baby_toiletries.jpg
ERROR - 2020-07-17 16:33:41 --> 404 Page Not Found: Uploads/bakery_and_pasta.jpg
DEBUG - 2020-07-17 16:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:41 --> 404 Page Not Found: Uploads/bathroom.jpg
ERROR - 2020-07-17 16:33:41 --> 404 Page Not Found: Uploads/At__the_dentists.JPG
DEBUG - 2020-07-17 16:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:41 --> 404 Page Not Found: Uploads/baby_clothes.jpg
DEBUG - 2020-07-17 16:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:41 --> 404 Page Not Found: Uploads/birds.jpg
DEBUG - 2020-07-17 16:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:41 --> 404 Page Not Found: Uploads/berries.jpg
DEBUG - 2020-07-17 16:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:41 --> 404 Page Not Found: Uploads/bedroom.jpg
DEBUG - 2020-07-17 16:33:41 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:33:41 --> 404 Page Not Found: Uploads/childrens_clothes.jpg
DEBUG - 2020-07-17 16:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:41 --> 404 Page Not Found: Uploads/body_parts.jpg
DEBUG - 2020-07-17 16:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:41 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 16:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:41 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 16:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:41 --> 404 Page Not Found: Uploads/containers_and_portions.jpg
DEBUG - 2020-07-17 16:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:42 --> 404 Page Not Found: Uploads/cooking_verbs.jpg
ERROR - 2020-07-17 16:33:42 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 16:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:42 --> 404 Page Not Found: Uploads/dairy.jpg
ERROR - 2020-07-17 16:33:42 --> 404 Page Not Found: Uploads/opposites_doubles.jpg
DEBUG - 2020-07-17 16:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:42 --> 404 Page Not Found: Uploads/drinks.jpg
DEBUG - 2020-07-17 16:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:42 --> 404 Page Not Found: Uploads/electronic_appliances.jpg
DEBUG - 2020-07-17 16:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:42 --> 404 Page Not Found: Uploads/equipment.jpg
DEBUG - 2020-07-17 16:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:42 --> 404 Page Not Found: Uploads/everyday_life.jpg
DEBUG - 2020-07-17 16:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:42 --> 404 Page Not Found: Uploads/employment.jpg
ERROR - 2020-07-17 16:33:42 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 16:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:42 --> 404 Page Not Found: Uploads/face_and_head.jpg
DEBUG - 2020-07-17 16:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:42 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 16:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:42 --> 404 Page Not Found: Uploads/fish_and_seafood.jpg
DEBUG - 2020-07-17 16:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:42 --> 404 Page Not Found: Uploads/fixtures.jpg
DEBUG - 2020-07-17 16:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:42 --> 404 Page Not Found: Uploads/furniture.jpg
ERROR - 2020-07-17 16:33:42 --> 404 Page Not Found: Uploads/fruits.jpg
DEBUG - 2020-07-17 16:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:42 --> 404 Page Not Found: Uploads/grains_and_cereals.jpg
ERROR - 2020-07-17 16:33:42 --> 404 Page Not Found: Uploads/generic.jpg
DEBUG - 2020-07-17 16:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:42 --> 404 Page Not Found: Uploads/ground_and_air.jpg
DEBUG - 2020-07-17 16:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:43 --> 404 Page Not Found: Uploads/herbs_and_spices.jpg
DEBUG - 2020-07-17 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:43 --> 404 Page Not Found: Uploads/illnesses.jpg
DEBUG - 2020-07-17 16:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:43 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:43 --> 404 Page Not Found: Uploads/in_the_kitchen.jpg
DEBUG - 2020-07-17 16:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:43 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:43 --> 404 Page Not Found: Uploads/insects.jpg
DEBUG - 2020-07-17 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:43 --> 404 Page Not Found: Uploads/items_at_home.jpg
DEBUG - 2020-07-17 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:43 --> 404 Page Not Found: Uploads/laundry_and_cleaning.jpg
DEBUG - 2020-07-17 16:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:43 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:43 --> 404 Page Not Found: Uploads/materials_and_patterns.jpg
DEBUG - 2020-07-17 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:43 --> 404 Page Not Found: Uploads/medical_equipment.jpg
ERROR - 2020-07-17 16:33:43 --> 404 Page Not Found: Uploads/meat.jpg
DEBUG - 2020-07-17 16:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:43 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:43 --> 404 Page Not Found: Uploads/medical_symptoms.jpg
DEBUG - 2020-07-17 16:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:43 --> 404 Page Not Found: Uploads/medical_terms.jpg
DEBUG - 2020-07-17 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:43 --> 404 Page Not Found: Uploads/medication.jpg
DEBUG - 2020-07-17 16:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:43 --> 404 Page Not Found: Uploads/Mushrooms.jpg
DEBUG - 2020-07-17 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:43 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:43 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:44 --> 404 Page Not Found: Uploads/numbers_ordinals.png
ERROR - 2020-07-17 16:33:44 --> 404 Page Not Found: Uploads/nationalities.jpg
ERROR - 2020-07-17 16:33:44 --> 404 Page Not Found: Uploads/numbers_cardinals.png
DEBUG - 2020-07-17 16:33:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:44 --> 404 Page Not Found: Uploads/nuts_and_dried_fruit.jpg
DEBUG - 2020-07-17 16:33:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:44 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 16:33:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:44 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 16:33:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:44 --> 404 Page Not Found: Uploads/reptiles_and_amphibians.jpg
ERROR - 2020-07-17 16:33:44 --> 404 Page Not Found: Uploads/Ready_meals.JPG
ERROR - 2020-07-17 16:33:44 --> 404 Page Not Found: Uploads/rooms.jpg
DEBUG - 2020-07-17 16:33:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:44 --> 404 Page Not Found: Uploads/Sauces_and_condiments.jpg
DEBUG - 2020-07-17 16:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:44 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 16:33:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:44 --> 404 Page Not Found: Uploads/sea_animals_and_fish.jpg
ERROR - 2020-07-17 16:33:44 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 16:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:44 --> 404 Page Not Found: Uploads/shoes_and_trousers.jpg
DEBUG - 2020-07-17 16:33:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:44 --> 404 Page Not Found: Uploads/Toiletries.jpg
DEBUG - 2020-07-17 16:33:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:44 --> 404 Page Not Found: Uploads/sport_terms.png
ERROR - 2020-07-17 16:33:44 --> 404 Page Not Found: Uploads/Snacks_and_sweets.JPG
DEBUG - 2020-07-17 16:33:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:44 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:33:44 --> 404 Page Not Found: Uploads/tools_and_diy.jpg
DEBUG - 2020-07-17 16:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:44 --> 404 Page Not Found: Uploads/toys_and_games.jpg
ERROR - 2020-07-17 16:33:44 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 16:33:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:44 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 16:33:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:45 --> 404 Page Not Found: Uploads/Vegetables.JPG
ERROR - 2020-07-17 16:33:45 --> 404 Page Not Found: Uploads/types_of_sports.jpg
DEBUG - 2020-07-17 16:33:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:45 --> 404 Page Not Found: Uploads/1_verbs.png
ERROR - 2020-07-17 16:33:45 --> 404 Page Not Found: Uploads/2_verbs.png
DEBUG - 2020-07-17 16:33:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:45 --> 404 Page Not Found: Uploads/water.jpg
DEBUG - 2020-07-17 16:33:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:45 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 16:33:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:33:45 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 16:34:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:01 --> Total execution time: 0.1043
DEBUG - 2020-07-17 16:34:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:01 --> Total execution time: 0.1219
DEBUG - 2020-07-17 16:34:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:34:01 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:01 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 16:34:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:02 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:34:02 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 16:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:02 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:34:02 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 16:34:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:02 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-17 16:34:02 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 16:34:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:02 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 16:34:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:02 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 16:34:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:02 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:34:02 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 16:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:02 --> 404 Page Not Found: Uploads/entertainment.jpg
ERROR - 2020-07-17 16:34:02 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 16:34:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:02 --> 404 Page Not Found: Uploads/grammar.jpg
ERROR - 2020-07-17 16:34:02 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 16:34:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:02 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 16:34:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:02 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 16:34:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:02 --> 404 Page Not Found: Uploads/legal_terminology.jpg
ERROR - 2020-07-17 16:34:02 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 16:34:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:02 --> 404 Page Not Found: Uploads/numbers.png
ERROR - 2020-07-17 16:34:02 --> 404 Page Not Found: Uploads/music.jpg
ERROR - 2020-07-17 16:34:02 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 16:34:02 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:03 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 16:34:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:03 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 16:34:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:03 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 16:34:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:03 --> 404 Page Not Found: Uploads/shapes.png
ERROR - 2020-07-17 16:34:03 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 16:34:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:03 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 16:34:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:03 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 16:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:03 --> 404 Page Not Found: Uploads/transport.jpg
ERROR - 2020-07-17 16:34:03 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 16:34:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:03 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:34:03 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 16:34:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:03 --> 404 Page Not Found: Uploads/weather.jpg
ERROR - 2020-07-17 16:34:03 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 16:34:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:03 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:04 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 16:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:04 --> 404 Page Not Found: Uploads/numbers.png
ERROR - 2020-07-17 16:34:04 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 16:34:04 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:04 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 16:34:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:08 --> Total execution time: 0.1211
DEBUG - 2020-07-17 16:34:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:08 --> Total execution time: 0.1333
DEBUG - 2020-07-17 16:34:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:34:08 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:08 --> 404 Page Not Found: Uploads/accessories.jpg
DEBUG - 2020-07-17 16:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:09 --> 404 Page Not Found: Uploads/adverbs.jpg
DEBUG - 2020-07-17 16:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:09 --> 404 Page Not Found: Uploads/appearance.jpg
DEBUG - 2020-07-17 16:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:09 --> 404 Page Not Found: Uploads/animals_in_the_world.jpg
ERROR - 2020-07-17 16:34:09 --> 404 Page Not Found: Uploads/animals_with_hooves.jpg
DEBUG - 2020-07-17 16:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:09 --> 404 Page Not Found: Uploads/animals_in_europe.jpg
DEBUG - 2020-07-17 16:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:09 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:34:09 --> 404 Page Not Found: Uploads/at_home.jpg
DEBUG - 2020-07-17 16:34:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:09 --> 404 Page Not Found: Uploads/At__the_dentists.JPG
DEBUG - 2020-07-17 16:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:09 --> 404 Page Not Found: Uploads/baby_clothes.jpg
DEBUG - 2020-07-17 16:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:09 --> 404 Page Not Found: Uploads/bakery_and_pasta.jpg
ERROR - 2020-07-17 16:34:09 --> 404 Page Not Found: Uploads/baby_toiletries.jpg
DEBUG - 2020-07-17 16:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:09 --> 404 Page Not Found: Uploads/bathroom.jpg
DEBUG - 2020-07-17 16:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:09 --> 404 Page Not Found: Uploads/bedroom.jpg
DEBUG - 2020-07-17 16:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:09 --> 404 Page Not Found: Uploads/berries.jpg
DEBUG - 2020-07-17 16:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:09 --> 404 Page Not Found: Uploads/body_parts.jpg
ERROR - 2020-07-17 16:34:09 --> 404 Page Not Found: Uploads/childrens_clothes.jpg
ERROR - 2020-07-17 16:34:09 --> 404 Page Not Found: Uploads/birds.jpg
DEBUG - 2020-07-17 16:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:10 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:10 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:10 --> 404 Page Not Found: Uploads/containers_and_portions.jpg
DEBUG - 2020-07-17 16:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:10 --> 404 Page Not Found: Uploads/cooking_verbs.jpg
DEBUG - 2020-07-17 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:10 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 16:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:10 --> 404 Page Not Found: Uploads/dairy.jpg
DEBUG - 2020-07-17 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:10 --> 404 Page Not Found: Uploads/opposites_doubles.jpg
DEBUG - 2020-07-17 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:10 --> 404 Page Not Found: Uploads/drinks.jpg
DEBUG - 2020-07-17 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:10 --> 404 Page Not Found: Uploads/electronic_appliances.jpg
DEBUG - 2020-07-17 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:10 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 16:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:10 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:34:10 --> 404 Page Not Found: Uploads/equipment.jpg
DEBUG - 2020-07-17 16:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:10 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:10 --> 404 Page Not Found: Uploads/everyday_life.jpg
DEBUG - 2020-07-17 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:10 --> 404 Page Not Found: Uploads/face_and_head.jpg
DEBUG - 2020-07-17 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:10 --> 404 Page Not Found: Uploads/fixtures.jpg
ERROR - 2020-07-17 16:34:10 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 16:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:10 --> 404 Page Not Found: Uploads/fish_and_seafood.jpg
DEBUG - 2020-07-17 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:10 --> 404 Page Not Found: Uploads/fruits.jpg
DEBUG - 2020-07-17 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:11 --> 404 Page Not Found: Uploads/furniture.jpg
DEBUG - 2020-07-17 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:11 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:34:11 --> 404 Page Not Found: Uploads/grains_and_cereals.jpg
DEBUG - 2020-07-17 16:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:11 --> 404 Page Not Found: Uploads/ground_and_air.jpg
DEBUG - 2020-07-17 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:11 --> 404 Page Not Found: Uploads/generic.jpg
DEBUG - 2020-07-17 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:11 --> 404 Page Not Found: Uploads/herbs_and_spices.jpg
DEBUG - 2020-07-17 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:11 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:11 --> 404 Page Not Found: Uploads/illnesses.jpg
DEBUG - 2020-07-17 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:11 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:34:11 --> 404 Page Not Found: Uploads/in_the_kitchen.jpg
DEBUG - 2020-07-17 16:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:11 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:11 --> 404 Page Not Found: Uploads/insects.jpg
DEBUG - 2020-07-17 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:11 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:34:11 --> 404 Page Not Found: Uploads/items_at_home.jpg
DEBUG - 2020-07-17 16:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:11 --> 404 Page Not Found: Uploads/laundry_and_cleaning.jpg
DEBUG - 2020-07-17 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:11 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:11 --> 404 Page Not Found: Uploads/materials.jpg
DEBUG - 2020-07-17 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:11 --> 404 Page Not Found: Uploads/materials_and_patterns.jpg
DEBUG - 2020-07-17 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:11 --> 404 Page Not Found: Uploads/meat.jpg
DEBUG - 2020-07-17 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:11 --> 404 Page Not Found: Uploads/medical_equipment.jpg
DEBUG - 2020-07-17 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:11 --> 404 Page Not Found: Uploads/medical_symptoms.jpg
DEBUG - 2020-07-17 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:11 --> 404 Page Not Found: Uploads/medical_terms.jpg
DEBUG - 2020-07-17 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:12 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:34:12 --> 404 Page Not Found: Uploads/medication.jpg
DEBUG - 2020-07-17 16:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:12 --> 404 Page Not Found: Uploads/months_and_days.jpg
ERROR - 2020-07-17 16:34:12 --> 404 Page Not Found: Uploads/Mushrooms.jpg
DEBUG - 2020-07-17 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:12 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 16:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:12 --> 404 Page Not Found: Uploads/nationalities.jpg
DEBUG - 2020-07-17 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:12 --> 404 Page Not Found: Uploads/numbers_cardinals.png
DEBUG - 2020-07-17 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:12 --> 404 Page Not Found: Uploads/numbers_ordinals.png
ERROR - 2020-07-17 16:34:12 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
ERROR - 2020-07-17 16:34:12 --> 404 Page Not Found: Uploads/nuts_and_dried_fruit.jpg
DEBUG - 2020-07-17 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:12 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:12 --> 404 Page Not Found: Uploads/reptiles_and_amphibians.jpg
ERROR - 2020-07-17 16:34:12 --> 404 Page Not Found: Uploads/Ready_meals.JPG
DEBUG - 2020-07-17 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:12 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:12 --> 404 Page Not Found: Uploads/rooms.jpg
ERROR - 2020-07-17 16:34:12 --> 404 Page Not Found: Uploads/Sauces_and_condiments.jpg
DEBUG - 2020-07-17 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:12 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:34:12 --> 404 Page Not Found: Uploads/sea_animals_and_fish.jpg
DEBUG - 2020-07-17 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:12 --> 404 Page Not Found: Uploads/shoes_and_trousers.jpg
DEBUG - 2020-07-17 16:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:12 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:34:12 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 16:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:12 --> 404 Page Not Found: Uploads/Snacks_and_sweets.JPG
DEBUG - 2020-07-17 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:12 --> 404 Page Not Found: Uploads/sport_terms.png
DEBUG - 2020-07-17 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:12 --> 404 Page Not Found: Uploads/Toiletries.jpg
DEBUG - 2020-07-17 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:13 --> 404 Page Not Found: Uploads/toys_and_games.jpg
DEBUG - 2020-07-17 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:13 --> 404 Page Not Found: Uploads/travel.jpg
ERROR - 2020-07-17 16:34:13 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 16:34:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:13 --> 404 Page Not Found: Uploads/tools_and_diy.jpg
DEBUG - 2020-07-17 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:13 --> 404 Page Not Found: Uploads/types_of_sports.jpg
DEBUG - 2020-07-17 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:13 --> 404 Page Not Found: Uploads/Vegetables.JPG
DEBUG - 2020-07-17 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:13 --> 404 Page Not Found: Uploads/1_verbs.png
DEBUG - 2020-07-17 16:34:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:13 --> 404 Page Not Found: Uploads/water.jpg
ERROR - 2020-07-17 16:34:13 --> 404 Page Not Found: Uploads/2_verbs.png
DEBUG - 2020-07-17 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:13 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:13 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 16:34:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:16 --> Total execution time: 0.1283
DEBUG - 2020-07-17 16:34:16 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:16 --> Total execution time: 0.3470
DEBUG - 2020-07-17 16:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:17 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:34:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:17 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:34:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:17 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:34:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:18 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:34:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:18 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:34:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:18 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:34:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:18 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:34:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:19 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:34:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:19 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:34:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:19 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:34:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:19 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:34:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:19 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:20 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:34:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:20 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:34:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:20 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:34:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:23 --> Total execution time: 0.1392
DEBUG - 2020-07-17 16:34:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:23 --> Total execution time: 0.1252
DEBUG - 2020-07-17 16:34:23 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:34:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:26 --> Total execution time: 0.1483
DEBUG - 2020-07-17 16:34:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:26 --> Total execution time: 0.1265
DEBUG - 2020-07-17 16:34:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:34:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:26 --> 404 Page Not Found: Uploads/words
ERROR - 2020-07-17 16:34:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:26 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:27 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-07-17 16:34:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:28 --> Total execution time: 0.1435
DEBUG - 2020-07-17 16:34:28 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:29 --> Total execution time: 0.3629
DEBUG - 2020-07-17 16:34:29 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:29 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:34:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:34 --> Total execution time: 0.1510
DEBUG - 2020-07-17 16:34:34 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:35 --> Total execution time: 0.4318
DEBUG - 2020-07-17 16:34:35 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:34:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:37 --> Total execution time: 0.1494
DEBUG - 2020-07-17 16:34:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:37 --> Total execution time: 0.1229
DEBUG - 2020-07-17 16:34:37 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:34:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:39 --> Total execution time: 0.1200
DEBUG - 2020-07-17 16:34:39 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:39 --> Total execution time: 0.1666
DEBUG - 2020-07-17 16:34:40 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:34:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:42 --> Total execution time: 0.1299
DEBUG - 2020-07-17 16:34:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-17 16:34:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\header.php 86
DEBUG - 2020-07-17 16:34:42 --> Total execution time: 0.1202
DEBUG - 2020-07-17 16:34:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:34:42 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:42 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_select_translation.jpg
DEBUG - 2020-07-17 16:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:43 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_multichoice_with_word.jpg
ERROR - 2020-07-17 16:34:43 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_choose_the_letter.jpg
DEBUG - 2020-07-17 16:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:43 --> 404 Page Not Found: Uploads/type.png
ERROR - 2020-07-17 16:34:43 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_multichoice_with_image.jpg
DEBUG - 2020-07-17 16:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:43 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:34:43 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_write_the_word.jpg
DEBUG - 2020-07-17 16:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:43 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_matching.jpg
DEBUG - 2020-07-17 16:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:43 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_flashcards.jpg
ERROR - 2020-07-17 16:34:43 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_flashcards1.jpg
DEBUG - 2020-07-17 16:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:43 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_listening_comprehension.jpg
DEBUG - 2020-07-17 16:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:43 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_grammar_fill_the_gap.jpg
ERROR - 2020-07-17 16:34:43 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_grammar_multichoice.jpg
DEBUG - 2020-07-17 16:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:43 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_text.jpg
DEBUG - 2020-07-17 16:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:43 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_dialgues_multichoice.jpg
ERROR - 2020-07-17 16:34:43 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_Culture_text.jpg
DEBUG - 2020-07-17 16:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:43 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_multichoice_with_word.jpg
ERROR - 2020-07-17 16:34:43 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_select_translation.jpg
ERROR - 2020-07-17 16:34:43 --> 404 Page Not Found: Uploads/SFI_exercise_type_icons_multichoice_with_image.jpg
DEBUG - 2020-07-17 16:34:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:46 --> Total execution time: 0.1174
DEBUG - 2020-07-17 16:34:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-17 16:34:46 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\voolsy\langoadmin\application\views\admin\header.php 86
DEBUG - 2020-07-17 16:34:46 --> Total execution time: 0.1641
DEBUG - 2020-07-17 16:34:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:46 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:34:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:46 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-17 16:34:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:46 --> No URI present. Default controller set.
DEBUG - 2020-07-17 16:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:47 --> Total execution time: 0.3182
DEBUG - 2020-07-17 16:34:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:47 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-17 16:34:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:47 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-17 16:34:47 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:47 --> No URI present. Default controller set.
DEBUG - 2020-07-17 16:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:47 --> Total execution time: 0.1333
DEBUG - 2020-07-17 16:34:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:48 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:48 --> No URI present. Default controller set.
DEBUG - 2020-07-17 16:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:48 --> 404 Page Not Found: Uploads/user_profile
DEBUG - 2020-07-17 16:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:49 --> Total execution time: 0.2953
DEBUG - 2020-07-17 16:34:50 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:51 --> Total execution time: 0.1254
DEBUG - 2020-07-17 16:34:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:51 --> Total execution time: 0.1364
DEBUG - 2020-07-17 16:34:51 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:34:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:57 --> Total execution time: 0.1511
DEBUG - 2020-07-17 16:34:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:34:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:34:57 --> Total execution time: 0.1181
DEBUG - 2020-07-17 16:34:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:34:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:57 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 16:34:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:57 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 16:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:57 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:57 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:34:57 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 16:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:57 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:34:57 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-17 16:34:57 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 16:34:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:57 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 16:34:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:58 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 16:34:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:58 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 16:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:58 --> 404 Page Not Found: Uploads/grammar.jpg
ERROR - 2020-07-17 16:34:58 --> 404 Page Not Found: Uploads/family_members.jpg
ERROR - 2020-07-17 16:34:58 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 16:34:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:58 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 16:34:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:58 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 16:34:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:58 --> 404 Page Not Found: Uploads/legal_terminology.jpg
ERROR - 2020-07-17 16:34:58 --> 404 Page Not Found: Uploads/in_the_office.jpg
DEBUG - 2020-07-17 16:34:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:58 --> 404 Page Not Found: Uploads/materials.jpg
ERROR - 2020-07-17 16:34:58 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 16:34:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:58 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 16:34:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:58 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 16:34:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:58 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 16:34:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:34:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:58 --> 404 Page Not Found: Uploads/opposites.jpg
ERROR - 2020-07-17 16:34:58 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
DEBUG - 2020-07-17 16:34:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:58 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 16:34:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:58 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 16:34:58 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:58 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 16:34:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:59 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 16:34:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:59 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 16:34:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:59 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 16:34:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:59 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 16:34:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:59 --> 404 Page Not Found: Uploads/weather.jpg
DEBUG - 2020-07-17 16:34:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:59 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 16:34:59 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:34:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:34:59 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 16:44:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:44:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:44:44 --> Total execution time: 0.1435
DEBUG - 2020-07-17 16:44:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:44:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:44:44 --> Total execution time: 0.1681
DEBUG - 2020-07-17 16:44:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:44:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-07-17 16:44:44 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:44:44 --> 404 Page Not Found: Uploads/animals.jpg
DEBUG - 2020-07-17 16:44:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:44:45 --> 404 Page Not Found: Uploads/employment.jpg
DEBUG - 2020-07-17 16:44:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:44:45 --> 404 Page Not Found: Uploads/clothes.jpg
DEBUG - 2020-07-17 16:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:44:45 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:44:45 --> 404 Page Not Found: Uploads/colours.jpg
DEBUG - 2020-07-17 16:44:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:44:45 --> 404 Page Not Found: Uploads/at_the_pharmacy.jpg
DEBUG - 2020-07-17 16:44:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:44:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:44:45 --> 404 Page Not Found: Uploads/body.jpg
ERROR - 2020-07-17 16:44:45 --> 404 Page Not Found: Uploads/countries.jpg
DEBUG - 2020-07-17 16:44:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:44:45 --> 404 Page Not Found: Uploads/health_care.jpg
DEBUG - 2020-07-17 16:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:44:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:44:45 --> 404 Page Not Found: Uploads/family_members.jpg
DEBUG - 2020-07-17 16:44:45 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:44:45 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-07-17 16:44:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:44:45 --> 404 Page Not Found: Uploads/grammar.jpg
DEBUG - 2020-07-17 16:44:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:44:45 --> 404 Page Not Found: Uploads/holidays_and_festivals.jpg
DEBUG - 2020-07-17 16:44:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:44:45 --> 404 Page Not Found: Uploads/home.jpg
DEBUG - 2020-07-17 16:44:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:44:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:44:45 --> 404 Page Not Found: Uploads/in_the_office.jpg
ERROR - 2020-07-17 16:44:45 --> 404 Page Not Found: Uploads/materials.jpg
ERROR - 2020-07-17 16:44:45 --> 404 Page Not Found: Uploads/legal_terminology.jpg
DEBUG - 2020-07-17 16:44:45 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:44:45 --> 404 Page Not Found: Uploads/months_and_days.jpg
DEBUG - 2020-07-17 16:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:44:46 --> 404 Page Not Found: Uploads/music.jpg
DEBUG - 2020-07-17 16:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:44:46 --> 404 Page Not Found: Uploads/numbers.png
DEBUG - 2020-07-17 16:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:44:46 --> 404 Page Not Found: Uploads/professions.jpg
DEBUG - 2020-07-17 16:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:46 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:44:46 --> 404 Page Not Found: Uploads/places.jpg
DEBUG - 2020-07-17 16:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:44:46 --> 404 Page Not Found: Uploads/personal_characteristics_and_qualities.jpg
ERROR - 2020-07-17 16:44:46 --> 404 Page Not Found: Uploads/opposites.jpg
DEBUG - 2020-07-17 16:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:44:46 --> UTF-8 Support Enabled
ERROR - 2020-07-17 16:44:46 --> 404 Page Not Found: Uploads/scotland.jpg
DEBUG - 2020-07-17 16:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:44:46 --> 404 Page Not Found: Uploads/shapes.png
DEBUG - 2020-07-17 16:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:44:46 --> 404 Page Not Found: Uploads/sports.jpg
DEBUG - 2020-07-17 16:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:44:46 --> 404 Page Not Found: Uploads/transport.jpg
DEBUG - 2020-07-17 16:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:44:46 --> 404 Page Not Found: Uploads/supermarket.jpg
DEBUG - 2020-07-17 16:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:44:46 --> 404 Page Not Found: Uploads/travel.jpg
DEBUG - 2020-07-17 16:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:44:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-07-17 16:44:46 --> 404 Page Not Found: Uploads/weather.jpg
ERROR - 2020-07-17 16:44:46 --> 404 Page Not Found: Uploads/what_time_is_it.jpg
DEBUG - 2020-07-17 16:59:52 --> UTF-8 Support Enabled
DEBUG - 2020-07-17 16:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-17 16:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-17 16:59:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-17 16:59:52 --> Total execution time: 0.1209
