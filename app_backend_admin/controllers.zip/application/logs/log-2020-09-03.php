<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-09-03 13:44:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:44:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:44:10 --> Total execution time: 0.1873
DEBUG - 2020-09-03 13:47:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:47:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:47:12 --> Total execution time: 0.1422
DEBUG - 2020-09-03 13:49:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:49:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:49:06 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2020-09-03 13:49:06 --> Total execution time: 0.1451
DEBUG - 2020-09-03 13:49:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:49:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:49:10 --> get_subcategory_list->{"lang":"37","category_id":"94","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-03 13:49:10 --> Total execution time: 0.1144
DEBUG - 2020-09-03 13:49:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:49:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:49:14 --> get_exercise_type_list->{"lang":"37","subcategory_id":"232","support_lang_id":"3"}
DEBUG - 2020-09-03 13:49:14 --> Total execution time: 0.1479
DEBUG - 2020-09-03 13:49:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:49:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:49:18 --> get_dialogue_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"2","category_id":"94","subcategory_id":"232","support_lang_id":"3"}
ERROR - 2020-09-03 13:49:18 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-03 13:49:18 --> Total execution time: 0.1154
DEBUG - 2020-09-03 13:49:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:49:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:49:22 --> get_dialogue_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"2","category_id":"94","subcategory_id":"232","support_lang_id":"3"}
ERROR - 2020-09-03 13:49:22 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-03 13:49:22 --> Total execution time: 0.1411
DEBUG - 2020-09-03 13:49:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:49:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:49:45 --> get_subcategory_list->{"lang":"37","category_id":"94","user_id":"0","support_lang_id":"3"}
DEBUG - 2020-09-03 13:49:45 --> Total execution time: 0.1400
DEBUG - 2020-09-03 13:49:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:49:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:49:54 --> Total execution time: 0.1295
DEBUG - 2020-09-03 13:50:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:50:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:50:02 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-03 13:50:02 --> Total execution time: 0.1015
DEBUG - 2020-09-03 13:50:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:50:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:50:06 --> get_subcategory_list->{"lang":"37","category_id":"126","user_id":"0","support_lang_id":"2"}
DEBUG - 2020-09-03 13:50:06 --> Total execution time: 0.1163
DEBUG - 2020-09-03 13:50:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:50:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:50:10 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-03 13:50:10 --> Total execution time: 0.1122
DEBUG - 2020-09-03 13:50:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:50:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:50:13 --> get_dialogue_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
ERROR - 2020-09-03 13:50:13 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-03 13:50:13 --> Total execution time: 0.1131
DEBUG - 2020-09-03 13:50:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:50:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:50:48 --> get_subcategory_list->{"lang":"37","category_id":"126","user_id":"0","support_lang_id":"2"}
DEBUG - 2020-09-03 13:50:48 --> Total execution time: 0.1585
DEBUG - 2020-09-03 13:53:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:53:45 --> No URI present. Default controller set.
DEBUG - 2020-09-03 13:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:53:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:53:45 --> Total execution time: 0.1699
DEBUG - 2020-09-03 13:53:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:53:48 --> No URI present. Default controller set.
DEBUG - 2020-09-03 13:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:53:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:53:48 --> Total execution time: 0.1478
DEBUG - 2020-09-03 13:54:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:54:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:54:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:54:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:54:33 --> Total execution time: 0.1387
DEBUG - 2020-09-03 13:54:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:54:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-03 13:54:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-03 13:55:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:55:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:55:25 --> Total execution time: 0.1763
DEBUG - 2020-09-03 13:55:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:55:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-03 13:55:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-09-03 13:55:27 --> Total execution time: 0.1305
DEBUG - 2020-09-03 13:55:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:55:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-03 13:55:30 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-03 13:55:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:55:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:55:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:55:43 --> Total execution time: 0.1828
DEBUG - 2020-09-03 13:55:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:55:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-03 13:55:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-09-03 13:55:45 --> Total execution time: 0.1724
DEBUG - 2020-09-03 13:55:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:55:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-03 13:55:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-03 13:56:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:56:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:56:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:56:02 --> Total execution time: 0.1181
DEBUG - 2020-09-03 13:56:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:56:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-03 13:56:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-09-03 13:56:05 --> Total execution time: 0.1481
DEBUG - 2020-09-03 13:56:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:56:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-03 13:56:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-03 13:56:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:56:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:56:32 --> Total execution time: 0.1665
DEBUG - 2020-09-03 13:56:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:56:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:56:37 --> Total execution time: 0.1718
DEBUG - 2020-09-03 13:56:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:56:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:56:53 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-03 13:56:53 --> Total execution time: 0.1589
DEBUG - 2020-09-03 13:56:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:56:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:56:58 --> get_subcategory_list->{"lang":"37","category_id":"126","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-03 13:56:58 --> Total execution time: 0.1355
DEBUG - 2020-09-03 13:57:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:57:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:57:04 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-03 13:57:04 --> Total execution time: 0.1327
DEBUG - 2020-09-03 13:57:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:57:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:57:08 --> get_dialogue_type_1->{"slang":"37","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
ERROR - 2020-09-03 13:57:08 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2020-09-03 13:57:08 --> Total execution time: 0.1388
DEBUG - 2020-09-03 13:57:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:57:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:57:16 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-03 13:57:16 --> Total execution time: 0.1493
DEBUG - 2020-09-03 13:57:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:57:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:57:18 --> Total execution time: 0.1382
DEBUG - 2020-09-03 13:57:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:57:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-03 13:57:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-03 13:57:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:57:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:57:23 --> get_subcategory_list->{"lang":"37","category_id":"126","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-03 13:57:23 --> Total execution time: 0.1066
DEBUG - 2020-09-03 13:57:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:57:39 --> Total execution time: 0.1757
DEBUG - 2020-09-03 13:57:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:57:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:57:48 --> Total execution time: 0.1575
DEBUG - 2020-09-03 13:57:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:57:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:57:53 --> Total execution time: 0.1488
DEBUG - 2020-09-03 13:58:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:58:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:58:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:58:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-03 13:58:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-09-03 13:58:48 --> Total execution time: 0.1722
DEBUG - 2020-09-03 13:58:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:58:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-03 13:58:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-03 13:59:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:59:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:59:00 --> Total execution time: 0.1669
DEBUG - 2020-09-03 13:59:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:59:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-03 13:59:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-03 13:59:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 13:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 13:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 13:59:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 13:59:15 --> Total execution time: 0.1667
DEBUG - 2020-09-03 14:00:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 14:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 14:00:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 14:00:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 14:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 14:00:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-03 14:00:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-09-03 14:00:08 --> Total execution time: 0.1293
DEBUG - 2020-09-03 14:00:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:00:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-03 14:00:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-03 14:00:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 14:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 14:00:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 14:00:19 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-03 14:00:19 --> Total execution time: 0.1389
DEBUG - 2020-09-03 14:00:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 14:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 14:00:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 14:00:26 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-03 14:00:26 --> Total execution time: 0.0943
DEBUG - 2020-09-03 14:00:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 14:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 14:00:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 14:00:30 --> get_subcategory_list->{"lang":"37","category_id":"126","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-03 14:00:30 --> Total execution time: 0.1258
DEBUG - 2020-09-03 14:00:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 14:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 14:00:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 14:00:34 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-03 14:00:34 --> Total execution time: 0.1264
DEBUG - 2020-09-03 14:00:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 14:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 14:00:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 14:00:39 --> get_dialogue_type_1->{"slang":"37","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-03 14:00:39 --> Total execution time: 0.1451
DEBUG - 2020-09-03 14:00:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 14:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 14:00:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 14:00:57 --> Total execution time: 0.1955
DEBUG - 2020-09-03 14:01:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-03 14:01:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-03 14:01:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 14:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 14:01:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 14:01:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 14:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 14:01:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-03 14:01:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-09-03 14:01:23 --> Total execution time: 0.1403
DEBUG - 2020-09-03 14:01:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:01:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-03 14:01:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-03 14:01:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 14:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 14:01:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 14:01:39 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-03 14:01:39 --> Total execution time: 0.1360
DEBUG - 2020-09-03 14:02:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 14:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 14:02:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 14:02:04 --> get_subcategory_list->{"lang":"37","category_id":"126","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-03 14:02:04 --> Total execution time: 0.1082
DEBUG - 2020-09-03 14:02:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 14:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 14:02:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 14:02:09 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-03 14:02:09 --> Total execution time: 0.1544
DEBUG - 2020-09-03 14:02:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 14:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 14:02:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 14:02:13 --> get_dialogue_type_1->{"slang":"37","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-03 14:02:13 --> Total execution time: 0.1076
DEBUG - 2020-09-03 14:02:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 14:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 14:02:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 14:02:44 --> Total execution time: 0.2080
DEBUG - 2020-09-03 14:02:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-03 14:02:47 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-03 14:03:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 14:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 14:03:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 14:03:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 14:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 14:03:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-03 14:03:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-09-03 14:03:10 --> Total execution time: 0.1323
DEBUG - 2020-09-03 14:03:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:03:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-03 14:03:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-03 14:03:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 14:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 14:03:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 14:03:22 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-03 14:03:22 --> Total execution time: 0.1326
DEBUG - 2020-09-03 14:03:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 14:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 14:03:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 14:03:27 --> get_dialogue_type_1->{"slang":"37","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-03 14:03:27 --> Total execution time: 0.1573
DEBUG - 2020-09-03 14:04:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 14:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 14:04:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 14:04:41 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-03 14:04:41 --> Total execution time: 0.1348
DEBUG - 2020-09-03 14:05:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 14:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 14:05:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 14:05:09 --> get_subcategory_list->{"lang":"37","category_id":"126","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-03 14:05:09 --> Total execution time: 0.1275
DEBUG - 2020-09-03 14:05:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-03 14:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-03 14:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-03 14:05:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-03 14:05:11 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-03 14:05:11 --> Total execution time: 0.1388
