<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-09-11 09:33:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:33:10 --> No URI present. Default controller set.
DEBUG - 2020-09-11 09:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 09:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 09:33:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 09:33:10 --> Total execution time: 0.1695
DEBUG - 2020-09-11 09:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:33:25 --> No URI present. Default controller set.
DEBUG - 2020-09-11 09:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 09:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 09:33:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 09:33:25 --> Total execution time: 0.1821
DEBUG - 2020-09-11 09:34:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:34:32 --> No URI present. Default controller set.
DEBUG - 2020-09-11 09:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 09:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 09:34:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 09:34:32 --> Total execution time: 0.1774
DEBUG - 2020-09-11 09:37:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:37:13 --> No URI present. Default controller set.
DEBUG - 2020-09-11 09:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 09:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 09:37:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 09:37:13 --> Total execution time: 0.1598
DEBUG - 2020-09-11 09:38:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:38:36 --> No URI present. Default controller set.
DEBUG - 2020-09-11 09:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 09:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 09:38:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 09:38:36 --> Total execution time: 0.1323
DEBUG - 2020-09-11 09:39:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:39:29 --> No URI present. Default controller set.
DEBUG - 2020-09-11 09:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 09:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 09:39:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 09:39:29 --> Total execution time: 0.1266
DEBUG - 2020-09-11 09:39:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:39:31 --> No URI present. Default controller set.
DEBUG - 2020-09-11 09:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 09:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 09:39:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 09:39:31 --> Total execution time: 0.1254
DEBUG - 2020-09-11 09:39:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 09:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 09:39:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 09:39:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 09:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 09:39:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 09:39:58 --> Total execution time: 0.1704
DEBUG - 2020-09-11 09:40:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:40:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 09:40:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-11 09:40:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:40:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 09:40:03 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-11 09:40:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:40:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 09:40:04 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-09-11 09:40:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 09:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 09:40:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 09:40:07 --> Total execution time: 0.1365
DEBUG - 2020-09-11 09:40:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:40:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 09:40:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-11 09:40:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 09:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 09:40:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 09:40:48 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 09:40:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 09:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 09:40:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 09:40:51 --> Total execution time: 0.1648
DEBUG - 2020-09-11 09:40:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:40:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 09:40:54 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-11 09:40:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:40:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 09:40:54 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-11 09:40:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:40:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 09:40:56 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-09-11 09:42:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:42:38 --> No URI present. Default controller set.
DEBUG - 2020-09-11 09:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 09:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 09:42:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 09:42:38 --> Total execution time: 0.1217
DEBUG - 2020-09-11 09:42:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 09:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 09:42:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 09:42:54 --> Total execution time: 0.1801
DEBUG - 2020-09-11 09:45:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:45:12 --> No URI present. Default controller set.
DEBUG - 2020-09-11 09:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 09:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 09:45:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 09:45:12 --> Total execution time: 0.1484
DEBUG - 2020-09-11 09:45:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 09:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 09:45:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 09:45:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 09:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 09:45:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 09:45:19 --> Total execution time: 0.1216
DEBUG - 2020-09-11 09:45:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:45:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 09:45:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-11 09:45:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:45:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 09:45:52 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-11 09:47:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 09:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 09:47:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 09:47:49 --> Total execution time: 0.1687
DEBUG - 2020-09-11 09:47:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:47:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 09:47:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-11 09:47:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:47:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 09:47:54 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-11 09:48:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:48:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 09:48:28 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-09-11 09:50:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:50:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 09:50:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 09:50:58 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-11 09:50:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 09:50:58 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-09-11 11:03:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:03:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:03:39 --> user_login->{"email":"admin@gmail.com","password":"e10adc3949ba59abbe56e057f20f883e"}
DEBUG - 2020-09-11 11:03:39 --> Total execution time: 0.1496
DEBUG - 2020-09-11 11:03:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:03:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:03:42 --> Total execution time: 0.1067
DEBUG - 2020-09-11 11:03:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:03:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:03:49 --> Total execution time: 0.1304
DEBUG - 2020-09-11 11:03:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:03:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:03:57 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2020-09-11 11:03:57 --> Total execution time: 0.1244
DEBUG - 2020-09-11 11:04:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:04:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:04:01 --> get_subcategory_list->{"lang":"37","category_id":"67","user_id":"1","support_lang_id":"1"}
DEBUG - 2020-09-11 11:04:01 --> Total execution time: 0.1052
DEBUG - 2020-09-11 11:04:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:04:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:04:16 --> get_exercise_type_list->{"lang":"37","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2020-09-11 11:04:16 --> Total execution time: 0.1008
DEBUG - 2020-09-11 11:04:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:04:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:04:21 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"1","exercise_mode_id":"1","category_id":"67","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2020-09-11 11:04:21 --> Total execution time: 0.2032
DEBUG - 2020-09-11 11:04:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:04:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 11:04:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-11 11:04:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:04:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:04:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 11:04:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-11 11:04:24 --> UTF-8 Support Enabled
ERROR - 2020-09-11 11:04:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-11 11:04:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 11:04:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-11 11:04:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:04:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 11:04:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-11 11:04:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:04:26 --> UTF-8 Support Enabled
ERROR - 2020-09-11 11:04:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-11 11:04:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 11:04:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-11 11:04:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:04:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 11:04:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-11 11:04:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:04:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 11:04:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-11 11:04:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:04:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 11:04:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-11 11:04:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:04:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 11:04:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-11 11:04:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:04:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 11:04:38 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-11 11:04:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:04:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:04:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:04:39 --> get_subcategory_list->{"lang":"37","category_id":"67","user_id":"1","support_lang_id":"1"}
DEBUG - 2020-09-11 11:04:39 --> Total execution time: 0.1403
DEBUG - 2020-09-11 11:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:04:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:04:39 --> get_exercise_type_list->{"lang":"37","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2020-09-11 11:04:39 --> Total execution time: 0.1174
DEBUG - 2020-09-11 11:04:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:04:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:04:40 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2020-09-11 11:04:40 --> Total execution time: 0.1477
DEBUG - 2020-09-11 11:04:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:04:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:04:44 --> get_subcategory_list->{"lang":"37","category_id":"78","user_id":"1","support_lang_id":"1"}
DEBUG - 2020-09-11 11:04:44 --> Total execution time: 0.1418
DEBUG - 2020-09-11 11:04:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:04:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:04:45 --> get_exercise_type_list->{"lang":"37","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2020-09-11 11:04:45 --> Total execution time: 0.1094
DEBUG - 2020-09-11 11:04:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:05:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:05:00 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"1","exercise_mode_id":"1","category_id":"78","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2020-09-11 11:05:00 --> Total execution time: 0.1314
DEBUG - 2020-09-11 11:05:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:05:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:05:03 --> get_exercise_type_list->{"lang":"37","subcategory_id":"156","support_lang_id":"1"}
DEBUG - 2020-09-11 11:05:03 --> Total execution time: 0.1026
DEBUG - 2020-09-11 11:05:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:05:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:05:04 --> get_subcategory_list->{"lang":"37","category_id":"78","user_id":"1","support_lang_id":"1"}
DEBUG - 2020-09-11 11:05:04 --> Total execution time: 0.1206
DEBUG - 2020-09-11 11:05:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:05:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:05:05 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2020-09-11 11:05:05 --> Total execution time: 0.1006
DEBUG - 2020-09-11 11:05:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:05:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:05:12 --> Total execution time: 0.1531
DEBUG - 2020-09-11 11:05:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:05:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:05:21 --> Total execution time: 0.1294
DEBUG - 2020-09-11 11:05:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:05:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:05:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:05:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 11:05:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-11 11:05:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 11:05:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-11 11:05:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 11:05:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-11 11:05:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:05:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 11:05:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-11 11:05:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:05:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:05:27 --> UTF-8 Support Enabled
ERROR - 2020-09-11 11:05:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-11 11:05:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 11:05:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-11 11:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:05:27 --> UTF-8 Support Enabled
ERROR - 2020-09-11 11:05:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-11 11:05:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-11 11:05:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2020-09-11 11:05:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:05:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:05:47 --> Total execution time: 0.1026
DEBUG - 2020-09-11 11:05:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:05:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:05:51 --> Total execution time: 0.1372
DEBUG - 2020-09-11 11:06:02 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:06:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:06:02 --> Total execution time: 0.1191
DEBUG - 2020-09-11 11:06:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:06:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:06:05 --> Total execution time: 0.1125
DEBUG - 2020-09-11 11:06:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:06:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:06:09 --> Total execution time: 0.1392
DEBUG - 2020-09-11 11:06:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:06:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:06:17 --> get_category_list->{"lang":"38","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-11 11:06:17 --> Total execution time: 0.1286
DEBUG - 2020-09-11 11:06:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:06:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:06:20 --> get_subcategory_list->{"lang":"38","category_id":"123","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-11 11:06:20 --> Total execution time: 0.1276
DEBUG - 2020-09-11 11:06:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:06:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:06:22 --> get_exercise_type_list->{"lang":"38","subcategory_id":"151","support_lang_id":"3"}
DEBUG - 2020-09-11 11:06:22 --> Total execution time: 0.1271
DEBUG - 2020-09-11 11:06:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:06:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:06:27 --> get_sorce_lan_word_type_8->{"slang":"38","tlang":"3","exercise_mode_id":"1","category_id":"123","subcategory_id":"151","support_lang_id":"3"}
DEBUG - 2020-09-11 11:06:27 --> Total execution time: 0.1622
DEBUG - 2020-09-11 11:06:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:06:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:06:31 --> get_exercise_type_list->{"lang":"38","subcategory_id":"151","support_lang_id":"3"}
DEBUG - 2020-09-11 11:06:31 --> Total execution time: 0.1002
DEBUG - 2020-09-11 11:06:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:06:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:06:34 --> get_subcategory_list->{"lang":"38","category_id":"123","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-11 11:06:34 --> Total execution time: 0.1590
DEBUG - 2020-09-11 11:06:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:06:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:06:35 --> get_exercise_type_list->{"lang":"38","subcategory_id":"273","support_lang_id":"3"}
DEBUG - 2020-09-11 11:06:35 --> Total execution time: 0.1303
DEBUG - 2020-09-11 11:06:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:06:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:06:37 --> get_subcategory_list->{"lang":"38","category_id":"123","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-11 11:06:37 --> Total execution time: 0.1063
DEBUG - 2020-09-11 11:06:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:06:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:06:37 --> get_category_list->{"lang":"38","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-11 11:06:37 --> Total execution time: 0.1321
DEBUG - 2020-09-11 11:06:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:06:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:06:46 --> Total execution time: 0.1601
DEBUG - 2020-09-11 11:06:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:06:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-11 11:06:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'as word
								FROM tbl_word  where subcategory_id='9' AND exercise_mode_id='1' at line 1 - Invalid query: SELECT  as word
								FROM tbl_word  where subcategory_id='9' AND exercise_mode_id='1' AND word_id!=4241 AND is_active='1'
ERROR - 2020-09-11 11:06:57 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_test_exercise_model.php 236
DEBUG - 2020-09-11 11:07:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:07:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-11 11:07:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'as word
								FROM tbl_word  where subcategory_id='141' AND exercise_mode_id=' at line 1 - Invalid query: SELECT  as word
								FROM tbl_word  where subcategory_id='141' AND exercise_mode_id='1' AND word_id!=2817 AND is_active='1'
ERROR - 2020-09-11 11:07:05 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_test_exercise_model.php 236
DEBUG - 2020-09-11 11:07:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:07:15 --> Total execution time: 0.1232
DEBUG - 2020-09-11 11:07:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:07:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-11 11:07:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'as word,word_id,image_file,word_english,audio_file,category_id,subcategory_id
	' at line 1 - Invalid query: SELECT  as word,word_id,image_file,word_english,audio_file,category_id,subcategory_id
								FROM tbl_word where  is_active='1' AND is_image_available='1' AND is_audio_available='1'  ORDER BY RAND()
LIMIT 10 
ERROR - 2020-09-11 11:07:27 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Api_test_exercise_model.php 291
DEBUG - 2020-09-11 11:07:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:07:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:07:37 --> get_category_list->{"lang":"38","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-11 11:07:37 --> Total execution time: 0.1072
DEBUG - 2020-09-11 11:07:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:07:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:07:41 --> get_subcategory_list->{"lang":"38","category_id":"125","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-11 11:07:41 --> Total execution time: 0.1354
DEBUG - 2020-09-11 11:07:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:07:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:07:42 --> get_exercise_type_list->{"lang":"38","subcategory_id":"273","support_lang_id":"3"}
DEBUG - 2020-09-11 11:07:42 --> Total execution time: 0.1112
DEBUG - 2020-09-11 11:07:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:07:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-11 11:07:46 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-09-11 11:07:46 --> Total execution time: 0.0991
DEBUG - 2020-09-11 11:07:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:07:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:07:52 --> get_exercise_type_list->{"lang":"38","subcategory_id":"273","support_lang_id":"3"}
DEBUG - 2020-09-11 11:07:52 --> Total execution time: 0.1152
DEBUG - 2020-09-11 11:07:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:07:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:07:53 --> get_subcategory_list->{"lang":"38","category_id":"125","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-11 11:07:53 --> Total execution time: 0.1493
DEBUG - 2020-09-11 11:07:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:07:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:07:54 --> get_category_list->{"lang":"38","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2020-09-11 11:07:54 --> Total execution time: 0.1591
DEBUG - 2020-09-11 11:08:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:08:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:08:11 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2020-09-11 11:08:11 --> Total execution time: 0.1043
DEBUG - 2020-09-11 11:08:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:08:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:08:12 --> get_subcategory_list->{"lang":"38","category_id":"125","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-11 11:08:12 --> Total execution time: 0.1115
DEBUG - 2020-09-11 11:08:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:08:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:08:15 --> get_exercise_type_list->{"lang":"38","subcategory_id":"275","support_lang_id":"3"}
DEBUG - 2020-09-11 11:08:15 --> Total execution time: 0.1304
DEBUG - 2020-09-11 11:08:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:08:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-11 11:08:22 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2020-09-11 11:08:22 --> Total execution time: 0.1148
DEBUG - 2020-09-11 11:08:26 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:08:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:08:26 --> get_subcategory_list->{"lang":"38","category_id":"125","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-11 11:08:26 --> Total execution time: 0.1454
DEBUG - 2020-09-11 11:08:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:08:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:08:27 --> get_exercise_type_list->{"lang":"38","subcategory_id":"275","support_lang_id":"3"}
DEBUG - 2020-09-11 11:08:27 --> Total execution time: 0.1114
DEBUG - 2020-09-11 11:08:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:08:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:08:27 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2020-09-11 11:08:27 --> Total execution time: 0.1577
DEBUG - 2020-09-11 11:08:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:08:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:08:46 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2020-09-11 11:08:46 --> Total execution time: 0.1379
DEBUG - 2020-09-11 11:08:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:08:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:08:50 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-11 11:08:50 --> Total execution time: 0.1555
DEBUG - 2020-09-11 11:08:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:08:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:08:55 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"3"}
DEBUG - 2020-09-11 11:08:55 --> Total execution time: 0.1704
DEBUG - 2020-09-11 11:09:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:09:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:09:00 --> get_dialogue_type_1->{"slang":"38","tlang":"3","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"3"}
DEBUG - 2020-09-11 11:09:00 --> Total execution time: 0.1245
DEBUG - 2020-09-11 11:09:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:09:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:09:10 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"3"}
DEBUG - 2020-09-11 11:09:10 --> Total execution time: 0.1284
DEBUG - 2020-09-11 11:09:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:09:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:09:11 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"1","support_lang_id":"3"}
DEBUG - 2020-09-11 11:09:11 --> Total execution time: 0.1423
DEBUG - 2020-09-11 11:09:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-11 11:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 11:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-11 11:09:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:09:16 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2020-09-11 11:09:16 --> Total execution time: 0.1356
