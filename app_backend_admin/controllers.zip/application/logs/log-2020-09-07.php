<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-09-07 11:07:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:07:28 --> No URI present. Default controller set.
DEBUG - 2020-09-07 11:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 11:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 11:07:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:07:29 --> Total execution time: 0.2046
DEBUG - 2020-09-07 11:07:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:07:35 --> No URI present. Default controller set.
DEBUG - 2020-09-07 11:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 11:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 11:07:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:07:35 --> Total execution time: 0.1293
DEBUG - 2020-09-07 11:07:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 11:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 11:07:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:07:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 11:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 11:07:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:07:57 --> Total execution time: 0.2005
DEBUG - 2020-09-07 11:08:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:08:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-07 11:08:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-07 11:08:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 11:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 11:08:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:08:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:08:10 --> Total execution time: 0.1533
DEBUG - 2020-09-07 11:08:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 11:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 11:08:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:08:13 --> Total execution time: 0.2217
DEBUG - 2020-09-07 11:08:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:08:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-07 11:08:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-07 11:08:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:08:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-07 11:08:16 --> 404 Page Not Found: Uploads/badger.jpg
DEBUG - 2020-09-07 11:08:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 11:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 11:08:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:08:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:08:32 --> Total execution time: 0.1505
DEBUG - 2020-09-07 11:08:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 11:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 11:08:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:08:35 --> Total execution time: 0.1825
DEBUG - 2020-09-07 11:08:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-07 11:08:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-07 11:08:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:08:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-07 11:08:40 --> 404 Page Not Found: Uploads/test.jpg
DEBUG - 2020-09-07 11:08:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:08:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-07 11:08:47 --> 404 Page Not Found: Uploads/entertainment.jpg
DEBUG - 2020-09-07 11:10:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 11:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 11:10:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:10:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 11:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 11:10:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:11:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:11:00 --> No URI present. Default controller set.
DEBUG - 2020-09-07 11:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 11:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 11:11:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:11:00 --> Total execution time: 0.1960
DEBUG - 2020-09-07 11:11:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:13:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:13:32 --> No URI present. Default controller set.
DEBUG - 2020-09-07 11:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 11:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 11:13:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:13:33 --> Total execution time: 0.1653
DEBUG - 2020-09-07 11:13:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 11:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 11:13:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:13:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 11:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 11:13:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:13:39 --> Total execution time: 0.1126
DEBUG - 2020-09-07 11:13:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:13:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-07 11:13:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-07 11:24:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 11:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 11:24:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:24:17 --> Total execution time: 0.1502
DEBUG - 2020-09-07 11:24:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 11:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 11:24:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:24:19 --> Total execution time: 0.1746
DEBUG - 2020-09-07 11:24:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:24:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-07 11:24:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-07 11:48:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 11:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 11:48:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:49:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:49:57 --> No URI present. Default controller set.
DEBUG - 2020-09-07 11:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 11:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 11:49:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:49:57 --> Total execution time: 0.2041
DEBUG - 2020-09-07 11:50:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 11:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 11:50:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:50:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 11:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 11:50:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:50:18 --> Total execution time: 0.2274
DEBUG - 2020-09-07 11:50:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:50:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-07 11:50:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-07 11:54:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:54:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-07 11:54:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-07 11:54:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 11:54:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-07 11:54:23 --> 404 Page Not Found: Assets/js
DEBUG - 2020-09-07 12:36:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 12:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 12:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 12:36:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 12:36:42 --> Total execution time: 0.1602
DEBUG - 2020-09-07 13:56:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 13:56:44 --> No URI present. Default controller set.
DEBUG - 2020-09-07 13:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 13:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 13:56:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 13:56:44 --> Total execution time: 0.1588
DEBUG - 2020-09-07 13:56:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 13:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 13:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 13:56:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 13:56:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 13:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 13:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 13:56:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 13:56:49 --> Total execution time: 0.1383
DEBUG - 2020-09-07 13:57:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 13:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 13:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 13:57:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 13:57:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 13:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-07 13:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-07 13:57:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 13:57:12 --> Total execution time: 0.1115
DEBUG - 2020-09-07 13:57:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 13:57:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-07 13:57:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-07 13:57:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 13:57:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-07 13:57:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-07 13:57:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-07 13:57:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-07 13:57:43 --> 404 Page Not Found: Assets/js
