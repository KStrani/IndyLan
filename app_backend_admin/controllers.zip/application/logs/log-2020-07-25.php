<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-07-25 10:25:07 --> UTF-8 Support Enabled
DEBUG - 2020-07-25 10:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-07-25 10:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-07-25 10:25:10 --> Session class already loaded. Second attempt ignored.
