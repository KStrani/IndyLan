<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-02-03 05:06:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:06:50 --> No URI present. Default controller set.
DEBUG - 2021-02-03 05:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:06:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:06:50 --> Total execution time: 0.1651
DEBUG - 2021-02-03 05:07:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:07:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:07:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:07:15 --> Total execution time: 0.1420
DEBUG - 2021-02-03 05:07:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:07:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:07:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:07:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:07:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:07:31 --> Total execution time: 0.1276
DEBUG - 2021-02-03 05:07:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:07:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:07:32 --> Total execution time: 0.1583
DEBUG - 2021-02-03 05:07:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:07:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:07:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:07:33 --> Total execution time: 0.1455
DEBUG - 2021-02-03 05:07:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:07:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:07:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:07:34 --> Total execution time: 0.1187
DEBUG - 2021-02-03 05:07:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:07:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:07:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:07:38 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 05:07:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:07:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:07:41 --> Total execution time: 0.1438
DEBUG - 2021-02-03 05:07:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:07:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:07:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:07:43 --> Total execution time: 0.1478
DEBUG - 2021-02-03 05:07:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:07:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:07:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:07:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:07:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:07:45 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 05:08:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:08:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:08:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:08:11 --> Total execution time: 0.1670
DEBUG - 2021-02-03 05:08:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:08:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:08:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:08:14 --> 404 Page Not Found: Uploads/words
ERROR - 2021-02-03 05:08:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:08:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:08:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:08:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 05:08:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:08:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:10:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:10:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:10:16 --> Total execution time: 0.1046
DEBUG - 2021-02-03 05:10:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:10:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:10:21 --> Total execution time: 0.1474
DEBUG - 2021-02-03 05:10:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:10:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:10:28 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 05:10:28 --> Total execution time: 0.1508
DEBUG - 2021-02-03 05:10:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:10:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:10:32 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 05:10:32 --> Total execution time: 0.1349
DEBUG - 2021-02-03 05:10:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:10:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:10:36 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 05:10:36 --> Total execution time: 0.1522
DEBUG - 2021-02-03 05:10:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:10:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:10:40 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-02-03 05:10:40 --> Total execution time: 0.1295
DEBUG - 2021-02-03 05:12:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:12:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:12:11 --> Total execution time: 0.1301
DEBUG - 2021-02-03 05:12:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:12:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:12:12 --> Total execution time: 0.1225
DEBUG - 2021-02-03 05:12:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:12:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:12:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 05:12:13 --> Total execution time: 0.1515
DEBUG - 2021-02-03 05:12:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:12:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:12:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 05:12:15 --> Total execution time: 0.1563
DEBUG - 2021-02-03 05:12:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:12:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:12:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:14:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:14:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:14:34 --> Total execution time: 0.1492
DEBUG - 2021-02-03 05:14:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:14:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:14:36 --> Total execution time: 0.1257
DEBUG - 2021-02-03 05:14:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:14:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:14:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:14:37 --> Total execution time: 0.1426
DEBUG - 2021-02-03 05:14:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:14:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:14:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:14:39 --> Total execution time: 0.1424
DEBUG - 2021-02-03 05:14:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:14:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:14:41 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:14:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:14:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:14:41 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 05:15:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:15:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:15:49 --> Total execution time: 0.1377
DEBUG - 2021-02-03 05:15:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:15:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:15:52 --> Total execution time: 0.1251
DEBUG - 2021-02-03 05:15:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:15:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:15:54 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:17:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:17:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:17:18 --> Total execution time: 0.1423
DEBUG - 2021-02-03 05:17:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:17:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:17:22 --> Total execution time: 0.1274
DEBUG - 2021-02-03 05:17:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:17:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:17:38 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:17:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:17:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:17:41 --> Total execution time: 0.1539
DEBUG - 2021-02-03 05:17:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:17:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:17:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:17:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:17:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:17:48 --> Total execution time: 0.1859
DEBUG - 2021-02-03 05:17:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:17:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:17:49 --> Total execution time: 0.1637
DEBUG - 2021-02-03 05:17:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:17:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:17:51 --> Total execution time: 0.1721
DEBUG - 2021-02-03 05:17:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:17:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:17:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:17:51 --> Total execution time: 0.1603
DEBUG - 2021-02-03 05:17:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:17:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:17:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:17:52 --> Total execution time: 0.1324
DEBUG - 2021-02-03 05:17:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:17:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:17:53 --> Total execution time: 0.1448
DEBUG - 2021-02-03 05:17:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:17:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:17:53 --> Total execution time: 0.1351
DEBUG - 2021-02-03 05:17:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:17:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:17:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:17:53 --> Total execution time: 0.1411
DEBUG - 2021-02-03 05:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:17:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:17:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:17:53 --> Total execution time: 0.1897
DEBUG - 2021-02-03 05:17:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:17:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:17:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:17:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:17:55 --> Total execution time: 0.1661
DEBUG - 2021-02-03 05:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:17:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:17:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:17:55 --> Total execution time: 0.1478
DEBUG - 2021-02-03 05:17:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:17:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:17:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:17:55 --> Total execution time: 0.1613
DEBUG - 2021-02-03 05:17:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:17:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:17:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:18:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:18:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:18:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:18:14 --> Total execution time: 0.1709
DEBUG - 2021-02-03 05:18:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:18:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:18:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:18:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:18:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:18:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 05:18:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:18:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:18:39 --> Total execution time: 0.1447
DEBUG - 2021-02-03 05:18:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:18:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:18:41 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:18:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:18:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:18:51 --> Total execution time: 0.1708
DEBUG - 2021-02-03 05:20:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:20:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:20:20 --> Total execution time: 0.1403
DEBUG - 2021-02-03 05:20:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:20:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:20:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:22:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:22:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:22:14 --> Total execution time: 0.1839
DEBUG - 2021-02-03 05:22:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:22:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:22:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:22:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:22:36 --> Total execution time: 0.1595
DEBUG - 2021-02-03 05:22:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:22:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:22:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:25:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:25:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:25:50 --> Total execution time: 0.1370
DEBUG - 2021-02-03 05:25:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:25:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:25:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:26:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:26:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:26:03 --> Total execution time: 0.1258
DEBUG - 2021-02-03 05:26:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:26:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:26:04 --> Total execution time: 0.1154
DEBUG - 2021-02-03 05:26:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:26:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:26:05 --> Total execution time: 0.1169
DEBUG - 2021-02-03 05:26:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:26:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:26:07 --> Total execution time: 0.1349
DEBUG - 2021-02-03 05:26:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:26:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:26:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:26:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:26:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:26:35 --> Total execution time: 0.1463
DEBUG - 2021-02-03 05:26:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:26:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:27:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:27:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:27:22 --> Total execution time: 0.1145
DEBUG - 2021-02-03 05:27:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:27:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:27:22 --> Query error: Unknown column 'mode_name' in 'order clause' - Invalid query: SELECT *
FROM `tbl_exercise_type`
WHERE `exercise_mode_id` = '5'
ORDER BY `mode_name` ASC
ERROR - 2021-02-03 05:27:22 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 980
DEBUG - 2021-02-03 05:30:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:30:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:30:50 --> Total execution time: 0.1353
DEBUG - 2021-02-03 05:30:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:30:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:30:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:31:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:31:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:31:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:31:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:31:20 --> Total execution time: 0.1534
DEBUG - 2021-02-03 05:31:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:31:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:31:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:31:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:31:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:31:44 --> Total execution time: 0.1238
DEBUG - 2021-02-03 05:31:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:31:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:31:46 --> Total execution time: 0.1517
DEBUG - 2021-02-03 05:31:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:31:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:31:47 --> Total execution time: 0.1762
DEBUG - 2021-02-03 05:31:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:31:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:31:47 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:31:47 --> Total execution time: 0.2012
DEBUG - 2021-02-03 05:31:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:31:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:31:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:31:49 --> Total execution time: 0.1594
DEBUG - 2021-02-03 05:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:31:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:31:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:31:49 --> Total execution time: 0.1690
DEBUG - 2021-02-03 05:31:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:31:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:31:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:31:49 --> Total execution time: 0.1819
DEBUG - 2021-02-03 05:31:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:31:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:31:50 --> Total execution time: 0.1575
DEBUG - 2021-02-03 05:31:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:31:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:31:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:31:52 --> Total execution time: 0.1588
DEBUG - 2021-02-03 05:31:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:31:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:31:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:31:52 --> Total execution time: 0.1546
DEBUG - 2021-02-03 05:31:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:31:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:31:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:32:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:32:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:32:01 --> Total execution time: 0.1190
DEBUG - 2021-02-03 05:32:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:32:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:32:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:32:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:32:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:32:13 --> Total execution time: 0.1361
DEBUG - 2021-02-03 05:32:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:32:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:33:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:33:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:33:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:33:00 --> Total execution time: 0.1286
DEBUG - 2021-02-03 05:33:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:33:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:33:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:33:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:33:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:33:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:33:11 --> Total execution time: 0.1697
DEBUG - 2021-02-03 05:33:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:33:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:33:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:33:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:33:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:33:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 05:33:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:33:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:33:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 05:34:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:34:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:34:40 --> Total execution time: 0.1858
DEBUG - 2021-02-03 05:34:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:34:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:34:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:34:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:34:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:34:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 05:34:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:34:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:34:56 --> Total execution time: 0.1261
DEBUG - 2021-02-03 05:34:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:34:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:34:57 --> Total execution time: 0.1878
DEBUG - 2021-02-03 05:34:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:34:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:34:57 --> Total execution time: 0.1450
DEBUG - 2021-02-03 05:34:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:34:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:34:57 --> Total execution time: 0.1268
DEBUG - 2021-02-03 05:34:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:34:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:34:59 --> Total execution time: 0.1889
DEBUG - 2021-02-03 05:35:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:35:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:35:00 --> Total execution time: 0.1708
DEBUG - 2021-02-03 05:35:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:35:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:35:00 --> Total execution time: 0.1744
DEBUG - 2021-02-03 05:35:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:35:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:35:00 --> Total execution time: 0.1673
DEBUG - 2021-02-03 05:35:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:35:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:35:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:35:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:35:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:35:22 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:35:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:35:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:35:25 --> Total execution time: 0.1552
DEBUG - 2021-02-03 05:35:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:35:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:35:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:35:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:35:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:35:32 --> Total execution time: 0.1241
DEBUG - 2021-02-03 05:35:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:35:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:35:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:35:35 --> Total execution time: 0.1301
DEBUG - 2021-02-03 05:35:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:35:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:35:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:35:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:35:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:35:46 --> Total execution time: 0.1832
DEBUG - 2021-02-03 05:35:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:35:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:35:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:35:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:35:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:35:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 05:35:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:35:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:35:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 05:35:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:35:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:35:56 --> Total execution time: 0.1326
DEBUG - 2021-02-03 05:35:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:35:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:35:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:35:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:35:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:35:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 05:36:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:36:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:36:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:36:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:36:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:36:13 --> Total execution time: 0.1457
DEBUG - 2021-02-03 05:36:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:36:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:36:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:36:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:36:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 05:36:23 --> Total execution time: 0.1968
DEBUG - 2021-02-03 05:36:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:36:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:36:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:36:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:36:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:36:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 05:36:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:36:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:36:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 05:37:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:37:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:37:59 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 05:37:59 --> Total execution time: 0.1747
DEBUG - 2021-02-03 05:38:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:38:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:38:04 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 05:38:04 --> Total execution time: 0.1516
DEBUG - 2021-02-03 05:38:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:38:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:38:08 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 05:38:08 --> Total execution time: 0.1609
DEBUG - 2021-02-03 05:38:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:38:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:38:26 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 05:38:26 --> Total execution time: 0.1275
DEBUG - 2021-02-03 05:38:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:38:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:38:30 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 05:38:30 --> Total execution time: 0.1348
DEBUG - 2021-02-03 05:38:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:38:35 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 05:38:35 --> Total execution time: 0.1262
DEBUG - 2021-02-03 05:38:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:38:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:38:39 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-02-03 05:38:39 --> Total execution time: 0.1357
DEBUG - 2021-02-03 05:38:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:38:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:38:48 --> Total execution time: 0.1084
DEBUG - 2021-02-03 05:38:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:38:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:38:49 --> Total execution time: 0.1355
DEBUG - 2021-02-03 05:38:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:38:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:38:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 05:38:50 --> Total execution time: 0.1488
DEBUG - 2021-02-03 05:38:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:38:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:38:51 --> Total execution time: 0.1442
DEBUG - 2021-02-03 05:38:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:38:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:38:52 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 05:38:52 --> Total execution time: 0.1332
DEBUG - 2021-02-03 05:38:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:38:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:38:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 05:38:54 --> Total execution time: 0.1621
DEBUG - 2021-02-03 05:38:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:38:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:40:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:40:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:51:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:51:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:51:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 05:51:02 --> Total execution time: 0.1225
DEBUG - 2021-02-03 05:51:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:51:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:51:04 --> Total execution time: 0.1214
DEBUG - 2021-02-03 05:51:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:51:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:51:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 05:51:04 --> Total execution time: 0.1165
DEBUG - 2021-02-03 05:51:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:51:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:51:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:51:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:51:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:51:16 --> Total execution time: 0.1201
DEBUG - 2021-02-03 05:51:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:51:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:51:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 05:51:18 --> Total execution time: 0.1922
DEBUG - 2021-02-03 05:51:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:51:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:51:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:51:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:51:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:51:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 05:51:27 --> Total execution time: 0.1399
DEBUG - 2021-02-03 05:51:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:51:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:51:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 05:51:30 --> Total execution time: 0.1618
DEBUG - 2021-02-03 05:51:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:51:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:51:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:51:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:51:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:51:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:51:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:51:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 05:51:58 --> Total execution time: 0.1373
DEBUG - 2021-02-03 05:52:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:52:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:52:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:54:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:54:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:54:07 --> Total execution time: 0.1318
DEBUG - 2021-02-03 05:54:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:54:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:54:12 --> Total execution time: 0.1135
DEBUG - 2021-02-03 05:54:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:54:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:54:18 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 05:54:18 --> Total execution time: 0.1305
DEBUG - 2021-02-03 05:54:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:54:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:54:22 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 05:54:22 --> Total execution time: 0.1173
DEBUG - 2021-02-03 05:54:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:54:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:54:25 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 05:54:25 --> Total execution time: 0.1169
DEBUG - 2021-02-03 05:54:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:54:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:54:29 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-02-03 05:54:29 --> Total execution time: 0.1329
DEBUG - 2021-02-03 05:54:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:54:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:54:40 --> Total execution time: 0.1285
DEBUG - 2021-02-03 05:54:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:54:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:54:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:55:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:55:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:55:04 --> Total execution time: 0.1429
DEBUG - 2021-02-03 05:55:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:55:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:55:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:55:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:55:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:55:45 --> Total execution time: 0.1120
DEBUG - 2021-02-03 05:57:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:57:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:57:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:57:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:57:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 05:57:27 --> Total execution time: 0.1399
DEBUG - 2021-02-03 05:57:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:57:29 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:58:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:58:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:58:18 --> Total execution time: 0.1291
DEBUG - 2021-02-03 05:58:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:58:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:58:19 --> Total execution time: 0.1241
DEBUG - 2021-02-03 05:58:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:58:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:58:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-03 05:58:21 --> Total execution time: 0.1453
DEBUG - 2021-02-03 05:58:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:58:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:58:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-03 05:58:21 --> Total execution time: 0.1437
DEBUG - 2021-02-03 05:58:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:58:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:58:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:58:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:58:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:58:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 05:58:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:58:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 05:58:31 --> Total execution time: 0.1418
DEBUG - 2021-02-03 05:58:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:58:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 05:58:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-03 05:58:34 --> Total execution time: 0.1329
DEBUG - 2021-02-03 05:58:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:58:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:58:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 05:58:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:58:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 05:58:36 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 05:59:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 05:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 05:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 05:59:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:05:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:05:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:05:22 --> Total execution time: 0.1433
DEBUG - 2021-02-03 06:05:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:05:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:05:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:05:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:05:32 --> Total execution time: 0.1363
DEBUG - 2021-02-03 06:05:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:05:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:05:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:05:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:05:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:05:45 --> Total execution time: 0.1500
DEBUG - 2021-02-03 06:05:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:05:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:05:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 06:05:48 --> Total execution time: 0.1397
DEBUG - 2021-02-03 06:05:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:05:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:06:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:06:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:06:01 --> Total execution time: 0.1696
DEBUG - 2021-02-03 06:06:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:06:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:06:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 06:06:04 --> Total execution time: 0.1451
DEBUG - 2021-02-03 06:06:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:06:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:06:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:06:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:06:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:06:12 --> Total execution time: 0.1359
DEBUG - 2021-02-03 06:06:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:06:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:06:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 06:06:15 --> Total execution time: 0.1345
DEBUG - 2021-02-03 06:06:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:06:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:06:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:06:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:06:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:06:31 --> Total execution time: 0.1526
DEBUG - 2021-02-03 06:06:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:06:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:06:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 06:06:33 --> Total execution time: 0.1521
DEBUG - 2021-02-03 06:06:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:06:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:06:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:06:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:06:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:06:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 06:06:43 --> Total execution time: 0.1996
DEBUG - 2021-02-03 06:06:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:06:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:06:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:06:46 --> 404 Page Not Found: Assets/chosen
ERROR - 2021-02-03 06:06:46 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 06:06:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:06:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:06:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 06:07:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:07:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:07:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 06:07:04 --> Total execution time: 0.1330
DEBUG - 2021-02-03 06:07:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:07:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:07:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:07:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:07:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:07:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:07:31 --> Total execution time: 0.1556
DEBUG - 2021-02-03 06:07:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:07:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:07:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 06:07:34 --> Total execution time: 0.1572
DEBUG - 2021-02-03 06:07:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:07:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:07:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:07:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:07:54 --> Total execution time: 0.1294
DEBUG - 2021-02-03 06:07:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:07:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:07:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 06:07:58 --> Total execution time: 0.1769
DEBUG - 2021-02-03 06:08:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:08:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:08:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:08:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:08:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:08:05 --> Total execution time: 0.1528
DEBUG - 2021-02-03 06:08:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:08:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:08:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-03 06:08:08 --> Total execution time: 0.1800
DEBUG - 2021-02-03 06:08:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:08:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:08:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:08:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:08:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:08:34 --> Total execution time: 0.1769
DEBUG - 2021-02-03 06:08:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:08:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:08:36 --> Total execution time: 0.1619
DEBUG - 2021-02-03 06:08:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:08:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:17:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:17:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:17:07 --> Total execution time: 0.1601
DEBUG - 2021-02-03 06:17:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:17:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:17:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-03 06:17:09 --> Total execution time: 0.1577
DEBUG - 2021-02-03 06:17:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:17:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:17:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:17:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:17:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:17:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 06:17:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:17:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:17:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-03 06:17:17 --> Total execution time: 0.1689
DEBUG - 2021-02-03 06:17:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:17:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:17:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-03 06:17:20 --> Total execution time: 0.1164
DEBUG - 2021-02-03 06:17:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:17:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:17:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:17:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:17:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:17:23 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 06:17:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:17:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:18:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:18:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:18:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-03 06:18:00 --> Total execution time: 0.1419
DEBUG - 2021-02-03 06:18:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:18:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:18:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:18:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:18:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:18:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 06:18:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:18:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:18:06 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 06:18:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:18:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:18:35 --> Total execution time: 0.1285
DEBUG - 2021-02-03 06:18:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:18:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:18:36 --> Total execution time: 0.1596
DEBUG - 2021-02-03 06:18:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:18:37 --> Total execution time: 0.1736
DEBUG - 2021-02-03 06:18:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:18:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:18:37 --> Total execution time: 0.1465
DEBUG - 2021-02-03 06:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:18:37 --> Total execution time: 0.1827
DEBUG - 2021-02-03 06:18:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:18:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:18:38 --> Total execution time: 0.1589
DEBUG - 2021-02-03 06:18:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:18:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:18:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:18:39 --> Total execution time: 0.1450
DEBUG - 2021-02-03 06:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:18:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:18:39 --> Total execution time: 0.1451
DEBUG - 2021-02-03 06:18:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:18:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:18:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:18:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:18:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:18:45 --> Total execution time: 0.1180
DEBUG - 2021-02-03 06:18:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:18:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:18:48 --> Total execution time: 0.1414
DEBUG - 2021-02-03 06:18:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:18:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:18:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:18:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:18:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:18:55 --> Total execution time: 0.1499
DEBUG - 2021-02-03 06:18:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:18:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:18:59 --> Total execution time: 0.1342
DEBUG - 2021-02-03 06:19:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:19:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:19:18 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:19:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:19:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:19:20 --> Total execution time: 0.1373
DEBUG - 2021-02-03 06:19:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:19:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:19:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:19:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:19:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:19:35 --> Total execution time: 0.1470
DEBUG - 2021-02-03 06:19:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:19:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:19:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-03 06:19:38 --> Total execution time: 0.1358
DEBUG - 2021-02-03 06:19:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:19:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:19:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:19:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:19:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:19:40 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 06:19:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:19:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:19:43 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 06:22:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:22:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:22:53 --> Total execution time: 0.1320
DEBUG - 2021-02-03 06:22:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:22:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:22:57 --> Total execution time: 0.1099
DEBUG - 2021-02-03 06:23:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:23:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:23:02 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:23:02 --> Total execution time: 0.1111
DEBUG - 2021-02-03 06:23:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:23:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:23:05 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:23:05 --> Total execution time: 0.1425
DEBUG - 2021-02-03 06:23:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:23:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:23:09 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:23:09 --> Total execution time: 0.1131
DEBUG - 2021-02-03 06:23:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:23:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:23:17 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:23:17 --> Total execution time: 0.1186
DEBUG - 2021-02-03 06:23:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:23:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:23:20 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 06:23:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:23:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:23:23 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 06:23:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:23:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:23:24 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:23:24 --> Total execution time: 0.1373
DEBUG - 2021-02-03 06:23:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:23:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:23:28 --> get_sorce_lan_word_type_6->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:23:28 --> Total execution time: 0.1413
DEBUG - 2021-02-03 06:23:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:23:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:23:35 --> Total execution time: 0.1129
DEBUG - 2021-02-03 06:23:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:23:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:23:47 --> Total execution time: 0.1425
DEBUG - 2021-02-03 06:23:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:23:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:23:51 --> Total execution time: 0.1343
DEBUG - 2021-02-03 06:23:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:23:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:23:56 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:23:56 --> Total execution time: 0.1366
DEBUG - 2021-02-03 06:23:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:23:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:23:59 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:23:59 --> Total execution time: 0.1207
DEBUG - 2021-02-03 06:24:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:24:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:24:04 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:24:04 --> Total execution time: 0.1730
DEBUG - 2021-02-03 06:24:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:24:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:24:12 --> get_sorce_lan_word_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:24:12 --> Total execution time: 0.1609
DEBUG - 2021-02-03 06:24:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:24:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:24:30 --> Total execution time: 0.1293
DEBUG - 2021-02-03 06:24:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:24:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:24:54 --> Total execution time: 0.1123
DEBUG - 2021-02-03 06:25:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:25:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:25:15 --> Total execution time: 0.1229
DEBUG - 2021-02-03 06:25:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:25:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:25:21 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:25:21 --> Total execution time: 0.1071
DEBUG - 2021-02-03 06:25:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:25:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:25:25 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:25:25 --> Total execution time: 0.1570
DEBUG - 2021-02-03 06:25:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:25:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:25:29 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:25:29 --> Total execution time: 0.1514
DEBUG - 2021-02-03 06:25:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:25:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:25:36 --> get_sorce_lan_word_type_5->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:25:36 --> Total execution time: 0.1199
DEBUG - 2021-02-03 06:25:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:25:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:25:39 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 06:25:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:25:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:25:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 06:26:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:26:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:26:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 06:26:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:26:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:26:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 06:26:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:26:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:26:55 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:26:55 --> Total execution time: 0.1370
DEBUG - 2021-02-03 06:27:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:27:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:27:05 --> get_sorce_lan_word_type_4->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:27:05 --> Total execution time: 0.1497
DEBUG - 2021-02-03 06:27:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:27:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:27:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 06:27:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:27:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:27:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 06:27:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:27:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:27:12 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 06:27:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:27:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:27:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 06:27:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:27:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:27:32 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:27:32 --> Total execution time: 0.1166
DEBUG - 2021-02-03 06:27:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:27:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:27:37 --> get_sorce_lan_word_type_7->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:27:37 --> Total execution time: 0.1159
DEBUG - 2021-02-03 06:28:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:28:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:28:25 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:28:25 --> Total execution time: 0.1214
DEBUG - 2021-02-03 06:28:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:28:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:28:30 --> get_sorce_lan_word_type_3->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:28:30 --> Total execution time: 0.1885
DEBUG - 2021-02-03 06:28:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:28:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:28:56 --> Total execution time: 0.1512
DEBUG - 2021-02-03 06:29:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:29:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:29:22 --> Total execution time: 0.1112
DEBUG - 2021-02-03 06:29:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:29:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:29:26 --> Total execution time: 0.1776
DEBUG - 2021-02-03 06:29:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:29:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:29:36 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:29:36 --> Total execution time: 0.1404
DEBUG - 2021-02-03 06:29:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:29:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:29:39 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:29:39 --> Total execution time: 0.1494
DEBUG - 2021-02-03 06:29:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:29:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:29:43 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:29:43 --> Total execution time: 0.1366
DEBUG - 2021-02-03 06:29:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:29:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:29:50 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:29:50 --> Total execution time: 0.1185
DEBUG - 2021-02-03 06:29:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:29:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:29:53 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:29:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:29:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 06:29:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:29:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:29:59 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 06:30:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:30:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:30:02 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 06:30:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:30:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:30:22 --> Total execution time: 0.1301
DEBUG - 2021-02-03 06:30:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:30:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:30:35 --> Total execution time: 0.1293
DEBUG - 2021-02-03 06:30:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:30:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:30:42 --> Total execution time: 0.1186
DEBUG - 2021-02-03 06:30:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:30:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:30:48 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:30:48 --> Total execution time: 0.1189
DEBUG - 2021-02-03 06:30:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:30:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:30:52 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:30:52 --> Total execution time: 0.1135
DEBUG - 2021-02-03 06:30:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:30:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:30:56 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:30:56 --> Total execution time: 0.1119
DEBUG - 2021-02-03 06:31:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:31:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:31:17 --> get_sorce_lan_word_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:31:17 --> Total execution time: 0.1722
DEBUG - 2021-02-03 06:31:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:31:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:31:26 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:31:26 --> Total execution time: 0.1459
DEBUG - 2021-02-03 06:31:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:31:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:31:32 --> get_sorce_lan_word_type_6->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:31:32 --> Total execution time: 0.1288
DEBUG - 2021-02-03 06:31:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:31:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:31:39 --> Total execution time: 0.1196
DEBUG - 2021-02-03 06:31:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:31:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:31:50 --> Total execution time: 0.1465
DEBUG - 2021-02-03 06:31:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:31:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:31:59 --> Total execution time: 0.1332
DEBUG - 2021-02-03 06:32:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:32:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:32:24 --> Total execution time: 0.1386
DEBUG - 2021-02-03 06:32:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:32:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:32:24 --> Total execution time: 0.1471
DEBUG - 2021-02-03 06:32:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:32:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:32:26 --> Total execution time: 0.1343
DEBUG - 2021-02-03 06:32:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:32:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:32:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:32:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:32:26 --> Total execution time: 0.1744
DEBUG - 2021-02-03 06:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:32:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:32:26 --> Total execution time: 0.1567
DEBUG - 2021-02-03 06:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:32:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:32:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 06:32:27 --> Total execution time: 0.1640
DEBUG - 2021-02-03 06:32:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:32:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:32:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 06:32:28 --> Total execution time: 0.1380
DEBUG - 2021-02-03 06:32:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:32:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:32:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 06:32:29 --> Total execution time: 0.1510
DEBUG - 2021-02-03 06:32:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:32:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:32:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:32:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 06:32:29 --> Total execution time: 0.1435
DEBUG - 2021-02-03 06:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:32:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:32:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 06:32:29 --> Total execution time: 0.2083
DEBUG - 2021-02-03 06:32:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:32:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:33:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:33:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:33:32 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 06:33:32 --> Total execution time: 0.1567
DEBUG - 2021-02-03 06:33:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:33:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:35:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:35:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:35:33 --> Total execution time: 0.1404
DEBUG - 2021-02-03 06:35:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:35:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:35:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 06:35:36 --> Total execution time: 0.1345
DEBUG - 2021-02-03 06:35:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:35:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:35:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:35:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:35:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:35:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 06:35:43 --> Total execution time: 0.1853
DEBUG - 2021-02-03 06:35:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:35:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:35:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 06:35:45 --> Total execution time: 0.1469
DEBUG - 2021-02-03 06:35:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:35:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:35:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:36:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:36:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:36:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:36:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:36:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 06:36:56 --> Total execution time: 0.1698
DEBUG - 2021-02-03 06:36:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:36:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:36:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:37:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:37:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:37:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 06:37:09 --> Total execution time: 0.1482
DEBUG - 2021-02-03 06:37:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:37:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:37:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:37:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:37:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:37:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:37:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:37:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 06:37:37 --> Total execution time: 0.1495
DEBUG - 2021-02-03 06:37:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:37:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:37:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:39:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:39:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:39:03 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 06:39:03 --> Total execution time: 0.1537
DEBUG - 2021-02-03 06:39:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:39:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:39:08 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:39:08 --> Total execution time: 0.1564
DEBUG - 2021-02-03 06:39:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:39:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:39:12 --> get_exercise_type_list->{"lang":"37","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-03 06:39:12 --> Total execution time: 0.1409
DEBUG - 2021-02-03 06:39:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:39:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:39:15 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-02-03 06:39:15 --> Total execution time: 0.1348
DEBUG - 2021-02-03 06:39:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:39:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:39:41 --> Total execution time: 0.1544
DEBUG - 2021-02-03 06:39:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:39:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:39:41 --> Total execution time: 0.1311
DEBUG - 2021-02-03 06:39:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:39:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:39:42 --> Total execution time: 0.1532
DEBUG - 2021-02-03 06:39:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:39:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:39:42 --> Total execution time: 0.2123
DEBUG - 2021-02-03 06:39:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:39:43 --> Total execution time: 0.1562
DEBUG - 2021-02-03 06:39:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:39:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:39:43 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 06:39:43 --> Total execution time: 0.1868
DEBUG - 2021-02-03 06:39:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:39:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:39:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 06:39:44 --> Total execution time: 0.1797
DEBUG - 2021-02-03 06:39:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:39:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:39:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 06:39:44 --> Total execution time: 0.2176
DEBUG - 2021-02-03 06:39:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:39:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:39:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 06:39:46 --> Total execution time: 0.1530
DEBUG - 2021-02-03 06:39:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:39:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:39:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 06:39:46 --> Total execution time: 0.1748
DEBUG - 2021-02-03 06:39:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:39:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:39:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:40:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:40:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:45:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:45:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:45:36 --> Total execution time: 0.1353
DEBUG - 2021-02-03 06:45:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:45:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:45:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 06:45:39 --> Total execution time: 0.1640
DEBUG - 2021-02-03 06:45:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:45:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:45:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 06:45:41 --> Total execution time: 0.1325
DEBUG - 2021-02-03 06:45:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:45:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:45:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:45:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:45:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:45:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 06:45:48 --> Total execution time: 0.1723
DEBUG - 2021-02-03 06:45:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:45:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:45:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 06:45:51 --> Total execution time: 0.1227
DEBUG - 2021-02-03 06:45:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:45:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:45:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:46:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:46:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:46:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:46:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:46:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 06:46:29 --> Total execution time: 0.1401
DEBUG - 2021-02-03 06:46:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:46:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 06:46:31 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 06:47:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:47:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:47:03 --> Total execution time: 0.1257
DEBUG - 2021-02-03 06:47:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:47:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:47:08 --> Total execution time: 0.1554
DEBUG - 2021-02-03 06:47:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:47:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:47:14 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 06:47:14 --> Total execution time: 0.1034
DEBUG - 2021-02-03 06:47:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:47:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:47:18 --> get_subcategory_list->{"lang":"37","category_id":"9","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 06:47:18 --> Total execution time: 0.1303
DEBUG - 2021-02-03 06:47:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:47:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 06:47:23 --> get_exercise_type_list->{"lang":"37","subcategory_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 06:47:23 --> Total execution time: 0.1472
DEBUG - 2021-02-03 06:47:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 06:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 06:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 06:47:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 06:47:26 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-02-03 06:47:26 --> Total execution time: 0.1210
DEBUG - 2021-02-03 09:09:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 09:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 09:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 09:09:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 09:09:38 --> Total execution time: 0.1216
DEBUG - 2021-02-03 09:09:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 09:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 09:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 09:09:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 09:09:38 --> Total execution time: 0.1320
DEBUG - 2021-02-03 09:09:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 09:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 09:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 09:09:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 09:09:39 --> Total execution time: 0.1528
DEBUG - 2021-02-03 09:09:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 09:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 09:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 09:09:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 09:09:40 --> Total execution time: 0.1267
DEBUG - 2021-02-03 09:09:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 09:09:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 09:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 09:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 09:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 09:09:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 09:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 09:09:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 09:09:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 09:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 09:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 09:09:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 09:09:41 --> Total execution time: 0.1296
DEBUG - 2021-02-03 09:09:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 09:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 09:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 09:09:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 09:09:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 09:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 09:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 09:09:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 09:09:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 09:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 09:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 09:09:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 09:09:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 09:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 09:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 09:09:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 09:09:46 --> Total execution time: 0.1079
DEBUG - 2021-02-03 09:10:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 09:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 09:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 09:10:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 09:10:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 09:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 09:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 09:10:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 09:10:33 --> Total execution time: 0.1299
DEBUG - 2021-02-03 09:10:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 09:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 09:10:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 09:59:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 09:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 09:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 09:59:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 09:59:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 09:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 09:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 09:59:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 09:59:43 --> Total execution time: 0.1496
DEBUG - 2021-02-03 09:59:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 09:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 09:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 09:59:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 09:59:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 09:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 09:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 09:59:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 09:59:54 --> Total execution time: 0.1367
DEBUG - 2021-02-03 09:59:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 09:59:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 09:59:56 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:00:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:00:02 --> Total execution time: 0.1411
DEBUG - 2021-02-03 10:00:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:00:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 10:00:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 10:00:04 --> Total execution time: 0.1595
DEBUG - 2021-02-03 10:00:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:00:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 10:00:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 10:00:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:00:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 10:00:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 10:00:19 --> Total execution time: 0.1401
DEBUG - 2021-02-03 10:00:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:00:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 10:00:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 10:00:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:00:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 10:00:22 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 10:00:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:00:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 10:00:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 10:00:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:00:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:00:31 --> Total execution time: 0.1451
DEBUG - 2021-02-03 10:00:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:00:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 10:00:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 10:00:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:00:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 10:00:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 10:00:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:00:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 10:00:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 10:00:42 --> Total execution time: 0.1268
DEBUG - 2021-02-03 10:00:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:00:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 10:00:45 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 10:00:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:00:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:00:48 --> Total execution time: 0.1453
DEBUG - 2021-02-03 10:00:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:00:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 10:00:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 10:01:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:01:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:01:28 --> Total execution time: 0.1814
DEBUG - 2021-02-03 10:03:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:03:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:03:17 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:03:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:03:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:03:17 --> Total execution time: 0.1214
DEBUG - 2021-02-03 10:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:03:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:03:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:03:17 --> Total execution time: 0.0971
DEBUG - 2021-02-03 10:03:17 --> Total execution time: 0.1789
DEBUG - 2021-02-03 10:03:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:03:20 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:03:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:03:20 --> Total execution time: 0.1477
DEBUG - 2021-02-03 10:03:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:03:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:03:49 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:03:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:03:49 --> Total execution time: 0.1350
DEBUG - 2021-02-03 10:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:03:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:03:49 --> Total execution time: 0.1476
DEBUG - 2021-02-03 10:03:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:03:53 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:03:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:03:53 --> Total execution time: 0.1314
DEBUG - 2021-02-03 10:03:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:03:56 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:03:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:03:56 --> Total execution time: 0.1255
DEBUG - 2021-02-03 10:05:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:05:43 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:05:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:05:43 --> Total execution time: 0.1541
DEBUG - 2021-02-03 10:05:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:05:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:05:44 --> Total execution time: 0.1108
DEBUG - 2021-02-03 10:05:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:05:46 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:05:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:05:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:05:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:05:46 --> Total execution time: 0.1341
DEBUG - 2021-02-03 10:05:46 --> Total execution time: 0.1480
DEBUG - 2021-02-03 10:06:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:06:21 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:06:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:06:21 --> Total execution time: 0.1420
DEBUG - 2021-02-03 10:06:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:06:23 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:06:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:06:23 --> Total execution time: 0.1553
DEBUG - 2021-02-03 10:06:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:06:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:06:26 --> Total execution time: 0.1628
DEBUG - 2021-02-03 10:06:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:06:29 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:06:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:06:29 --> Total execution time: 0.1254
DEBUG - 2021-02-03 10:09:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:09:09 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:09:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:09:09 --> Total execution time: 0.1298
DEBUG - 2021-02-03 10:09:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:09:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:09:11 --> Total execution time: 0.1657
DEBUG - 2021-02-03 10:09:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:09:12 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:09:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:09:12 --> Total execution time: 0.1330
DEBUG - 2021-02-03 10:09:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:09:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:09:15 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:09:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:09:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:09:16 --> Total execution time: 0.1634
DEBUG - 2021-02-03 10:09:16 --> Total execution time: 0.1458
DEBUG - 2021-02-03 10:09:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:09:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:09:16 --> Total execution time: 0.1248
DEBUG - 2021-02-03 10:09:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:09:18 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:09:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:09:18 --> Total execution time: 0.1489
DEBUG - 2021-02-03 10:09:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:09:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:09:20 --> Total execution time: 0.1280
DEBUG - 2021-02-03 10:09:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:09:23 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:09:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:09:23 --> Total execution time: 0.1682
DEBUG - 2021-02-03 10:09:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:09:25 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:09:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:09:26 --> Total execution time: 0.1337
DEBUG - 2021-02-03 10:09:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:09:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:09:26 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 10:09:26 --> Total execution time: 0.1459
DEBUG - 2021-02-03 10:09:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:09:33 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:09:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:09:33 --> Total execution time: 0.1448
DEBUG - 2021-02-03 10:09:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:09:35 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:09:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:09:36 --> Total execution time: 0.1565
DEBUG - 2021-02-03 10:09:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:09:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:09:49 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 10:09:49 --> Total execution time: 0.1335
DEBUG - 2021-02-03 10:09:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:09:50 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:09:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:09:51 --> Total execution time: 0.1429
DEBUG - 2021-02-03 10:09:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:09:54 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:09:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:09:54 --> Total execution time: 0.1723
DEBUG - 2021-02-03 10:09:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:09:57 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:09:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:09:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:09:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:09:57 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 10:09:57 --> Total execution time: 0.1346
DEBUG - 2021-02-03 10:09:57 --> Total execution time: 0.1568
DEBUG - 2021-02-03 10:10:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:10:00 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:10:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:10:00 --> Total execution time: 0.1547
DEBUG - 2021-02-03 10:10:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:10:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:10:05 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:10:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:10:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:10:06 --> Total execution time: 0.1403
DEBUG - 2021-02-03 10:10:06 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 10:10:06 --> Total execution time: 0.1657
DEBUG - 2021-02-03 10:10:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:10:09 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:10:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:10:09 --> Total execution time: 0.1162
DEBUG - 2021-02-03 10:10:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:10:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:10:21 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:10:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:10:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:10:21 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 10:10:21 --> Total execution time: 0.1236
DEBUG - 2021-02-03 10:10:21 --> Total execution time: 0.1297
DEBUG - 2021-02-03 10:10:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:10:24 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:10:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:10:24 --> Total execution time: 0.1553
DEBUG - 2021-02-03 10:10:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:10:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:10:30 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:10:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 10:10:30 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-02-03 10:10:30 --> Total execution time: 0.1276
DEBUG - 2021-02-03 10:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:10:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:10:30 --> Total execution time: 0.1513
DEBUG - 2021-02-03 10:11:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:11:58 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:11:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:11:59 --> Total execution time: 0.1349
DEBUG - 2021-02-03 10:12:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:12:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 10:12:56 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-02-03 10:12:56 --> Total execution time: 0.1190
DEBUG - 2021-02-03 10:14:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:14:46 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:14:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:14:46 --> Total execution time: 0.1351
DEBUG - 2021-02-03 10:14:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:14:48 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:14:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:14:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:14:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:14:48 --> Total execution time: 0.1474
DEBUG - 2021-02-03 10:14:48 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 10:14:48 --> Total execution time: 0.1166
DEBUG - 2021-02-03 10:14:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:14:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:14:49 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 10:14:49 --> Total execution time: 0.1481
DEBUG - 2021-02-03 10:14:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:14:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:14:49 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 10:14:49 --> Total execution time: 0.1320
DEBUG - 2021-02-03 10:14:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:14:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:14:50 --> Total execution time: 0.1294
DEBUG - 2021-02-03 10:14:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:14:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:14:50 --> Total execution time: 0.1377
DEBUG - 2021-02-03 10:15:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:15:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:15:12 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:15:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:15:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:15:12 --> Total execution time: 0.1470
DEBUG - 2021-02-03 10:15:12 --> Total execution time: 0.1649
DEBUG - 2021-02-03 10:15:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:15:15 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:15:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:15:15 --> Total execution time: 0.1806
DEBUG - 2021-02-03 10:17:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:17:13 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:17:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:17:13 --> Total execution time: 0.1444
DEBUG - 2021-02-03 10:19:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:19:22 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:19:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:19:22 --> Total execution time: 0.1293
DEBUG - 2021-02-03 10:19:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:19:26 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:19:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:19:27 --> Total execution time: 0.1540
DEBUG - 2021-02-03 10:19:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:19:32 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:19:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:19:32 --> Total execution time: 0.1563
DEBUG - 2021-02-03 10:19:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:19:40 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:19:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:19:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:19:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:19:41 --> Total execution time: 0.1354
DEBUG - 2021-02-03 10:19:41 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 10:19:41 --> Total execution time: 0.1369
DEBUG - 2021-02-03 10:19:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:19:42 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:19:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:19:42 --> Total execution time: 0.1331
DEBUG - 2021-02-03 10:19:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:19:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:19:46 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:19:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:19:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:19:46 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 10:19:46 --> Total execution time: 0.1602
DEBUG - 2021-02-03 10:19:46 --> Total execution time: 0.1444
DEBUG - 2021-02-03 10:19:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:19:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:19:51 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:19:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:19:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:19:51 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 10:19:51 --> Total execution time: 0.1502
DEBUG - 2021-02-03 10:19:51 --> Total execution time: 0.1218
DEBUG - 2021-02-03 10:20:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:20:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:20:00 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:20:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:20:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 10:20:00 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-02-03 10:20:00 --> Total execution time: 0.1278
DEBUG - 2021-02-03 10:20:00 --> Total execution time: 0.1300
DEBUG - 2021-02-03 10:20:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:20:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:20:18 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:20:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:20:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:20:18 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 10:20:18 --> Total execution time: 0.1533
DEBUG - 2021-02-03 10:20:18 --> Total execution time: 0.1254
DEBUG - 2021-02-03 10:20:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:20:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:20:19 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 10:20:19 --> Total execution time: 0.1414
DEBUG - 2021-02-03 10:20:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:20:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:20:19 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 10:20:19 --> Total execution time: 0.1189
DEBUG - 2021-02-03 10:20:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:20:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:20:21 --> Total execution time: 0.1352
DEBUG - 2021-02-03 10:20:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:20:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:20:21 --> Total execution time: 0.1357
DEBUG - 2021-02-03 10:21:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:21:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:21:20 --> Total execution time: 0.1359
DEBUG - 2021-02-03 10:21:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:21:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 10:21:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 10:21:23 --> Total execution time: 0.1545
DEBUG - 2021-02-03 10:21:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:21:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 10:21:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 10:21:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:21:36 --> Total execution time: 0.1509
DEBUG - 2021-02-03 10:21:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:21:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:21:37 --> Total execution time: 0.1819
DEBUG - 2021-02-03 10:21:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:21:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:21:38 --> Total execution time: 0.1864
DEBUG - 2021-02-03 10:21:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:21:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 10:21:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 10:21:38 --> Total execution time: 0.1764
DEBUG - 2021-02-03 10:21:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:21:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 10:21:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 10:21:41 --> Total execution time: 0.1184
DEBUG - 2021-02-03 10:21:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:21:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 10:21:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 10:21:41 --> Total execution time: 0.1537
DEBUG - 2021-02-03 10:21:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:21:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 10:21:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 10:21:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:21:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:21:50 --> Total execution time: 0.1367
DEBUG - 2021-02-03 10:21:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:21:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:21:51 --> Total execution time: 0.1605
DEBUG - 2021-02-03 10:21:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:21:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:21:53 --> Total execution time: 0.1423
DEBUG - 2021-02-03 10:21:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:21:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:21:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:21:53 --> Total execution time: 0.1591
DEBUG - 2021-02-03 10:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:21:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 10:21:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 10:21:53 --> Total execution time: 0.2038
DEBUG - 2021-02-03 10:21:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:21:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:21:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 10:21:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 10:21:55 --> Total execution time: 0.2107
DEBUG - 2021-02-03 10:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:21:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 10:21:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 10:21:55 --> Total execution time: 0.1642
DEBUG - 2021-02-03 10:21:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:21:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 10:21:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 10:21:55 --> Total execution time: 0.1784
DEBUG - 2021-02-03 10:21:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 10:21:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 10:22:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:22:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:22:03 --> Total execution time: 0.1357
DEBUG - 2021-02-03 10:22:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:22:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:22:05 --> Total execution time: 0.1490
DEBUG - 2021-02-03 10:22:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:22:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:22:06 --> Total execution time: 0.1228
DEBUG - 2021-02-03 10:22:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:22:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:22:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:22:07 --> Total execution time: 0.1539
DEBUG - 2021-02-03 10:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:22:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 10:22:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 10:22:07 --> Total execution time: 0.1409
DEBUG - 2021-02-03 10:22:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:22:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:22:07 --> Total execution time: 0.1236
DEBUG - 2021-02-03 10:22:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:22:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 10:22:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 10:22:07 --> Total execution time: 0.1346
DEBUG - 2021-02-03 10:22:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:22:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 10:22:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 10:22:09 --> Total execution time: 0.1765
DEBUG - 2021-02-03 10:22:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:22:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:22:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 10:22:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 10:22:09 --> Total execution time: 0.1462
DEBUG - 2021-02-03 10:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:22:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 10:22:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 10:22:09 --> Total execution time: 0.1368
DEBUG - 2021-02-03 10:22:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:22:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 10:22:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 10:22:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:22:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:22:38 --> Total execution time: 0.1138
DEBUG - 2021-02-03 10:22:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:22:46 --> Total execution time: 0.1584
DEBUG - 2021-02-03 10:22:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:22:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:22:54 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 10:22:54 --> Total execution time: 0.1167
DEBUG - 2021-02-03 10:22:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:22:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:22:57 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 10:22:57 --> Total execution time: 0.1437
DEBUG - 2021-02-03 10:23:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:23:01 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:23:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:23:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:23:01 --> Total execution time: 0.1164
DEBUG - 2021-02-03 10:23:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:23:01 --> Total execution time: 0.1536
DEBUG - 2021-02-03 10:23:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:23:03 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:23:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:23:03 --> Total execution time: 0.1171
DEBUG - 2021-02-03 10:23:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:23:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:23:05 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 10:23:05 --> Total execution time: 0.1138
DEBUG - 2021-02-03 10:23:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:23:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:23:09 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:23:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:23:09 --> Total execution time: 0.1248
DEBUG - 2021-02-03 10:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:23:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:23:09 --> Total execution time: 0.1465
DEBUG - 2021-02-03 10:23:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:23:13 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:23:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:23:13 --> Total execution time: 0.1652
DEBUG - 2021-02-03 10:23:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:23:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 10:23:13 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-02-03 10:23:13 --> Total execution time: 0.1337
DEBUG - 2021-02-03 10:23:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:23:15 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:23:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:23:15 --> Total execution time: 0.1554
DEBUG - 2021-02-03 10:23:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:23:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:23:24 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:23:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:23:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:23:24 --> Total execution time: 0.1411
DEBUG - 2021-02-03 10:23:24 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 10:23:24 --> Total execution time: 0.1668
DEBUG - 2021-02-03 10:23:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:23:25 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:23:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:23:26 --> Total execution time: 0.1432
DEBUG - 2021-02-03 10:23:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:23:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:23:30 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:23:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:23:30 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 10:23:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:23:30 --> Total execution time: 0.1542
DEBUG - 2021-02-03 10:23:30 --> Total execution time: 0.1612
DEBUG - 2021-02-03 10:23:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:23:33 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:23:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:23:33 --> Total execution time: 0.1607
DEBUG - 2021-02-03 10:23:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:23:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:23:37 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 10:23:37 --> Total execution time: 0.1404
DEBUG - 2021-02-03 10:23:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:23:37 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:23:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:23:37 --> Total execution time: 0.1063
DEBUG - 2021-02-03 10:23:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:23:39 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:23:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:23:39 --> Total execution time: 0.1563
DEBUG - 2021-02-03 10:23:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:23:45 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:23:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:23:46 --> Total execution time: 0.1359
DEBUG - 2021-02-03 10:23:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:23:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 10:23:46 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-02-03 10:23:46 --> Total execution time: 0.1288
DEBUG - 2021-02-03 10:23:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:23:49 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:23:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:23:49 --> Total execution time: 0.1500
DEBUG - 2021-02-03 10:24:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:24:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 10:24:18 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-02-03 10:24:18 --> Total execution time: 0.1167
DEBUG - 2021-02-03 10:25:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:25:44 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:25:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:25:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:25:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:25:44 --> Total execution time: 0.1452
DEBUG - 2021-02-03 10:25:44 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 10:25:44 --> Total execution time: 0.1294
DEBUG - 2021-02-03 10:25:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:25:47 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:25:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:25:47 --> Total execution time: 0.1151
DEBUG - 2021-02-03 10:26:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:26:53 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:26:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:26:53 --> Total execution time: 0.1444
DEBUG - 2021-02-03 10:26:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:26:56 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:26:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:26:56 --> Total execution time: 0.1590
DEBUG - 2021-02-03 10:27:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:27:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:27:04 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:27:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:27:04 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 10:27:04 --> Total execution time: 0.1213
DEBUG - 2021-02-03 10:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:27:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:27:04 --> Total execution time: 0.1477
DEBUG - 2021-02-03 10:27:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:27:06 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:27:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:27:06 --> Total execution time: 0.1417
DEBUG - 2021-02-03 10:27:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:27:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:27:13 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 10:27:13 --> Total execution time: 0.1764
DEBUG - 2021-02-03 10:27:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:27:16 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:27:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:27:16 --> Total execution time: 0.1247
DEBUG - 2021-02-03 10:27:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:27:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:27:41 --> get_exercise_type_list->{"lang":null,"subcategory_id":null,"support_lang_id":null}
ERROR - 2021-02-03 10:27:41 --> {"status":0,"message":"Parameters not passed","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2021-02-03 10:27:41 --> Total execution time: 0.1401
DEBUG - 2021-02-03 10:28:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:28:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:28:44 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:28:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:28:44 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 10:28:44 --> Total execution time: 0.1306
DEBUG - 2021-02-03 10:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:28:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:28:44 --> Total execution time: 0.1556
DEBUG - 2021-02-03 10:28:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:28:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:28:45 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 10:28:45 --> Total execution time: 0.1192
DEBUG - 2021-02-03 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:28:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:28:47 --> Total execution time: 0.1016
DEBUG - 2021-02-03 10:28:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:28:48 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:28:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:28:48 --> Total execution time: 0.1267
DEBUG - 2021-02-03 10:28:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:28:48 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:28:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:28:48 --> Total execution time: 0.1690
DEBUG - 2021-02-03 10:28:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:28:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:28:49 --> Total execution time: 0.0981
DEBUG - 2021-02-03 10:28:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:28:51 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:28:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:28:51 --> Total execution time: 0.1602
DEBUG - 2021-02-03 10:30:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:30:06 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:30:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:30:06 --> Total execution time: 0.1718
DEBUG - 2021-02-03 10:30:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:30:08 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:30:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:30:08 --> Total execution time: 0.1326
DEBUG - 2021-02-03 10:30:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:30:18 --> No URI present. Default controller set.
DEBUG - 2021-02-03 10:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:30:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:30:18 --> Total execution time: 0.1607
DEBUG - 2021-02-03 10:46:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:46:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:46:08 --> user_login->{"email":"a.strani@hw.ac.uk","password":"e10adc3949ba59abbe56e057f20f883e"}
ERROR - 2021-02-03 10:46:08 --> {"status":0,"message":"Username or Password Wrong!!","message_en":"","result":[],"status_message":"OK"}
DEBUG - 2021-02-03 10:46:08 --> Total execution time: 0.1087
DEBUG - 2021-02-03 10:47:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:47:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:47:08 --> user_register->{"first_name":"harsh","last_name":"","email":"harsh.n@voolsy.com","password":"123456","confirm_password":"123456","social_id":null,"social_type":"0","user_image":null}
DEBUG - 2021-02-03 10:47:08 --> Total execution time: 0.1213
DEBUG - 2021-02-03 10:47:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:47:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:47:11 --> Total execution time: 0.1308
DEBUG - 2021-02-03 10:47:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:47:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:47:35 --> Total execution time: 0.1681
DEBUG - 2021-02-03 10:47:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:47:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:47:46 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 10:47:46 --> Total execution time: 0.1647
DEBUG - 2021-02-03 10:47:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:47:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:47:52 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-02-03 10:47:52 --> Total execution time: 0.1112
DEBUG - 2021-02-03 10:48:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 10:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 10:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 10:48:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 10:48:14 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 10:48:14 --> Total execution time: 0.1191
DEBUG - 2021-02-03 11:05:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:05:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:05:51 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-02-03 11:05:51 --> Total execution time: 0.1035
DEBUG - 2021-02-03 11:14:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:14:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:14:49 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 11:14:49 --> Total execution time: 0.1029
DEBUG - 2021-02-03 11:14:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:14:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:14:55 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"2","support_lang_id":"3"}
ERROR - 2021-02-03 11:14:55 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 11:14:55 --> Total execution time: 0.1686
DEBUG - 2021-02-03 11:15:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:15:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:15:02 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 11:15:02 --> Total execution time: 0.1432
DEBUG - 2021-02-03 11:15:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:15:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:15:06 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-02-03 11:15:06 --> Total execution time: 0.1211
DEBUG - 2021-02-03 11:15:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:15:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:15:10 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 11:15:10 --> Total execution time: 0.1402
DEBUG - 2021-02-03 11:15:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:15:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:15:15 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"7","support_lang_id":"3"}
ERROR - 2021-02-03 11:15:15 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 11:15:15 --> Total execution time: 0.1299
DEBUG - 2021-02-03 11:15:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:15:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:15:19 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 11:15:19 --> Total execution time: 0.1044
DEBUG - 2021-02-03 11:15:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:15:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:15:22 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-02-03 11:15:22 --> Total execution time: 0.1084
DEBUG - 2021-02-03 11:15:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:15:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:15:26 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 11:15:26 --> Total execution time: 0.1111
DEBUG - 2021-02-03 11:15:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:15:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:15:31 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 11:15:31 --> Total execution time: 0.1039
DEBUG - 2021-02-03 11:15:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:15:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:15:35 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-02-03 11:15:35 --> Total execution time: 0.1054
DEBUG - 2021-02-03 11:15:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:15:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:15:38 --> get_exercise_type_list->{"lang":"37","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-03 11:15:38 --> Total execution time: 0.1422
DEBUG - 2021-02-03 11:15:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:15:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:15:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 11:15:43 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-02-03 11:15:43 --> Total execution time: 0.1171
DEBUG - 2021-02-03 11:15:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:15:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:15:51 --> get_exercise_type_list->{"lang":"37","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-03 11:15:51 --> Total execution time: 0.1599
DEBUG - 2021-02-03 11:15:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:15:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:15:55 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-02-03 11:15:55 --> Total execution time: 0.1795
DEBUG - 2021-02-03 11:16:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:16:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:16:02 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 11:16:02 --> Total execution time: 0.1049
DEBUG - 2021-02-03 11:16:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:16:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:16:34 --> Total execution time: 0.1059
DEBUG - 2021-02-03 11:16:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:16:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:16:37 --> Total execution time: 0.1123
DEBUG - 2021-02-03 11:16:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:16:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:16:47 --> Total execution time: 0.1357
DEBUG - 2021-02-03 11:17:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:17:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:17:00 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"2"}
DEBUG - 2021-02-03 11:17:00 --> Total execution time: 0.1388
DEBUG - 2021-02-03 11:17:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:17:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:17:04 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"771","support_lang_id":"2"}
DEBUG - 2021-02-03 11:17:04 --> Total execution time: 0.1672
DEBUG - 2021-02-03 11:17:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:17:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:17:08 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"2"}
DEBUG - 2021-02-03 11:17:08 --> Total execution time: 0.1157
DEBUG - 2021-02-03 11:17:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:17:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 11:17:12 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-02-03 11:17:12 --> Total execution time: 0.1465
DEBUG - 2021-02-03 11:17:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:17:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:17:18 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"2"}
DEBUG - 2021-02-03 11:17:18 --> Total execution time: 0.1432
DEBUG - 2021-02-03 11:17:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:17:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:17:20 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"771","support_lang_id":"2"}
DEBUG - 2021-02-03 11:17:20 --> Total execution time: 0.1161
DEBUG - 2021-02-03 11:17:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:17:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:17:22 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"2"}
DEBUG - 2021-02-03 11:17:22 --> Total execution time: 0.1240
DEBUG - 2021-02-03 11:17:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:17:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:17:35 --> Total execution time: 0.1217
DEBUG - 2021-02-03 11:17:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:17:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:17:39 --> Total execution time: 0.1138
DEBUG - 2021-02-03 11:21:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:21:58 --> No URI present. Default controller set.
DEBUG - 2021-02-03 11:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:21:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:21:58 --> Total execution time: 0.1752
DEBUG - 2021-02-03 11:22:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:22:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:22:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:22:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:22:07 --> Total execution time: 0.1319
DEBUG - 2021-02-03 11:22:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:22:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 11:22:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:22:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:22:25 --> Total execution time: 0.1552
DEBUG - 2021-02-03 11:22:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:22:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:22:28 --> Total execution time: 0.1580
DEBUG - 2021-02-03 11:22:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:22:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:22:31 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 11:23:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:23:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:23:39 --> Total execution time: 0.1625
DEBUG - 2021-02-03 11:23:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:23:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:23:42 --> Total execution time: 0.1792
DEBUG - 2021-02-03 11:23:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:23:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:23:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 11:23:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:23:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:23:57 --> Total execution time: 0.1507
DEBUG - 2021-02-03 11:24:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:24:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:24:00 --> Total execution time: 0.1691
DEBUG - 2021-02-03 11:24:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:24:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 11:24:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:24:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:24:11 --> Total execution time: 0.1411
DEBUG - 2021-02-03 11:24:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:24:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:24:14 --> Total execution time: 0.1514
DEBUG - 2021-02-03 11:24:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:24:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:24:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 11:24:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:24:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:24:27 --> Total execution time: 0.1500
DEBUG - 2021-02-03 11:24:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:24:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:24:32 --> Total execution time: 0.1670
DEBUG - 2021-02-03 11:24:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:24:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:24:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 11:24:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:24:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:24:43 --> Total execution time: 0.1397
DEBUG - 2021-02-03 11:24:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:24:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:24:46 --> Total execution time: 0.1328
DEBUG - 2021-02-03 11:24:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:24:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:24:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 11:24:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:24:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:24:58 --> Total execution time: 0.1511
DEBUG - 2021-02-03 11:25:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:25:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:25:02 --> Total execution time: 0.1281
DEBUG - 2021-02-03 11:25:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:25:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:25:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 11:25:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:25:14 --> Total execution time: 0.1556
DEBUG - 2021-02-03 11:25:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:25:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:25:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 11:25:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:25:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:25:36 --> Total execution time: 0.1232
DEBUG - 2021-02-03 11:25:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:25:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 11:25:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-03 11:25:38 --> Total execution time: 0.1452
DEBUG - 2021-02-03 11:25:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:25:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:25:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 11:25:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:25:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:25:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:25:44 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 11:25:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:25:44 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 11:26:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:26:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:26:03 --> Total execution time: 0.1236
DEBUG - 2021-02-03 11:26:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:26:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:26:23 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2021-02-03 11:26:23 --> Total execution time: 0.1487
DEBUG - 2021-02-03 11:27:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:27:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:27:06 --> Total execution time: 0.1449
DEBUG - 2021-02-03 11:27:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:27:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:27:10 --> Total execution time: 0.1176
DEBUG - 2021-02-03 11:27:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:27:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:27:14 --> Total execution time: 0.1057
DEBUG - 2021-02-03 11:27:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:27:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:27:21 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:27:21 --> Total execution time: 0.1614
DEBUG - 2021-02-03 11:27:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:27:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:27:33 --> Total execution time: 0.1177
DEBUG - 2021-02-03 11:27:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:27:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:27:36 --> Total execution time: 0.1270
DEBUG - 2021-02-03 11:27:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:27:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:27:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 11:27:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:27:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:27:47 --> Total execution time: 0.1636
DEBUG - 2021-02-03 11:27:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:27:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:27:50 --> Total execution time: 0.1499
DEBUG - 2021-02-03 11:27:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:27:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:27:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 11:28:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:28:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:28:53 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-02-03 11:28:53 --> Total execution time: 0.1382
DEBUG - 2021-02-03 11:29:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:29:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:29:05 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 11:29:05 --> Total execution time: 0.1228
DEBUG - 2021-02-03 11:29:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:29:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:29:06 --> No URI present. Default controller set.
DEBUG - 2021-02-03 11:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:29:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:29:06 --> Total execution time: 0.1142
DEBUG - 2021-02-03 11:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:29:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:29:06 --> Total execution time: 0.1283
DEBUG - 2021-02-03 11:29:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:29:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:29:18 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-02-03 11:29:18 --> Total execution time: 0.1073
DEBUG - 2021-02-03 11:29:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:29:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:29:57 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:29:57 --> Total execution time: 0.1393
DEBUG - 2021-02-03 11:33:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:33:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:33:14 --> Total execution time: 0.1454
DEBUG - 2021-02-03 11:33:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:33:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:33:17 --> Total execution time: 0.1351
DEBUG - 2021-02-03 11:33:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:33:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:33:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 11:33:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:33:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:36:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:36:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:36:30 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:36:30 --> Total execution time: 0.1330
DEBUG - 2021-02-03 11:36:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:36:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:36:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 11:36:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:36:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:36:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 11:36:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:36:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:36:35 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:36:35 --> Total execution time: 0.1414
DEBUG - 2021-02-03 11:36:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:36:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:36:39 --> get_sorce_lan_word_type_5->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:36:39 --> Total execution time: 0.1367
DEBUG - 2021-02-03 11:36:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:36:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:36:42 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 11:36:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:36:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:36:43 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:36:43 --> Total execution time: 0.1776
DEBUG - 2021-02-03 11:36:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:36:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:36:47 --> get_sorce_lan_word_type_4->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:36:47 --> Total execution time: 0.1251
DEBUG - 2021-02-03 11:36:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:36:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:36:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:36:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 11:36:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:36:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 11:36:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:36:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:36:51 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:36:51 --> Total execution time: 0.1142
DEBUG - 2021-02-03 11:36:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:36:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:36:57 --> get_sorce_lan_word_type_9->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:36:57 --> Total execution time: 0.1616
DEBUG - 2021-02-03 11:37:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:37:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:37:09 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:37:09 --> Total execution time: 0.1164
DEBUG - 2021-02-03 11:37:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:37:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:37:15 --> get_sorce_lan_word_type_7->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:37:15 --> Total execution time: 0.1553
DEBUG - 2021-02-03 11:37:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:37:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:37:18 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:37:18 --> Total execution time: 0.1459
DEBUG - 2021-02-03 11:37:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:37:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:37:22 --> get_sorce_lan_word_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:37:22 --> Total execution time: 0.1662
DEBUG - 2021-02-03 11:37:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:37:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:37:26 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:37:26 --> Total execution time: 0.1636
DEBUG - 2021-02-03 11:37:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:37:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:37:32 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:37:32 --> Total execution time: 0.1532
DEBUG - 2021-02-03 11:37:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:37:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:37:35 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 11:37:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:37:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:37:36 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:37:36 --> Total execution time: 0.1500
DEBUG - 2021-02-03 11:37:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:37:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:37:40 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-02-03 11:37:40 --> Total execution time: 0.1428
DEBUG - 2021-02-03 11:37:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:37:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:37:46 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:37:46 --> Total execution time: 0.1652
DEBUG - 2021-02-03 11:37:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:37:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:37:52 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 11:37:52 --> Total execution time: 0.1404
DEBUG - 2021-02-03 11:37:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:37:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:37:59 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-02-03 11:37:59 --> Total execution time: 0.1346
DEBUG - 2021-02-03 11:38:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:38:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:38:28 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 11:38:28 --> Total execution time: 0.1431
DEBUG - 2021-02-03 11:38:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:38:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:38:36 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 11:38:36 --> Total execution time: 0.1185
DEBUG - 2021-02-03 11:38:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:38:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:38:52 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-02-03 11:38:52 --> Total execution time: 0.1273
DEBUG - 2021-02-03 11:43:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:43:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:43:09 --> get_exercise_type_list->{"lang":"37","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-03 11:43:09 --> Total execution time: 0.1058
DEBUG - 2021-02-03 11:43:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:43:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:43:14 --> get_dialogue_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"2","category_id":"7","subcategory_id":"6","support_lang_id":"3"}
ERROR - 2021-02-03 11:43:14 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 11:43:14 --> Total execution time: 0.1297
DEBUG - 2021-02-03 11:43:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:43:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:43:22 --> get_exercise_type_list->{"lang":"37","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-03 11:43:22 --> Total execution time: 0.1270
DEBUG - 2021-02-03 11:43:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:43:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:43:31 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-02-03 11:43:31 --> Total execution time: 0.1395
DEBUG - 2021-02-03 11:43:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:43:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:43:35 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 11:43:35 --> Total execution time: 0.1205
DEBUG - 2021-02-03 11:44:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:44:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:44:56 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 11:44:56 --> Total execution time: 0.1468
DEBUG - 2021-02-03 11:45:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:45:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:45:02 --> get_subcategory_list->{"lang":"37","category_id":"9","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-02-03 11:45:02 --> Total execution time: 0.1059
DEBUG - 2021-02-03 11:45:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:45:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:45:20 --> get_exercise_type_list->{"lang":"37","subcategory_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 11:45:20 --> Total execution time: 0.1166
DEBUG - 2021-02-03 11:46:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:46:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:46:19 --> get_subcategory_list->{"lang":"37","category_id":"9","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-02-03 11:46:19 --> Total execution time: 0.1728
DEBUG - 2021-02-03 11:46:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:46:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:46:23 --> get_exercise_type_list->{"lang":"37","subcategory_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 11:46:23 --> Total execution time: 0.1175
DEBUG - 2021-02-03 11:46:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:46:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:46:28 --> get_phrases_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"3","category_id":"9","subcategory_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 11:46:28 --> Total execution time: 0.1219
DEBUG - 2021-02-03 11:46:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:46:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:46:36 --> get_exercise_type_list->{"lang":"37","subcategory_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 11:46:36 --> Total execution time: 0.1572
DEBUG - 2021-02-03 11:46:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:46:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:46:40 --> get_subcategory_list->{"lang":"37","category_id":"9","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-02-03 11:46:40 --> Total execution time: 0.1514
DEBUG - 2021-02-03 11:46:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:46:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:46:55 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 11:46:55 --> Total execution time: 0.1233
DEBUG - 2021-02-03 11:47:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:47:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:47:09 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 11:47:09 --> Total execution time: 0.1235
DEBUG - 2021-02-03 11:47:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:47:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:47:22 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-02-03 11:47:22 --> Total execution time: 0.1165
DEBUG - 2021-02-03 11:47:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:47:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:47:48 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 11:47:48 --> Total execution time: 0.1626
DEBUG - 2021-02-03 11:47:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:47:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:47:52 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"8","subcategory_id":"3","support_lang_id":"3"}
ERROR - 2021-02-03 11:47:52 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 11:47:52 --> Total execution time: 0.1321
DEBUG - 2021-02-03 11:47:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:47:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:47:57 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 11:47:57 --> Total execution time: 0.1264
DEBUG - 2021-02-03 11:48:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:48:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:48:36 --> Total execution time: 0.1018
DEBUG - 2021-02-03 11:48:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:48:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:48:40 --> Total execution time: 0.1136
DEBUG - 2021-02-03 11:48:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:48:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:48:47 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 11:48:47 --> Total execution time: 0.1337
DEBUG - 2021-02-03 11:48:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:48:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:48:50 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 11:48:50 --> Total execution time: 0.1215
DEBUG - 2021-02-03 11:48:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:48:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:48:54 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 11:48:54 --> Total execution time: 0.1138
DEBUG - 2021-02-03 11:48:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:48:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:48:57 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"2","support_lang_id":"3"}
ERROR - 2021-02-03 11:48:57 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 11:48:57 --> Total execution time: 0.1204
DEBUG - 2021-02-03 11:49:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:49:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:49:02 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 11:49:02 --> Total execution time: 0.1134
DEBUG - 2021-02-03 11:49:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:49:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:49:42 --> Total execution time: 0.1259
DEBUG - 2021-02-03 11:49:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:49:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:49:45 --> Total execution time: 0.1119
DEBUG - 2021-02-03 11:49:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:49:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:49:55 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 11:49:55 --> Total execution time: 0.1465
DEBUG - 2021-02-03 11:49:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:49:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:49:59 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:49:59 --> Total execution time: 0.1312
DEBUG - 2021-02-03 11:50:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:50:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:50:03 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 11:50:03 --> Total execution time: 0.1115
DEBUG - 2021-02-03 11:50:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:50:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:50:07 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"2","support_lang_id":"3"}
ERROR - 2021-02-03 11:50:07 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 11:50:07 --> Total execution time: 0.1151
DEBUG - 2021-02-03 11:50:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:50:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:50:13 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 11:50:13 --> Total execution time: 0.1166
DEBUG - 2021-02-03 11:50:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:50:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:50:17 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:50:17 --> Total execution time: 0.1369
DEBUG - 2021-02-03 11:50:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:50:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:50:20 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 11:50:20 --> Total execution time: 0.1351
DEBUG - 2021-02-03 11:50:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:50:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:50:25 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"7","support_lang_id":"3"}
ERROR - 2021-02-03 11:50:25 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 11:50:25 --> Total execution time: 0.1486
DEBUG - 2021-02-03 11:50:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:50:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:50:37 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 11:50:37 --> Total execution time: 0.1395
DEBUG - 2021-02-03 11:50:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:50:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:50:38 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:50:38 --> Total execution time: 0.1378
DEBUG - 2021-02-03 11:50:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:50:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:50:38 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 11:50:38 --> Total execution time: 0.1284
DEBUG - 2021-02-03 11:50:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:50:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:50:41 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 11:50:41 --> Total execution time: 0.1037
DEBUG - 2021-02-03 11:50:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:50:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:50:43 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:50:43 --> Total execution time: 0.1405
DEBUG - 2021-02-03 11:50:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:50:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:50:44 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 11:50:44 --> Total execution time: 0.1198
DEBUG - 2021-02-03 11:50:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:50:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 11:50:46 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-02-03 11:50:46 --> Total execution time: 0.1230
DEBUG - 2021-02-03 11:50:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:50:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:50:50 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 11:50:50 --> Total execution time: 0.1233
DEBUG - 2021-02-03 11:50:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:50:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:50:51 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:50:51 --> Total execution time: 0.1167
DEBUG - 2021-02-03 11:50:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:50:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:50:52 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 11:50:52 --> Total execution time: 0.1337
DEBUG - 2021-02-03 11:50:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:50:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:50:55 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 11:50:55 --> Total execution time: 0.1617
DEBUG - 2021-02-03 11:50:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:50:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:50:57 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:50:57 --> Total execution time: 0.1388
DEBUG - 2021-02-03 11:50:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:51:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:51:00 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 11:51:00 --> Total execution time: 0.1570
DEBUG - 2021-02-03 11:51:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:51:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 11:51:00 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-02-03 11:51:00 --> Total execution time: 0.1083
DEBUG - 2021-02-03 11:51:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:51:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:51:04 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 11:51:04 --> Total execution time: 0.1672
DEBUG - 2021-02-03 11:51:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:51:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:51:07 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:51:07 --> Total execution time: 0.1187
DEBUG - 2021-02-03 11:51:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:51:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:51:07 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 11:51:07 --> Total execution time: 0.1116
DEBUG - 2021-02-03 11:51:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:51:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:51:10 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 11:51:10 --> Total execution time: 0.1554
DEBUG - 2021-02-03 11:51:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:51:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:51:11 --> get_subcategory_list->{"lang":"37","category_id":"9","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:51:11 --> Total execution time: 0.1244
DEBUG - 2021-02-03 11:51:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:51:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:51:12 --> get_exercise_type_list->{"lang":"37","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-03 11:51:12 --> Total execution time: 0.1224
DEBUG - 2021-02-03 11:51:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:51:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 11:51:13 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-02-03 11:51:13 --> Total execution time: 0.1406
DEBUG - 2021-02-03 11:51:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:51:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:51:15 --> get_exercise_type_list->{"lang":"37","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-03 11:51:15 --> Total execution time: 0.1177
DEBUG - 2021-02-03 11:51:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:51:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:51:16 --> get_subcategory_list->{"lang":"37","category_id":"9","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:51:16 --> Total execution time: 0.1357
DEBUG - 2021-02-03 11:51:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:51:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:51:18 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 11:51:18 --> Total execution time: 0.0965
DEBUG - 2021-02-03 11:51:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:51:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:51:20 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:51:20 --> Total execution time: 0.1318
DEBUG - 2021-02-03 11:51:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:51:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:51:21 --> get_exercise_type_list->{"lang":"37","subcategory_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 11:51:21 --> Total execution time: 0.1578
DEBUG - 2021-02-03 11:51:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:51:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 11:51:23 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-02-03 11:51:23 --> Total execution time: 0.1491
DEBUG - 2021-02-03 11:52:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:52:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:52:23 --> Total execution time: 0.1452
DEBUG - 2021-02-03 11:52:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:52:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:52:27 --> Total execution time: 0.1444
DEBUG - 2021-02-03 11:52:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:52:33 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 11:52:33 --> Total execution time: 0.1812
DEBUG - 2021-02-03 11:52:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:52:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:52:36 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 11:52:36 --> Total execution time: 0.1286
DEBUG - 2021-02-03 11:52:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:52:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:52:40 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 11:52:40 --> Total execution time: 0.1482
DEBUG - 2021-02-03 11:52:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:52:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:52:44 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"7","support_lang_id":"3"}
ERROR - 2021-02-03 11:52:44 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 11:52:44 --> Total execution time: 0.1388
DEBUG - 2021-02-03 11:54:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:54:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:54:04 --> Total execution time: 0.1295
DEBUG - 2021-02-03 11:54:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:54:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:54:05 --> Total execution time: 0.1252
DEBUG - 2021-02-03 11:54:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:54:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:54:06 --> Total execution time: 0.1400
DEBUG - 2021-02-03 11:54:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:54:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:54:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:54:07 --> Total execution time: 0.1283
DEBUG - 2021-02-03 11:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:54:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:54:07 --> Total execution time: 0.1415
DEBUG - 2021-02-03 11:54:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:54:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:54:07 --> No URI present. Default controller set.
DEBUG - 2021-02-03 11:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:54:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:54:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:54:07 --> Total execution time: 0.1411
DEBUG - 2021-02-03 11:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:54:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:54:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:54:08 --> Total execution time: 0.1311
DEBUG - 2021-02-03 11:54:08 --> Total execution time: 0.1206
DEBUG - 2021-02-03 11:54:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:54:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:54:08 --> Total execution time: 0.1265
DEBUG - 2021-02-03 11:54:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:54:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:54:09 --> Total execution time: 0.1290
DEBUG - 2021-02-03 11:54:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:54:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:54:09 --> Total execution time: 0.1097
DEBUG - 2021-02-03 11:54:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:54:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:54:09 --> Total execution time: 0.1268
DEBUG - 2021-02-03 11:54:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:54:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:54:11 --> Total execution time: 0.1299
DEBUG - 2021-02-03 11:54:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:54:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:54:12 --> Total execution time: 0.1276
DEBUG - 2021-02-03 11:54:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:54:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:54:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 11:54:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:54:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:54:25 --> Total execution time: 0.1653
DEBUG - 2021-02-03 11:54:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:54:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:54:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 11:56:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:56:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:56:47 --> Total execution time: 0.1111
DEBUG - 2021-02-03 11:56:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 11:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 11:56:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 11:56:50 --> Total execution time: 0.1430
DEBUG - 2021-02-03 11:56:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 11:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 11:56:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:01:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:01:04 --> No URI present. Default controller set.
DEBUG - 2021-02-03 12:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:01:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:01:04 --> Total execution time: 0.1304
DEBUG - 2021-02-03 12:01:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:01:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:01:21 --> Total execution time: 0.1377
DEBUG - 2021-02-03 12:01:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:01:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:01:26 --> Total execution time: 0.1642
DEBUG - 2021-02-03 12:01:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:01:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:01:32 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 12:01:32 --> Total execution time: 0.1655
DEBUG - 2021-02-03 12:01:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:01:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:01:36 --> get_subcategory_list->{"lang":"37","category_id":"9","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 12:01:36 --> Total execution time: 0.1384
DEBUG - 2021-02-03 12:01:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:01:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:01:40 --> get_exercise_type_list->{"lang":"37","subcategory_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 12:01:40 --> Total execution time: 0.1095
DEBUG - 2021-02-03 12:03:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:03:01 --> Total execution time: 0.1284
DEBUG - 2021-02-03 12:03:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:03:02 --> Total execution time: 0.1162
DEBUG - 2021-02-03 12:03:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:03:02 --> Total execution time: 0.1184
DEBUG - 2021-02-03 12:03:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:03:03 --> Total execution time: 0.1116
DEBUG - 2021-02-03 12:03:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:03:03 --> Total execution time: 0.1537
DEBUG - 2021-02-03 12:03:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:03:04 --> Total execution time: 0.1280
DEBUG - 2021-02-03 12:03:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:03:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:03:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 12:03:05 --> Total execution time: 0.1271
DEBUG - 2021-02-03 12:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:03:05 --> Total execution time: 0.1084
DEBUG - 2021-02-03 12:03:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:03:05 --> Total execution time: 0.1286
DEBUG - 2021-02-03 12:03:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:03:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 12:03:05 --> Total execution time: 0.1248
DEBUG - 2021-02-03 12:03:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:03:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 12:03:05 --> Total execution time: 0.1215
DEBUG - 2021-02-03 12:03:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:03:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 12:03:05 --> Total execution time: 0.1162
DEBUG - 2021-02-03 12:03:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:03:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 12:03:06 --> Total execution time: 0.1349
DEBUG - 2021-02-03 12:03:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:03:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 12:03:07 --> Total execution time: 0.1718
DEBUG - 2021-02-03 12:03:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:03:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 12:03:07 --> Total execution time: 0.1315
DEBUG - 2021-02-03 12:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:03:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 12:03:07 --> Total execution time: 0.1799
DEBUG - 2021-02-03 12:03:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:03:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:03:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:03:17 --> Total execution time: 0.1017
DEBUG - 2021-02-03 12:03:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:03:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:03:20 --> Total execution time: 0.2031
DEBUG - 2021-02-03 12:03:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:03:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:03:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:03:33 --> Total execution time: 0.1722
DEBUG - 2021-02-03 12:03:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:03:34 --> Total execution time: 0.1471
DEBUG - 2021-02-03 12:03:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:03:34 --> Total execution time: 0.1236
DEBUG - 2021-02-03 12:03:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:03:35 --> Total execution time: 0.1356
DEBUG - 2021-02-03 12:03:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:03:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 12:03:36 --> Total execution time: 0.1299
DEBUG - 2021-02-03 12:03:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:03:37 --> Total execution time: 0.1639
DEBUG - 2021-02-03 12:03:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:03:37 --> Total execution time: 0.1281
DEBUG - 2021-02-03 12:03:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:03:37 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 12:03:37 --> Total execution time: 0.1304
DEBUG - 2021-02-03 12:03:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:03:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 12:03:38 --> Total execution time: 0.1633
DEBUG - 2021-02-03 12:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:03:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 12:03:38 --> Total execution time: 0.1876
DEBUG - 2021-02-03 12:03:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:03:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 12:03:40 --> Total execution time: 0.1581
DEBUG - 2021-02-03 12:03:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:03:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 12:03:40 --> Total execution time: 0.1834
DEBUG - 2021-02-03 12:03:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:03:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:03:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:03:48 --> Total execution time: 0.1374
DEBUG - 2021-02-03 12:03:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:03:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:03:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 12:03:50 --> Total execution time: 0.1681
DEBUG - 2021-02-03 12:03:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:03:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:03:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:05:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:05:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:05:43 --> Total execution time: 0.1425
DEBUG - 2021-02-03 12:05:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:05:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:05:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:05:45 --> Total execution time: 0.1745
DEBUG - 2021-02-03 12:05:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:05:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:05:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:05:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:05:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:05:59 --> Total execution time: 0.1425
DEBUG - 2021-02-03 12:05:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:05:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:05:59 --> Total execution time: 0.1319
DEBUG - 2021-02-03 12:06:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:06:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:06:01 --> Total execution time: 0.1595
DEBUG - 2021-02-03 12:06:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:06:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:06:01 --> Total execution time: 0.1459
DEBUG - 2021-02-03 12:06:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:06:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:06:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:06:01 --> Total execution time: 0.1442
DEBUG - 2021-02-03 12:06:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:06:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:06:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:06:02 --> Total execution time: 0.1502
DEBUG - 2021-02-03 12:06:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:06:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:06:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:06:03 --> Total execution time: 0.1148
DEBUG - 2021-02-03 12:06:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:06:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:06:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:06:03 --> Total execution time: 0.1246
DEBUG - 2021-02-03 12:06:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:06:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:06:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:08:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:08:38 --> No URI present. Default controller set.
DEBUG - 2021-02-03 12:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:08:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:08:38 --> Total execution time: 0.1599
DEBUG - 2021-02-03 12:09:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:09:41 --> No URI present. Default controller set.
DEBUG - 2021-02-03 12:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:09:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:09:41 --> Total execution time: 0.1170
DEBUG - 2021-02-03 12:11:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:11:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:11:56 --> Total execution time: 0.1446
DEBUG - 2021-02-03 12:11:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:11:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:11:58 --> Total execution time: 0.1473
DEBUG - 2021-02-03 12:12:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:12:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:12:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:12:00 --> Total execution time: 0.1272
DEBUG - 2021-02-03 12:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:12:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:12:00 --> Total execution time: 0.2431
DEBUG - 2021-02-03 12:12:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:12:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:12:00 --> Total execution time: 0.1285
DEBUG - 2021-02-03 12:12:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:12:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:12:00 --> Total execution time: 0.1480
DEBUG - 2021-02-03 12:12:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:12:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:12:02 --> Total execution time: 0.1659
DEBUG - 2021-02-03 12:12:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:12:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:12:03 --> Total execution time: 0.1506
DEBUG - 2021-02-03 12:12:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:12:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:12:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:12:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:12:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:12:13 --> Total execution time: 0.1408
DEBUG - 2021-02-03 12:12:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:12:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:12:16 --> Total execution time: 0.1589
DEBUG - 2021-02-03 12:12:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:12:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:12:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:12:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:12:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:12:36 --> Total execution time: 0.1703
DEBUG - 2021-02-03 12:12:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:12:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:12:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:12:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:12:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:12:55 --> Total execution time: 0.1452
DEBUG - 2021-02-03 12:12:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:12:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:12:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:13:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:13:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:13:05 --> Total execution time: 0.1791
DEBUG - 2021-02-03 12:13:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:13:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:13:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:13:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:13:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:13:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:13:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:13:37 --> Total execution time: 0.1398
DEBUG - 2021-02-03 12:13:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:13:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:13:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:14:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:14:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:14:03 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 12:14:03 --> Total execution time: 0.1114
DEBUG - 2021-02-03 12:14:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:14:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:14:05 --> Total execution time: 0.1257
DEBUG - 2021-02-03 12:14:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:14:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:14:05 --> get_subcategory_list->{"lang":"37","category_id":"9","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 12:14:05 --> Total execution time: 0.0956
DEBUG - 2021-02-03 12:14:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:14:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:14:06 --> Total execution time: 0.1350
DEBUG - 2021-02-03 12:14:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:14:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:14:11 --> Total execution time: 0.1135
DEBUG - 2021-02-03 12:14:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:14:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:14:25 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 12:14:25 --> Total execution time: 0.1494
DEBUG - 2021-02-03 12:14:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:14:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:14:30 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 12:14:30 --> Total execution time: 0.1197
DEBUG - 2021-02-03 12:14:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:14:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:14:35 --> get_exercise_type_list->{"lang":"37","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-03 12:14:35 --> Total execution time: 0.1767
DEBUG - 2021-02-03 12:14:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:14:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:14:37 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 12:14:37 --> Total execution time: 0.1137
DEBUG - 2021-02-03 12:14:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:14:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:14:37 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 12:14:37 --> Total execution time: 0.1256
DEBUG - 2021-02-03 12:14:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:14:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:14:40 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 12:14:40 --> Total execution time: 0.1241
DEBUG - 2021-02-03 12:14:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:14:45 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 12:14:45 --> Total execution time: 0.1247
DEBUG - 2021-02-03 12:14:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:14:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:14:50 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 12:14:50 --> Total execution time: 0.1304
DEBUG - 2021-02-03 12:14:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:14:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:14:54 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"7","support_lang_id":"3"}
ERROR - 2021-02-03 12:14:54 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 12:14:54 --> Total execution time: 0.1469
DEBUG - 2021-02-03 12:15:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:15:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:15:01 --> Total execution time: 0.1485
DEBUG - 2021-02-03 12:15:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:15:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:15:01 --> Total execution time: 0.1678
DEBUG - 2021-02-03 12:15:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:15:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:15:02 --> Total execution time: 0.1266
DEBUG - 2021-02-03 12:15:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:15:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:15:02 --> Total execution time: 0.1100
DEBUG - 2021-02-03 12:15:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:15:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:15:03 --> Total execution time: 0.1294
DEBUG - 2021-02-03 12:15:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:15:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:15:03 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:15:03 --> Total execution time: 0.1479
DEBUG - 2021-02-03 12:15:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:15:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:15:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:15:04 --> Total execution time: 0.1362
DEBUG - 2021-02-03 12:15:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:15:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:15:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:15:05 --> Total execution time: 0.1614
DEBUG - 2021-02-03 12:15:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:15:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:15:05 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:15:05 --> Total execution time: 0.1607
DEBUG - 2021-02-03 12:15:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:15:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:15:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:15:06 --> Total execution time: 0.1317
DEBUG - 2021-02-03 12:15:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:15:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:15:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:15:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:15:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:15:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:15:23 --> Total execution time: 0.1228
DEBUG - 2021-02-03 12:15:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:15:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:15:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:15:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:15:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:15:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 12:15:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:15:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:15:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 12:16:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:16:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:16:12 --> Total execution time: 0.1819
DEBUG - 2021-02-03 12:16:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:16:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:16:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:16:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:16:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:16:38 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 12:16:38 --> Total execution time: 0.1163
DEBUG - 2021-02-03 12:16:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:16:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:16:40 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 12:16:40 --> Total execution time: 0.1447
DEBUG - 2021-02-03 12:16:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:16:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:16:48 --> Total execution time: 0.1324
DEBUG - 2021-02-03 12:16:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:16:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:16:53 --> Total execution time: 0.1515
DEBUG - 2021-02-03 12:17:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:17:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:17:05 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"1"}
DEBUG - 2021-02-03 12:17:05 --> Total execution time: 0.1038
DEBUG - 2021-02-03 12:17:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:17:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:17:08 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"1","support_lang_id":"1"}
DEBUG - 2021-02-03 12:17:08 --> Total execution time: 0.1396
DEBUG - 2021-02-03 12:17:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:17:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:17:12 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"1"}
DEBUG - 2021-02-03 12:17:12 --> Total execution time: 0.1237
DEBUG - 2021-02-03 12:17:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:17:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:17:17 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"7","support_lang_id":"1"}
ERROR - 2021-02-03 12:17:17 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 12:17:17 --> Total execution time: 0.1629
DEBUG - 2021-02-03 12:17:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:17:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:17:46 --> Total execution time: 0.1305
DEBUG - 2021-02-03 12:17:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:17:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:18:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:18:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:18:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:18:02 --> Total execution time: 0.1821
DEBUG - 2021-02-03 12:18:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:18:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:18:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:18:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:18:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:18:12 --> Total execution time: 0.1322
DEBUG - 2021-02-03 12:18:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:18:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:18:17 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"1"}
DEBUG - 2021-02-03 12:18:17 --> Total execution time: 0.1290
DEBUG - 2021-02-03 12:18:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:18:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:18:20 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"1","support_lang_id":"1"}
DEBUG - 2021-02-03 12:18:20 --> Total execution time: 0.1268
DEBUG - 2021-02-03 12:18:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:18:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:18:24 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"1"}
DEBUG - 2021-02-03 12:18:24 --> Total execution time: 0.1106
DEBUG - 2021-02-03 12:18:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:18:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:18:28 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"7","support_lang_id":"1"}
ERROR - 2021-02-03 12:18:28 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 12:18:28 --> Total execution time: 0.1232
DEBUG - 2021-02-03 12:18:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:18:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:18:42 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"1"}
DEBUG - 2021-02-03 12:18:42 --> Total execution time: 0.1127
DEBUG - 2021-02-03 12:18:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:18:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:18:45 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"1","support_lang_id":"1"}
DEBUG - 2021-02-03 12:18:45 --> Total execution time: 0.1233
DEBUG - 2021-02-03 12:18:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:18:49 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"1"}
DEBUG - 2021-02-03 12:18:49 --> Total execution time: 0.1130
DEBUG - 2021-02-03 12:19:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:19:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:19:22 --> Total execution time: 0.1938
DEBUG - 2021-02-03 12:19:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:19:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:19:24 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:19:24 --> Total execution time: 0.1536
DEBUG - 2021-02-03 12:19:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:19:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:19:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:19:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:19:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:19:27 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 12:19:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:19:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:19:29 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 12:19:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:19:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:19:37 --> Total execution time: 0.1201
DEBUG - 2021-02-03 12:19:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:19:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:19:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:19:40 --> Total execution time: 0.1823
DEBUG - 2021-02-03 12:19:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:19:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:19:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:29:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:29:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:29:49 --> Total execution time: 0.1726
DEBUG - 2021-02-03 12:29:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:29:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:29:51 --> Total execution time: 0.1448
DEBUG - 2021-02-03 12:29:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:29:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:29:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:29:52 --> Total execution time: 0.1723
DEBUG - 2021-02-03 12:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:29:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:29:52 --> Total execution time: 0.1891
DEBUG - 2021-02-03 12:29:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:29:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:29:54 --> Total execution time: 0.1528
DEBUG - 2021-02-03 12:29:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:29:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:29:55 --> Total execution time: 0.1561
DEBUG - 2021-02-03 12:29:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:29:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:29:58 --> Total execution time: 0.1237
DEBUG - 2021-02-03 12:29:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:29:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:29:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:30:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:30:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:30:04 --> Total execution time: 0.1298
DEBUG - 2021-02-03 12:30:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:30:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:30:07 --> Total execution time: 0.1349
DEBUG - 2021-02-03 12:30:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:30:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:30:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:30:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:30:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:30:37 --> Total execution time: 0.1373
DEBUG - 2021-02-03 12:30:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:30:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:30:39 --> Total execution time: 0.1929
DEBUG - 2021-02-03 12:30:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:30:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:30:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:30:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:30:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:31:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:31:36 --> No URI present. Default controller set.
DEBUG - 2021-02-03 12:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:31:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:31:37 --> Total execution time: 0.1767
DEBUG - 2021-02-03 12:31:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:31:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:31:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:31:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:31:49 --> Total execution time: 0.1370
DEBUG - 2021-02-03 12:31:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:31:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:31:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:32:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:32:23 --> No URI present. Default controller set.
DEBUG - 2021-02-03 12:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:32:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:32:23 --> Total execution time: 0.1751
DEBUG - 2021-02-03 12:32:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:32:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:32:25 --> Total execution time: 0.1310
DEBUG - 2021-02-03 12:32:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:32:29 --> No URI present. Default controller set.
DEBUG - 2021-02-03 12:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:32:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:32:29 --> Total execution time: 0.1373
DEBUG - 2021-02-03 12:32:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:32:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:32:31 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 12:32:31 --> Total execution time: 0.1338
DEBUG - 2021-02-03 12:32:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:32:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:32:35 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 12:32:35 --> Total execution time: 0.1359
DEBUG - 2021-02-03 12:32:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:32:35 --> No URI present. Default controller set.
DEBUG - 2021-02-03 12:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:32:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:32:35 --> Total execution time: 0.1686
DEBUG - 2021-02-03 12:32:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:32:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:32:39 --> Total execution time: 0.1261
DEBUG - 2021-02-03 12:32:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:32:44 --> No URI present. Default controller set.
DEBUG - 2021-02-03 12:32:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:32:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:32:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:32:44 --> Total execution time: 0.1241
DEBUG - 2021-02-03 12:32:44 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 12:32:44 --> Total execution time: 0.1228
DEBUG - 2021-02-03 12:32:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:32:55 --> No URI present. Default controller set.
DEBUG - 2021-02-03 12:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:32:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:32:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:32:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:32:55 --> Total execution time: 0.1713
DEBUG - 2021-02-03 12:32:55 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"2","support_lang_id":"3"}
ERROR - 2021-02-03 12:32:55 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 12:32:55 --> Total execution time: 0.1545
DEBUG - 2021-02-03 12:33:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:33:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:33:07 --> Total execution time: 0.1475
DEBUG - 2021-02-03 12:33:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:33:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:33:10 --> Total execution time: 0.1344
DEBUG - 2021-02-03 12:33:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:33:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:33:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:33:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:33:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:33:17 --> Total execution time: 0.1292
DEBUG - 2021-02-03 12:33:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:33:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:33:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:33:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:33:20 --> No URI present. Default controller set.
DEBUG - 2021-02-03 12:33:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:33:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:33:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:33:20 --> Total execution time: 0.1580
DEBUG - 2021-02-03 12:33:20 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 12:33:20 --> Total execution time: 0.1555
DEBUG - 2021-02-03 12:33:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:33:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:33:24 --> No URI present. Default controller set.
DEBUG - 2021-02-03 12:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:33:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:33:24 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"2","support_lang_id":"3"}
ERROR - 2021-02-03 12:33:24 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 12:33:24 --> Total execution time: 0.1597
DEBUG - 2021-02-03 12:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:33:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:33:24 --> Total execution time: 0.1583
DEBUG - 2021-02-03 12:33:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:33:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:33:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:33:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:33:49 --> No URI present. Default controller set.
DEBUG - 2021-02-03 12:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:33:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:33:49 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 12:33:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:33:49 --> Total execution time: 0.1242
DEBUG - 2021-02-03 12:33:49 --> Total execution time: 0.1419
DEBUG - 2021-02-03 12:36:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:36:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:36:48 --> Total execution time: 0.2020
DEBUG - 2021-02-03 12:36:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:36:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:36:52 --> Total execution time: 0.1562
DEBUG - 2021-02-03 12:37:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:37:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:37:04 --> Total execution time: 0.1502
DEBUG - 2021-02-03 12:37:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:37:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:37:09 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 12:37:09 --> Total execution time: 0.1693
DEBUG - 2021-02-03 12:37:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:37:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:37:14 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 12:37:14 --> Total execution time: 0.1357
DEBUG - 2021-02-03 12:37:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:37:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:37:18 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 12:37:18 --> Total execution time: 0.1463
DEBUG - 2021-02-03 12:37:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:37:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:37:22 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"7","support_lang_id":"3"}
ERROR - 2021-02-03 12:37:22 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 12:37:22 --> Total execution time: 0.1301
DEBUG - 2021-02-03 12:37:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:37:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:37:25 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 12:37:25 --> Total execution time: 0.1444
DEBUG - 2021-02-03 12:38:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:38:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:38:39 --> Total execution time: 0.1557
DEBUG - 2021-02-03 12:38:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:38:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:38:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 12:38:41 --> Total execution time: 0.1671
DEBUG - 2021-02-03 12:38:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:38:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:38:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:38:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:38:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:38:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:38:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:38:55 --> Total execution time: 0.1609
DEBUG - 2021-02-03 12:38:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:38:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:38:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:38:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:38:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:38:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:38:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:38:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:38:57 --> UTF-8 Support Enabled
ERROR - 2021-02-03 12:38:57 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 12:38:57 --> Total execution time: 0.1373
DEBUG - 2021-02-03 12:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:38:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:38:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:38:58 --> Total execution time: 0.1243
DEBUG - 2021-02-03 12:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:38:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:38:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:38:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:38:58 --> Total execution time: 0.1341
DEBUG - 2021-02-03 12:38:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:38:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:38:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:38:58 --> Total execution time: 0.1294
DEBUG - 2021-02-03 12:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:38:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:38:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:38:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:38:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:38:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:38:59 --> Total execution time: 0.1334
DEBUG - 2021-02-03 12:39:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:39:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:00 --> Total execution time: 0.1467
DEBUG - 2021-02-03 12:39:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:01 --> Total execution time: 0.1345
DEBUG - 2021-02-03 12:39:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:02 --> Total execution time: 0.1440
DEBUG - 2021-02-03 12:39:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:11 --> Total execution time: 0.1488
DEBUG - 2021-02-03 12:39:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:12 --> Total execution time: 0.1408
DEBUG - 2021-02-03 12:39:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:39:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:39:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:39:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:39:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:15 --> Total execution time: 0.1633
DEBUG - 2021-02-03 12:39:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:17 --> Total execution time: 0.1406
DEBUG - 2021-02-03 12:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:39:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:39:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:39:19 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:19 --> Total execution time: 0.1306
DEBUG - 2021-02-03 12:39:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:39:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:39:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:22 --> Total execution time: 0.1386
DEBUG - 2021-02-03 12:39:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:39:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:39:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:28 --> Total execution time: 0.1505
DEBUG - 2021-02-03 12:39:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:30 --> Total execution time: 0.1515
DEBUG - 2021-02-03 12:39:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:39:31 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:39:31 --> Total execution time: 0.1733
DEBUG - 2021-02-03 12:39:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:32 --> Total execution time: 0.1443
DEBUG - 2021-02-03 12:39:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:39:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 12:39:32 --> Total execution time: 0.1226
DEBUG - 2021-02-03 12:39:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:39:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:39:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:39:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 12:39:34 --> Total execution time: 0.1421
DEBUG - 2021-02-03 12:39:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:39:34 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:34 --> Total execution time: 0.1298
DEBUG - 2021-02-03 12:39:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:37 --> UTF-8 Support Enabled
ERROR - 2021-02-03 12:39:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:37 --> Total execution time: 0.1412
DEBUG - 2021-02-03 12:39:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:37 --> Total execution time: 0.1393
DEBUG - 2021-02-03 12:39:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:39:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:39:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:40 --> Total execution time: 0.2115
DEBUG - 2021-02-03 12:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:40 --> Total execution time: 0.1829
DEBUG - 2021-02-03 12:39:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:42 --> Total execution time: 0.1621
DEBUG - 2021-02-03 12:39:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:39:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:39:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:39:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:39:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:46 --> Total execution time: 0.1302
DEBUG - 2021-02-03 12:39:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:49 --> Total execution time: 0.1573
DEBUG - 2021-02-03 12:39:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:39:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:39:50 --> Total execution time: 0.1564
DEBUG - 2021-02-03 12:39:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:39:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:39:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:39:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:39:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:40:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:40:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:40:06 --> Total execution time: 0.1361
DEBUG - 2021-02-03 12:40:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:40:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:40:34 --> Total execution time: 0.1515
DEBUG - 2021-02-03 12:40:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:40:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:40:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:40:36 --> Total execution time: 0.1447
DEBUG - 2021-02-03 12:40:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:40:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:40:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:40:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:40:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:41:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:41:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:41:10 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"7","support_lang_id":"3"}
ERROR - 2021-02-03 12:41:10 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 12:41:10 --> Total execution time: 0.1854
DEBUG - 2021-02-03 12:41:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:41:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:41:24 --> Total execution time: 0.1820
DEBUG - 2021-02-03 12:41:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:41:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:41:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:41:25 --> Total execution time: 0.1829
DEBUG - 2021-02-03 12:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:41:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:41:26 --> Total execution time: 0.1257
DEBUG - 2021-02-03 12:41:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:41:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:41:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:41:26 --> Total execution time: 0.1788
DEBUG - 2021-02-03 12:41:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:41:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:41:27 --> Total execution time: 0.1434
DEBUG - 2021-02-03 12:41:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:41:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:41:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:41:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:41:28 --> Total execution time: 0.1934
DEBUG - 2021-02-03 12:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:41:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:41:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:41:29 --> Total execution time: 0.1922
DEBUG - 2021-02-03 12:41:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:41:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:41:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:41:30 --> Total execution time: 0.2013
DEBUG - 2021-02-03 12:41:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:41:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:41:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:41:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:41:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:41:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:41:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:41:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:41:48 --> Total execution time: 0.1818
DEBUG - 2021-02-03 12:41:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:41:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:41:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:41:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:41:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:41:52 --> Total execution time: 0.1282
DEBUG - 2021-02-03 12:41:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:41:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:41:56 --> Total execution time: 0.1344
DEBUG - 2021-02-03 12:42:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:42:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:42:08 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 12:42:08 --> Total execution time: 0.1413
DEBUG - 2021-02-03 12:42:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:42:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:42:13 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 12:42:13 --> Total execution time: 0.1372
DEBUG - 2021-02-03 12:42:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:42:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:42:18 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 12:42:18 --> Total execution time: 0.1326
DEBUG - 2021-02-03 12:42:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:42:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:42:22 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"7","support_lang_id":"3"}
ERROR - 2021-02-03 12:42:22 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 12:42:22 --> Total execution time: 0.1127
DEBUG - 2021-02-03 12:42:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:42:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:42:34 --> Total execution time: 0.1545
DEBUG - 2021-02-03 12:42:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:42:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:42:38 --> Total execution time: 0.1388
DEBUG - 2021-02-03 12:42:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:42:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:42:53 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 12:42:53 --> Total execution time: 0.1526
DEBUG - 2021-02-03 12:42:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:42:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:42:56 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 12:42:56 --> Total execution time: 0.1142
DEBUG - 2021-02-03 12:43:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:43:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:43:01 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 12:43:01 --> Total execution time: 0.1114
DEBUG - 2021-02-03 12:43:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:43:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:43:06 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"8","subcategory_id":"3","support_lang_id":"3"}
ERROR - 2021-02-03 12:43:06 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 12:43:06 --> Total execution time: 0.1406
DEBUG - 2021-02-03 12:43:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:43:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:43:31 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 12:43:31 --> Total execution time: 0.1215
DEBUG - 2021-02-03 12:43:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:43:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:43:56 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 12:43:56 --> Total execution time: 0.1541
DEBUG - 2021-02-03 12:45:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:45:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:45:39 --> Total execution time: 0.1258
DEBUG - 2021-02-03 12:45:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:45:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:45:45 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"1"}
DEBUG - 2021-02-03 12:45:45 --> Total execution time: 0.1631
DEBUG - 2021-02-03 12:45:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:45:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:45:50 --> Total execution time: 0.1649
DEBUG - 2021-02-03 12:45:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:45:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:45:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:46:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:46:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:46:03 --> Total execution time: 0.1603
DEBUG - 2021-02-03 12:46:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:46:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:46:06 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:46:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:46:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:46:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:46:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:46:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:46:40 --> Total execution time: 0.1386
DEBUG - 2021-02-03 12:46:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:46:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:46:43 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:46:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:46:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:46:48 --> Total execution time: 0.1216
DEBUG - 2021-02-03 12:46:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:46:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:46:56 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 12:46:56 --> Total execution time: 0.1114
DEBUG - 2021-02-03 12:47:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:47:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:47:00 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 12:47:00 --> Total execution time: 0.1386
DEBUG - 2021-02-03 12:47:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:47:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:47:03 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 12:47:03 --> Total execution time: 0.1084
DEBUG - 2021-02-03 12:47:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:47:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:47:07 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 12:47:07 --> Total execution time: 0.1218
DEBUG - 2021-02-03 12:47:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:47:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:47:09 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 12:47:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:47:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:47:21 --> get_sorce_lan_word_type_6->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 12:47:21 --> Total execution time: 0.1221
DEBUG - 2021-02-03 12:47:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:47:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:47:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 12:47:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:47:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:47:33 --> Total execution time: 0.1155
DEBUG - 2021-02-03 12:47:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:47:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:47:38 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 12:47:38 --> Total execution time: 0.1457
DEBUG - 2021-02-03 12:47:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:47:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:47:49 --> get_sorce_lan_word_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 12:47:49 --> Total execution time: 0.1825
DEBUG - 2021-02-03 12:47:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:47:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:47:57 --> get_sorce_lan_word_type_3->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 12:47:57 --> Total execution time: 0.1557
DEBUG - 2021-02-03 12:48:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:48:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:48:06 --> get_sorce_lan_word_type_7->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 12:48:06 --> Total execution time: 0.1278
DEBUG - 2021-02-03 12:48:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:48:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:48:15 --> get_sorce_lan_word_type_4->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 12:48:15 --> Total execution time: 0.1274
DEBUG - 2021-02-03 12:48:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:48:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:48:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 12:48:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:48:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:48:22 --> get_sorce_lan_word_type_5->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 12:48:22 --> Total execution time: 0.1474
DEBUG - 2021-02-03 12:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:48:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:48:32 --> get_sorce_lan_word_type_9->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 12:48:32 --> Total execution time: 0.1515
DEBUG - 2021-02-03 12:49:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:49:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:49:19 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 12:49:19 --> Total execution time: 0.1444
DEBUG - 2021-02-03 12:49:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:49:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:49:24 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 12:49:24 --> Total execution time: 0.1274
DEBUG - 2021-02-03 12:49:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:49:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:49:28 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 12:49:28 --> Total execution time: 0.1562
DEBUG - 2021-02-03 12:49:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:49:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:49:32 --> get_exercise_type_list->{"lang":"37","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-03 12:49:32 --> Total execution time: 0.1340
DEBUG - 2021-02-03 12:49:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:49:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:49:36 --> get_dialogue_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"2","category_id":"7","subcategory_id":"6","support_lang_id":"3"}
ERROR - 2021-02-03 12:49:36 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 12:49:36 --> Total execution time: 0.1330
DEBUG - 2021-02-03 12:49:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:49:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:49:43 --> Total execution time: 0.1511
DEBUG - 2021-02-03 12:49:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:49:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:49:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 12:49:45 --> Total execution time: 0.1432
DEBUG - 2021-02-03 12:49:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:49:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:49:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:50:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:50:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:50:06 --> Total execution time: 0.1560
DEBUG - 2021-02-03 12:50:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:50:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:50:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:50:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:50:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:50:15 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 12:50:15 --> Total execution time: 0.1301
DEBUG - 2021-02-03 12:50:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:50:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:50:26 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 12:50:26 --> Total execution time: 0.1431
DEBUG - 2021-02-03 12:50:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:50:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:50:37 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 12:50:37 --> Total execution time: 0.1341
DEBUG - 2021-02-03 12:50:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:50:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:50:41 --> get_exercise_type_list->{"lang":"37","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-03 12:50:41 --> Total execution time: 0.1182
DEBUG - 2021-02-03 12:50:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:50:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:50:46 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 12:50:46 --> Total execution time: 0.1565
DEBUG - 2021-02-03 12:50:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:50:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:50:49 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 12:50:49 --> Total execution time: 0.1348
DEBUG - 2021-02-03 12:50:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:50:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:50:50 --> get_dialogue_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"2","category_id":"7","subcategory_id":"6","support_lang_id":"3"}
ERROR - 2021-02-03 12:50:50 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 12:50:50 --> Total execution time: 0.1381
DEBUG - 2021-02-03 12:50:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:50:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:50:51 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:50:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:50:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:50:57 --> Total execution time: 0.1512
DEBUG - 2021-02-03 12:50:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:51:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:51:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 12:51:00 --> Total execution time: 0.1397
DEBUG - 2021-02-03 12:51:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:51:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:51:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:51:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:51:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:51:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 12:51:07 --> Total execution time: 0.1578
DEBUG - 2021-02-03 12:51:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:51:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:51:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 12:51:10 --> Total execution time: 0.1468
DEBUG - 2021-02-03 12:51:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:51:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:51:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:51:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:51:17 --> Total execution time: 0.1606
DEBUG - 2021-02-03 12:51:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:51:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:51:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:52:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:52:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:52:04 --> get_dialogue_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"2","category_id":"7","subcategory_id":"6","support_lang_id":"3"}
ERROR - 2021-02-03 12:52:04 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 12:52:04 --> Total execution time: 0.1313
DEBUG - 2021-02-03 12:52:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:52:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:52:08 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 12:52:08 --> Total execution time: 0.1572
DEBUG - 2021-02-03 12:52:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:52:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:52:14 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 12:52:14 --> Total execution time: 0.1466
DEBUG - 2021-02-03 12:52:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:52:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:52:18 --> get_subcategory_list->{"lang":"37","category_id":"9","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 12:52:18 --> Total execution time: 0.1261
DEBUG - 2021-02-03 12:52:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:52:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:52:21 --> get_exercise_type_list->{"lang":"37","subcategory_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 12:52:21 --> Total execution time: 0.1611
DEBUG - 2021-02-03 12:52:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:52:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:52:24 --> get_phrases_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"3","category_id":"9","subcategory_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 12:52:24 --> Total execution time: 0.1308
DEBUG - 2021-02-03 12:52:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:52:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:52:31 --> get_subcategory_list->{"lang":"37","category_id":"9","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 12:52:31 --> Total execution time: 0.1577
DEBUG - 2021-02-03 12:52:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:52:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:52:36 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 12:52:36 --> Total execution time: 0.1236
DEBUG - 2021-02-03 12:52:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:52:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:52:40 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 12:52:40 --> Total execution time: 0.1340
DEBUG - 2021-02-03 12:52:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:52:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:52:43 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 12:52:43 --> Total execution time: 0.1432
DEBUG - 2021-02-03 12:52:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:52:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:52:47 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"8","subcategory_id":"3","support_lang_id":"3"}
ERROR - 2021-02-03 12:52:47 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 12:52:47 --> Total execution time: 0.1355
DEBUG - 2021-02-03 12:52:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:52:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:52:53 --> Total execution time: 0.1651
DEBUG - 2021-02-03 12:52:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:52:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:52:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 12:52:55 --> Total execution time: 0.1672
DEBUG - 2021-02-03 12:52:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:52:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:52:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:53:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:53:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:53:10 --> Total execution time: 0.1599
DEBUG - 2021-02-03 12:53:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:53:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:53:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 12:53:13 --> Total execution time: 0.1726
DEBUG - 2021-02-03 12:53:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:53:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:53:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:53:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:53:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 12:53:20 --> Total execution time: 0.1829
DEBUG - 2021-02-03 12:53:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:53:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:53:23 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 12:53:23 --> Total execution time: 0.1957
DEBUG - 2021-02-03 12:53:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:53:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:53:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:53:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:53:30 --> Total execution time: 0.1619
DEBUG - 2021-02-03 12:53:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:53:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:53:31 --> Total execution time: 0.1461
DEBUG - 2021-02-03 12:53:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:53:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:53:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:53:32 --> Total execution time: 0.1262
DEBUG - 2021-02-03 12:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:53:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:53:32 --> Total execution time: 0.1352
DEBUG - 2021-02-03 12:53:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:53:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:53:32 --> Total execution time: 0.1370
DEBUG - 2021-02-03 12:53:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:53:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:53:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:53:33 --> Total execution time: 0.1347
DEBUG - 2021-02-03 12:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:53:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:53:33 --> Total execution time: 0.1376
DEBUG - 2021-02-03 12:53:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:53:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:53:34 --> Total execution time: 0.1410
DEBUG - 2021-02-03 12:53:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:53:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:53:34 --> Total execution time: 0.1445
DEBUG - 2021-02-03 12:53:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:53:35 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:53:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:53:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:53:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:53:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:53:35 --> Total execution time: 0.1760
DEBUG - 2021-02-03 12:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:53:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:53:36 --> Total execution time: 0.2124
DEBUG - 2021-02-03 12:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:53:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:53:36 --> Total execution time: 0.2035
DEBUG - 2021-02-03 12:53:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:53:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:53:36 --> Total execution time: 0.1239
DEBUG - 2021-02-03 12:53:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:53:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:53:38 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 12:53:38 --> Total execution time: 0.1205
DEBUG - 2021-02-03 12:53:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:53:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:53:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:53:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:53:42 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 12:53:42 --> Total execution time: 0.1332
DEBUG - 2021-02-03 12:53:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:53:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:53:48 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 12:53:48 --> Total execution time: 0.1617
DEBUG - 2021-02-03 12:53:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:53:52 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 12:53:52 --> Total execution time: 0.1039
DEBUG - 2021-02-03 12:53:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:53:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:53:55 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"8","subcategory_id":"3","support_lang_id":"3"}
ERROR - 2021-02-03 12:53:55 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 12:53:55 --> Total execution time: 0.1317
DEBUG - 2021-02-03 12:54:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:54:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:54:31 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 12:54:31 --> Total execution time: 0.1073
DEBUG - 2021-02-03 12:54:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:54:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:54:36 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 12:54:36 --> Total execution time: 0.1138
DEBUG - 2021-02-03 12:54:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:54:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:54:40 --> Total execution time: 0.1249
DEBUG - 2021-02-03 12:54:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:54:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:54:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:54:42 --> Total execution time: 0.1571
DEBUG - 2021-02-03 12:54:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:54:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:54:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:54:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:54:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:54:49 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 12:54:49 --> Total execution time: 0.1352
DEBUG - 2021-02-03 12:54:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:54:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:54:54 --> Total execution time: 0.1454
DEBUG - 2021-02-03 12:54:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:54:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:54:55 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 12:54:55 --> Total execution time: 0.1086
DEBUG - 2021-02-03 12:54:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:54:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:54:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:55:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:55:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:55:01 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 12:55:01 --> Total execution time: 0.1651
DEBUG - 2021-02-03 12:55:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:55:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:55:04 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"2","support_lang_id":"3"}
ERROR - 2021-02-03 12:55:04 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 12:55:04 --> Total execution time: 0.1490
DEBUG - 2021-02-03 12:55:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:55:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:55:18 --> Total execution time: 0.1619
DEBUG - 2021-02-03 12:55:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:55:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:55:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:55:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:55:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:55:33 --> Total execution time: 0.1848
DEBUG - 2021-02-03 12:55:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:55:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:55:36 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 12:55:36 --> Total execution time: 0.1519
DEBUG - 2021-02-03 12:55:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:55:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:55:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:55:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:55:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:55:38 --> Total execution time: 0.1714
DEBUG - 2021-02-03 12:55:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:55:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:55:42 --> Total execution time: 0.1344
DEBUG - 2021-02-03 12:55:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:55:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:55:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:55:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:55:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:55:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 12:55:48 --> Total execution time: 0.1524
DEBUG - 2021-02-03 12:55:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:55:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:55:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:55:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:55:50 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 12:55:50 --> Total execution time: 0.1568
DEBUG - 2021-02-03 12:55:50 --> Total execution time: 0.1422
DEBUG - 2021-02-03 12:55:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:55:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:55:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:55:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:55:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:55:53 --> Total execution time: 0.1356
DEBUG - 2021-02-03 12:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:55:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:55:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:56:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:56:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:56:07 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 12:56:07 --> Total execution time: 0.1195
DEBUG - 2021-02-03 12:56:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:56:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:56:10 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 12:56:10 --> Total execution time: 0.1142
DEBUG - 2021-02-03 12:56:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:56:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:56:13 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"7","support_lang_id":"3"}
ERROR - 2021-02-03 12:56:13 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 12:56:13 --> Total execution time: 0.1514
DEBUG - 2021-02-03 12:56:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:56:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:56:17 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 12:56:17 --> Total execution time: 0.0987
DEBUG - 2021-02-03 12:56:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:56:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:56:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:56:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:56:38 --> Total execution time: 0.1588
DEBUG - 2021-02-03 12:56:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:56:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:56:40 --> Total execution time: 0.1652
DEBUG - 2021-02-03 12:56:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:56:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:56:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:56:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:56:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:56:43 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-02-03 12:56:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:56:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:56:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:56:43 --> Total execution time: 0.1171
DEBUG - 2021-02-03 12:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:56:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:56:43 --> Total execution time: 0.1324
DEBUG - 2021-02-03 12:56:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:56:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:56:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:56:45 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-02-03 12:56:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:56:45 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-02-03 12:56:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:56:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:56:47 --> Total execution time: 0.1218
DEBUG - 2021-02-03 12:56:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:56:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:56:54 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 12:56:54 --> Total execution time: 0.1984
DEBUG - 2021-02-03 12:56:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:56:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:56:54 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 12:56:54 --> Total execution time: 0.1299
DEBUG - 2021-02-03 12:56:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:56:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:56:57 --> get_subcategory_list->{"lang":"37","category_id":"9","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 12:56:57 --> Total execution time: 0.1240
DEBUG - 2021-02-03 12:56:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:57:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:57:00 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-02-03 12:57:00 --> Total execution time: 0.1530
DEBUG - 2021-02-03 12:57:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:57:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:57:01 --> get_exercise_type_list->{"lang":"37","subcategory_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 12:57:01 --> Total execution time: 0.1140
DEBUG - 2021-02-03 12:57:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:57:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:57:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:57:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:57:04 --> get_phrases_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"3","category_id":"9","subcategory_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 12:57:04 --> Total execution time: 0.1385
DEBUG - 2021-02-03 12:57:04 --> Total execution time: 0.1286
DEBUG - 2021-02-03 12:57:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:57:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:57:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 12:57:06 --> Total execution time: 0.1366
DEBUG - 2021-02-03 12:57:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:57:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:57:06 --> Total execution time: 0.1509
DEBUG - 2021-02-03 12:57:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:57:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:57:08 --> Total execution time: 0.1424
DEBUG - 2021-02-03 12:57:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:57:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:57:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:57:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:57:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:57:09 --> get_subcategory_list->{"lang":"37","category_id":"9","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 12:57:09 --> Total execution time: 0.1184
DEBUG - 2021-02-03 12:57:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:57:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:57:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:57:09 --> Total execution time: 0.1392
DEBUG - 2021-02-03 12:57:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:57:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:57:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 12:57:11 --> Total execution time: 0.1580
DEBUG - 2021-02-03 12:57:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:57:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:57:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:57:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:57:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:57:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 12:57:15 --> Total execution time: 0.1551
DEBUG - 2021-02-03 12:57:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:57:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:57:17 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 12:57:17 --> Total execution time: 0.1629
DEBUG - 2021-02-03 12:57:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:57:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 12:57:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 12:57:18 --> Total execution time: 0.1516
DEBUG - 2021-02-03 12:57:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:57:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 12:57:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 12:57:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:57:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:57:21 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 12:57:21 --> Total execution time: 0.1183
DEBUG - 2021-02-03 12:57:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:57:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:57:27 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 12:57:27 --> Total execution time: 0.1510
DEBUG - 2021-02-03 12:57:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:57:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:57:29 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"8","subcategory_id":"3","support_lang_id":"3"}
ERROR - 2021-02-03 12:57:29 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 12:57:29 --> Total execution time: 0.1386
DEBUG - 2021-02-03 12:57:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:57:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:57:30 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 12:57:30 --> Total execution time: 0.1463
DEBUG - 2021-02-03 12:58:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:58:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:58:05 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 12:58:05 --> Total execution time: 0.1484
DEBUG - 2021-02-03 12:58:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:58:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:58:10 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"7","support_lang_id":"3"}
ERROR - 2021-02-03 12:58:10 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 12:58:10 --> Total execution time: 0.1098
DEBUG - 2021-02-03 12:58:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:58:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:58:13 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 12:58:13 --> Total execution time: 0.1578
DEBUG - 2021-02-03 12:58:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:58:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:58:18 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 12:58:18 --> Total execution time: 0.1538
DEBUG - 2021-02-03 12:58:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:58:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:58:30 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 12:58:30 --> Total execution time: 0.1519
DEBUG - 2021-02-03 12:59:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 12:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 12:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 12:59:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 12:59:58 --> Total execution time: 0.1284
DEBUG - 2021-02-03 13:00:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:00:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:00:10 --> Total execution time: 0.1320
DEBUG - 2021-02-03 13:00:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:00:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:00:16 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 13:00:16 --> Total execution time: 0.1627
DEBUG - 2021-02-03 13:00:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:00:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:00:17 --> Total execution time: 0.1294
DEBUG - 2021-02-03 13:00:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:00:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:00:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:00:19 --> Total execution time: 0.1266
DEBUG - 2021-02-03 13:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:00:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:00:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 13:00:19 --> Total execution time: 0.1367
DEBUG - 2021-02-03 13:00:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:00:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:00:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 13:00:22 --> Total execution time: 0.1298
DEBUG - 2021-02-03 13:00:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:00:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:00:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:00:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:00:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:00:26 --> Total execution time: 0.1274
DEBUG - 2021-02-03 13:00:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:00:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:00:34 --> Total execution time: 0.1280
DEBUG - 2021-02-03 13:00:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:00:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:00:35 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 13:00:35 --> Total execution time: 0.1373
DEBUG - 2021-02-03 13:00:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:00:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:00:38 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 13:00:38 --> Total execution time: 0.1433
DEBUG - 2021-02-03 13:00:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:00:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:00:40 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:00:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:00:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:00:43 --> Total execution time: 0.0971
DEBUG - 2021-02-03 13:00:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:00:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:00:50 --> Total execution time: 0.1368
DEBUG - 2021-02-03 13:00:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:00:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:01:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:01:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:01:02 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 13:01:02 --> Total execution time: 0.1195
DEBUG - 2021-02-03 13:01:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:01:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:01:03 --> Total execution time: 0.1284
DEBUG - 2021-02-03 13:01:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:01:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:01:04 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:01:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:01:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:01:04 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 13:01:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:01:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:01:12 --> Total execution time: 0.1357
DEBUG - 2021-02-03 13:01:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:01:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:01:14 --> Total execution time: 0.1374
DEBUG - 2021-02-03 13:01:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:01:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:01:23 --> Total execution time: 0.1415
DEBUG - 2021-02-03 13:01:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:01:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:01:28 --> Total execution time: 0.1246
DEBUG - 2021-02-03 13:01:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:01:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:01:35 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 13:01:35 --> Total execution time: 0.1487
DEBUG - 2021-02-03 13:01:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:01:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:01:41 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 13:01:41 --> Total execution time: 0.1477
DEBUG - 2021-02-03 13:01:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:01:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:01:46 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 13:01:46 --> Total execution time: 0.1566
DEBUG - 2021-02-03 13:01:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:01:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:01:49 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"7","support_lang_id":"3"}
ERROR - 2021-02-03 13:01:49 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 13:01:49 --> Total execution time: 0.1307
DEBUG - 2021-02-03 13:02:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:02:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:02:03 --> Total execution time: 0.1086
DEBUG - 2021-02-03 13:02:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:02:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:02:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:02:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:02:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:02:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 13:02:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:02:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:02:43 --> Total execution time: 0.1285
DEBUG - 2021-02-03 13:02:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:02:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:02:44 --> Total execution time: 0.1395
DEBUG - 2021-02-03 13:02:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:02:45 --> Total execution time: 0.1404
DEBUG - 2021-02-03 13:02:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:02:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:02:47 --> Total execution time: 0.2166
DEBUG - 2021-02-03 13:02:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:02:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:02:49 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:02:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:02:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:02:50 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-02-03 13:02:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:02:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:02:51 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-02-03 13:02:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:02:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:02:51 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-02-03 13:03:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:03:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:03:00 --> Total execution time: 0.1419
DEBUG - 2021-02-03 13:03:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:03:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:03:02 --> Total execution time: 0.1432
DEBUG - 2021-02-03 13:03:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:03:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:03:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:03:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:03:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:03:05 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-02-03 13:03:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:03:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:03:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:03:07 --> 404 Page Not Found: Uploads/crayfish_party
ERROR - 2021-02-03 13:03:07 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-02-03 13:03:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:03:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:03:11 --> Total execution time: 0.1274
DEBUG - 2021-02-03 13:03:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:03:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:03:14 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:03:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:03:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:03:55 --> Total execution time: 0.1303
DEBUG - 2021-02-03 13:03:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:03:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:03:57 --> Total execution time: 0.1285
DEBUG - 2021-02-03 13:03:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:03:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:03:57 --> Total execution time: 0.1279
DEBUG - 2021-02-03 13:03:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:03:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:03:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:03:57 --> Total execution time: 0.1651
DEBUG - 2021-02-03 13:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:03:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:03:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:03:57 --> Total execution time: 0.1436
DEBUG - 2021-02-03 13:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:03:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:03:58 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 13:03:58 --> Total execution time: 0.1880
DEBUG - 2021-02-03 13:03:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:03:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:03:58 --> Total execution time: 0.1526
DEBUG - 2021-02-03 13:03:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:03:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:03:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 13:03:59 --> Total execution time: 0.1406
DEBUG - 2021-02-03 13:03:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:04:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:04:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 13:04:00 --> Total execution time: 0.1635
DEBUG - 2021-02-03 13:04:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:04:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:04:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:04:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:04:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 13:04:00 --> Total execution time: 0.1399
DEBUG - 2021-02-03 13:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:04:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:04:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 13:04:00 --> Total execution time: 0.2019
DEBUG - 2021-02-03 13:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:04:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:04:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 13:04:01 --> Total execution time: 0.2025
DEBUG - 2021-02-03 13:04:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:04:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:04:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:04:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:04:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:04:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:04:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:04:18 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 13:04:18 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 13:04:18 --> Total execution time: 0.2023
DEBUG - 2021-02-03 13:04:18 --> Total execution time: 0.2171
DEBUG - 2021-02-03 13:06:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:06:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:06:17 --> Total execution time: 0.1239
DEBUG - 2021-02-03 13:06:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:06:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:06:17 --> Total execution time: 0.1336
DEBUG - 2021-02-03 13:06:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:06:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:06:18 --> Total execution time: 0.1294
DEBUG - 2021-02-03 13:06:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:06:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:06:19 --> Total execution time: 0.1161
DEBUG - 2021-02-03 13:06:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:06:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:06:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:06:20 --> Total execution time: 0.1508
DEBUG - 2021-02-03 13:06:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:06:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:06:20 --> Total execution time: 0.1148
DEBUG - 2021-02-03 13:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:06:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:06:20 --> Total execution time: 0.1336
DEBUG - 2021-02-03 13:06:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:06:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:06:20 --> Total execution time: 0.1580
DEBUG - 2021-02-03 13:06:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:06:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:06:21 --> Total execution time: 0.1571
DEBUG - 2021-02-03 13:06:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:06:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:06:22 --> Total execution time: 0.1531
DEBUG - 2021-02-03 13:06:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:06:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:06:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:06:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:06:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:06:25 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-02-03 13:06:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:06:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:06:27 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-02-03 13:06:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:06:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:06:27 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-02-03 13:06:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:06:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:06:36 --> Total execution time: 0.1486
DEBUG - 2021-02-03 13:06:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:06:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:06:39 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:07:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:07:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:07:54 --> Total execution time: 0.1289
DEBUG - 2021-02-03 13:07:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:07:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:07:55 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 13:07:55 --> Total execution time: 0.1303
DEBUG - 2021-02-03 13:07:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:07:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:07:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:07:58 --> 404 Page Not Found: Assets/chosen
ERROR - 2021-02-03 13:07:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 13:09:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:09:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:09:16 --> Total execution time: 0.1371
DEBUG - 2021-02-03 13:09:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:09:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:09:19 --> Total execution time: 0.1393
DEBUG - 2021-02-03 13:09:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:09:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:09:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:09:22 --> 404 Page Not Found: Uploads/pencil.jpg
ERROR - 2021-02-03 13:09:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:09:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:09:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:09:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:09:22 --> 404 Page Not Found: Uploads/crayfish_party
ERROR - 2021-02-03 13:09:22 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-02-03 13:09:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:09:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:09:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:09:24 --> 404 Page Not Found: Uploads/pencil.jpg
ERROR - 2021-02-03 13:09:24 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-02-03 13:09:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:09:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:09:37 --> Total execution time: 0.1310
DEBUG - 2021-02-03 13:09:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:09:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:09:39 --> Total execution time: 0.1548
DEBUG - 2021-02-03 13:09:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:09:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:09:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:09:42 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-02-03 13:09:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:09:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:09:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:09:42 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-02-03 13:09:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:09:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:09:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:09:42 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-02-03 13:09:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:09:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:09:47 --> Total execution time: 0.1370
DEBUG - 2021-02-03 13:09:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:09:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:09:50 --> Total execution time: 0.1482
DEBUG - 2021-02-03 13:09:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:09:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:09:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:09:52 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-02-03 13:09:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:09:52 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-02-03 13:09:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:09:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:09:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:09:52 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-02-03 13:09:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:09:52 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:09:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:09:55 --> UTF-8 Support Enabled
ERROR - 2021-02-03 13:09:55 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-02-03 13:09:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:09:55 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-02-03 13:09:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:09:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:09:55 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-02-03 13:13:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:13:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:13:17 --> Total execution time: 0.1564
DEBUG - 2021-02-03 13:13:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:13:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:13:18 --> Total execution time: 0.1164
DEBUG - 2021-02-03 13:13:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:13:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:13:19 --> Total execution time: 0.1155
DEBUG - 2021-02-03 13:13:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:13:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:13:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:13:20 --> Total execution time: 0.1423
DEBUG - 2021-02-03 13:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:13:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:13:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:13:20 --> Total execution time: 0.1472
DEBUG - 2021-02-03 13:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:13:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:13:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:13:20 --> Total execution time: 0.1255
DEBUG - 2021-02-03 13:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:13:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:13:20 --> Total execution time: 0.1182
DEBUG - 2021-02-03 13:13:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:13:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:13:22 --> Total execution time: 0.1325
DEBUG - 2021-02-03 13:13:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:13:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:13:22 --> Total execution time: 0.1365
DEBUG - 2021-02-03 13:13:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:13:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:13:22 --> Total execution time: 0.1275
DEBUG - 2021-02-03 13:13:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:13:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:13:26 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:13:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:13:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:13:26 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-02-03 13:13:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:13:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:13:28 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-02-03 13:13:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:13:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:13:28 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-02-03 13:13:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:13:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:13:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:13:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:13:32 --> Total execution time: 0.1676
DEBUG - 2021-02-03 13:13:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:13:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:13:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:13:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:13:51 --> Total execution time: 0.1581
DEBUG - 2021-02-03 13:13:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:13:54 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:14:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:14:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:14:23 --> Total execution time: 0.1613
DEBUG - 2021-02-03 13:14:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:14:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:14:27 --> Total execution time: 0.1339
DEBUG - 2021-02-03 13:14:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:14:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:14:29 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:14:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:14:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:14:30 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-02-03 13:14:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:14:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:14:31 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-02-03 13:14:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:14:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:14:32 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-02-03 13:14:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:14:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:14:37 --> Total execution time: 0.1368
DEBUG - 2021-02-03 13:14:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:14:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:14:38 --> Total execution time: 0.1370
DEBUG - 2021-02-03 13:14:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:14:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:14:39 --> Total execution time: 0.1520
DEBUG - 2021-02-03 13:14:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:14:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:14:41 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 13:14:41 --> Total execution time: 0.1349
DEBUG - 2021-02-03 13:14:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:14:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:14:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:14:43 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-02-03 13:14:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:14:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:14:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:14:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:14:44 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-02-03 13:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:14:44 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-02-03 13:17:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:17:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:17:10 --> Total execution time: 0.1324
DEBUG - 2021-02-03 13:17:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:17:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:17:14 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 13:17:14 --> Total execution time: 0.1195
DEBUG - 2021-02-03 13:17:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:17:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:17:15 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-02-03 13:17:15 --> Total execution time: 0.1931
DEBUG - 2021-02-03 13:17:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:17:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:17:19 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 13:17:19 --> Total execution time: 0.1121
DEBUG - 2021-02-03 13:17:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:17:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:17:23 --> Total execution time: 0.1124
DEBUG - 2021-02-03 13:17:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:17:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:17:26 --> Total execution time: 0.1155
DEBUG - 2021-02-03 13:17:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:17:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:17:35 --> Total execution time: 0.1546
DEBUG - 2021-02-03 13:17:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:17:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:17:49 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 13:17:49 --> Total execution time: 0.1138
DEBUG - 2021-02-03 13:17:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:17:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:17:53 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"3"}
DEBUG - 2021-02-03 13:17:53 --> Total execution time: 0.1657
DEBUG - 2021-02-03 13:17:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:17:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:17:59 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 13:17:59 --> Total execution time: 0.1434
DEBUG - 2021-02-03 13:18:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:18:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:18:05 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 13:18:05 --> Total execution time: 0.0991
DEBUG - 2021-02-03 13:18:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:18:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:18:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:18:07 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 13:18:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:18:08 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 13:18:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:18:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:18:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 13:18:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:18:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:18:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 13:18:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:18:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:18:28 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 13:18:28 --> Total execution time: 0.1280
DEBUG - 2021-02-03 13:18:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:18:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:18:29 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"745","support_lang_id":"3"}
DEBUG - 2021-02-03 13:18:29 --> Total execution time: 0.1200
DEBUG - 2021-02-03 13:18:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:18:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:18:30 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 13:18:30 --> Total execution time: 0.0945
DEBUG - 2021-02-03 13:18:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:18:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:18:38 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 13:18:38 --> Total execution time: 0.1171
DEBUG - 2021-02-03 13:18:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:18:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:18:42 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"745","support_lang_id":"3"}
DEBUG - 2021-02-03 13:18:42 --> Total execution time: 0.1573
DEBUG - 2021-02-03 13:18:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:18:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:18:43 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 13:18:43 --> Total execution time: 0.1333
DEBUG - 2021-02-03 13:18:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:18:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:18:46 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 13:18:46 --> Total execution time: 0.1169
DEBUG - 2021-02-03 13:18:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:18:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:18:50 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"745","support_lang_id":"3"}
DEBUG - 2021-02-03 13:18:50 --> Total execution time: 0.1071
DEBUG - 2021-02-03 13:18:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:18:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:18:53 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 13:18:53 --> Total execution time: 0.1017
DEBUG - 2021-02-03 13:18:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:18:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:18:58 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"8","subcategory_id":"3","support_lang_id":"3"}
ERROR - 2021-02-03 13:18:58 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 13:18:58 --> Total execution time: 0.1264
DEBUG - 2021-02-03 13:19:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:19:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:19:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:19:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:19:10 --> Total execution time: 0.1753
DEBUG - 2021-02-03 13:19:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:19:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:19:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:19:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:19:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:19:13 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-02-03 13:19:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:19:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:19:15 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-02-03 13:19:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:19:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:19:15 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-02-03 13:19:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:19:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:19:51 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 13:19:51 --> Total execution time: 0.1318
DEBUG - 2021-02-03 13:20:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:20:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:20:07 --> Total execution time: 0.1684
DEBUG - 2021-02-03 13:20:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:20:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:20:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 13:20:10 --> Total execution time: 0.1449
DEBUG - 2021-02-03 13:20:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:20:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:20:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 13:20:11 --> Total execution time: 0.1501
DEBUG - 2021-02-03 13:20:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:20:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:20:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:20:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:20:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:20:27 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 13:20:27 --> Total execution time: 0.1459
DEBUG - 2021-02-03 13:20:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:20:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:20:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 13:20:30 --> Total execution time: 0.1904
DEBUG - 2021-02-03 13:20:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:20:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:20:32 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 13:20:32 --> Total execution time: 0.1476
DEBUG - 2021-02-03 13:20:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:20:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:20:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:20:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:20:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:20:45 --> get_grammer_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"8","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 13:20:45 --> Total execution time: 0.1374
DEBUG - 2021-02-03 13:21:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:21:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:21:18 --> Total execution time: 0.1259
DEBUG - 2021-02-03 13:21:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:21:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:21:25 --> Total execution time: 0.1595
DEBUG - 2021-02-03 13:21:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:21:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:21:28 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:21:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:21:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:21:42 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 13:21:42 --> Total execution time: 0.1476
DEBUG - 2021-02-03 13:21:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:21:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:21:50 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"8","subcategory_id":"3","support_lang_id":"3"}
ERROR - 2021-02-03 13:21:50 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 13:21:50 --> Total execution time: 0.1261
DEBUG - 2021-02-03 13:21:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:21:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:21:54 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 13:21:54 --> Total execution time: 0.1392
DEBUG - 2021-02-03 13:21:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:21:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:21:57 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"745","support_lang_id":"3"}
DEBUG - 2021-02-03 13:21:57 --> Total execution time: 0.1214
DEBUG - 2021-02-03 13:22:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:22:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:22:01 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 13:22:01 --> Total execution time: 0.1074
DEBUG - 2021-02-03 13:22:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:22:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:22:17 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"8","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 13:22:17 --> Total execution time: 0.1464
DEBUG - 2021-02-03 13:22:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:22:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:22:41 --> Total execution time: 0.1003
DEBUG - 2021-02-03 13:22:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:22:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:22:44 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 13:22:44 --> Total execution time: 0.1118
DEBUG - 2021-02-03 13:22:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:22:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:22:51 --> Total execution time: 0.1724
DEBUG - 2021-02-03 13:22:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:22:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:22:53 --> Total execution time: 0.1542
DEBUG - 2021-02-03 13:22:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:22:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:22:55 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:22:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:22:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:22:56 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-02-03 13:22:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:22:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:22:57 --> Total execution time: 0.1580
DEBUG - 2021-02-03 13:22:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:23:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:23:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:23:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:23:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:23:22 --> Total execution time: 0.1540
DEBUG - 2021-02-03 13:23:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:23:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:23:26 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 13:23:26 --> Total execution time: 0.2392
DEBUG - 2021-02-03 13:23:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:23:27 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:23:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:23:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:23:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 13:23:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:23:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:23:34 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"745","support_lang_id":"3"}
DEBUG - 2021-02-03 13:23:34 --> Total execution time: 0.1176
DEBUG - 2021-02-03 13:23:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:23:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:23:35 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 13:23:35 --> Total execution time: 0.1169
DEBUG - 2021-02-03 13:23:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:23:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:23:38 --> Total execution time: 0.1154
DEBUG - 2021-02-03 13:27:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:27:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:27:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:27:57 --> Total execution time: 0.1317
DEBUG - 2021-02-03 13:27:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:27:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:27:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 13:27:59 --> Total execution time: 0.1582
DEBUG - 2021-02-03 13:28:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:28:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:28:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:28:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:28:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:28:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:28:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:28:57 --> Total execution time: 0.1290
DEBUG - 2021-02-03 13:28:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:28:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:28:58 --> Total execution time: 0.1949
DEBUG - 2021-02-03 13:29:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:29:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:29:00 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-03 13:29:00 --> Total execution time: 0.1519
DEBUG - 2021-02-03 13:29:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:29:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:29:01 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-03 13:29:01 --> Total execution time: 0.1685
DEBUG - 2021-02-03 13:29:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:29:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:29:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:29:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 13:29:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:29:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 13:29:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:29:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:31:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:31:54 --> No URI present. Default controller set.
DEBUG - 2021-02-03 13:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:31:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:31:55 --> Total execution time: 0.1460
DEBUG - 2021-02-03 13:32:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:32:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:32:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:32:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:32:07 --> Total execution time: 0.1203
DEBUG - 2021-02-03 13:32:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:32:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:32:09 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:32:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:32:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:33:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:33:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:33:06 --> Total execution time: 0.1307
DEBUG - 2021-02-03 13:33:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:33:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:33:07 --> Total execution time: 0.1305
DEBUG - 2021-02-03 13:33:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:33:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:33:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 13:33:09 --> Total execution time: 0.1604
DEBUG - 2021-02-03 13:33:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:33:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:33:10 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-03 13:33:10 --> Total execution time: 0.1471
DEBUG - 2021-02-03 13:33:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:33:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:33:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:33:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:33:13 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:33:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:33:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:33:13 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 13:33:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:33:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:33:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 13:33:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:33:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:33:31 --> Total execution time: 0.1562
DEBUG - 2021-02-03 13:33:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:33:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:33:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 13:33:33 --> Total execution time: 0.1444
DEBUG - 2021-02-03 13:33:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:33:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:33:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:36:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:36:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:36:37 --> Total execution time: 0.1145
DEBUG - 2021-02-03 13:36:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:36:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:36:40 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 13:36:40 --> Total execution time: 0.1756
DEBUG - 2021-02-03 13:36:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:36:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:36:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:36:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:36:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:42:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:42:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:42:33 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 13:42:33 --> Total execution time: 0.1083
DEBUG - 2021-02-03 13:42:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:42:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:42:33 --> Total execution time: 0.1046
DEBUG - 2021-02-03 13:42:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:42:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:42:34 --> Total execution time: 0.1350
DEBUG - 2021-02-03 13:42:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:42:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:42:34 --> Total execution time: 0.1247
DEBUG - 2021-02-03 13:42:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:43:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:43:00 --> Total execution time: 0.1172
DEBUG - 2021-02-03 13:43:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:43:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:43:14 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 13:43:14 --> Total execution time: 0.1375
DEBUG - 2021-02-03 13:43:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:43:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:43:15 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"745","support_lang_id":"3"}
DEBUG - 2021-02-03 13:43:15 --> Total execution time: 0.1147
DEBUG - 2021-02-03 13:43:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:43:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:43:16 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 13:43:16 --> Total execution time: 0.1174
DEBUG - 2021-02-03 13:43:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:43:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:43:20 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-02-03 13:43:20 --> Total execution time: 0.0971
DEBUG - 2021-02-03 13:43:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:43:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:43:24 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 13:43:24 --> Total execution time: 0.1270
DEBUG - 2021-02-03 13:43:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:43:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:43:25 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"745","support_lang_id":"3"}
DEBUG - 2021-02-03 13:43:25 --> Total execution time: 0.1175
DEBUG - 2021-02-03 13:43:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:43:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:43:27 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 13:43:27 --> Total execution time: 0.1201
DEBUG - 2021-02-03 13:44:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:44:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:44:01 --> Total execution time: 0.1150
DEBUG - 2021-02-03 13:44:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:44:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:44:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:44:36 --> Total execution time: 0.1616
DEBUG - 2021-02-03 13:44:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:44:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:44:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 13:44:39 --> Total execution time: 0.1758
DEBUG - 2021-02-03 13:44:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:44:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:44:41 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:44:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:44:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:44:54 --> Total execution time: 0.1175
DEBUG - 2021-02-03 13:45:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:45:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:45:56 --> Total execution time: 0.1093
DEBUG - 2021-02-03 13:45:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:45:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:45:59 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-03 13:45:59 --> Total execution time: 0.1341
DEBUG - 2021-02-03 13:46:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:46:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:46:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:46:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:46:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:46:03 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 13:46:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:46:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:46:05 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 13:46:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:46:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:46:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:46:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:46:49 --> Total execution time: 0.1655
DEBUG - 2021-02-03 13:46:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:46:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:46:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 13:46:51 --> Total execution time: 0.1458
DEBUG - 2021-02-03 13:46:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:46:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:46:54 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:47:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:47:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:47:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:47:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:47:26 --> Total execution time: 0.1469
DEBUG - 2021-02-03 13:47:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:47:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:47:29 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-02-03 13:47:29 --> Total execution time: 0.1640
DEBUG - 2021-02-03 13:47:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:47:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:47:31 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:47:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:47:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:47:31 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 13:47:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:47:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:47:33 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 13:49:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:49:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:49:04 --> Total execution time: 0.1502
DEBUG - 2021-02-03 13:49:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:49:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:49:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:49:07 --> Total execution time: 0.1388
DEBUG - 2021-02-03 13:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:49:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:49:07 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 13:49:07 --> Total execution time: 0.1332
DEBUG - 2021-02-03 13:49:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:49:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 13:49:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 13:49:09 --> Total execution time: 0.1760
DEBUG - 2021-02-03 13:49:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:49:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 13:49:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 13:49:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:49:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:49:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:49:42 --> Total execution time: 0.1668
DEBUG - 2021-02-03 13:57:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:57:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:57:45 --> Total execution time: 0.1331
DEBUG - 2021-02-03 13:58:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:58:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:58:01 --> Total execution time: 0.1483
DEBUG - 2021-02-03 13:58:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:58:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:58:01 --> Total execution time: 0.1217
DEBUG - 2021-02-03 13:58:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:58:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:58:06 --> Total execution time: 0.1175
DEBUG - 2021-02-03 13:58:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:58:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:58:14 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 13:58:14 --> Total execution time: 0.1591
DEBUG - 2021-02-03 13:58:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:58:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:58:19 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 13:58:19 --> Total execution time: 0.1319
DEBUG - 2021-02-03 13:58:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:58:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:58:23 --> get_exercise_type_list->{"lang":"37","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-03 13:58:23 --> Total execution time: 0.1377
DEBUG - 2021-02-03 13:58:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:58:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:58:25 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 13:58:25 --> Total execution time: 0.1383
DEBUG - 2021-02-03 13:58:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:58:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:58:26 --> get_dialogue_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"2","category_id":"7","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-03 13:58:26 --> Total execution time: 0.1235
DEBUG - 2021-02-03 13:58:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:58:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:58:30 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-02-03 13:58:30 --> Total execution time: 0.1295
DEBUG - 2021-02-03 13:58:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:58:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:58:33 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 13:58:33 --> Total execution time: 0.1153
DEBUG - 2021-02-03 13:58:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:58:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:58:37 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"8","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 13:58:37 --> Total execution time: 0.1371
DEBUG - 2021-02-03 13:58:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:58:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:58:44 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 13:58:44 --> Total execution time: 0.1319
DEBUG - 2021-02-03 13:58:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:58:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:58:50 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 13:58:50 --> Total execution time: 0.1030
DEBUG - 2021-02-03 13:58:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:58:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:58:53 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 13:58:53 --> Total execution time: 0.1171
DEBUG - 2021-02-03 13:59:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:59:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:59:00 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 13:59:00 --> Total execution time: 0.1069
DEBUG - 2021-02-03 13:59:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:59:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:59:03 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"8","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 13:59:03 --> Total execution time: 0.1140
DEBUG - 2021-02-03 13:59:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:59:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:59:12 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 13:59:12 --> Total execution time: 0.1405
DEBUG - 2021-02-03 13:59:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:59:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:59:17 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 13:59:17 --> Total execution time: 0.1682
DEBUG - 2021-02-03 13:59:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:59:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:59:21 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 13:59:21 --> Total execution time: 0.1246
DEBUG - 2021-02-03 13:59:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:59:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:59:25 --> get_exercise_type_list->{"lang":"37","subcategory_id":"10","support_lang_id":"3"}
DEBUG - 2021-02-03 13:59:25 --> Total execution time: 0.1733
DEBUG - 2021-02-03 13:59:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:59:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:59:29 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"10","support_lang_id":"3"}
ERROR - 2021-02-03 13:59:29 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 13:59:29 --> Total execution time: 0.1413
DEBUG - 2021-02-03 13:59:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:59:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:59:33 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"0","support_lang_id":"3"}
DEBUG - 2021-02-03 13:59:33 --> Total execution time: 0.1466
DEBUG - 2021-02-03 13:59:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:59:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:59:36 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 13:59:36 --> Total execution time: 0.1539
DEBUG - 2021-02-03 13:59:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:59:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:59:39 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 13:59:39 --> Total execution time: 0.1815
DEBUG - 2021-02-03 13:59:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 13:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 13:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 13:59:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 13:59:53 --> Total execution time: 0.1460
DEBUG - 2021-02-03 14:00:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:00:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:00:40 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 14:00:40 --> Total execution time: 0.1288
DEBUG - 2021-02-03 14:00:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:00:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:00:40 --> Total execution time: 0.1216
DEBUG - 2021-02-03 14:00:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:00:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:00:45 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"771","support_lang_id":"3"}
DEBUG - 2021-02-03 14:00:45 --> Total execution time: 0.1371
DEBUG - 2021-02-03 14:00:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:00:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:00:51 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 14:00:51 --> Total execution time: 0.0965
DEBUG - 2021-02-03 14:01:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:10 --> Total execution time: 0.1170
DEBUG - 2021-02-03 14:01:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:13 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:14 --> Total execution time: 0.1144
DEBUG - 2021-02-03 14:01:14 --> Total execution time: 0.1111
DEBUG - 2021-02-03 14:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:14 --> Total execution time: 0.1765
DEBUG - 2021-02-03 14:01:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:18 --> Total execution time: 0.1228
DEBUG - 2021-02-03 14:01:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:18 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:18 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 14:01:18 --> Total execution time: 0.1315
DEBUG - 2021-02-03 14:01:18 --> Total execution time: 0.1245
DEBUG - 2021-02-03 14:01:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:19 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 14:01:19 --> Total execution time: 0.1123
DEBUG - 2021-02-03 14:01:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:23 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:23 --> Total execution time: 0.1718
DEBUG - 2021-02-03 14:01:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:24 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:01:24 --> Total execution time: 0.1534
DEBUG - 2021-02-03 14:01:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:24 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 14:01:24 --> Total execution time: 0.1445
DEBUG - 2021-02-03 14:01:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:28 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 14:01:28 --> Total execution time: 0.1228
DEBUG - 2021-02-03 14:01:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:28 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:28 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 14:01:28 --> Total execution time: 0.1320
DEBUG - 2021-02-03 14:01:28 --> Total execution time: 0.1641
DEBUG - 2021-02-03 14:01:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:31 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 14:01:31 --> Total execution time: 0.1211
DEBUG - 2021-02-03 14:01:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:33 --> get_exercise_type_list->{"lang":"37","subcategory_id":"8","support_lang_id":"3"}
DEBUG - 2021-02-03 14:01:33 --> Total execution time: 0.1308
DEBUG - 2021-02-03 14:01:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:34 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:34 --> Total execution time: 0.1590
DEBUG - 2021-02-03 14:01:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:01:34 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 14:01:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:37 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"8","support_lang_id":"3"}
ERROR - 2021-02-03 14:01:37 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 14:01:37 --> Total execution time: 0.1200
DEBUG - 2021-02-03 14:01:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:37 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:01:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:01:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 14:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:37 --> Total execution time: 0.1508
DEBUG - 2021-02-03 14:01:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:41 --> get_exercise_type_list->{"lang":"37","subcategory_id":"8","support_lang_id":"3"}
DEBUG - 2021-02-03 14:01:41 --> Total execution time: 0.1433
DEBUG - 2021-02-03 14:01:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:41 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:42 --> Total execution time: 0.1573
DEBUG - 2021-02-03 14:01:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:44 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:44 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 14:01:45 --> Total execution time: 0.1409
DEBUG - 2021-02-03 14:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:45 --> Total execution time: 0.1383
DEBUG - 2021-02-03 14:01:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:49 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 14:01:49 --> Total execution time: 0.1168
DEBUG - 2021-02-03 14:01:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:49 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:49 --> get_exercise_type_list->{"lang":"37","subcategory_id":"10","support_lang_id":"3"}
DEBUG - 2021-02-03 14:01:49 --> Total execution time: 0.1466
DEBUG - 2021-02-03 14:01:49 --> Total execution time: 0.1502
DEBUG - 2021-02-03 14:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:53 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"10","support_lang_id":"3"}
ERROR - 2021-02-03 14:01:53 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 14:01:53 --> Total execution time: 0.1124
DEBUG - 2021-02-03 14:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:53 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:53 --> Total execution time: 0.1689
DEBUG - 2021-02-03 14:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:53 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:01:53 --> Total execution time: 0.1206
DEBUG - 2021-02-03 14:01:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:57 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:57 --> get_exercise_type_list->{"lang":"37","subcategory_id":"10","support_lang_id":"3"}
DEBUG - 2021-02-03 14:01:57 --> Total execution time: 0.1191
DEBUG - 2021-02-03 14:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:57 --> Total execution time: 0.1444
DEBUG - 2021-02-03 14:01:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:01:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:01:58 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 14:01:58 --> Total execution time: 0.1132
DEBUG - 2021-02-03 14:02:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:00 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 14:02:00 --> Total execution time: 0.1229
DEBUG - 2021-02-03 14:02:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:00 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:00 --> Total execution time: 0.1602
DEBUG - 2021-02-03 14:02:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:01 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 14:02:01 --> Total execution time: 0.1108
DEBUG - 2021-02-03 14:02:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:05 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 14:02:05 --> Total execution time: 0.1142
DEBUG - 2021-02-03 14:02:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:05 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:05 --> Total execution time: 0.1334
DEBUG - 2021-02-03 14:02:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:08 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:08 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 14:02:08 --> Total execution time: 0.1448
DEBUG - 2021-02-03 14:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:08 --> Total execution time: 0.1353
DEBUG - 2021-02-03 14:02:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:02:11 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 14:02:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:15 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:15 --> Total execution time: 0.1415
DEBUG - 2021-02-03 14:02:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:19 --> Total execution time: 0.1127
DEBUG - 2021-02-03 14:02:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:21 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:21 --> Total execution time: 0.1384
DEBUG - 2021-02-03 14:02:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:21 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 14:02:21 --> Total execution time: 0.1242
DEBUG - 2021-02-03 14:02:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:24 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:24 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 14:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:24 --> Total execution time: 0.1395
DEBUG - 2021-02-03 14:02:24 --> Total execution time: 0.1183
DEBUG - 2021-02-03 14:02:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:28 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 14:02:28 --> Total execution time: 0.1056
DEBUG - 2021-02-03 14:02:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:28 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:28 --> Total execution time: 0.1278
DEBUG - 2021-02-03 14:02:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:33 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:33 --> Total execution time: 0.1624
DEBUG - 2021-02-03 14:02:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:34 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:02:34 --> Total execution time: 0.1292
DEBUG - 2021-02-03 14:02:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:38 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:38 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 14:02:38 --> Total execution time: 0.1534
DEBUG - 2021-02-03 14:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:38 --> Total execution time: 0.1624
DEBUG - 2021-02-03 14:02:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:39 --> Total execution time: 0.1839
DEBUG - 2021-02-03 14:02:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:42 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:42 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:02:42 --> Total execution time: 0.1281
DEBUG - 2021-02-03 14:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:42 --> Total execution time: 0.1495
DEBUG - 2021-02-03 14:02:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:42 --> Total execution time: 0.1499
DEBUG - 2021-02-03 14:02:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:02:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 14:02:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:46 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:46 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:02:46 --> Total execution time: 0.1168
DEBUG - 2021-02-03 14:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:46 --> Total execution time: 0.1418
DEBUG - 2021-02-03 14:02:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:48 --> get_exercise_type_list->{"lang":"37","subcategory_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 14:02:48 --> Total execution time: 0.1346
DEBUG - 2021-02-03 14:02:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:02:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 14:02:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:52 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:02:52 --> Total execution time: 0.1476
DEBUG - 2021-02-03 14:02:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:02:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:02:58 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 14:02:58 --> Total execution time: 0.1243
DEBUG - 2021-02-03 14:03:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:03:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:03:05 --> Total execution time: 0.1391
DEBUG - 2021-02-03 14:03:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:03:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 14:03:08 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 167
DEBUG - 2021-02-03 14:03:08 --> Total execution time: 0.1545
DEBUG - 2021-02-03 14:03:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:03:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:03:10 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 14:03:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:03:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:03:17 --> Total execution time: 0.1400
DEBUG - 2021-02-03 14:03:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:03:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 14:03:21 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/culture_list.php 142
DEBUG - 2021-02-03 14:03:21 --> Total execution time: 0.1793
DEBUG - 2021-02-03 14:03:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:03:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:03:21 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 14:03:21 --> Total execution time: 0.1386
DEBUG - 2021-02-03 14:03:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:03:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:03:24 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 14:03:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:03:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:03:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 14:03:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:03:25 --> get_subcategory_list->{"lang":"37","category_id":"9","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:03:25 --> Total execution time: 0.1240
DEBUG - 2021-02-03 14:03:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:03:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:03:30 --> get_exercise_type_list->{"lang":"37","subcategory_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 14:03:30 --> Total execution time: 0.1209
DEBUG - 2021-02-03 14:03:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:03:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:03:30 --> Total execution time: 0.1628
DEBUG - 2021-02-03 14:03:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:03:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 14:03:33 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2021-02-03 14:03:33 --> Total execution time: 0.1231
DEBUG - 2021-02-03 14:03:35 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:03:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:03:35 --> get_phrases_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"3","category_id":"9","subcategory_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 14:03:35 --> Total execution time: 0.1571
DEBUG - 2021-02-03 14:03:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:03:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:03:36 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 14:03:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:03:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:03:44 --> get_exercise_type_list->{"lang":"37","subcategory_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 14:03:44 --> Total execution time: 0.1201
DEBUG - 2021-02-03 14:03:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:03:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:03:48 --> Total execution time: 0.1366
DEBUG - 2021-02-03 14:03:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:03:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:03:49 --> get_subcategory_list->{"lang":"37","category_id":"9","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:03:49 --> Total execution time: 0.1110
DEBUG - 2021-02-03 14:03:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:03:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 14:03:51 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-02-03 14:03:51 --> Total execution time: 0.1459
DEBUG - 2021-02-03 14:03:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:03:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:03:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 14:04:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:04:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:04:01 --> get_exercise_type_list->{"lang":"37","subcategory_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 14:04:01 --> Total execution time: 0.1066
DEBUG - 2021-02-03 14:04:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:04:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:04:26 --> get_phrases_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"3","category_id":"9","subcategory_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 14:04:26 --> Total execution time: 0.1522
DEBUG - 2021-02-03 14:04:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:04:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:04:33 --> get_exercise_type_list->{"lang":"37","subcategory_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 14:04:33 --> Total execution time: 0.1408
DEBUG - 2021-02-03 14:04:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:04:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:04:37 --> get_subcategory_list->{"lang":"37","category_id":"9","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:04:37 --> Total execution time: 0.1223
DEBUG - 2021-02-03 14:04:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:04:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:04:51 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 14:04:51 --> Total execution time: 0.1135
DEBUG - 2021-02-03 14:06:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:06:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:06:28 --> Total execution time: 0.1628
DEBUG - 2021-02-03 14:06:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:06:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:06:31 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-02-03 14:06:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:06:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:06:32 --> 404 Page Not Found: Uploads/pencil.jpg
DEBUG - 2021-02-03 14:06:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:06:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:06:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:06:33 --> 404 Page Not Found: Uploads/crayfish_party
DEBUG - 2021-02-03 14:06:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:06:33 --> 404 Page Not Found: Uploads/icecream.jpg
DEBUG - 2021-02-03 14:07:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:07:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:07:18 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 14:07:18 --> Total execution time: 0.1018
DEBUG - 2021-02-03 14:07:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:07:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:07:22 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:07:22 --> Total execution time: 0.1174
DEBUG - 2021-02-03 14:07:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:07:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:07:27 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 14:07:27 --> Total execution time: 0.1364
DEBUG - 2021-02-03 14:07:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:07:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:07:31 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"8","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 14:07:31 --> Total execution time: 0.0966
DEBUG - 2021-02-03 14:07:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:07:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:07:54 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 14:07:54 --> Total execution time: 0.1420
DEBUG - 2021-02-03 14:07:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:07:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:07:59 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:07:59 --> Total execution time: 0.1140
DEBUG - 2021-02-03 14:08:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:08:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:08:33 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 14:08:33 --> Total execution time: 0.1279
DEBUG - 2021-02-03 14:08:39 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:08:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:08:39 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"8","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 14:08:39 --> Total execution time: 0.1064
DEBUG - 2021-02-03 14:08:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:08:51 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 14:08:51 --> Total execution time: 0.1407
DEBUG - 2021-02-03 14:08:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:08:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:08:55 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:08:55 --> Total execution time: 0.1198
DEBUG - 2021-02-03 14:08:56 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:08:56 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:08:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:08:56 --> Total execution time: 0.1019
DEBUG - 2021-02-03 14:08:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:08:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:08:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 14:08:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:08:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:08:59 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 14:08:59 --> Total execution time: 0.1232
DEBUG - 2021-02-03 14:09:05 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:09:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:09:05 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 14:09:05 --> Total execution time: 0.1128
DEBUG - 2021-02-03 14:09:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:09:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:09:10 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:09:10 --> Total execution time: 0.1530
DEBUG - 2021-02-03 14:09:13 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:09:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:09:13 --> get_exercise_type_list->{"lang":"37","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-03 14:09:13 --> Total execution time: 0.1765
DEBUG - 2021-02-03 14:09:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:09:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:09:17 --> get_dialogue_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"2","category_id":"7","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-03 14:09:17 --> Total execution time: 0.1340
DEBUG - 2021-02-03 14:09:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:09:26 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:09:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:09:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:09:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 14:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:09:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:09:26 --> Total execution time: 0.1301
DEBUG - 2021-02-03 14:09:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:09:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:09:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 14:09:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:09:48 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:09:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:09:48 --> Total execution time: 0.1365
DEBUG - 2021-02-03 14:09:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:09:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:09:48 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:09:48 --> Total execution time: 0.1833
DEBUG - 2021-02-03 14:09:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:09:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:09:49 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 14:09:49 --> Total execution time: 0.1585
DEBUG - 2021-02-03 14:09:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:09:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:09:50 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:09:50 --> Total execution time: 0.1617
DEBUG - 2021-02-03 14:09:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:09:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:09:50 --> No URI present. Default controller set.
DEBUG - 2021-02-03 14:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:09:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:09:50 --> Total execution time: 0.1397
DEBUG - 2021-02-03 14:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:09:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:09:50 --> Total execution time: 0.1339
DEBUG - 2021-02-03 14:09:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:09:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:09:51 --> Total execution time: 0.1203
DEBUG - 2021-02-03 14:10:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:10:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:10:09 --> Total execution time: 0.1097
DEBUG - 2021-02-03 14:11:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:11:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:11:26 --> Total execution time: 0.1101
DEBUG - 2021-02-03 14:12:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:12:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:12:23 --> Total execution time: 0.1185
DEBUG - 2021-02-03 14:12:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:12:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:12:43 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 14:12:43 --> Total execution time: 0.1361
DEBUG - 2021-02-03 14:12:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:12:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:12:47 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:12:47 --> Total execution time: 0.1384
DEBUG - 2021-02-03 14:12:50 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:12:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:12:50 --> get_exercise_type_list->{"lang":"37","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-03 14:12:50 --> Total execution time: 0.0999
DEBUG - 2021-02-03 14:12:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:12:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:12:55 --> get_dialogue_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"2","category_id":"7","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-03 14:12:55 --> Total execution time: 0.1123
DEBUG - 2021-02-03 14:13:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:13:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:13:17 --> get_exercise_type_list->{"lang":"37","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-03 14:13:17 --> Total execution time: 0.1169
DEBUG - 2021-02-03 14:13:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:13:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:13:20 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:13:20 --> Total execution time: 0.0993
DEBUG - 2021-02-03 14:13:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:13:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:13:24 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 14:13:24 --> Total execution time: 0.1434
DEBUG - 2021-02-03 14:13:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:13:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:13:32 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 14:13:33 --> Total execution time: 0.1789
DEBUG - 2021-02-03 14:13:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:13:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:13:37 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:13:37 --> Total execution time: 0.1110
DEBUG - 2021-02-03 14:13:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:13:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:13:42 --> get_exercise_type_list->{"lang":"37","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 14:13:42 --> Total execution time: 0.1327
DEBUG - 2021-02-03 14:13:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:13:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:13:46 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 14:13:46 --> Total execution time: 0.1756
DEBUG - 2021-02-03 14:13:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:13:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:13:48 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 14:13:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:13:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:13:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 14:14:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:14:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:14:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:14:15 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 14:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:14:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:14:15 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 14:14:15 --> Total execution time: 0.1203
DEBUG - 2021-02-03 14:14:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:14:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:14:18 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 14:14:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:14:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:14:46 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"7","support_lang_id":"3"}
DEBUG - 2021-02-03 14:14:46 --> Total execution time: 0.1405
DEBUG - 2021-02-03 14:14:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:14:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:14:49 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 14:14:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:14:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:14:54 --> Total execution time: 0.1636
DEBUG - 2021-02-03 14:15:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:15:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:15:24 --> Total execution time: 0.1508
DEBUG - 2021-02-03 14:15:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:15:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:15:47 --> Total execution time: 0.1274
DEBUG - 2021-02-03 14:15:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:15:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:15:55 --> get_category_list->{"lang":"41","exercise_mode_id":"1","support_lang_id":"3"}
ERROR - 2021-02-03 14:15:55 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2021-02-03 14:15:55 --> Total execution time: 0.1109
DEBUG - 2021-02-03 14:15:59 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:15:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:15:59 --> Total execution time: 0.1527
DEBUG - 2021-02-03 14:16:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:16:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:16:04 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:16:04 --> Total execution time: 0.1135
DEBUG - 2021-02-03 14:16:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:16:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:16:08 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:16:08 --> Total execution time: 0.1339
DEBUG - 2021-02-03 14:16:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:16:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:16:12 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:16:12 --> Total execution time: 0.1392
DEBUG - 2021-02-03 14:16:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:16:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:16:16 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:16:16 --> Total execution time: 0.1319
DEBUG - 2021-02-03 14:16:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:16:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:16:23 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 14:16:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:16:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:16:24 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 14:16:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:16:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:16:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 14:16:28 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:16:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 14:16:28 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 14:16:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:16:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:16:29 --> Total execution time: 0.1423
DEBUG - 2021-02-03 14:16:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:16:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:16:38 --> Total execution time: 0.0981
DEBUG - 2021-02-03 14:16:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:16:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:16:48 --> Total execution time: 0.1435
DEBUG - 2021-02-03 14:16:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:16:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:16:54 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 14:16:54 --> Total execution time: 0.1421
DEBUG - 2021-02-03 14:16:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:16:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:16:58 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:16:58 --> Total execution time: 0.1302
DEBUG - 2021-02-03 14:17:03 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:17:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:17:04 --> get_exercise_type_list->{"lang":"37","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-03 14:17:04 --> Total execution time: 0.1307
DEBUG - 2021-02-03 14:17:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:17:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:17:08 --> get_dialogue_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"2","category_id":"7","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-03 14:17:08 --> Total execution time: 0.1148
DEBUG - 2021-02-03 14:17:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:17:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:17:32 --> get_exercise_type_list->{"lang":"37","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-03 14:17:32 --> Total execution time: 0.1367
DEBUG - 2021-02-03 14:17:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:17:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:17:32 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:17:32 --> Total execution time: 0.1457
DEBUG - 2021-02-03 14:17:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:17:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:17:43 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 14:17:43 --> Total execution time: 0.1451
DEBUG - 2021-02-03 14:17:52 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:17:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:17:52 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 14:17:52 --> Total execution time: 0.1376
DEBUG - 2021-02-03 14:17:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:17:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:17:58 --> get_subcategory_list->{"lang":"37","category_id":"9","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:17:58 --> Total execution time: 0.1218
DEBUG - 2021-02-03 14:18:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:18:14 --> get_exercise_type_list->{"lang":"37","subcategory_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 14:18:14 --> Total execution time: 0.1272
DEBUG - 2021-02-03 14:18:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:18:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 14:18:15 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-02-03 14:18:15 --> Total execution time: 0.0973
DEBUG - 2021-02-03 14:18:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:18:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:18:19 --> get_exercise_type_list->{"lang":"37","subcategory_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 14:18:19 --> Total execution time: 0.1436
DEBUG - 2021-02-03 14:18:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:18:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:18:23 --> get_phrases_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"3","category_id":"9","subcategory_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 14:18:23 --> Total execution time: 0.1605
DEBUG - 2021-02-03 14:18:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:18:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:18:33 --> Total execution time: 0.1295
DEBUG - 2021-02-03 14:18:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:18:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:18:43 --> Total execution time: 0.1316
DEBUG - 2021-02-03 14:18:48 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:18:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:18:48 --> Total execution time: 0.1217
DEBUG - 2021-02-03 14:20:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:20:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:20:07 --> Total execution time: 0.1307
DEBUG - 2021-02-03 14:20:33 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 14:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 14:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 14:20:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 14:20:33 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 14:20:33 --> Total execution time: 0.1344
DEBUG - 2021-02-03 15:10:09 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 15:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 15:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 15:10:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 15:10:09 --> Total execution time: 0.1628
DEBUG - 2021-02-03 15:15:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 15:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 15:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 15:15:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 15:15:42 --> Total execution time: 0.1120
DEBUG - 2021-02-03 19:49:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:49:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-02-03 19:49:47 --> {"status":0,"message":"Record not found!!","message_en":"","result":[],"status_message":"OK"}
DEBUG - 2021-02-03 19:49:47 --> Total execution time: 0.1032
DEBUG - 2021-02-03 19:50:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:50:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:50:04 --> user_login->{"email":"ronak.doshi@voolsy.com","password":"e10adc3949ba59abbe56e057f20f883e"}
ERROR - 2021-02-03 19:50:04 --> {"status":0,"message":"Username or Password Wrong!!","message_en":"","result":[],"status_message":"OK"}
DEBUG - 2021-02-03 19:50:04 --> Total execution time: 0.1167
DEBUG - 2021-02-03 19:50:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:50:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:50:17 --> user_login->{"email":"ronak.doshi@voolsy.com","password":"b51dedb33ef8d983d741d5e035760a08"}
DEBUG - 2021-02-03 19:50:17 --> Total execution time: 0.1617
DEBUG - 2021-02-03 19:52:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:52:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:52:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:52:14 --> Total execution time: 0.1326
DEBUG - 2021-02-03 19:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:52:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:52:15 --> Total execution time: 0.1472
DEBUG - 2021-02-03 19:52:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:52:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:52:26 --> Total execution time: 0.1215
DEBUG - 2021-02-03 19:52:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:52:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:52:29 --> Total execution time: 0.1092
DEBUG - 2021-02-03 19:52:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:52:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:52:34 --> Total execution time: 0.1178
DEBUG - 2021-02-03 19:52:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:52:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:52:41 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 19:52:41 --> Total execution time: 0.1361
DEBUG - 2021-02-03 19:52:45 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:52:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:52:46 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 19:52:46 --> Total execution time: 0.1453
DEBUG - 2021-02-03 19:52:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:52:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:52:49 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 19:52:49 --> Total execution time: 0.1310
DEBUG - 2021-02-03 19:52:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:52:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:52:53 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 19:52:53 --> Total execution time: 0.1571
DEBUG - 2021-02-03 19:52:55 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 19:52:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 19:53:00 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 19:53:00 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 19:53:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:53:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:53:06 --> Total execution time: 0.1510
DEBUG - 2021-02-03 19:53:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:53:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:53:14 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 19:53:14 --> Total execution time: 0.1456
DEBUG - 2021-02-03 19:53:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:53:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 19:53:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 19:53:16 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:53:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 19:53:17 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 19:53:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:53:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:53:18 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 19:53:18 --> Total execution time: 0.1528
DEBUG - 2021-02-03 19:53:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:53:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:53:22 --> get_sorce_lan_word_type_6->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 19:53:22 --> Total execution time: 0.1346
DEBUG - 2021-02-03 19:53:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:53:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:53:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 19:53:25 --> 404 Page Not Found: Uploads/words
ERROR - 2021-02-03 19:53:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 19:53:34 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:53:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:53:34 --> Total execution time: 0.1506
DEBUG - 2021-02-03 19:53:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:53:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:53:36 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 19:53:36 --> Total execution time: 0.1358
DEBUG - 2021-02-03 19:53:41 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:53:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:53:41 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 19:53:41 --> Total execution time: 0.1486
DEBUG - 2021-02-03 19:53:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:53:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 19:53:44 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 19:53:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:53:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 19:53:51 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 19:54:04 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:54:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:54:04 --> Total execution time: 0.1174
DEBUG - 2021-02-03 19:54:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:54:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:54:07 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 19:54:07 --> Total execution time: 0.1288
DEBUG - 2021-02-03 19:54:11 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:54:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:54:11 --> get_sorce_lan_word_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 19:54:11 --> Total execution time: 0.1396
DEBUG - 2021-02-03 19:54:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:54:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:54:24 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 19:54:24 --> Total execution time: 0.1020
DEBUG - 2021-02-03 19:54:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:54:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:54:28 --> get_sorce_lan_word_type_3->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 19:54:28 --> Total execution time: 0.1043
DEBUG - 2021-02-03 19:54:37 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:54:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:54:37 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 19:54:37 --> Total execution time: 0.1383
DEBUG - 2021-02-03 19:54:40 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:54:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:54:41 --> get_sorce_lan_word_type_7->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 19:54:41 --> Total execution time: 0.1316
DEBUG - 2021-02-03 19:55:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:55:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:55:17 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 19:55:17 --> Total execution time: 0.1629
DEBUG - 2021-02-03 19:55:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:55:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:55:21 --> get_sorce_lan_word_type_4->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 19:55:21 --> Total execution time: 0.1551
DEBUG - 2021-02-03 19:55:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:55:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 19:55:25 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 19:55:53 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:55:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 19:55:53 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 19:56:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:56:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:56:02 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 19:56:02 --> Total execution time: 0.0948
DEBUG - 2021-02-03 19:56:07 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:56:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:56:07 --> get_sorce_lan_word_type_5->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 19:56:07 --> Total execution time: 0.1134
DEBUG - 2021-02-03 19:56:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:56:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:56:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 19:56:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 19:56:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-02-03 19:56:10 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-02-03 19:56:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:56:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:56:19 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 19:56:19 --> Total execution time: 0.1501
DEBUG - 2021-02-03 19:56:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:56:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:56:23 --> get_sorce_lan_word_type_9->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 19:56:23 --> Total execution time: 0.1500
DEBUG - 2021-02-03 19:56:51 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:56:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:56:51 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 19:56:51 --> Total execution time: 0.1529
DEBUG - 2021-02-03 19:56:57 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 19:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 19:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 19:56:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 19:56:57 --> get_sorce_lan_word_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 19:56:57 --> Total execution time: 0.1290
DEBUG - 2021-02-03 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:00:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:00:02 --> Total execution time: 0.1138
DEBUG - 2021-02-03 20:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:00:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:00:02 --> Total execution time: 0.1382
DEBUG - 2021-02-03 20:00:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:00:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:00:12 --> Total execution time: 0.1709
DEBUG - 2021-02-03 20:00:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:00:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:00:18 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 20:00:18 --> Total execution time: 0.1560
DEBUG - 2021-02-03 20:00:22 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:00:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:00:22 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 20:00:22 --> Total execution time: 0.1305
DEBUG - 2021-02-03 20:00:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:00:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:00:26 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 20:00:26 --> Total execution time: 0.1536
DEBUG - 2021-02-03 20:00:30 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:00:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:00:30 --> get_sorce_lan_word_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 20:00:30 --> Total execution time: 0.1199
DEBUG - 2021-02-03 20:01:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:01:38 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:01:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:01:38 --> Total execution time: 0.1380
DEBUG - 2021-02-03 20:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:01:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:01:38 --> Total execution time: 0.1217
DEBUG - 2021-02-03 20:02:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:02:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:02:14 --> Total execution time: 0.1407
DEBUG - 2021-02-03 20:02:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:02:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:02:19 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 20:02:19 --> Total execution time: 0.1743
DEBUG - 2021-02-03 20:02:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:02:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:02:23 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 20:02:23 --> Total execution time: 0.1691
DEBUG - 2021-02-03 20:02:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:02:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:02:27 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 20:02:27 --> Total execution time: 0.1476
DEBUG - 2021-02-03 20:02:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:02:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:02:32 --> get_sorce_lan_word_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 20:02:32 --> Total execution time: 0.1210
DEBUG - 2021-02-03 20:02:42 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:02:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:02:42 --> Total execution time: 0.1434
DEBUG - 2021-02-03 20:02:43 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:02:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:02:43 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 20:02:43 --> Total execution time: 0.1673
DEBUG - 2021-02-03 20:02:47 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:02:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:02:47 --> get_sorce_lan_word_type_3->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 20:02:47 --> Total execution time: 0.1373
DEBUG - 2021-02-03 20:03:08 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:03:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:03:09 --> Total execution time: 0.1114
DEBUG - 2021-02-03 20:03:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:03:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:03:10 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 20:03:10 --> Total execution time: 0.1129
DEBUG - 2021-02-03 20:03:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:03:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:03:14 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 20:03:14 --> Total execution time: 0.1477
DEBUG - 2021-02-03 20:03:17 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:03:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:03:17 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-02-03 20:03:17 --> Total execution time: 0.1147
DEBUG - 2021-02-03 20:03:20 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:03:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:03:20 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 20:03:20 --> Total execution time: 0.1453
DEBUG - 2021-02-03 20:03:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:03:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:03:24 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 20:03:24 --> Total execution time: 0.1393
DEBUG - 2021-02-03 20:03:27 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:03:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:03:27 --> get_exercise_type_list->{"lang":"37","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-03 20:03:27 --> Total execution time: 0.1373
DEBUG - 2021-02-03 20:03:31 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:03:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:03:31 --> get_dialogue_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"2","category_id":"7","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-03 20:03:31 --> Total execution time: 0.1146
DEBUG - 2021-02-03 20:03:44 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:03:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:03:44 --> get_exercise_type_list->{"lang":"37","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-02-03 20:03:44 --> Total execution time: 0.1185
DEBUG - 2021-02-03 20:03:46 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:03:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:03:46 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 20:03:46 --> Total execution time: 0.1542
DEBUG - 2021-02-03 20:03:49 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:03:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:03:49 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-02-03 20:03:49 --> Total execution time: 0.1526
DEBUG - 2021-02-03 20:03:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:03:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:03:54 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 20:03:54 --> Total execution time: 0.1562
DEBUG - 2021-02-03 20:03:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:03:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:03:58 --> get_subcategory_list->{"lang":"37","category_id":"9","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 20:03:58 --> Total execution time: 0.1752
DEBUG - 2021-02-03 20:04:02 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:04:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:04:02 --> get_exercise_type_list->{"lang":"37","subcategory_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 20:04:02 --> Total execution time: 0.1070
DEBUG - 2021-02-03 20:04:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:04:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:04:06 --> get_phrases_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"3","category_id":"9","subcategory_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 20:04:06 --> Total execution time: 0.1185
DEBUG - 2021-02-03 20:04:12 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:04:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:04:12 --> Total execution time: 0.1146
DEBUG - 2021-02-03 20:04:14 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:04:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:04:14 --> get_exercise_type_list->{"lang":"37","subcategory_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 20:04:14 --> Total execution time: 0.1242
DEBUG - 2021-02-03 20:04:18 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:04:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:04:18 --> get_subcategory_list->{"lang":"37","category_id":"9","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 20:04:18 --> Total execution time: 0.1351
DEBUG - 2021-02-03 20:04:21 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:04:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:04:21 --> get_category_list->{"lang":"37","exercise_mode_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 20:04:21 --> Total execution time: 0.1349
DEBUG - 2021-02-03 20:04:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:04:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:04:25 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 20:04:25 --> Total execution time: 0.1150
DEBUG - 2021-02-03 20:04:29 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:04:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:04:29 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 20:04:29 --> Total execution time: 0.1208
DEBUG - 2021-02-03 20:04:32 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:04:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:04:32 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 20:04:32 --> Total execution time: 0.1197
DEBUG - 2021-02-03 20:04:36 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:04:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:04:36 --> get_grammer_type_2->{"slang":"37","tlang":"37","exercise_mode_id":"4","category_id":"8","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 20:04:36 --> Total execution time: 0.1569
DEBUG - 2021-02-03 20:04:54 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:04:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:04:54 --> get_exercise_type_list->{"lang":"37","subcategory_id":"3","support_lang_id":"3"}
DEBUG - 2021-02-03 20:04:54 --> Total execution time: 0.1206
DEBUG - 2021-02-03 20:04:58 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:04:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:04:58 --> get_subcategory_list->{"lang":"37","category_id":"8","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 20:04:58 --> Total execution time: 0.1222
DEBUG - 2021-02-03 20:05:01 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:05:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:05:01 --> get_category_list->{"lang":"37","exercise_mode_id":"4","support_lang_id":"3"}
DEBUG - 2021-02-03 20:05:01 --> Total execution time: 0.1321
DEBUG - 2021-02-03 20:05:06 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:05:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:05:06 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 20:05:06 --> Total execution time: 0.1349
DEBUG - 2021-02-03 20:05:10 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:05:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:05:10 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 20:05:10 --> Total execution time: 0.1276
DEBUG - 2021-02-03 20:05:15 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:05:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:05:15 --> get_exercise_type_list->{"lang":"37","subcategory_id":"10","support_lang_id":"3"}
DEBUG - 2021-02-03 20:05:15 --> Total execution time: 0.1513
DEBUG - 2021-02-03 20:05:19 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:05:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:05:19 --> get_culture_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"5","category_id":"6","subcategory_id":"10","support_lang_id":"3"}
ERROR - 2021-02-03 20:05:19 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"BAD REQUEST"}
DEBUG - 2021-02-03 20:05:19 --> Total execution time: 0.1250
DEBUG - 2021-02-03 20:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:05:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:05:23 --> get_exercise_type_list->{"lang":"37","subcategory_id":"10","support_lang_id":"3"}
DEBUG - 2021-02-03 20:05:23 --> Total execution time: 0.1370
DEBUG - 2021-02-03 20:05:24 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:05:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:05:24 --> get_subcategory_list->{"lang":"37","category_id":"6","user_id":"746","support_lang_id":"3"}
DEBUG - 2021-02-03 20:05:24 --> Total execution time: 0.1273
DEBUG - 2021-02-03 20:05:25 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:05:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:05:25 --> get_category_list->{"lang":"37","exercise_mode_id":"5","support_lang_id":"3"}
DEBUG - 2021-02-03 20:05:25 --> Total execution time: 0.1556
DEBUG - 2021-02-03 20:05:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:05:26 --> UTF-8 Support Enabled
DEBUG - 2021-02-03 20:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-02-03 20:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:05:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:05:26 --> Total execution time: 0.1215
DEBUG - 2021-02-03 20:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-02-03 20:05:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-02-03 20:05:26 --> Total execution time: 0.1504
