<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-01-31 09:23:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 09:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 09:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 09:23:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 09:23:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 09:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 09:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 09:23:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 09:23:55 --> Total execution time: 0.1726
DEBUG - 2021-01-31 09:24:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 09:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 09:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 09:24:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 09:24:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 09:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 09:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 09:24:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 09:24:58 --> Total execution time: 0.1224
DEBUG - 2021-01-31 09:25:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 09:25:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 09:25:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-31 09:25:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 09:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 09:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 09:25:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 09:25:12 --> Total execution time: 0.1117
DEBUG - 2021-01-31 09:25:14 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 09:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 09:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 09:25:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-31 09:25:15 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-31 09:25:15 --> Total execution time: 0.1457
DEBUG - 2021-01-31 09:25:17 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 09:25:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 09:25:17 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-31 10:13:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:13:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:13:03 --> Total execution time: 0.1299
DEBUG - 2021-01-31 10:13:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:13:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-31 10:13:06 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-31 10:13:06 --> Total execution time: 0.1351
DEBUG - 2021-01-31 10:13:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:13:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:13:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-31 10:13:14 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:13:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-31 10:13:14 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-31 10:13:14 --> Total execution time: 0.1653
DEBUG - 2021-01-31 10:13:17 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:13:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-31 10:13:17 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-31 10:13:17 --> Total execution time: 0.1301
DEBUG - 2021-01-31 10:13:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:13:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:13:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-31 10:15:30 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:15:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:15:33 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:15:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-31 10:15:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-31 10:15:34 --> Total execution time: 0.1250
DEBUG - 2021-01-31 10:15:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:15:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:15:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-31 10:15:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:15:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:15:37 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-31 10:15:38 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:15:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:15:38 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-31 10:15:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:15:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:15:55 --> Total execution time: 0.1245
DEBUG - 2021-01-31 10:15:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:15:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:15:57 --> Total execution time: 0.1398
DEBUG - 2021-01-31 10:15:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:15:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:15:58 --> Total execution time: 0.1370
DEBUG - 2021-01-31 10:15:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:16:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:16:00 --> Total execution time: 0.1599
DEBUG - 2021-01-31 10:16:00 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:16:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:16:00 --> Total execution time: 0.1493
DEBUG - 2021-01-31 10:16:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:16:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:16:01 --> Total execution time: 0.1752
DEBUG - 2021-01-31 10:16:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:16:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:16:03 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-31 10:16:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:16:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:16:12 --> Total execution time: 0.1303
DEBUG - 2021-01-31 10:16:19 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:16:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:16:19 --> Total execution time: 0.1383
DEBUG - 2021-01-31 10:16:56 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:16:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:16:56 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:16:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:16:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:16:59 --> Total execution time: 0.1381
DEBUG - 2021-01-31 10:17:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:17:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:17:01 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-31 10:17:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:17:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:17:20 --> Total execution time: 0.1550
DEBUG - 2021-01-31 10:17:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:17:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-31 10:17:22 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2021-01-31 10:17:22 --> Total execution time: 0.1734
DEBUG - 2021-01-31 10:17:25 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:17:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:17:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-31 10:17:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:17:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:17:26 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-31 10:17:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:17:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:17:51 --> Total execution time: 0.1174
DEBUG - 2021-01-31 10:17:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:17:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:17:55 --> Total execution time: 0.0966
DEBUG - 2021-01-31 10:18:00 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:18:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:18:00 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-31 10:18:00 --> Total execution time: 0.1286
DEBUG - 2021-01-31 10:18:03 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:18:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:18:03 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-31 10:18:03 --> Total execution time: 0.1043
DEBUG - 2021-01-31 10:18:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:18:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:18:07 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-31 10:18:07 --> Total execution time: 0.1221
DEBUG - 2021-01-31 10:18:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:18:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:18:10 --> get_sorce_lan_word_type_8->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-31 10:18:10 --> Total execution time: 0.1005
DEBUG - 2021-01-31 10:18:14 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:18:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:18:14 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-31 10:18:16 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:18:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:18:16 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-31 10:18:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:18:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:18:27 --> Total execution time: 0.0976
DEBUG - 2021-01-31 10:18:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:18:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:18:40 --> Total execution time: 0.1376
DEBUG - 2021-01-31 10:18:45 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:18:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:18:45 --> Total execution time: 0.1192
DEBUG - 2021-01-31 10:19:01 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:19:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:19:01 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-31 10:19:01 --> Total execution time: 0.1051
DEBUG - 2021-01-31 10:19:05 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:19:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:19:05 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-31 10:19:05 --> Total execution time: 0.1201
DEBUG - 2021-01-31 10:19:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:19:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:19:09 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-31 10:19:09 --> Total execution time: 0.1050
DEBUG - 2021-01-31 10:19:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:19:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:19:15 --> get_sorce_lan_word_type_6->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-31 10:19:15 --> Total execution time: 0.1353
DEBUG - 2021-01-31 10:19:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:19:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:19:20 --> Total execution time: 0.1178
DEBUG - 2021-01-31 10:19:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:19:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:19:39 --> Total execution time: 0.1152
DEBUG - 2021-01-31 10:19:49 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:19:49 --> Total execution time: 0.1055
DEBUG - 2021-01-31 10:20:37 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:20:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:20:37 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-31 10:20:37 --> Total execution time: 0.1154
DEBUG - 2021-01-31 10:20:41 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:20:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:20:41 --> get_subcategory_list->{"lang":"37","category_id":"1","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-31 10:20:41 --> Total execution time: 0.1172
DEBUG - 2021-01-31 10:20:44 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:20:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:20:45 --> get_exercise_type_list->{"lang":"37","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-31 10:20:45 --> Total execution time: 0.1441
DEBUG - 2021-01-31 10:20:52 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:20:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:20:52 --> get_sorce_lan_word_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"1","category_id":"1","subcategory_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-31 10:20:52 --> Total execution time: 0.1578
DEBUG - 2021-01-31 10:20:55 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:20:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:20:55 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-31 10:20:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:20:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:20:58 --> 404 Page Not Found: Uploads/words
DEBUG - 2021-01-31 10:21:17 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:21:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:21:17 --> Total execution time: 0.1183
DEBUG - 2021-01-31 10:21:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:21:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:21:27 --> Total execution time: 0.1012
DEBUG - 2021-01-31 10:21:50 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:21:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:21:50 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-01-31 10:21:50 --> Total execution time: 0.1317
DEBUG - 2021-01-31 10:21:54 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:21:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:21:54 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-31 10:21:54 --> Total execution time: 0.1140
DEBUG - 2021-01-31 10:22:15 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:22:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:22:15 --> Total execution time: 0.1818
DEBUG - 2021-01-31 10:22:18 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:22:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-31 10:22:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-31 10:22:18 --> Total execution time: 0.1474
DEBUG - 2021-01-31 10:22:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:22:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-31 10:22:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:22:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:24:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:24:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-31 10:24:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-31 10:24:09 --> Total execution time: 0.1237
DEBUG - 2021-01-31 10:24:10 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:24:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:24:10 --> Total execution time: 0.1618
DEBUG - 2021-01-31 10:24:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:24:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-31 10:24:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-31 10:24:11 --> Total execution time: 0.1552
DEBUG - 2021-01-31 10:24:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:24:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-31 10:24:13 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-31 10:24:13 --> Total execution time: 0.1538
DEBUG - 2021-01-31 10:24:16 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:24:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:24:16 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-31 10:24:25 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:24:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:24:25 --> Total execution time: 0.1510
DEBUG - 2021-01-31 10:24:26 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:24:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:24:26 --> Total execution time: 0.1329
DEBUG - 2021-01-31 10:24:27 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:24:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:24:27 --> Total execution time: 0.1310
DEBUG - 2021-01-31 10:24:28 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:24:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:24:28 --> Total execution time: 0.1728
DEBUG - 2021-01-31 10:24:29 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:24:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:24:29 --> Total execution time: 0.1708
DEBUG - 2021-01-31 10:24:32 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:24:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:24:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-31 10:25:00 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:25:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:25:00 --> Total execution time: 0.1421
DEBUG - 2021-01-31 10:25:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:25:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:25:02 --> Total execution time: 0.1405
DEBUG - 2021-01-31 10:25:05 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:25:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:25:05 --> Total execution time: 0.1264
DEBUG - 2021-01-31 10:25:08 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:25:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:25:08 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-31 10:25:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:25:21 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:25:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-31 10:25:21 --> Query error: Unknown column 'mode_name' in 'order clause' - Invalid query: SELECT *
FROM `tbl_exercise_type`
WHERE `exercise_mode_id` = '2'
ORDER BY `mode_name` ASC
ERROR - 2021-01-31 10:25:21 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home/langoalphademo/public_html/indylan/application/models/Admin_model.php 970
DEBUG - 2021-01-31 10:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:25:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:25:21 --> Total execution time: 0.2356
DEBUG - 2021-01-31 10:26:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:26:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:26:59 --> Total execution time: 0.1443
DEBUG - 2021-01-31 10:27:02 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:27:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:27:02 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-31 10:27:48 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:27:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:27:48 --> Total execution time: 0.1114
DEBUG - 2021-01-31 10:28:22 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:28:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:28:22 --> Total execution time: 0.1503
DEBUG - 2021-01-31 10:28:25 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:28:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:28:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-31 10:28:39 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:28:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:28:41 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:28:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:28:41 --> Total execution time: 0.1298
DEBUG - 2021-01-31 10:28:44 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:28:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:28:44 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-31 10:28:50 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:28:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:28:50 --> Total execution time: 0.2000
DEBUG - 2021-01-31 10:28:51 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:28:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:28:51 --> Total execution time: 0.1338
DEBUG - 2021-01-31 10:28:53 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:28:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-31 10:28:53 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-31 10:28:53 --> Total execution time: 0.1298
DEBUG - 2021-01-31 10:28:54 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:28:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-31 10:28:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-31 10:28:54 --> Total execution time: 0.1127
DEBUG - 2021-01-31 10:28:57 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:28:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-31 10:29:06 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:29:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:29:06 --> Total execution time: 0.1280
DEBUG - 2021-01-31 10:29:09 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:29:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-31 10:29:09 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-31 10:29:09 --> Total execution time: 0.1596
DEBUG - 2021-01-31 10:29:11 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:29:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-31 10:29:11 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-31 10:29:11 --> Total execution time: 0.1169
DEBUG - 2021-01-31 10:29:12 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:29:12 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-31 10:29:18 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:29:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-31 10:29:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-31 10:29:18 --> Total execution time: 0.1349
DEBUG - 2021-01-31 10:29:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:29:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-31 10:29:20 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-31 10:29:20 --> Total execution time: 0.1809
DEBUG - 2021-01-31 10:29:23 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:29:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:29:23 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-31 10:33:53 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:33:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:33:56 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:33:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-31 10:33:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-31 10:33:56 --> Total execution time: 0.1315
DEBUG - 2021-01-31 10:33:59 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:33:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:33:59 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-31 10:34:18 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:34:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-31 10:34:18 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2021-01-31 10:34:18 --> Total execution time: 0.1619
DEBUG - 2021-01-31 10:34:20 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:34:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-01-31 10:34:20 --> 404 Page Not Found: Assets/chosen
DEBUG - 2021-01-31 10:35:40 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:35:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:35:40 --> Total execution time: 0.1204
DEBUG - 2021-01-31 10:35:46 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:35:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:35:46 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"3"}
DEBUG - 2021-01-31 10:35:46 --> Total execution time: 0.1117
DEBUG - 2021-01-31 10:35:50 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:35:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:35:50 --> get_subcategory_list->{"lang":"37","category_id":"7","user_id":"1","support_lang_id":"3"}
DEBUG - 2021-01-31 10:35:50 --> Total execution time: 0.1791
DEBUG - 2021-01-31 10:35:54 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:35:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:35:54 --> get_exercise_type_list->{"lang":"37","subcategory_id":"6","support_lang_id":"3"}
DEBUG - 2021-01-31 10:35:54 --> Total execution time: 0.1155
DEBUG - 2021-01-31 10:35:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:35:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2021-01-31 10:35:58 --> {"status":0,"message":"Invalid Exercise Type","message_en":"","result":"","status_message":"NOT FOUND"}
DEBUG - 2021-01-31 10:35:58 --> Total execution time: 0.1141
DEBUG - 2021-01-31 10:36:58 --> UTF-8 Support Enabled
DEBUG - 2021-01-31 10:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-01-31 10:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-01-31 10:36:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-01-31 10:36:58 --> Total execution time: 0.1543
