<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-09-04 05:27:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:27:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:27:33 --> Total execution time: 0.1515
DEBUG - 2020-09-04 05:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:29:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:29:42 --> Total execution time: 0.1289
DEBUG - 2020-09-04 05:33:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:33:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:33:03 --> Total execution time: 0.1225
DEBUG - 2020-09-04 05:33:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:33:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:33:13 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 05:33:13 --> Total execution time: 0.1375
DEBUG - 2020-09-04 05:33:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:33:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:33:17 --> get_subcategory_list->{"lang":"37","category_id":"126","user_id":"0","support_lang_id":"2"}
DEBUG - 2020-09-04 05:33:17 --> Total execution time: 0.1198
DEBUG - 2020-09-04 05:33:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:33:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:33:20 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 05:33:20 --> Total execution time: 0.1162
DEBUG - 2020-09-04 05:33:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:33:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:33:24 --> get_dialogue_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 05:33:24 --> Total execution time: 0.1448
DEBUG - 2020-09-04 05:35:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:35:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:35:55 --> get_subcategory_list->{"lang":"37","category_id":"126","user_id":"0","support_lang_id":"2"}
DEBUG - 2020-09-04 05:35:55 --> Total execution time: 0.1618
DEBUG - 2020-09-04 05:36:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:36:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:36:13 --> Total execution time: 0.1184
DEBUG - 2020-09-04 05:36:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:36:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:36:21 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 05:36:21 --> Total execution time: 0.1475
DEBUG - 2020-09-04 05:36:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:36:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:36:25 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"0","support_lang_id":"2"}
DEBUG - 2020-09-04 05:36:25 --> Total execution time: 0.1254
DEBUG - 2020-09-04 05:36:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:36:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:36:29 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 05:36:29 --> Total execution time: 0.1286
DEBUG - 2020-09-04 05:36:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:36:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:36:32 --> get_dialogue_type_1->{"slang":"38","tlang":"38","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 05:36:32 --> Total execution time: 0.1401
DEBUG - 2020-09-04 05:44:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:44:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:44:45 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 05:44:45 --> Total execution time: 0.2337
DEBUG - 2020-09-04 05:44:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:44:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:44:50 --> get_subcategory_list->{"lang":"37","category_id":"126","user_id":"0","support_lang_id":"2"}
DEBUG - 2020-09-04 05:44:50 --> Total execution time: 0.1239
DEBUG - 2020-09-04 05:44:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:44:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:44:53 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 05:44:53 --> Total execution time: 0.1734
DEBUG - 2020-09-04 05:44:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:44:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:44:59 --> get_dialogue_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 05:44:59 --> Total execution time: 0.1890
DEBUG - 2020-09-04 05:52:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:52:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:52:57 --> get_subcategory_list->{"lang":"37","category_id":"126","user_id":"0","support_lang_id":"2"}
DEBUG - 2020-09-04 05:52:57 --> Total execution time: 0.1457
DEBUG - 2020-09-04 05:53:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:53:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:53:08 --> Total execution time: 0.1722
DEBUG - 2020-09-04 05:53:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:53:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:53:16 --> get_category_list->{"lang":"37","exercise_mode_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-04 05:53:16 --> Total execution time: 0.1494
DEBUG - 2020-09-04 05:53:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:53:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:53:21 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 05:53:21 --> Total execution time: 0.1516
DEBUG - 2020-09-04 05:53:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:53:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:53:24 --> get_subcategory_list->{"lang":"37","category_id":"126","user_id":"0","support_lang_id":"2"}
DEBUG - 2020-09-04 05:53:24 --> Total execution time: 0.1620
DEBUG - 2020-09-04 05:53:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:53:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:53:28 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 05:53:28 --> Total execution time: 0.1540
DEBUG - 2020-09-04 05:53:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 05:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 05:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 05:53:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 05:53:32 --> get_dialogue_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 05:53:32 --> Total execution time: 0.1651
DEBUG - 2020-09-04 08:01:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:01:49 --> No URI present. Default controller set.
DEBUG - 2020-09-04 08:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:01:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:01:49 --> Total execution time: 0.1504
DEBUG - 2020-09-04 08:02:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:02:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:02:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:02:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:02:39 --> Total execution time: 0.1567
DEBUG - 2020-09-04 08:02:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:02:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 08:02:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 08:02:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:02:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:02:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:02:58 --> Total execution time: 0.1375
DEBUG - 2020-09-04 08:03:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:03:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:03:01 --> Total execution time: 0.1539
DEBUG - 2020-09-04 08:03:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:03:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 08:03:05 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 08:03:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:03:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 08:03:06 --> 404 Page Not Found: Uploads/badger.jpg
DEBUG - 2020-09-04 08:03:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:03:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:03:22 --> Total execution time: 0.1860
DEBUG - 2020-09-04 08:03:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:03:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 08:03:25 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 08:07:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:07:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:07:39 --> Total execution time: 0.1628
DEBUG - 2020-09-04 08:07:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:07:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-04 08:07:42 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-09-04 08:07:42 --> Total execution time: 0.1590
DEBUG - 2020-09-04 08:07:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:07:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 08:07:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 08:07:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:07:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:07:57 --> Total execution time: 0.1501
DEBUG - 2020-09-04 08:08:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:08:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 08:08:00 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 08:08:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:08:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:08:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:08:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-04 08:08:44 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-09-04 08:08:44 --> Total execution time: 0.1302
DEBUG - 2020-09-04 08:08:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:08:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 08:08:47 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 08:09:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:09:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:09:04 --> Total execution time: 0.1645
DEBUG - 2020-09-04 08:09:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:09:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:09:08 --> Total execution time: 0.1296
DEBUG - 2020-09-04 08:09:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:09:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:09:33 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 08:09:33 --> Total execution time: 0.1321
DEBUG - 2020-09-04 08:09:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:09:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:09:37 --> get_subcategory_list->{"lang":"37","category_id":"126","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-04 08:09:37 --> Total execution time: 0.1636
DEBUG - 2020-09-04 08:09:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:09:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:09:45 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:09:45 --> Total execution time: 0.1493
DEBUG - 2020-09-04 08:09:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:09:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:09:50 --> get_dialogue_type_1->{"slang":"37","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:09:50 --> Total execution time: 0.1297
DEBUG - 2020-09-04 08:11:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:11:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:11:18 --> Total execution time: 0.1889
DEBUG - 2020-09-04 08:11:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:11:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 08:11:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 08:11:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:11:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:11:27 --> Total execution time: 0.1524
DEBUG - 2020-09-04 08:11:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:11:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-04 08:11:30 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-09-04 08:11:30 --> Total execution time: 0.1761
DEBUG - 2020-09-04 08:11:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:11:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 08:11:33 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 08:11:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:11:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:11:42 --> Total execution time: 0.1567
DEBUG - 2020-09-04 08:11:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:11:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 08:11:45 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 08:11:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:11:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:11:54 --> Total execution time: 0.1268
DEBUG - 2020-09-04 08:12:25 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:12:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:12:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:12:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-04 08:12:28 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-09-04 08:12:28 --> Total execution time: 0.1318
DEBUG - 2020-09-04 08:12:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:12:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 08:12:32 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 08:12:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:12:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:12:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:12:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:12:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:12:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:12:39 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 08:12:39 --> Total execution time: 0.1293
DEBUG - 2020-09-04 08:12:39 --> Total execution time: 0.1641
DEBUG - 2020-09-04 08:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:12:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:12:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:12:39 --> get_subcategory_list->{"lang":"37","category_id":"126","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-04 08:12:39 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:12:39 --> Total execution time: 0.2235
DEBUG - 2020-09-04 08:12:39 --> Total execution time: 0.1725
DEBUG - 2020-09-04 08:12:40 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:12:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:12:40 --> Total execution time: 0.1055
DEBUG - 2020-09-04 08:12:46 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:12:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:12:46 --> Total execution time: 0.1784
DEBUG - 2020-09-04 08:12:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:12:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:12:49 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 08:12:49 --> Total execution time: 0.1366
DEBUG - 2020-09-04 08:12:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:12:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:12:52 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-04 08:12:52 --> Total execution time: 0.1348
DEBUG - 2020-09-04 08:12:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:12:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:12:56 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:12:56 --> Total execution time: 0.1630
DEBUG - 2020-09-04 08:12:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:12:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:12:59 --> get_dialogue_type_1->{"slang":"38","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:12:59 --> Total execution time: 0.1446
DEBUG - 2020-09-04 08:13:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:13:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:13:14 --> Total execution time: 0.1149
DEBUG - 2020-09-04 08:13:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:13:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:13:19 --> Total execution time: 0.1296
DEBUG - 2020-09-04 08:13:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:13:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:13:27 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 08:13:27 --> Total execution time: 0.1397
DEBUG - 2020-09-04 08:13:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:13:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:13:31 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-04 08:13:31 --> Total execution time: 0.1339
DEBUG - 2020-09-04 08:13:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:13:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:13:36 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:13:36 --> Total execution time: 0.1450
DEBUG - 2020-09-04 08:13:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:13:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:13:40 --> get_dialogue_type_1->{"slang":"38","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:13:40 --> Total execution time: 0.1525
DEBUG - 2020-09-04 08:13:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:13:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:13:50 --> Total execution time: 0.1997
DEBUG - 2020-09-04 08:13:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:13:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 08:13:53 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 08:14:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:14:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:14:03 --> Total execution time: 0.1544
DEBUG - 2020-09-04 08:14:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:14:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:14:09 --> Total execution time: 0.1104
DEBUG - 2020-09-04 08:14:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:14:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:14:20 --> Total execution time: 0.1264
DEBUG - 2020-09-04 08:14:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:14:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:14:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:14:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-04 08:14:45 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-09-04 08:14:45 --> Total execution time: 0.1163
DEBUG - 2020-09-04 08:14:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 08:14:48 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 08:14:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:14:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:14:56 --> get_category_list->{"lang":"39","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 08:14:56 --> Total execution time: 0.1392
DEBUG - 2020-09-04 08:15:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:15:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:15:00 --> get_subcategory_list->{"lang":"39","category_id":"126","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-04 08:15:00 --> Total execution time: 0.1572
DEBUG - 2020-09-04 08:15:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:15:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:15:04 --> get_exercise_type_list->{"lang":"39","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:15:04 --> Total execution time: 0.1060
DEBUG - 2020-09-04 08:15:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:15:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:15:08 --> get_dialogue_type_1->{"slang":"39","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:15:08 --> Total execution time: 0.1171
DEBUG - 2020-09-04 08:15:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:15:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:15:16 --> Total execution time: 0.1632
DEBUG - 2020-09-04 08:15:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:15:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 08:15:18 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 08:15:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:15:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:15:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:15:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-04 08:15:34 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-09-04 08:15:34 --> Total execution time: 0.1592
DEBUG - 2020-09-04 08:15:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:15:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 08:15:37 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 08:15:45 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:15:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:15:46 --> Total execution time: 0.1744
DEBUG - 2020-09-04 08:15:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:15:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:15:50 --> Total execution time: 0.1545
DEBUG - 2020-09-04 08:15:59 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:15:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:15:59 --> get_category_list->{"lang":"39","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 08:15:59 --> Total execution time: 0.1615
DEBUG - 2020-09-04 08:16:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:16:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:16:03 --> get_subcategory_list->{"lang":"39","category_id":"126","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-04 08:16:03 --> Total execution time: 0.1069
DEBUG - 2020-09-04 08:16:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:16:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:16:09 --> get_exercise_type_list->{"lang":"39","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:16:09 --> Total execution time: 0.1155
DEBUG - 2020-09-04 08:16:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:16:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:16:12 --> get_dialogue_type_1->{"slang":"39","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:16:12 --> Total execution time: 0.1760
DEBUG - 2020-09-04 08:17:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:17:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:17:17 --> Total execution time: 0.1412
DEBUG - 2020-09-04 08:17:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:17:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:17:18 --> Total execution time: 0.1788
DEBUG - 2020-09-04 08:17:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:17:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 08:17:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 08:17:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:17:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:17:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:17:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-04 08:17:56 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-09-04 08:17:56 --> Total execution time: 0.1745
DEBUG - 2020-09-04 08:17:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:17:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:17:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:17:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 08:17:58 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 08:17:58 --> Total execution time: 0.1399
DEBUG - 2020-09-04 08:18:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:18:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:18:06 --> get_category_list->{"lang":"39","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 08:18:06 --> Total execution time: 0.1369
DEBUG - 2020-09-04 08:18:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:18:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:18:10 --> get_subcategory_list->{"lang":"39","category_id":"126","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-04 08:18:10 --> Total execution time: 0.1316
DEBUG - 2020-09-04 08:18:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:18:14 --> get_exercise_type_list->{"lang":"39","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:18:14 --> Total execution time: 0.1424
DEBUG - 2020-09-04 08:18:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:18:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:18:17 --> get_dialogue_type_1->{"slang":"39","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:18:17 --> Total execution time: 0.1388
DEBUG - 2020-09-04 08:18:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:18:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:18:41 --> get_exercise_type_list->{"lang":"39","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:18:41 --> Total execution time: 0.1224
DEBUG - 2020-09-04 08:18:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:18:44 --> get_subcategory_list->{"lang":"39","category_id":"126","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-04 08:18:44 --> Total execution time: 0.1318
DEBUG - 2020-09-04 08:18:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:18:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:18:48 --> Total execution time: 0.1660
DEBUG - 2020-09-04 08:18:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:18:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 08:18:50 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 08:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:19:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:19:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:19:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-04 08:19:04 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/dialogue_list.php 171
DEBUG - 2020-09-04 08:19:04 --> Total execution time: 0.1748
DEBUG - 2020-09-04 08:19:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:19:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 08:19:07 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 08:19:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:19:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:19:14 --> get_exercise_type_list->{"lang":"39","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:19:14 --> Total execution time: 0.1147
DEBUG - 2020-09-04 08:19:17 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:19:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:19:18 --> get_dialogue_type_1->{"slang":"39","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:19:18 --> Total execution time: 0.1402
DEBUG - 2020-09-04 08:40:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:40:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:40:41 --> Total execution time: 0.1419
DEBUG - 2020-09-04 08:40:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:40:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:40:47 --> Total execution time: 0.1344
DEBUG - 2020-09-04 08:43:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:43:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:43:24 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 08:43:24 --> Total execution time: 0.1283
DEBUG - 2020-09-04 08:43:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:43:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:43:28 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"0","support_lang_id":"2"}
DEBUG - 2020-09-04 08:43:28 --> Total execution time: 0.1388
DEBUG - 2020-09-04 08:43:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:43:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:43:36 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:43:36 --> Total execution time: 0.1266
DEBUG - 2020-09-04 08:43:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:43:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:43:39 --> get_dialogue_type_1->{"slang":"38","tlang":"38","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:43:39 --> Total execution time: 0.1099
DEBUG - 2020-09-04 08:47:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:47:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:47:07 --> Total execution time: 0.1363
DEBUG - 2020-09-04 08:54:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:54:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:54:51 --> Total execution time: 0.1351
DEBUG - 2020-09-04 08:54:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:54:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:54:58 --> Total execution time: 0.1440
DEBUG - 2020-09-04 08:55:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:55:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:55:03 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 08:55:03 --> Total execution time: 0.0978
DEBUG - 2020-09-04 08:55:07 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:55:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:55:08 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"0","support_lang_id":"2"}
DEBUG - 2020-09-04 08:55:08 --> Total execution time: 0.1180
DEBUG - 2020-09-04 08:55:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:55:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:55:11 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:55:11 --> Total execution time: 0.1478
DEBUG - 2020-09-04 08:55:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:55:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:55:14 --> get_dialogue_type_1->{"slang":"38","tlang":"38","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:55:14 --> Total execution time: 0.1120
DEBUG - 2020-09-04 08:56:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:56:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:56:04 --> get_dialogue_type_1->{"slang":"38","tlang":"38","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:56:04 --> Total execution time: 0.1265
DEBUG - 2020-09-04 08:56:30 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:56:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:56:30 --> Total execution time: 0.1369
DEBUG - 2020-09-04 08:56:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:56:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:56:35 --> Total execution time: 0.1079
DEBUG - 2020-09-04 08:56:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:56:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:56:43 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 08:56:43 --> Total execution time: 0.1207
DEBUG - 2020-09-04 08:56:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:56:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:56:47 --> get_subcategory_list->{"lang":"37","category_id":"126","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-04 08:56:47 --> Total execution time: 0.1253
DEBUG - 2020-09-04 08:56:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:56:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:56:51 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:56:51 --> Total execution time: 0.1001
DEBUG - 2020-09-04 08:56:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:56:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:56:55 --> get_dialogue_type_1->{"slang":"37","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:56:55 --> Total execution time: 0.1366
DEBUG - 2020-09-04 08:57:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:57:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:57:03 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:57:03 --> Total execution time: 0.1003
DEBUG - 2020-09-04 08:57:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:57:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:57:14 --> Total execution time: 0.1564
DEBUG - 2020-09-04 08:57:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:57:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:57:18 --> Total execution time: 0.1472
DEBUG - 2020-09-04 08:57:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:57:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:57:23 --> get_dialogue_type_1->{"slang":"38","tlang":"38","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:57:23 --> Total execution time: 0.1648
DEBUG - 2020-09-04 08:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:57:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:57:24 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 08:57:24 --> Total execution time: 0.1453
DEBUG - 2020-09-04 08:57:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:57:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:57:28 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"1","support_lang_id":"2"}
DEBUG - 2020-09-04 08:57:28 --> Total execution time: 0.1641
DEBUG - 2020-09-04 08:57:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:57:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:57:31 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:57:31 --> Total execution time: 0.1321
DEBUG - 2020-09-04 08:57:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:57:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:57:36 --> get_dialogue_type_1->{"slang":"38","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 08:57:36 --> Total execution time: 0.1364
DEBUG - 2020-09-04 08:59:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:59:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:59:18 --> Total execution time: 0.1262
DEBUG - 2020-09-04 08:59:23 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 08:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 08:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 08:59:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 08:59:23 --> Total execution time: 0.1534
DEBUG - 2020-09-04 09:00:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 09:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 09:00:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 09:00:22 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 09:00:22 --> Total execution time: 0.1177
DEBUG - 2020-09-04 09:00:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 09:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 09:00:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 09:00:28 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"0","support_lang_id":"2"}
DEBUG - 2020-09-04 09:00:28 --> Total execution time: 0.1343
DEBUG - 2020-09-04 09:00:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 09:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 09:00:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 09:00:32 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 09:00:32 --> Total execution time: 0.1334
DEBUG - 2020-09-04 09:00:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 09:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 09:00:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 09:00:37 --> get_dialogue_type_1->{"slang":"38","tlang":"38","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 09:00:37 --> Total execution time: 0.1096
DEBUG - 2020-09-04 09:04:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 09:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 09:04:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 09:04:42 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"0","support_lang_id":"2"}
DEBUG - 2020-09-04 09:04:42 --> Total execution time: 0.1168
DEBUG - 2020-09-04 09:04:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 09:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 09:04:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 09:04:51 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 09:04:51 --> Total execution time: 0.1314
DEBUG - 2020-09-04 09:08:51 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 09:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 09:08:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 09:08:52 --> Total execution time: 0.1408
DEBUG - 2020-09-04 09:08:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 09:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 09:08:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-04 09:08:54 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/phrases_list.php 179
DEBUG - 2020-09-04 09:08:54 --> Total execution time: 0.2373
DEBUG - 2020-09-04 09:08:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:08:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 09:08:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 09:08:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 09:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 09:08:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 09:08:57 --> get_category_list->{"lang":"37","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 09:08:57 --> Total execution time: 0.1254
DEBUG - 2020-09-04 09:09:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 09:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 09:09:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 09:09:01 --> get_subcategory_list->{"lang":"37","category_id":"126","user_id":"0","support_lang_id":"2"}
DEBUG - 2020-09-04 09:09:01 --> Total execution time: 0.0991
DEBUG - 2020-09-04 09:09:04 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 09:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 09:09:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 09:09:04 --> get_exercise_type_list->{"lang":"37","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 09:09:04 --> Total execution time: 0.1084
DEBUG - 2020-09-04 09:09:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 09:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 09:09:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 09:09:08 --> get_dialogue_type_1->{"slang":"37","tlang":"37","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 09:09:08 --> Total execution time: 0.1437
DEBUG - 2020-09-04 09:09:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 09:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 09:09:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 09:09:31 --> Total execution time: 0.1532
DEBUG - 2020-09-04 09:10:20 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 09:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 09:10:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-04 09:10:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/langoalphademo/public_html/indylan/application/views/admin/add_phrases.php 41
DEBUG - 2020-09-04 09:10:20 --> Total execution time: 0.1695
DEBUG - 2020-09-04 09:10:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:10:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 09:10:22 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 09:10:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 09:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 09:10:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 09:10:27 --> Total execution time: 0.1169
DEBUG - 2020-09-04 09:29:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 09:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 09:29:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 09:29:34 --> Total execution time: 0.1507
DEBUG - 2020-09-04 09:30:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:30:05 --> No URI present. Default controller set.
DEBUG - 2020-09-04 09:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 09:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 09:30:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 09:30:05 --> Total execution time: 0.1267
DEBUG - 2020-09-04 09:30:28 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:30:28 --> No URI present. Default controller set.
DEBUG - 2020-09-04 09:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 09:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 09:30:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 09:30:29 --> Total execution time: 0.1408
DEBUG - 2020-09-04 09:30:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 09:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 09:30:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 09:30:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 09:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 09:30:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 09:30:53 --> Total execution time: 0.1354
DEBUG - 2020-09-04 09:30:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:30:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 09:30:57 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 09:33:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 09:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 09:33:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 09:33:04 --> Total execution time: 0.1375
DEBUG - 2020-09-04 09:33:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 09:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 09:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 09:33:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 09:33:27 --> Total execution time: 0.1590
DEBUG - 2020-09-04 10:10:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:10:22 --> No URI present. Default controller set.
DEBUG - 2020-09-04 10:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:10:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:10:22 --> Total execution time: 0.1360
DEBUG - 2020-09-04 10:10:32 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:10:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:10:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:10:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:10:35 --> Total execution time: 0.1514
DEBUG - 2020-09-04 10:10:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:10:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 10:10:38 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 10:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:21:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:21:05 --> Total execution time: 0.1665
DEBUG - 2020-09-04 10:21:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:21:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:21:08 --> Total execution time: 0.2042
DEBUG - 2020-09-04 10:21:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:21:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 10:21:11 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 10:21:16 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:21:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:21:16 --> Total execution time: 0.1249
DEBUG - 2020-09-04 10:21:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:21:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-04 10:21:19 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/words_list.php 189
DEBUG - 2020-09-04 10:21:19 --> Total execution time: 0.2286
DEBUG - 2020-09-04 10:21:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:21:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 10:21:21 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 10:21:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:21:36 --> Total execution time: 0.1324
DEBUG - 2020-09-04 10:21:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:21:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-04 10:21:39 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/langoalphademo/public_html/indylan/application/views/admin/grammer_list.php 168
DEBUG - 2020-09-04 10:21:39 --> Total execution time: 0.1700
DEBUG - 2020-09-04 10:21:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:21:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-04 10:21:42 --> 404 Page Not Found: Assets/chosen
DEBUG - 2020-09-04 10:44:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:44:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:44:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:44:03 --> Total execution time: 0.1397
DEBUG - 2020-09-04 10:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:44:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:44:03 --> Total execution time: 0.1636
DEBUG - 2020-09-04 10:44:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:44:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:44:22 --> Total execution time: 0.1396
DEBUG - 2020-09-04 10:44:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:44:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:44:29 --> get_category_list->{"lang":"38","exercise_mode_id":"5","support_lang_id":"1"}
ERROR - 2020-09-04 10:44:29 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-09-04 10:44:29 --> Total execution time: 0.1772
DEBUG - 2020-09-04 10:44:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:44:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:44:33 --> get_category_list->{"lang":"38","exercise_mode_id":"4","support_lang_id":"1"}
ERROR - 2020-09-04 10:44:33 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-09-04 10:44:33 --> Total execution time: 0.1579
DEBUG - 2020-09-04 10:44:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:44:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:44:37 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"1"}
ERROR - 2020-09-04 10:44:37 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-09-04 10:44:37 --> Total execution time: 0.1253
DEBUG - 2020-09-04 10:44:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:44:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:44:42 --> Total execution time: 0.1221
DEBUG - 2020-09-04 10:44:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:44:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:44:54 --> Total execution time: 0.1511
DEBUG - 2020-09-04 10:44:57 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:44:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:44:58 --> Total execution time: 0.1303
DEBUG - 2020-09-04 10:45:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:45:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:45:02 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 10:45:02 --> Total execution time: 0.1156
DEBUG - 2020-09-04 10:45:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:45:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:45:05 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"746","support_lang_id":"2"}
DEBUG - 2020-09-04 10:45:05 --> Total execution time: 0.1595
DEBUG - 2020-09-04 10:45:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:45:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:45:09 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 10:45:09 --> Total execution time: 0.1322
DEBUG - 2020-09-04 10:45:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:45:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:45:12 --> get_dialogue_type_1->{"slang":"38","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 10:45:12 --> Total execution time: 0.1376
DEBUG - 2020-09-04 10:47:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:47:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:47:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:47:14 --> Total execution time: 0.1312
DEBUG - 2020-09-04 10:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:47:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:47:14 --> Total execution time: 0.1172
DEBUG - 2020-09-04 10:47:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:47:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:47:30 --> Total execution time: 0.1141
DEBUG - 2020-09-04 10:47:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:47:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:47:35 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 10:47:35 --> Total execution time: 0.1146
DEBUG - 2020-09-04 10:47:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:47:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:47:39 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"746","support_lang_id":"2"}
DEBUG - 2020-09-04 10:47:39 --> Total execution time: 0.1269
DEBUG - 2020-09-04 10:47:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:47:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:47:44 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 10:47:44 --> Total execution time: 0.1131
DEBUG - 2020-09-04 10:47:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 10:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 10:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 10:47:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 10:47:50 --> get_dialogue_type_1->{"slang":"38","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 10:47:50 --> Total execution time: 0.1385
DEBUG - 2020-09-04 11:01:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:01:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:01:38 --> No URI present. Default controller set.
DEBUG - 2020-09-04 11:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:01:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:01:38 --> Total execution time: 0.1228
DEBUG - 2020-09-04 11:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:01:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:01:38 --> Total execution time: 0.1572
DEBUG - 2020-09-04 11:01:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:01:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:01:38 --> Total execution time: 0.1484
DEBUG - 2020-09-04 11:01:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:01:41 --> No URI present. Default controller set.
DEBUG - 2020-09-04 11:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:01:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:01:42 --> Total execution time: 0.1499
DEBUG - 2020-09-04 11:02:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:02:31 --> No URI present. Default controller set.
DEBUG - 2020-09-04 11:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:02:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:02:31 --> Total execution time: 0.1244
DEBUG - 2020-09-04 11:02:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:02:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:02:34 --> Total execution time: 0.1106
DEBUG - 2020-09-04 11:02:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:02:35 --> No URI present. Default controller set.
DEBUG - 2020-09-04 11:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:02:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:02:35 --> Total execution time: 0.1865
DEBUG - 2020-09-04 11:02:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:02:36 --> No URI present. Default controller set.
DEBUG - 2020-09-04 11:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:02:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:02:36 --> Total execution time: 0.1636
DEBUG - 2020-09-04 11:02:37 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:02:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:02:37 --> Total execution time: 0.1578
DEBUG - 2020-09-04 11:02:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:02:39 --> No URI present. Default controller set.
DEBUG - 2020-09-04 11:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:02:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:02:39 --> Total execution time: 0.1663
DEBUG - 2020-09-04 11:03:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:03:52 --> No URI present. Default controller set.
DEBUG - 2020-09-04 11:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:03:52 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:03:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:03:52 --> Total execution time: 0.1898
DEBUG - 2020-09-04 11:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:03:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:03:52 --> Total execution time: 0.1418
DEBUG - 2020-09-04 11:04:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:04:03 --> No URI present. Default controller set.
DEBUG - 2020-09-04 11:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:04:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:04:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:04:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:04:03 --> Total execution time: 0.1136
DEBUG - 2020-09-04 11:04:03 --> Total execution time: 0.1200
DEBUG - 2020-09-04 11:04:09 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:04:09 --> No URI present. Default controller set.
DEBUG - 2020-09-04 11:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:04:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:04:10 --> Total execution time: 0.1060
DEBUG - 2020-09-04 11:04:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:04:13 --> No URI present. Default controller set.
DEBUG - 2020-09-04 11:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:04:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:04:13 --> Total execution time: 0.1534
DEBUG - 2020-09-04 11:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:04:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:04:15 --> No URI present. Default controller set.
DEBUG - 2020-09-04 11:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:04:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:04:15 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 11:04:15 --> Total execution time: 0.1316
DEBUG - 2020-09-04 11:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:04:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:04:15 --> Total execution time: 0.1551
DEBUG - 2020-09-04 11:04:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:04:27 --> No URI present. Default controller set.
DEBUG - 2020-09-04 11:04:27 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:04:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:04:27 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"746","support_lang_id":"2"}
DEBUG - 2020-09-04 11:04:27 --> Total execution time: 0.1286
DEBUG - 2020-09-04 11:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:04:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:04:27 --> Total execution time: 0.1628
DEBUG - 2020-09-04 11:04:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:04:31 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:04:31 --> No URI present. Default controller set.
DEBUG - 2020-09-04 11:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:04:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:04:31 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 11:04:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:04:31 --> Total execution time: 0.1411
DEBUG - 2020-09-04 11:04:31 --> Total execution time: 0.1406
DEBUG - 2020-09-04 11:04:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:04:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:04:34 --> No URI present. Default controller set.
DEBUG - 2020-09-04 11:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:04:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:04:34 --> get_dialogue_type_1->{"slang":"38","tlang":"2","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 11:04:34 --> Total execution time: 0.0938
DEBUG - 2020-09-04 11:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:04:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:04:34 --> Total execution time: 0.1467
DEBUG - 2020-09-04 11:04:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:04:48 --> No URI present. Default controller set.
DEBUG - 2020-09-04 11:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:04:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:04:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:04:48 --> Total execution time: 0.1476
DEBUG - 2020-09-04 11:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:04:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:04:48 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 11:04:48 --> Total execution time: 0.1100
DEBUG - 2020-09-04 11:04:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:04:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:04:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:04:50 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"746","support_lang_id":"2"}
DEBUG - 2020-09-04 11:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:04:50 --> Total execution time: 0.1396
DEBUG - 2020-09-04 11:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:04:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:04:50 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 11:04:50 --> Total execution time: 0.1410
DEBUG - 2020-09-04 11:04:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:04:50 --> No URI present. Default controller set.
DEBUG - 2020-09-04 11:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:04:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:04:50 --> Total execution time: 0.1670
DEBUG - 2020-09-04 11:04:53 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:04:53 --> No URI present. Default controller set.
DEBUG - 2020-09-04 11:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:04:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:04:53 --> Total execution time: 0.1402
DEBUG - 2020-09-04 11:04:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:04:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:04:54 --> Total execution time: 0.1418
DEBUG - 2020-09-04 11:04:54 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:04:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:04:54 --> Total execution time: 0.1387
DEBUG - 2020-09-04 11:05:58 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:05:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:05:58 --> user_register->{"first_name":"Test","last_name":"One","email":"","password":"","confirm_password":"","social_id":"112964767201531","social_type":"1","user_image":"https:\/\/graph.facebook.com\/v6.0\/112964767201531\/picture?height=500&width=500&migration_overrides={october_2012:true}&access_token=EAAIlhhBZAKoQBAJmJ0eu6mwJJqDH24itSZCELn8u0l2dnokW7z6O09qcF5G9FJ1l0JkPPyOJotyVhTrkgmbxza1fgi3omEHb3Tmnd1FZBukbBTWGv9sV8ZAJZBsoanX7L9wp59ZAkh6HejuwIZBGqvq8ZAsgRSsIZAPN34LzFk0yJ77x0MNAxy9ktsrGf37rghbqAaBeMi11E5xvYzUXE6OiUE7ZBiJywcoxptI1gdJK6AKAZDZD"}
DEBUG - 2020-09-04 11:05:58 --> Total execution time: 0.1650
DEBUG - 2020-09-04 11:06:01 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:06:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:06:01 --> Total execution time: 0.1254
DEBUG - 2020-09-04 11:06:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 11:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 11:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 11:06:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 11:06:06 --> Total execution time: 0.1489
DEBUG - 2020-09-04 12:32:05 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:32:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:32:05 --> Total execution time: 0.1308
DEBUG - 2020-09-04 12:32:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:32:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:32:29 --> Total execution time: 0.1441
DEBUG - 2020-09-04 12:32:35 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:32:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:32:35 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 12:32:35 --> Total execution time: 0.1121
DEBUG - 2020-09-04 12:32:38 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:32:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:32:38 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"0","support_lang_id":"2"}
DEBUG - 2020-09-04 12:32:38 --> Total execution time: 0.1683
DEBUG - 2020-09-04 12:32:41 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:32:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:32:41 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 12:32:41 --> Total execution time: 0.1482
DEBUG - 2020-09-04 12:32:44 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:32:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:32:45 --> get_dialogue_type_1->{"slang":"38","tlang":"38","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 12:32:45 --> Total execution time: 0.1457
DEBUG - 2020-09-04 12:34:47 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:34:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:34:47 --> Total execution time: 0.1163
DEBUG - 2020-09-04 12:34:50 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:34:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:34:50 --> Total execution time: 0.1460
DEBUG - 2020-09-04 12:34:56 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:34:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:34:56 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"1"}
ERROR - 2020-09-04 12:34:56 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-09-04 12:34:56 --> Total execution time: 0.1403
DEBUG - 2020-09-04 12:35:00 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:35:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:35:00 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"1"}
ERROR - 2020-09-04 12:35:00 --> {"status":0,"message":"Record not found","message_en":"","result":[],"status_message":"NOT FOUND"}
DEBUG - 2020-09-04 12:35:00 --> Total execution time: 0.0971
DEBUG - 2020-09-04 12:35:06 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:35:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:35:06 --> Total execution time: 0.1131
DEBUG - 2020-09-04 12:35:11 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:35:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:35:11 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 12:35:11 --> Total execution time: 0.1382
DEBUG - 2020-09-04 12:35:15 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:35:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:35:15 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"0","support_lang_id":"2"}
DEBUG - 2020-09-04 12:35:15 --> Total execution time: 0.1283
DEBUG - 2020-09-04 12:35:19 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:35:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:35:19 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 12:35:19 --> Total execution time: 0.1372
DEBUG - 2020-09-04 12:35:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:35:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:35:22 --> get_dialogue_type_1->{"slang":"38","tlang":"38","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 12:35:22 --> Total execution time: 0.1213
DEBUG - 2020-09-04 12:38:13 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:38:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:38:13 --> Total execution time: 0.1153
DEBUG - 2020-09-04 12:39:21 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:39:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:39:21 --> Total execution time: 0.1624
DEBUG - 2020-09-04 12:39:29 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:39:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:39:29 --> Total execution time: 0.1440
DEBUG - 2020-09-04 12:39:34 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:39:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:39:34 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 12:39:34 --> Total execution time: 0.1779
DEBUG - 2020-09-04 12:39:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:39:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:39:39 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"0","support_lang_id":"2"}
DEBUG - 2020-09-04 12:39:39 --> Total execution time: 0.1036
DEBUG - 2020-09-04 12:39:42 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:39:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:39:42 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 12:39:42 --> Total execution time: 0.1155
DEBUG - 2020-09-04 12:39:48 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:39:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:39:48 --> get_dialogue_type_1->{"slang":"38","tlang":"38","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 12:39:48 --> Total execution time: 0.1315
DEBUG - 2020-09-04 12:40:18 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:40:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:40:18 --> get_dialogue_type_1->{"slang":"38","tlang":"38","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 12:40:18 --> Total execution time: 0.1372
DEBUG - 2020-09-04 12:41:14 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:41:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:41:14 --> get_dialogue_type_1->{"slang":"38","tlang":"38","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 12:41:14 --> Total execution time: 0.1147
DEBUG - 2020-09-04 12:42:08 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:42:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:42:12 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:42:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:42:12 --> Total execution time: 0.1399
DEBUG - 2020-09-04 12:42:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:42:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:42:22 --> Total execution time: 0.1291
DEBUG - 2020-09-04 12:42:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:42:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:42:33 --> Total execution time: 0.1155
DEBUG - 2020-09-04 12:42:39 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:42:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:42:39 --> get_category_list->{"lang":"38","exercise_mode_id":"2","support_lang_id":"2"}
DEBUG - 2020-09-04 12:42:39 --> Total execution time: 0.1125
DEBUG - 2020-09-04 12:42:43 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:42:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:42:44 --> get_subcategory_list->{"lang":"38","category_id":"126","user_id":"0","support_lang_id":"2"}
DEBUG - 2020-09-04 12:42:44 --> Total execution time: 0.1462
DEBUG - 2020-09-04 12:42:49 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:42:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:42:50 --> get_exercise_type_list->{"lang":"38","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 12:42:50 --> Total execution time: 0.1395
DEBUG - 2020-09-04 12:42:55 --> UTF-8 Support Enabled
DEBUG - 2020-09-04 12:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-04 12:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-09-04 12:42:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 12:42:55 --> get_dialogue_type_1->{"slang":"38","tlang":"38","exercise_mode_id":"2","category_id":"126","subcategory_id":"277","support_lang_id":"2"}
DEBUG - 2020-09-04 12:42:55 --> Total execution time: 0.1101
