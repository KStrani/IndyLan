<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-08-04 12:58:08 --> UTF-8 Support Enabled
DEBUG - 2020-08-04 12:58:08 --> No URI present. Default controller set.
DEBUG - 2020-08-04 12:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-04 12:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-04 12:58:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-04 12:58:11 --> Total execution time: 3.2431
