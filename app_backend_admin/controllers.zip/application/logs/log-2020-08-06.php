<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-08-06 03:08:48 --> UTF-8 Support Enabled
DEBUG - 2020-08-06 03:08:48 --> No URI present. Default controller set.
DEBUG - 2020-08-06 03:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-06 03:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-08-06 03:08:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-06 03:08:49 --> Total execution time: 0.9283
